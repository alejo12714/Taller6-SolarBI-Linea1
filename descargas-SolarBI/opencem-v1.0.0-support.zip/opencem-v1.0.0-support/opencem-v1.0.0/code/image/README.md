# Sky-image video processing

This directory is the installable source distribution for local-video
timestamp indexing, full-minute frame extraction, and privacy review. Install
it from this directory with the ONNX runtime extra appropriate for the target
machine, as documented in `VIDEO_PIPELINE_LIBRARY.md`.

The supplied `pipeline_config.example.json` records the release configuration:
camera-local `Asia/Shanghai` timestamps, 1920 by 1920 JPEG output, and FFmpeg
JPEG quality setting 5. These explicit release settings take precedence over
the package's native-resolution library default.

Video segments are catalogued in SQLite with content hashes, overlay-derived
intervals, and presentation-order frame offsets. The extractor selects indexed
full wall-clock-minute frames and decodes them in a single ordered FFmpeg pass.
`VIDEO_CATALOG_TEMPLATES.md` documents the supplied glyph calibration and its
reproducible compatibility command.

Automated person, face, upper-body, pose, and fixed-camera change scores rank
frames for manual review; they do not make deletion decisions. Reviewed
exclusions are applied transactionally and retained as tombstones in the
processing-state database.

Component-specific recorder authentication, search, and download code is not
distributed. The calibrated glyph arrays are retained with publication-safe
metadata so that the timestamp-indexing path remains reproducible.
