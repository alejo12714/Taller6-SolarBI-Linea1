# Reusable video pipeline library

The `video_pipeline` package organizes the workflow into focused domain
modules:

| Module | Responsibility |
|---|---|
| `acquisition` | Recorder-neutral interfaces and durable frame/exclusion state |
| `frames` | SQLite-indexed full-minute JPEG extraction, archive paths, exclusions |
| `indexing` | Endpoint registration, interval renaming, full frame indexing, minimal SQLite catalogue |
| `privacy` | Apple Vision or ONNX scanning, candidate ranking, browser review, reviewed deletion |
| `hardware`, `media`, `models` | Shared FFmpeg acceleration, media commands, ONNX runtime/model selection |

The fixed-overlay recognizer and its calibrated glyph archive are bundled in
the package and exposed through `HikvisionOverlayBackend`; no root-level
implementation or template file is required after installation. A custom NPZ
can still be selected with `archive.glyph_templates` or `--templates`.
`VIDEO_CATALOG_TEMPLATES.md` documents how the bundled archive was calibrated,
and `hikvision_video_catalog_templates.py` exposes the same template-building
implementation as a standalone compatibility command.

The public workflow starts from local video files. Component-specific recorder
authentication, search, and download code is intentionally excluded. This
boundary does not affect timestamp indexing, frame extraction, or privacy
review.

## Installation

Install the package with the ONNX runtime appropriate for the machine:

```sh
python -m pip install '.[cpu]'       # CPU, Apple Silicon, Windows ARM
python -m pip install '.[cuda]'      # CUDA 12
python -m pip install '.[cuda13]'    # CUDA 13
```

Then detect the machine and print the appropriate ONNX installation:

```sh
video-models --config pipeline_config.json
```

Install the selected runtime and prepare the selected OCR model:

```sh
video-models --config pipeline_config.json \
  --install-runtime --prepare
```

RapidOCR selects and downloads its official tiny, small, or medium model.
The current policy is:

| Hardware | ONNX provider | OCR size |
|---|---|---|
| NVIDIA CUDA on Linux or Windows | CUDA | medium |
| Apple Silicon | CoreML | small |
| Windows ARM / Snapdragon | CPU for ordinary OCR | tiny |
| Other systems | CPU | small |

QNN is selected only for a model manifest that explicitly contains a
quantized `qnn-int8` QDQ variant. Ordinary floating-point OCR models are not
silently sent to the Snapdragon NPU.

Release-pinned ONNX models can use the same selection policy through a JSON
manifest. Each hardware variant in the manifest must include its URL and
SHA-256 digest:

```sh
video-models --config pipeline_config.json \
  --manifest model_manifest.json --model-name privacy-person
```

Add `--qnn-model` on Windows ARM only when the manifest contains a compatible
quantized QDQ `qnn-int8` variant. Downloads are atomic and checksum-verified.

## Configuration and overrides

Copy `pipeline_config.example.json` to `pipeline_config.json`. Every lean
entry point accepts the same media overrides:

```text
--ffmpeg --ffprobe --accelerator --devices --decoder-threads --workers
```

Command-line values override JSON configuration. `--accelerator auto` probes
the local FFmpeg build and selects, in order:

1. CUDA when FFmpeg and the NVIDIA runtime are available.
2. VideoToolbox on Apple Silicon.
3. D3D11VA on Windows ARM.
4. CPU fallback.

CUDA device indices can be supplied as `--devices 0,1,2,3`. Decoder thread
counts apply per FFmpeg process.

## Entry points

For a compact end-to-end example covering local-video indexing, minute-frame
extraction, and privacy review, see:

```sh
VIDEO_DIR=/path/to/local/videos \
bash video_pipeline/example_full_pipeline.sh
```

Set `PRIVACY_MODEL=/path/to/person.onnx` on non-Apple systems. The example
creates a local review page and applies exclusions automatically on a later
run when `human_review_results.csv` is present.

Index local video files and extract full-minute JPEGs:

```sh
video-index /path/to/local/videos --config pipeline_config.json
frame-acquire --config pipeline_config.json \
  --video-dir /path/to/local/videos
```

The extractor reads exact presentation-frame offsets for full clock minutes
from `video_catalog.sqlite3`. If a local file does not yet have frame rows, the
same fixed-overlay full indexer used by `video-index` indexes it once and
commits the rows before JPEG extraction. FFmpeg then selects those integer
frame offsets in one ordered decode. There is no separate clock-calibration or
timestamp-seeking path. The supplied release configuration writes 1920 by 1920
JPEGs at FFmpeg quality setting 5.

Rename and fully index videos:

```sh
video-index /srv/video/incoming \
  --config pipeline_config.json --min-age 120 \
  --diagnostic-log /srv/video/catalog-diagnostics.log
```

Only full presentation-order indexing is exposed. New videos are renamed and
registered from endpoint OCR before any whole-file decode starts. Incomplete
rows are retried through the indexed `video`/`frame` anti-join; completed rows
are not reindexed.
Before renaming, an indexed interval-overlap lookup narrows duplicate checks.
An incoming file is removed only when an overlapping catalogued file exists
and its complete SHA-256 digest is identical; non-identical overlaps are kept.
The diagnostic log is append-only JSON Lines and includes failed filenames,
media assumptions, hardware choices, and the final run summary.

Every catalogue open idempotently creates complementary interval indexes on
`(start,end)` and `(end,start)`, including when an older minimal SQLite
catalogue is opened. This lets SQLite choose the selective side of an overlap
query. To replace an older, suspicious frame index with the current glyph
recognizer, choose a one-run jump threshold:

```sh
video-index /srv/video/archive \
  --config pipeline_config.json --reindex-jump-threshold 300
```

Frame rows are examined in presentation order. Any backwards timestamp or
forward jump larger than the supplied number of seconds makes that video's
frame rows pending again; the same invocation then performs a full reindex.
Because a genuine camera-clock change can also exceed the threshold, this is
an opt-in remediation option rather than a persistent default.

Merge two or more indexed folders into a new or empty output folder:

```sh
video-merge \
  /mnt/machine-a/videos \
  /mnt/machine-b/videos \
  /srv/video/combined
```

The final positional path is always the output. If it is absent or empty, at
least two distinct input folders are required. To add one or more archives to
an existing output catalogue:

```sh
video-merge \
  /mnt/machine-c/videos \
  /srv/video/combined
```

A non-empty output must already contain a valid, complete
`video_catalog.sqlite3` and its catalogued media. The output may also appear
among the input paths; it is ignored as a source, so this does not change the
result. Use `--database-name` when every folder uses another catalogue
filename.

Input folders are opened read-only and are not modified. Copies are published
atomically after size and SHA-256 verification, video IDs are remapped, and
frame rows are transferred in the same SQLite transaction. Overlapping
identical videos are not copied, while non-identical overlaps receive
collision-safe names. Uncatalogued source MP4s and invalid, missing, or
incomplete catalogue entries are reported as errors.

Run privacy review:

```sh
frame-privacy scan --config pipeline_config.json
frame-privacy rank --config pipeline_config.json \
  --raw output/human_review_scan/raw_scores.csv \
  --prepare-indices output/human_review_scan/second_pass_indices.txt
frame-privacy scan --config pipeline_config.json \
  --indices-file output/human_review_scan/second_pass_indices.txt \
  --perimeter-tiles --skip-change \
  --output output/human_review_scan/tiled_scores.csv
frame-privacy rank --config pipeline_config.json \
  --raw output/human_review_scan/raw_scores.csv \
  --tiled output/human_review_scan/tiled_scores.csv \
  --output-dir output/human_review_scan/review
frame-privacy apply --config pipeline_config.json \
  --review output/human_review_scan/review/human_review_results.csv \
  --scores output/human_review_scan/raw_scores.csv
```

Apple Silicon uses the full Swift scanner bundled in the package, including
the mask, temporal-change, selected-rescan, and perimeter-tile passes. Pass
`--swift-source` only to override it deliberately. Other systems accept a
COCO-person YOLO-style ONNX model through `scan --model MODEL.onnx`; a
QNN-quantized Snapdragon model must additionally be marked with `--qnn-model`.

## Tests

The package tests use temporary files and fake media/index backends; they do
not depend on the supplied MP4 recordings:

```sh
python -m unittest discover -s video_pipeline/tests -v
```
