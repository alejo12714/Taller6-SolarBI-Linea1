# Fixed-overlay timestamp indexing

The package reads the visible date and time overlay in each local camera video
to build a presentation-order frame index. RapidOCR anchors segment endpoints
and resolves ambiguous transitions. Between those anchors, calibrated binary
glyph templates identify second boundaries at deterministic pixel locations.

The bundled `hikvision_glyph_templates.npz` contains the calibrated numerical
arrays used for the OpenCEM recordings. It was built from three representative
recordings by sampling 60 seconds from each at one frame per second and applying
a minimum OCR confidence of 0.85. All 180 sampled frames were accepted. The
calibration retained 744 discriminative binary probes, estimated a
white-pixel probability for each digit and probe, and fitted an alignment
offset for every timestamp cell. Its publication metadata records only the
number of representative source videos; local paths and recorder filenames
have been removed. A different camera, resolution, overlay position, or font
requires new templates.

## Build custom templates

Install the package and select an ONNX runtime as described in
`VIDEO_PIPELINE_LIBRARY.md`. Then use representative local recordings:

```sh
python hikvision_video_catalog_templates.py build-templates \
  custom_glyph_templates.npz \
  sample_camera_video_1.mp4 \
  sample_camera_video_2.mp4 \
  sample_camera_video_3.mp4 \
  --sample-seconds 60 --sample-fps 1 --minimum-confidence 0.85
```

`hikvision_video_catalog_templates.py` is a compatibility entry point for the
packaged implementation in `video_pipeline.hikvision_overlay`; the two commands
therefore execute the same calibration code.

Select the result with `archive.glyph_templates` in the JSON configuration or
with `--templates` on `video-index` and `frame-acquire`.

## Index local videos

```sh
video-index /path/to/local/videos \
  --config pipeline_config.json \
  --timezone Asia/Shanghai \
  --workers 1 \
  --diagnostic-log video-catalog-diagnostics.log
```

The indexer first reads the exact first and final displayed timestamps, renames
the file to its observed interval, and commits a minimal `video` row. It then
decodes the complete presentation-order sequence and records verified
first-frame offsets for displayed seconds. Interrupted or failed indexing
therefore remains visible and can be resumed without repeating completed
videos.

Only byte-identical overlapping files are removed as duplicates. Content
fingerprints, observed intervals, and frame offsets are stored in
`video_catalog.sqlite3`. Recoverable clock discontinuities and OCR fallbacks
are written to the optional JSON-lines diagnostic log.
