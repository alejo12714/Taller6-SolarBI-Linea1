"""Recording-source interfaces and durable video acquisition."""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
import datetime as dt
import hashlib
import logging
from pathlib import Path
import shutil
import sqlite3
from typing import Any, Iterable, Protocol

from .errors import AcquisitionError, ConfigurationError


UTC = dt.timezone.utc
LOG = logging.getLogger(__name__)


def format_time(value: dt.datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_time(value: str) -> dt.datetime:
    normalized = value.strip().replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ConfigurationError(f"Invalid ISO-8601 timestamp: {value!r}") from exc
    if parsed.tzinfo is None:
        raise ConfigurationError(f"Timestamp has no timezone: {value!r}")
    return parsed.astimezone(UTC)


@dataclass(frozen=True)
class RecordingSegment:
    id: str
    name: str
    track_id: int
    start: dt.datetime
    end: dt.datetime
    playback_uri: str
    expected_size: int

    @classmethod
    def create(
        cls,
        *,
        name: str,
        track_id: int,
        start: dt.datetime,
        end: dt.datetime,
        playback_uri: str,
        expected_size: int,
        identity: str | None = None,
    ) -> "RecordingSegment":
        value = identity or f"{track_id}|{format_time(start)}|{format_time(end)}|{name}"
        return cls(
            hashlib.sha256(value.encode("utf-8")).hexdigest(),
            name,
            track_id,
            start.astimezone(UTC),
            end.astimezone(UTC),
            playback_uri,
            expected_size,
        )

    def download_name(self, extension: str = ".mp4") -> str:
        suffix = Path(self.name).suffix or extension
        stem = Path(self.name).stem
        return f"{stem}__{self.id[:12]}{suffix}"


class RecordingSource(Protocol):
    def search(
        self,
        start: dt.datetime,
        end: dt.datetime,
        track_id: int,
        page_size: int,
    ) -> Iterable[RecordingSegment]: ...

    def download(
        self,
        segment: RecordingSegment,
        destination: Path,
        size_tolerance: int,
    ) -> None: ...


class AcquisitionStore:
    """SQLite state for searches, downloads, frames, and exclusions."""

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.root = path.parent.resolve()
        self.connection = sqlite3.connect(path, timeout=30)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS segments (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                track_id INTEGER NOT NULL,
                start_utc TEXT NOT NULL,
                end_utc TEXT NOT NULL,
                playback_uri TEXT NOT NULL,
                expected_size INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                local_path TEXT,
                attempts INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_segments_work
                ON segments(status, start_utc);
            CREATE TABLE IF NOT EXISTS frames (
                timestamp_utc TEXT PRIMARY KEY,
                segment_id TEXT NOT NULL,
                path TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS excluded_frames (
                timestamp_utc TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                reason TEXT NOT NULL,
                excluded_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "AcquisitionStore":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def stored_path(self, path: Path | None) -> str | None:
        if path is None:
            return None
        try:
            return path.resolve().relative_to(self.root).as_posix()
        except ValueError:
            return str(path.resolve())

    def resolve_path(self, value: str) -> Path:
        normalized = value.replace("\\", "/")
        for marker in ("/frames/", "/videos/"):
            if marker in normalized:
                return self.root / marker.strip("/") / normalized.split(marker, 1)[1]
        path = Path(value)
        return path if path.is_absolute() else self.root / path

    def setting(self, key: str) -> str | None:
        row = self.connection.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
        return str(row["value"]) if row else None

    def set_setting(self, key: str, value: str) -> None:
        with self.connection:
            self.connection.execute(
                """
                INSERT INTO settings(key,value) VALUES(?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value
                """,
                (key, value),
            )

    def upsert(self, segment: RecordingSegment) -> None:
        now = format_time(dt.datetime.now(UTC))
        self.connection.execute(
            """
            INSERT INTO segments(
                id,name,track_id,start_utc,end_utc,playback_uri,
                expected_size,status,updated_at
            ) VALUES(?,?,?,?,?,?,?,'pending',?)
            ON CONFLICT(id) DO UPDATE SET
                playback_uri=excluded.playback_uri,
                expected_size=excluded.expected_size,
                updated_at=excluded.updated_at
            """,
            (
                segment.id,
                segment.name,
                segment.track_id,
                format_time(segment.start),
                format_time(segment.end),
                segment.playback_uri,
                segment.expected_size,
                now,
            ),
        )

    def pending(self, limit: int = 0) -> list[sqlite3.Row]:
        sql = "SELECT * FROM segments WHERE status!='complete' ORDER BY start_utc,id"
        parameters: tuple[Any, ...] = ()
        if limit:
            sql += " LIMIT ?"
            parameters = (limit,)
        return list(self.connection.execute(sql, parameters))

    def mark_downloaded(self, segment_id: str, path: Path) -> None:
        self._mark(segment_id, "downloaded", path, None)

    def mark_complete(self, segment_id: str, path: Path | None) -> None:
        self._mark(segment_id, "complete", path, None)

    def mark_failed(self, segment_id: str, error: str) -> None:
        with self.connection:
            self.connection.execute(
                """
                UPDATE segments
                SET attempts=attempts+1,last_error=?,updated_at=?
                WHERE id=?
                """,
                (error[-4000:], format_time(dt.datetime.now(UTC)), segment_id),
            )

    def _mark(
        self,
        segment_id: str,
        status: str,
        path: Path | None,
        error: str | None,
    ) -> None:
        with self.connection:
            self.connection.execute(
                """
                UPDATE segments
                SET status=?,local_path=?,last_error=?,updated_at=?
                WHERE id=?
                """,
                (
                    status,
                    self.stored_path(path),
                    error,
                    format_time(dt.datetime.now(UTC)),
                    segment_id,
                ),
            )

    def cached_complete(self) -> list[sqlite3.Row]:
        return list(
            self.connection.execute(
                """
                SELECT id,local_path,expected_size
                FROM segments
                WHERE status='complete' AND local_path IS NOT NULL
                ORDER BY start_utc
                """
            )
        )

    def clear_local_path(self, segment_id: str) -> None:
        with self.connection:
            self.connection.execute(
                "UPDATE segments SET local_path=NULL WHERE id=?", (segment_id,)
            )


@dataclass(frozen=True)
class SearchPolicy:
    track_id: int
    start: dt.datetime
    end: dt.datetime | None = None
    end_lag_seconds: float = 120
    overlap_seconds: float = 300
    page_size: int = 50


@dataclass(frozen=True)
class StoragePolicy:
    min_free_bytes: int = 5 * 1024**3
    max_video_cache_bytes: int = 0
    size_tolerance_bytes: int = 65536


def search_window(
    policy: SearchPolicy,
    store: AcquisitionStore,
    now: dt.datetime | None = None,
) -> tuple[dt.datetime, dt.datetime]:
    cursor = store.setting("last_successful_search_end")
    start = policy.start.astimezone(UTC)
    if cursor:
        start = max(
            start,
            parse_time(cursor) - dt.timedelta(seconds=policy.overlap_seconds),
        )
    end = policy.end or (
        (now or dt.datetime.now(UTC))
        - dt.timedelta(seconds=policy.end_lag_seconds)
    )
    if end <= start:
        raise ConfigurationError(
            f"Search end {format_time(end)} is not after start {format_time(start)}"
        )
    return start, end


def synchronize(
    source: RecordingSource,
    store: AcquisitionStore,
    policy: SearchPolicy,
    now: dt.datetime | None = None,
) -> int:
    start, end = search_window(policy, store, now)
    count = 0
    for segment in source.search(
        start, end, policy.track_id, policy.page_size
    ):
        store.upsert(segment)
        count += 1
        if count % 50 == 0:
            store.connection.commit()
    store.connection.commit()
    store.set_setting("last_successful_search_end", format_time(end))
    return count


def ensure_space(
    store: AcquisitionStore,
    video_dir: Path,
    bytes_needed: int,
    policy: StoragePolicy,
) -> None:
    video_dir.mkdir(parents=True, exist_ok=True)

    def state() -> tuple[bool, int, int]:
        free = shutil.disk_usage(video_dir).free
        cached = sum(
            store.resolve_path(str(row["local_path"])).stat().st_size
            for row in store.cached_complete()
            if store.resolve_path(str(row["local_path"])).is_file()
        )
        constrained = (
            free < policy.min_free_bytes + bytes_needed
            or (
                policy.max_video_cache_bytes > 0
                and cached + bytes_needed > policy.max_video_cache_bytes
            )
        )
        return constrained, free, cached

    constrained, free, cached = state()
    for row in store.cached_complete():
        if not constrained:
            break
        path = store.resolve_path(str(row["local_path"]))
        path.unlink(missing_ok=True)
        store.clear_local_path(str(row["id"]))
        constrained, free, cached = state()
    if constrained:
        raise AcquisitionError(
            f"Insufficient safe storage: free={free}, download={bytes_needed}, "
            f"minimum_free={policy.min_free_bytes}, cache={cached}"
        )


def row_segment(row: sqlite3.Row) -> RecordingSegment:
    return RecordingSegment(
        id=str(row["id"]),
        name=str(row["name"]),
        track_id=int(row["track_id"]),
        start=parse_time(str(row["start_utc"])),
        end=parse_time(str(row["end_utc"])),
        playback_uri=str(row["playback_uri"]),
        expected_size=int(row["expected_size"]),
    )


def acquire_pending(
    source: RecordingSource,
    store: AcquisitionStore,
    video_dir: Path,
    storage: StoragePolicy,
    *,
    limit: int = 0,
    prefetch: bool = True,
) -> list[Path]:
    rows = store.pending(limit)
    completed: list[Path] = []
    futures: dict[str, Future[None]] = {}

    def destination(segment: RecordingSegment) -> Path:
        return video_dir / segment.download_name()

    def schedule(
        executor: ThreadPoolExecutor,
        segment: RecordingSegment,
        *,
        opportunistic: bool,
    ) -> Future[None] | None:
        path = destination(segment)
        if path.is_file() or segment.id in futures:
            return futures.get(segment.id)
        partial = path.with_suffix(path.suffix + ".part")
        needed = max(
            0,
            segment.expected_size
            - (partial.stat().st_size if partial.is_file() else 0),
        )
        try:
            ensure_space(store, video_dir, needed, storage)
        except AcquisitionError:
            if opportunistic:
                return None
            raise
        future = executor.submit(
            source.download,
            segment,
            path,
            storage.size_tolerance_bytes,
        )
        futures[segment.id] = future
        return future

    with ThreadPoolExecutor(max_workers=1, thread_name_prefix="download") as executor:
        for index, row in enumerate(rows):
            segment = row_segment(row)
            path = destination(segment)
            try:
                future = futures.pop(segment.id, None)
                if future is None and not path.is_file():
                    future = schedule(executor, segment, opportunistic=False)
                    futures.pop(segment.id, None)
                if future is not None:
                    future.result()
                actual = path.stat().st_size
                if abs(actual - segment.expected_size) > storage.size_tolerance_bytes:
                    raise AcquisitionError(
                        f"{path} has {actual} bytes; expected "
                        f"{segment.expected_size} +/- {storage.size_tolerance_bytes}"
                    )
                store.mark_downloaded(segment.id, path)
                completed.append(path)
                if prefetch and index + 1 < len(rows):
                    schedule(
                        executor,
                        row_segment(rows[index + 1]),
                        opportunistic=True,
                    )
            except Exception as exc:
                store.mark_failed(segment.id, str(exc))
                if isinstance(exc, AcquisitionError):
                    raise
                raise AcquisitionError(
                    f"Could not acquire {segment.name}: {exc}"
                ) from exc
    return completed
