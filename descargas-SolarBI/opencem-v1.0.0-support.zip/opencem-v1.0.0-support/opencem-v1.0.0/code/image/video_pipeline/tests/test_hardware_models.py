import unittest

from video_pipeline.hardware import (
    Accelerator,
    HardwareProfile,
    cuda_version_from_text,
    select_accelerator,
)
from video_pipeline.models import runtime_plan, select_artifact


class HardwareModelTests(unittest.TestCase):
    def test_auto_accelerators_cover_supported_platforms(self):
        self.assertEqual(
            Accelerator.CUDA,
            select_accelerator(
                "auto",
                system="Linux",
                machine="x86_64",
                available={"cuda"},
                nvidia_runtime=True,
            ),
        )
        self.assertEqual(
            Accelerator.VIDEOTOOLBOX,
            select_accelerator(
                "auto",
                system="Darwin",
                machine="arm64",
                available={"videotoolbox"},
                nvidia_runtime=False,
            ),
        )
        self.assertEqual(
            Accelerator.D3D11VA,
            select_accelerator(
                "auto",
                system="Windows",
                machine="ARM64",
                available={"d3d11va"},
                nvidia_runtime=False,
            ),
        )

    def test_decoder_arguments_and_filters_are_platform_safe(self):
        cuda = HardwareProfile(
            "Linux",
            "x86_64",
            Accelerator.CUDA,
            (2, 4),
            frozenset({"cuda"}),
        )
        self.assertIn("4", cuda.decoder_input_args(1))
        self.assertEqual(["hwdownload", "format=nv12"], cuda.software_filter_prefix())
        apple = HardwareProfile(
            "Darwin",
            "arm64",
            Accelerator.VIDEOTOOLBOX,
            (),
            frozenset({"videotoolbox"}),
        )
        self.assertEqual(
            ["-hwaccel", "videotoolbox"], apple.decoder_input_args()
        )
        self.assertEqual([], apple.software_filter_prefix())

    def test_runtime_and_model_variant_follow_hardware(self):
        apple = HardwareProfile(
            "Darwin", "arm64", Accelerator.VIDEOTOOLBOX
        )
        plan = runtime_plan(apple)
        self.assertEqual("CoreMLExecutionProvider", plan.provider)
        self.assertEqual("small", plan.rapidocr_size)
        snapdragon = HardwareProfile(
            "Windows", "arm64", Accelerator.D3D11VA
        )
        qnn = runtime_plan(snapdragon, qnn_quantized_model=True)
        self.assertEqual("onnxruntime-qnn", qnn.pip_package)
        manifest = {
            "models": {
                "person": {
                    "variants": {
                        "qnn-int8": {
                            "url": "https://example.invalid/person.onnx",
                            "sha256": "a" * 64,
                        }
                    }
                }
            }
        }
        self.assertEqual(
            "qnn-int8",
            select_artifact(manifest, "person", qnn).variant,
        )

    def test_cuda_runtime_series_follows_driver_capability(self):
        self.assertEqual(
            12,
            cuda_version_from_text(
                "NVIDIA-SMI 570.00  CUDA Version: 12.8"
            ),
        )
        cuda12 = HardwareProfile(
            "Linux",
            "x86_64",
            Accelerator.CUDA,
            cuda_major=12,
        )
        cuda13 = HardwareProfile(
            "Linux",
            "x86_64",
            Accelerator.CUDA,
            cuda_major=13,
        )
        self.assertIn("<1.27", runtime_plan(cuda12).pip_package)
        self.assertIn(">=1.27", runtime_plan(cuda13).pip_package)
        self.assertIn("[cuda,cudnn]", runtime_plan(cuda12).pip_package)


if __name__ == "__main__":
    unittest.main()
