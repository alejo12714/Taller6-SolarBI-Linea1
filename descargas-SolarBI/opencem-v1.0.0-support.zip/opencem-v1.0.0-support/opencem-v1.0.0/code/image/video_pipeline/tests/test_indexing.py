import datetime as dt
from pathlib import Path
import sqlite3
import tempfile
import unittest
import zipfile

from video_pipeline.glyphs import bundled_glyph_templates
from video_pipeline.indexing import (
    CatalogRepository,
    CatalogService,
    EndpointInspection,
    FingerprintCache,
    FrameIndex,
    IndexedFrame,
)


UTC = dt.timezone.utc


class FakeBackend:
    def __init__(self, root: Path):
        self.root = root
        self.inspected = 0
        self.indexed = 0

    def _start(self, path: Path) -> dt.datetime:
        minute = (
            0
            if path.name.startswith("a") or "T000000" in path.name
            else 1
        )
        return dt.datetime(2026, 1, 1, 0, minute, tzinfo=UTC)

    def inspect_endpoints(self, path: Path, fingerprint: str, worker: int = 0):
        self.inspected += 1
        start = self._start(path)
        stat = path.stat()
        return EndpointInspection(
            path,
            fingerprint,
            stat.st_size,
            stat.st_mtime_ns,
            start,
            start + dt.timedelta(seconds=2),
            2.0,
        )

    def index(self, path: Path, worker: int = 0):
        self.indexed += 1
        self.test_case.assertFalse((self.root / "a.mp4").exists())
        self.test_case.assertFalse((self.root / "b.mp4").exists())
        start = self._start(path)
        return FrameIndex(
            path,
            start,
            start + dt.timedelta(seconds=2),
            (IndexedFrame(round(start.timestamp()) + 1, 20),),
        )


class IndexingTests(unittest.TestCase):
    def test_bundled_glyph_archive_contains_recognizer_inputs(self):
        with zipfile.ZipFile(bundled_glyph_templates()) as archive:
            self.assertTrue(
                {
                    "white_probability.npy",
                    "probe_indices.npy",
                    "cell_offsets.npy",
                    "metadata.npy",
                }.issubset(archive.namelist())
            )

    def test_catalog_finds_video_by_pre_rename_name(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "rotating-name.mp4"
            source.write_bytes(b"video")
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            with CatalogRepository(root / "catalog.sqlite3") as repository:
                video_id = repository.register(
                    EndpointInspection(
                        source=source,
                        fingerprint="digest",
                        size=5,
                        mtime_ns=0,
                        start=start,
                        end=start + dt.timedelta(seconds=1),
                        duration=1,
                    ),
                    root / "20260101T000000Z--20260101T000001Z.mp4",
                )
                video = repository.video_by_old_name(source.name)

            self.assertIsNotNone(video)
            assert video is not None
            self.assertEqual(video_id, video.id)
            self.assertEqual(
                "20260101T000000Z--20260101T000001Z.mp4",
                video.new_name,
            )

    def test_opening_existing_minimal_database_adds_interval_index(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "catalog.sqlite3"
            connection = sqlite3.connect(path)
            connection.executescript(
                """
                CREATE TABLE video(
                    id INTEGER PRIMARY KEY,
                    old_name TEXT NOT NULL,
                    new_name TEXT NOT NULL,
                    start REAL NOT NULL,
                    end REAL NOT NULL
                );
                CREATE TABLE frame(
                    video INTEGER NOT NULL,
                    second INTEGER NOT NULL,
                    frame_offset INTEGER NOT NULL,
                    PRIMARY KEY(video,second)
                );
                """
            )
            connection.close()
            with CatalogRepository(path) as repository:
                indexes = {
                    row[1]
                    for row in repository.connection.execute(
                        "PRAGMA index_list(video)"
                    )
                }
                self.assertTrue(
                    {"video_interval", "video_interval_end"} <= indexes
                )

    def test_two_phase_scan_renames_before_index_and_does_not_reindex(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "a.mp4").write_bytes(b"a")
            (root / "b.mp4").write_bytes(b"b")
            repository = CatalogRepository(root / "catalog.sqlite3")
            cache = FingerprintCache(root / "hash.sqlite3")
            backend = FakeBackend(root)
            backend.test_case = self
            try:
                service = CatalogService(
                    repository, backend, cache, workers=2, timezone="UTC"
                )
                first = service.scan(root, min_age=0)
                self.assertEqual((2, 2), (first.registered, first.indexed))
                self.assertEqual([], repository.pending())
                second = service.scan(root, min_age=0)
                self.assertEqual((0, 0), (second.registered, second.indexed))
                self.assertEqual(2, backend.inspected)
                self.assertEqual(2, backend.indexed)
            finally:
                cache.close()
                repository.close()

    def test_synthetic_frame_zero_does_not_complete_video(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            repository = CatalogRepository(root / "catalog.sqlite3")
            try:
                start = dt.datetime(2026, 1, 1, tzinfo=UTC)
                inspection = EndpointInspection(
                    root / "video.mp4",
                    "a" * 64,
                    1,
                    1,
                    start,
                    start + dt.timedelta(seconds=2),
                    2.0,
                )
                video_id = repository.register(
                    inspection, inspection.source
                )
                with repository.connection:
                    repository.connection.execute(
                        "INSERT INTO frame(video,second,frame_offset) VALUES(?,?,0)",
                        (video_id, round(start.timestamp())),
                    )
                self.assertEqual([video_id], [row.id for row in repository.pending()])
                repository.record_frames(
                    video_id,
                    (IndexedFrame(round(start.timestamp()) + 1, 20),),
                )
                self.assertEqual([], repository.pending())
            finally:
                repository.close()

    def test_identical_overlapping_file_is_removed(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            canonical = (
                root / "20260101T000000Z--20260101T000002Z.mp4"
            )
            incoming = root / "a-copy.mp4"
            canonical.write_bytes(b"same recording")
            incoming.write_bytes(b"same recording")
            repository = CatalogRepository(root / "catalog.sqlite3")
            cache = FingerprintCache(root / "hash.sqlite3")
            backend = FakeBackend(root)
            backend.test_case = self
            try:
                stat = canonical.stat()
                video_id = repository.register(
                    EndpointInspection(
                        canonical,
                        cache.digest(canonical),
                        stat.st_size,
                        stat.st_mtime_ns,
                        start,
                        start + dt.timedelta(seconds=2),
                        2.0,
                    ),
                    canonical,
                )
                repository.record_frames(
                    video_id,
                    (IndexedFrame(round(start.timestamp()) + 1, 20),),
                )
                report = CatalogService(
                    repository, backend, cache, timezone="UTC"
                ).scan(root, min_age=0)
                self.assertEqual(1, report.duplicates_removed)
                self.assertEqual(0, report.registered)
                self.assertFalse(incoming.exists())
                self.assertTrue(canonical.exists())
                count = repository.connection.execute(
                    "SELECT COUNT(*) FROM video"
                ).fetchone()[0]
                self.assertEqual(1, count)
            finally:
                cache.close()
                repository.close()

    def test_nonidentical_overlapping_file_is_retained(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            canonical = (
                root / "20260101T000000Z--20260101T000002Z.mp4"
            )
            incoming = root / "a-copy.mp4"
            canonical.write_bytes(b"recording one")
            incoming.write_bytes(b"recording two")
            repository = CatalogRepository(root / "catalog.sqlite3")
            cache = FingerprintCache(root / "hash.sqlite3")
            backend = FakeBackend(root)
            backend.test_case = self
            try:
                stat = canonical.stat()
                video_id = repository.register(
                    EndpointInspection(
                        canonical,
                        cache.digest(canonical),
                        stat.st_size,
                        stat.st_mtime_ns,
                        start,
                        start + dt.timedelta(seconds=2),
                        2.0,
                    ),
                    canonical,
                )
                repository.record_frames(
                    video_id,
                    (IndexedFrame(round(start.timestamp()) + 1, 20),),
                )
                report = CatalogService(
                    repository, backend, cache, timezone="UTC"
                ).scan(root, min_age=0)
                self.assertEqual(0, report.duplicates_removed)
                self.assertEqual(1, report.registered)
                self.assertEqual(1, report.indexed)
                self.assertFalse(incoming.exists())
                files = list(root.glob("*.mp4"))
                self.assertEqual(2, len(files))
                self.assertEqual(
                    {b"recording one", b"recording two"},
                    {path.read_bytes() for path in files},
                )
            finally:
                cache.close()
                repository.close()

    def test_implausible_jump_option_reindexes_selected_video(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            video = root / "20260101T000000Z--20260101T000002Z.mp4"
            video.write_bytes(b"recording")
            repository = CatalogRepository(root / "catalog.sqlite3")
            cache = FingerprintCache(root / "hash.sqlite3")
            backend = FakeBackend(root)
            backend.test_case = self
            try:
                stat = video.stat()
                video_id = repository.register(
                    EndpointInspection(
                        video,
                        cache.digest(video),
                        stat.st_size,
                        stat.st_mtime_ns,
                        start,
                        start + dt.timedelta(seconds=2),
                        2.0,
                    ),
                    video,
                )
                repository.record_frames(
                    video_id,
                    (
                        IndexedFrame(round(start.timestamp()), 1),
                        IndexedFrame(round(start.timestamp()) + 1000, 20),
                    ),
                )
                report = CatalogService(
                    repository, backend, cache, timezone="UTC"
                ).scan(
                    root,
                    min_age=0,
                    reindex_jump_threshold=300,
                )
                self.assertEqual(1, report.anomaly_reindexes)
                self.assertEqual(1, report.indexed)
                self.assertEqual(1, backend.indexed)
                self.assertEqual(
                    (IndexedFrame(round(start.timestamp()) + 1, 20),),
                    repository.frames_for(video_id),
                )
            finally:
                cache.close()
                repository.close()


if __name__ == "__main__":
    unittest.main()
