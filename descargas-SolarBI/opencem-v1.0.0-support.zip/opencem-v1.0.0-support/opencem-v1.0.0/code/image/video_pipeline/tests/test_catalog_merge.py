import datetime as dt
from pathlib import Path
import tempfile
import unittest

from video_pipeline.catalogs import CatalogMerger, merge_catalog_folders
from video_pipeline.errors import ConfigurationError
from video_pipeline.indexing import (
    CatalogRepository,
    EndpointInspection,
    FingerprintCache,
    IndexedFrame,
)


UTC = dt.timezone.utc


def add_video(
    repository: CatalogRepository,
    cache: FingerprintCache,
    path: Path,
    content: bytes,
    start: dt.datetime,
    *,
    indexed: bool = True,
) -> int:
    path.write_bytes(content)
    stat = path.stat()
    video_id = repository.register(
        EndpointInspection(
            path,
            cache.digest(path),
            stat.st_size,
            stat.st_mtime_ns,
            start,
            start + dt.timedelta(seconds=2),
            2.0,
        ),
        path,
    )
    if indexed:
        repository.record_frames(
            video_id,
            (IndexedFrame(round(start.timestamp()) + 1, 20),),
        )
    return video_id


class CatalogMergeTests(unittest.TestCase):
    def make_catalog(
        self,
        folder: Path,
        cache_path: Path,
        name: str,
        content: bytes,
        start: dt.datetime,
    ) -> None:
        folder.mkdir()
        with (
            CatalogRepository(folder / "video_catalog.sqlite3") as repository,
            FingerprintCache(cache_path) as cache,
        ):
            add_video(
                repository,
                cache,
                folder / name,
                content,
                start,
            )

    def test_merge_copies_video_and_remaps_frames(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            destination = root / "destination"
            source.mkdir()
            destination.mkdir()
            with (
                CatalogRepository(source / "video_catalog.sqlite3") as source_db,
                CatalogRepository(destination / "video_catalog.sqlite3") as destination_db,
                FingerprintCache(root / "source-hash.sqlite3") as source_cache,
                FingerprintCache(root / "destination-hash.sqlite3") as destination_cache,
            ):
                start = dt.datetime(2026, 1, 1, tzinfo=UTC)
                name = "20260101T000000Z--20260101T000002Z.mp4"
                add_video(
                    source_db,
                    source_cache,
                    source / name,
                    b"source video",
                    start,
                )
                report = CatalogMerger(
                    source_db,
                    destination_db,
                    source_cache,
                    destination_cache,
                ).merge(source, destination)
                self.assertEqual((1, 0), (report.imported, report.duplicates))
                imported = destination_db.all_videos()
                self.assertEqual(1, len(imported))
                self.assertEqual(
                    b"source video",
                    (destination / imported[0].new_name).read_bytes(),
                )
                self.assertEqual(
                    (IndexedFrame(round(start.timestamp()) + 1, 20),),
                    destination_db.frames_for(imported[0].id),
                )

    def test_merge_skips_identical_overlap_and_repairs_missing_index(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            destination = root / "destination"
            source.mkdir()
            destination.mkdir()
            with (
                CatalogRepository(source / "video_catalog.sqlite3") as source_db,
                CatalogRepository(destination / "video_catalog.sqlite3") as destination_db,
                FingerprintCache(root / "source-hash.sqlite3") as source_cache,
                FingerprintCache(root / "destination-hash.sqlite3") as destination_cache,
            ):
                start = dt.datetime(2026, 1, 1, tzinfo=UTC)
                source_name = "source-copy.mp4"
                destination_name = (
                    "20260101T000000Z--20260101T000002Z.mp4"
                )
                add_video(
                    source_db,
                    source_cache,
                    source / source_name,
                    b"identical",
                    start,
                )
                destination_id = add_video(
                    destination_db,
                    destination_cache,
                    destination / destination_name,
                    b"identical",
                    start,
                    indexed=False,
                )
                report = CatalogMerger(
                    source_db,
                    destination_db,
                    source_cache,
                    destination_cache,
                ).merge(source, destination)
                self.assertEqual(0, report.imported)
                self.assertEqual(1, report.duplicates)
                self.assertEqual(1, report.repaired_indexes)
                self.assertTrue(
                    destination_db.has_verified_frames(destination_id)
                )
                self.assertEqual(1, len(list(destination.glob("*.mp4"))))

    def test_merge_keeps_nonidentical_overlap_with_safe_name(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            destination = root / "destination"
            source.mkdir()
            destination.mkdir()
            with (
                CatalogRepository(source / "video_catalog.sqlite3") as source_db,
                CatalogRepository(destination / "video_catalog.sqlite3") as destination_db,
                FingerprintCache(root / "source-hash.sqlite3") as source_cache,
                FingerprintCache(root / "destination-hash.sqlite3") as destination_cache,
            ):
                start = dt.datetime(2026, 1, 1, tzinfo=UTC)
                name = "20260101T000000Z--20260101T000002Z.mp4"
                add_video(
                    source_db,
                    source_cache,
                    source / name,
                    b"source version",
                    start,
                )
                add_video(
                    destination_db,
                    destination_cache,
                    destination / name,
                    b"destination version",
                    start,
                )
                report = CatalogMerger(
                    source_db,
                    destination_db,
                    source_cache,
                    destination_cache,
                ).merge(source, destination)
                self.assertEqual((1, 0), (report.imported, report.duplicates))
                self.assertEqual(2, len(destination_db.all_videos()))
                self.assertEqual(
                    {b"source version", b"destination version"},
                    {
                        path.read_bytes()
                        for path in destination.glob("*.mp4")
                    },
                )

    def test_two_inputs_initialize_empty_output_without_modifying_inputs(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            first = root / "first"
            second = root / "second"
            output = root / "output"
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            self.make_catalog(
                first,
                root / "first-cache.sqlite3",
                "first.mp4",
                b"first",
                start,
            )
            self.make_catalog(
                second,
                root / "second-cache.sqlite3",
                "second.mp4",
                b"second",
                start + dt.timedelta(minutes=1),
            )
            snapshots = {
                path: (path.read_bytes(), path.stat().st_mtime_ns)
                for source in (first, second)
                for path in source.iterdir()
                if path.is_file()
            }

            report = merge_catalog_folders([first, second], output)

            self.assertEqual((2, 2), (report.discovered, report.imported))
            self.assertTrue(output.is_dir())
            with CatalogRepository(
                output / "video_catalog.sqlite3",
                readonly=True,
            ) as repository:
                self.assertEqual(2, len(repository.all_videos()))
            for path, snapshot in snapshots.items():
                self.assertEqual(snapshot, (path.read_bytes(), path.stat().st_mtime_ns))

    def test_empty_output_requires_two_distinct_inputs(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            output = root / "output"
            self.make_catalog(
                source,
                root / "source-cache.sqlite3",
                "source.mp4",
                b"source",
                dt.datetime(2026, 1, 1, tzinfo=UTC),
            )
            with self.assertRaisesRegex(
                ConfigurationError,
                "requires at least two distinct input",
            ):
                merge_catalog_folders([source], output)
            self.assertFalse(output.exists())

    def test_nonempty_output_requires_valid_complete_catalog(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            output = root / "output"
            self.make_catalog(
                source,
                root / "source-cache.sqlite3",
                "source.mp4",
                b"source",
                dt.datetime(2026, 1, 1, tzinfo=UTC),
            )
            output.mkdir()
            (output / "unrelated.txt").write_text("not a catalog")
            with self.assertRaisesRegex(
                ConfigurationError,
                "database does not exist",
            ):
                merge_catalog_folders([source], output)
            self.assertFalse(
                (output / "video_catalog.sqlite3").exists()
            )

    def test_output_may_be_repeated_among_nonempty_inputs(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / "source"
            output = root / "output"
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            self.make_catalog(
                source,
                root / "source-cache.sqlite3",
                "source.mp4",
                b"source",
                start + dt.timedelta(minutes=1),
            )
            self.make_catalog(
                output,
                root / "output-cache.sqlite3",
                "existing.mp4",
                b"existing",
                start,
            )

            report = merge_catalog_folders(
                [output, source, output],
                output,
            )

            self.assertEqual((1, 1), (report.discovered, report.imported))
            with CatalogRepository(
                output / "video_catalog.sqlite3",
                readonly=True,
            ) as repository:
                self.assertEqual(2, len(repository.all_videos()))


if __name__ == "__main__":
    unittest.main()
