import datetime as dt
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from video_pipeline.acquisition import (
    AcquisitionStore,
    RecordingSegment,
    SearchPolicy,
    search_window,
)
from video_pipeline.cli import acquire_frames_main
from video_pipeline.frames import (
    JPEGSettings,
    MinuteFrameExtractor,
    frame_path,
)
from video_pipeline.config import PipelineConfig
from video_pipeline.indexing import (
    CatalogRepository,
    EndpointInspection,
    FrameIndex,
    IndexedFrame,
)


UTC = dt.timezone.utc


class FakeArchive:
    def __init__(self):
        self.paths: dict[dt.datetime, Path] = {}

    def exists(self, timestamp: dt.datetime) -> bool:
        return timestamp in self.paths

    def add(self, timestamp, _segment_id, path):
        self.paths[timestamp] = path


class FakeMedia:
    ffmpeg = "ffmpeg"

    def __init__(self):
        self.commands: list[list[str]] = []

    def decoder_args(self, _sequence=0):
        return []

    def software_filters(self, filters):
        return ",".join(filters)

    def run(self, command, _purpose, timeout=None):
        self.commands.append(list(command))
        output = Path(command[-1])
        selection = command[command.index("-vf") + 1]
        count = selection.count("eq(n\\,")
        for index in range(count):
            Path(str(output) % index).write_bytes(b"jpeg")


class FakeFrameIndexBackend:
    def __init__(self, start: dt.datetime):
        self.start = start
        self.calls = 0

    def index(self, path: Path, worker: int = 0):
        self.calls += 1
        return FrameIndex(
            path,
            self.start,
            self.start + dt.timedelta(seconds=61),
            (
                IndexedFrame(round(self.start.timestamp()), 0),
                IndexedFrame(round(self.start.timestamp()) + 59, 1180),
                IndexedFrame(round(self.start.timestamp()) + 60, 1200),
            ),
        )


class AcquisitionFrameTests(unittest.TestCase):
    def test_native_resolution_is_the_default(self):
        jpeg = JPEGSettings()
        config = PipelineConfig.from_mapping({})
        self.assertEqual((0, 0), (jpeg.max_width, jpeg.max_height))
        self.assertEqual(
            (0, 0),
            (
                config.archive.max_width,
                config.archive.max_height,
            ),
        )

    def test_segment_download_name_is_collision_resistant(self):
        segment = RecordingSegment.create(
            name="000000001.mp4",
            track_id=101,
            start=dt.datetime(2026, 1, 1, tzinfo=UTC),
            end=dt.datetime(2026, 1, 1, 0, 1, tzinfo=UTC),
            playback_uri="test",
            expected_size=10,
        )
        self.assertRegex(
            segment.download_name(),
            r"^000000001__[0-9a-f]{12}\.mp4$",
        )

    def test_search_cursor_uses_overlap(self):
        with tempfile.TemporaryDirectory() as folder:
            with AcquisitionStore(Path(folder) / "state.sqlite3") as store:
                store.set_setting(
                    "last_successful_search_end", "2026-01-01T01:00:00Z"
                )
                start, end = search_window(
                    SearchPolicy(
                        track_id=1,
                        start=dt.datetime(2026, 1, 1, tzinfo=UTC),
                        overlap_seconds=300,
                    ),
                    store,
                    dt.datetime(2026, 1, 1, 2, 0, tzinfo=UTC),
                )
        self.assertEqual(
            dt.datetime(2026, 1, 1, 0, 55, tzinfo=UTC), start
        )
        self.assertEqual(
            dt.datetime(2026, 1, 1, 1, 58, tzinfo=UTC), end
        )

    def test_archive_path_uses_timestamp_timezone(self):
        timestamp = dt.datetime(2026, 1, 1, 0, 1, tzinfo=UTC)
        path = frame_path(Path("archive"), timestamp, "UTC")
        self.assertEqual(
            Path("archive/frames/2026/01/01/20260101T000100Z.jpg"),
            path,
        )

    def test_minute_extraction_indexes_on_demand_and_reuses_catalog(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video = root / "segment.mp4"
            video.write_bytes(b"video")
            start = dt.datetime(2026, 1, 1, 0, 0, 1, tzinfo=UTC)
            backend = FakeFrameIndexBackend(start)
            media = FakeMedia()
            archive = FakeArchive()
            with CatalogRepository(root / "catalog.sqlite3") as catalog:
                extractor = MinuteFrameExtractor(
                    media,
                    JPEGSettings(timezone="UTC"),
                )
                written = extractor.extract(
                    video,
                    segment_id="segment",
                    root=root,
                    archive=archive,  # type: ignore[arg-type]
                    catalog=catalog,
                    backend=backend,  # type: ignore[arg-type]
                )
                repeated = extractor.extract(
                    video,
                    segment_id="segment",
                    root=root,
                    archive=archive,  # type: ignore[arg-type]
                    catalog=catalog,
                    backend=backend,  # type: ignore[arg-type]
                )
                catalog_video = catalog.video_by_name(video.name)
                assert catalog_video is not None
                self.assertEqual(
                    (
                        IndexedFrame(round(start.timestamp()) + 59, 1180),
                    ),
                    catalog.minute_frames(catalog_video.id),
                )
            self.assertEqual(1, written)
            self.assertEqual(0, repeated)
            self.assertEqual(1, backend.calls)
            self.assertEqual(1, len(media.commands))
            selection = media.commands[0][media.commands[0].index("-vf") + 1]
            self.assertIn("eq(n\\,1180)", selection)
            self.assertNotIn("eq(n\\,1200)", selection)
            self.assertTrue(selection.endswith(",null"))

    def test_frame_cli_processes_catalogued_local_videos(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video_dir = root / "videos"
            video_dir.mkdir()
            video = video_dir / "segment.mp4"
            video.write_bytes(b"video")
            catalog_path = root / "video_catalog.sqlite3"
            start = dt.datetime(2026, 1, 1, tzinfo=UTC)
            stat = video.stat()
            with CatalogRepository(catalog_path) as catalog:
                video_id = catalog.register(
                    EndpointInspection(
                        video,
                        "fingerprint",
                        stat.st_size,
                        stat.st_mtime_ns,
                        start,
                        start + dt.timedelta(minutes=1),
                        60.0,
                    ),
                    video,
                )
                catalog.record_frames(
                    video_id,
                    (IndexedFrame(round(start.timestamp()), 1),),
                )

            calls: list[tuple[Path, str]] = []

            class FakeExtractor:
                def __init__(self, *_args, **_kwargs):
                    pass

                def extract(self, path: Path, *, segment_id: str, **_kwargs):
                    calls.append((path, segment_id))
                    return 1

            with (
                mock.patch(
                    "video_pipeline.cli._media",
                    return_value=(object(), object()),
                ),
                mock.patch(
                    "video_pipeline.cli.HikvisionOverlayBackend",
                    return_value=object(),
                ),
                mock.patch(
                    "video_pipeline.cli.MinuteFrameExtractor",
                    FakeExtractor,
                ),
            ):
                status = acquire_frames_main(
                    [
                        "--video-dir",
                        str(video_dir),
                        "--output-root",
                        str(root),
                        "--database",
                        str(root / "state.sqlite3"),
                        "--catalog-database",
                        str(catalog_path),
                        "--timezone",
                        "UTC",
                    ]
                )

            self.assertEqual(0, status)
            self.assertEqual([(video.resolve(), f"catalog:{video_id}")], calls)


if __name__ == "__main__":
    unittest.main()
