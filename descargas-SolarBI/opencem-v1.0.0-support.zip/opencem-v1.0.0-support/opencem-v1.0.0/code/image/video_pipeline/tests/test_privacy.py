import unittest
import datetime as dt
from importlib import resources
from pathlib import Path
import tempfile

from video_pipeline.acquisition import AcquisitionStore
from video_pipeline.frames import FrameArchive
from video_pipeline.privacy import (
    ReviewDecision,
    apply_human_decisions,
    rank_candidates,
    timestamp_from_frame,
    write_second_pass_indices,
)


def row(index, *, human=0, pose=0, change=0.0):
    return {
        "archive_index": index,
        "path": f"/frames/{index}.jpg",
        "human_full_count": human,
        "human_upper_count": 0,
        "face_count": 0,
        "pose_count": pose,
        "human_full_confidence": 0.9 if human else 0.0,
        "human_upper_confidence": 0.0,
        "face_confidence": 0.0,
        "pose_confidence": 0.8 if pose else 0.0,
        "edge_touch": 0,
        "change_tile_mean": change,
        "change_fraction": change,
        "change_reliable": 1,
        "error": "",
    }


class PrivacyTests(unittest.TestCase):
    def test_packaged_swift_scanner_has_full_review_features(self):
        source = (
            resources.files("video_pipeline")
            .joinpath("swift")
            .joinpath("vision_human_scan.swift")
            .read_text(encoding="utf-8")
        )
        for option in (
            "--mask",
            "--build-mask",
            "--indices-file",
            "--perimeter-tiles",
            "--skip-change",
        ):
            self.assertIn(option, source)

    def test_model_positive_is_retained_ahead_of_change_only_frames(self):
        values = [row(0, change=10), row(1, human=1), row(2, change=20)]
        selected = rank_candidates(values, count=2)
        self.assertIn(1, [item["archive_index"] for item in selected])
        human = next(item for item in selected if item["archive_index"] == 1)
        self.assertEqual(1, human["priority_tier"])

    def test_frame_timestamp_accepts_utc_and_numeric_offsets(self):
        utc = timestamp_from_frame(Path("20260101T120000Z.jpg"))
        china = timestamp_from_frame(Path("20260101T200000+0800.jpg"))
        self.assertEqual(utc, china)

    def test_second_pass_indices_follow_change_risk(self):
        values = [
            row(1, change=1.0),
            row(2, change=3.0),
            row(3, change=2.0),
        ]
        with tempfile.TemporaryDirectory() as folder:
            destination = Path(folder) / "indices.txt"
            write_second_pass_indices(values, destination, 2)
            self.assertEqual(
                ["2", "3"],
                destination.read_text().splitlines(),
            )

    def test_applying_human_decision_deletes_and_tombstones(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            frame = root / "frames/2026/01/01/20260101T120000Z.jpg"
            frame.parent.mkdir(parents=True)
            frame.write_bytes(b"jpeg")
            database = root / "state.sqlite3"
            timestamp = dt.datetime(2026, 1, 1, 12, tzinfo=dt.timezone.utc)
            with AcquisitionStore(database) as store:
                FrameArchive(store).add(timestamp, "segment", frame)
            applied = apply_human_decisions(
                [ReviewDecision(0, "human", frame.resolve())],
                output_root=root,
                database=database,
            )
            self.assertEqual(1, len(applied))
            self.assertFalse(frame.exists())
            with AcquisitionStore(database) as store:
                self.assertIsNotNone(
                    store.connection.execute(
                        "SELECT 1 FROM excluded_frames"
                    ).fetchone()
                )
                self.assertIsNone(
                    store.connection.execute("SELECT 1 FROM frames").fetchone()
                )


if __name__ == "__main__":
    unittest.main()
