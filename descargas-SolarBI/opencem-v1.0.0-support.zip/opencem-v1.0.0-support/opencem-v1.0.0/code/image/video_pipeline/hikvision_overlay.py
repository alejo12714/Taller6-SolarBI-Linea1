#!/usr/bin/env python3
"""Fixed-overlay recognition and indexing for Hikvision video files.

The recorder's numeric download name is deliberately not used as a permanent
identity. Each file receives a portable full-content fingerprint, whose local
calculation is cached by basename and creation timestamp, and its OSD clock is
read by a camera-specific glyph recognizer before the result is stored in
SQLite.

FFmpeg extracts only the fixed OSD strip. Normal scans classify the camera's
known black/white digit glyphs at deterministic cell locations. RapidOCR is
used to anchor the first and last timestamps and as a targeted fallback when
the deterministic comparison is ambiguous. The decoder accepts only legal
calendar dates and 24-hour clock values.
"""

from __future__ import annotations

import argparse
import bisect
import collections
import concurrent.futures
import contextlib
import dataclasses
import datetime as dt
import hashlib
import json
import logging
import os
from pathlib import Path
import platform
import queue
import re
import sqlite3
import statistics
import struct
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from typing import Any, Iterable, Iterator, Sequence
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .glyphs import bundled_glyph_templates


LOG = logging.getLogger("hikvision_video_catalog")
UTC = dt.timezone.utc
SCHEMA_VERSION = 2
DEFAULT_EXTENSIONS = ".mp4,.dav,.ps,.avi,.mkv,.mov"
DIAGNOSTIC_SCHEMA_VERSION = 1
_DIAGNOSTICS: "DiagnosticLog | None" = None


class CatalogError(RuntimeError):
    """An expected, operator-actionable catalogue failure."""


class GPUFrameSequenceConcern(CatalogError):
    """NVDEC output did not match the demuxed presentation-frame sequence."""

    def __init__(self, message: str, details: dict[str, Any]):
        super().__init__(message)
        self.details = details


@dataclasses.dataclass(frozen=True)
class Probe:
    duration: float
    size: int
    codec: str
    width: int
    height: int
    start_time: float = 0.0


@dataclasses.dataclass(frozen=True)
class OCRReading:
    offset: float
    timestamp: dt.datetime
    confidence: float
    text: str
    raw_date: str | None = None
    raw_time: str | None = None
    context_corrected: bool = False
    alternate_raw_time: str | None = None
    alternate_corrected: bool = False
    # Parsed timestamp before any temporal-context correction.  A valid raw
    # alternative must remain available so a persistent real clock jump can
    # be distinguished from a one-frame OCR error.
    observed_timestamp: dt.datetime | None = None


@dataclasses.dataclass(frozen=True)
class Analysis:
    source: Path
    fingerprint: str
    original_size: int
    original_mtime_ns: int
    probe: Probe
    start: dt.datetime
    end: dt.datetime
    readings: tuple[OCRReading, ...]
    timing_spread: float
    second_frames: tuple["SecondFrame", ...]
    first_frame: "FrameObservation"
    last_frame: "FrameObservation"


@dataclasses.dataclass(frozen=True)
class Registration:
    """Fast, durable result used before the expensive per-second index."""

    source: Path
    fingerprint: str
    original_size: int
    original_mtime_ns: int
    probe: Probe
    start: dt.datetime
    end: dt.datetime
    readings: tuple[OCRReading, ...]
    timing_spread: float


@dataclasses.dataclass(frozen=True)
class CatalogVideo:
    id: int
    old_name: str
    new_name: str
    start: float
    end: float


@dataclasses.dataclass(frozen=True)
class FrameObservation:
    timestamp: dt.datetime
    frame_number: int
    pts_seconds: float
    overlay_text: str
    confidence: float


@dataclasses.dataclass(frozen=True)
class SecondFrame:
    timestamp: dt.datetime
    frame_number: int
    previous_frame_number: int
    pts_seconds: float
    previous_pts_seconds: float
    overlay_text: str
    previous_overlay_text: str
    confidence: float
    previous_confidence: float


@dataclasses.dataclass(frozen=True)
class PendingContextTransition:
    previous: OCRReading
    current: OCRReading
    frame_number: int
    previous_pts_seconds: float
    pts_seconds: float
    pixel_delta: float


@dataclasses.dataclass(frozen=True)
class PendingDiscontinuityTransition:
    previous: OCRReading
    current: OCRReading
    frame_number: int
    previous_pts_seconds: float
    pts_seconds: float
    pixel_delta: float


@dataclasses.dataclass(frozen=True)
class PacketIndex:
    """Presentation-order decoded-frame timestamps obtained without pixel output."""

    pts_seconds: tuple[float, ...]
    keyframe_pts_seconds: tuple[float, ...]
    origin_seconds: float = 0.0
    packet_origin_seconds: float | None = None

    def frame_number(self, pts_seconds: float, tolerance: float = 0.00002) -> int:
        position = bisect.bisect_left(self.pts_seconds, pts_seconds)
        candidates = [index for index in (position - 1, position) if 0 <= index < len(self.pts_seconds)]
        if not candidates:
            raise CatalogError(f"Frame PTS {pts_seconds:.6f}s is outside the frame index")
        best = min(candidates, key=lambda index: abs(self.pts_seconds[index] - pts_seconds))
        error = abs(self.pts_seconds[best] - pts_seconds)
        if error > tolerance:
            raise CatalogError(
                f"Decoded frame PTS {pts_seconds:.6f}s is not in the frame index "
                f"(nearest {self.pts_seconds[best]:.6f}s, error {error:.6f}s)"
            )
        return best

    def preceding_keyframe(self, pts_seconds: float) -> float:
        position = bisect.bisect_right(self.keyframe_pts_seconds, pts_seconds) - 1
        return self.keyframe_pts_seconds[max(0, position)]


def utc_now_text() -> str:
    return dt.datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dt.datetime):
        return value.isoformat()
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return repr(value)


class DiagnosticLog:
    """Thread-safe append-only JSON-lines diagnostic report."""

    def __init__(self, path: Path, run_context: dict[str, Any]):
        self.path = path
        self.run_id = f"{utc_now_text()}-pid{os.getpid()}"
        self.run_context = json_safe(run_context)
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(
        self,
        event: str,
        *,
        video: Path | None = None,
        assumption: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        record: dict[str, Any] = {
            "diagnostic_schema": DIAGNOSTIC_SCHEMA_VERSION,
            "timestamp_utc": utc_now_text(),
            "run_id": self.run_id,
            "event": event,
            "assumption": assumption,
            "video_path": str(video.resolve(strict=False)) if video else None,
            "video_name": video.name if video else None,
            "details": json_safe(details or {}),
        }
        if video:
            try:
                stat = video.stat()
                record["file"] = {
                    "size_bytes": stat.st_size,
                    "mtime_ns": stat.st_mtime_ns,
                    "mtime_utc": dt.datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
                }
            except OSError as exc:
                record["file"] = {"stat_error": repr(exc)}
        line = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        try:
            with self._lock:
                with self.path.open("a", encoding="utf-8", newline="\n") as handle:
                    handle.write(line + "\n")
        except OSError as exc:
            LOG.error("Could not append diagnostic event to %s: %s", self.path, exc)


def diagnostic_event(
    event: str,
    *,
    video: Path | None = None,
    assumption: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    if _DIAGNOSTICS is not None:
        _DIAGNOSTICS.write(event, video=video, assumption=assumption, details=details)


def run_command(command: Sequence[str], purpose: str, timeout: float = 120.0) -> subprocess.CompletedProcess[bytes]:
    try:
        completed = subprocess.run(command, capture_output=True, check=False, timeout=timeout)
    except FileNotFoundError as exc:
        raise CatalogError(f"Executable not found while trying to {purpose}: {command[0]!r}") from exc
    except subprocess.TimeoutExpired as exc:
        raise CatalogError(f"Timed out after {timeout:g}s while trying to {purpose}: {command!r}") from exc
    if completed.returncode:
        stderr = completed.stderr.decode("utf-8", "replace")[-4000:]
        raise CatalogError(
            f"Could not {purpose} (exit {completed.returncode}). Command: {command!r}. stderr: {stderr}"
        )
    return completed


def probe_video(path: Path, ffprobe: str, ffmpeg_threads: int = 0) -> Probe:
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    completed = run_command(
        [
            ffprobe,
            "-v", "error",
            *thread_arguments,
            "-select_streams", "v:0",
            "-show_entries", "format=duration,size,start_time:stream=codec_name,width,height",
            "-of", "json",
            str(path),
        ],
        f"probe {path}",
    )
    try:
        data = json.loads(completed.stdout)
        stream = data["streams"][0]
        duration = float(data["format"]["duration"])
        size = int(data["format"].get("size") or path.stat().st_size)
        start_time = float(data["format"].get("start_time") or 0.0)
        result = Probe(
            duration,
            size,
            str(stream["codec_name"]),
            int(stream["width"]),
            int(stream["height"]),
            start_time,
        )
    except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CatalogError(f"FFprobe returned unusable metadata for {path}: {completed.stdout[:1500]!r}") from exc
    if result.duration <= 0 or result.width <= 0 or result.height <= 0:
        raise CatalogError(f"FFprobe returned invalid video dimensions/duration for {path}: {result}")
    return result


def executable_version(executable: str) -> str:
    completed = run_command([executable, "-version"], f"read {executable} version", timeout=30)
    return completed.stdout.decode("utf-8", "replace").splitlines()[0].strip()


def diagnostic_media_snapshot(path: Path, ffprobe: str, ffmpeg_threads: int) -> dict[str, Any]:
    """Collect cheap container/stream metadata after a file-level failure."""
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    try:
        completed = run_command(
            [
                ffprobe,
                "-v", "error",
                *thread_arguments,
                "-show_entries",
                (
                    "format=format_name,start_time,duration,size,bit_rate:"
                    "stream=index,codec_type,codec_name,profile,width,height,pix_fmt,"
                    "r_frame_rate,avg_frame_rate,time_base,start_time,duration,nb_frames"
                ),
                "-of", "json",
                str(path),
            ],
            f"collect diagnostic metadata for {path}",
            timeout=120,
        )
        return json.loads(completed.stdout)
    except Exception as exc:
        return {"probe_error": repr(exc)}


def content_fingerprint(path: Path, block_bytes: int = 4 * 1024 * 1024) -> str:
    """Return a full SHA-256 content identity, prefixed by the file size."""
    size = path.stat().st_size
    digest = hashlib.sha256(struct.pack(">Q", size))
    with path.open("rb") as handle:
        while chunk := handle.read(block_bytes):
            digest.update(chunk)
    return digest.hexdigest()


def local_creation_timestamp(stat: os.stat_result) -> tuple[str, int]:
    """Return the best stable local creation-time key available to Python."""
    birthtime_ns = getattr(stat, "st_birthtime_ns", None)
    if birthtime_ns is not None:
        return "birthtime_ns", int(birthtime_ns)
    birthtime = getattr(stat, "st_birthtime", None)
    if birthtime is not None:
        return "birthtime", round(float(birthtime) * 1_000_000_000)
    if os.name == "nt":
        return "windows_creation_time_ns", int(stat.st_ctime_ns)
    # Linux usually does not expose statx birth time through os.stat. In this
    # controlled workflow inode change time is a conservative cache surrogate:
    # metadata/content changes cause a harmless cache miss and recomputation.
    return "inode_change_time_ns", int(stat.st_ctime_ns)


def parse_hikvision_time(raw: str) -> tuple[int, int, int] | None:
    """Parse the camera's fixed six-digit clock without trusting separators."""
    digits = "".join(re.findall(r"\d", raw))
    if len(digits) == 6:
        hour = int(digits[:2])
        # On the supplied outlined font, a bright diagonal background can make
        # the leading zero in an hour such as 06 look like 9. The raw result 96
        # is impossible as an hour, while the position-preserving correction is
        # unique and valid. Do not apply broader digit substitutions.
        if hour > 23 and digits[0] == "9":
            corrected_hour = int("0" + digits[1])
            if corrected_hour <= 23:
                hour = corrected_hour
        return hour, int(digits[2:4]), int(digits[4:])
    # Retain support for the recorder occasionally rendering a one-digit hour,
    # but do not guess where a missing digit belongs in an ambiguous clock.
    match = re.search(
        r"(?<!\d)(\d{1,2})\s*[:：.\-]\s*(\d{2})\s*[:：.\-]\s*(\d{2})(?!\d)",
        raw,
    )
    if match:
        return tuple(int(value) for value in match.groups())
    return None


def differs_by_one_character_edit(observed: str, expected: str) -> bool:
    """True for exactly one substitution, insertion, or deletion."""
    if observed == expected or abs(len(observed) - len(expected)) > 1:
        return False
    if len(observed) == len(expected):
        return sum(left != right for left, right in zip(observed, expected)) == 1
    longer, shorter = (observed, expected) if len(observed) > len(expected) else (expected, observed)
    for index in range(len(longer)):
        if longer[:index] + longer[index + 1:] == shorter:
            return True
    return False


class SHA256Cache:
    """Disposable local cache; it is intentionally separate from the catalogue."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(path), timeout=30)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS sha256_cache (
                name TEXT NOT NULL,
                timestamp_source TEXT NOT NULL,
                creation_ns INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                PRIMARY KEY(name, timestamp_source, creation_ns)
            ) WITHOUT ROWID
            """
        )
        self.connection.commit()

    def get(self, name: str, timestamp_source: str, creation_ns: int) -> str | None:
        row = self.connection.execute(
            """
            SELECT sha256 FROM sha256_cache
            WHERE name=? AND timestamp_source=? AND creation_ns=?
            """,
            (name, timestamp_source, creation_ns),
        ).fetchone()
        if row is None or re.fullmatch(r"[0-9a-f]{64}", str(row[0])) is None:
            return None
        return str(row[0])

    def put(self, name: str, timestamp_source: str, creation_ns: int, sha256: str) -> None:
        if re.fullmatch(r"[0-9a-f]{64}", sha256) is None:
            raise CatalogError(f"Refusing to cache invalid SHA-256 value {sha256!r}")
        with self.connection:
            self.connection.execute(
                """
                INSERT INTO sha256_cache(name,timestamp_source,creation_ns,sha256)
                VALUES(?,?,?,?)
                ON CONFLICT(name,timestamp_source,creation_ns)
                DO UPDATE SET sha256=excluded.sha256
                """,
                (name, timestamp_source, creation_ns, sha256),
            )

    def close(self) -> None:
        self.connection.close()


def parse_pgm(data: bytes) -> tuple[int, int, bytes]:
    """Parse the binary P5 PGM emitted by FFmpeg (including comment lines)."""
    if not data.startswith(b"P5"):
        raise CatalogError(f"FFmpeg did not emit a binary PGM image; prefix={data[:32]!r}")
    position = 2
    tokens: list[bytes] = []
    while len(tokens) < 3:
        while position < len(data) and data[position] in b" \t\r\n":
            position += 1
        if position < len(data) and data[position] == ord("#"):
            while position < len(data) and data[position] not in b"\r\n":
                position += 1
            continue
        start = position
        while position < len(data) and data[position] not in b" \t\r\n":
            position += 1
        tokens.append(data[start:position])
    try:
        width, height, maximum = (int(token) for token in tokens)
    except ValueError as exc:
        raise CatalogError(f"Invalid PGM header: {tokens!r}") from exc
    if maximum != 255:
        raise CatalogError(f"Unsupported PGM maximum value {maximum}; expected 255")
    while position < len(data) and data[position] in b" \t\r\n":
        position += 1
    pixels = data[position:]
    if len(pixels) != width * height:
        raise CatalogError(f"Truncated PGM: {width}x{height} needs {width * height} bytes, got {len(pixels)}")
    return width, height, pixels


def extract_patch(pixels: bytes, width: int, height: int, box: Sequence[int]) -> list[int]:
    x, y, patch_width, patch_height = (int(value) for value in box)
    if x < 0 or y < 0 or x + patch_width > width or y + patch_height > height:
        raise CatalogError(f"OCR digit cell {box!r} lies outside extracted {width}x{height} OSD strip")
    result: list[int] = []
    for row in range(y, y + patch_height):
        start = row * width + x
        result.extend(pixels[start:start + patch_width])
    return result


def outlined_white_features(
    patch: Any,
    white_threshold: int = 90,
    contrast_threshold: int = 55,
    radius: int = 2,
) -> Any:
    """Return pixels locally brighter than the OSD's contrasting outline."""
    import numpy as np

    values = np.asarray(patch, dtype=np.uint8)
    if values.ndim != 2:
        raise CatalogError(f"Glyph feature input must be two-dimensional, got {values.shape}")
    height, width = values.shape
    try:
        import cv2

        kernel = np.ones((2 * radius + 1, 2 * radius + 1), dtype=np.uint8)
        local_minimum = cv2.erode(values, kernel, borderType=cv2.BORDER_REPLICATE)
    except ImportError:
        padded = np.pad(values, radius, mode="edge")
        local_minimum = np.full((height, width), 255, dtype=np.uint8)
        for y_offset in range(2 * radius + 1):
            for x_offset in range(2 * radius + 1):
                local_minimum = np.minimum(
                    local_minimum,
                    padded[y_offset:y_offset + height, x_offset:x_offset + width],
                )
    contrast = values.astype(np.int16) - local_minimum.astype(np.int16)
    return (values >= white_threshold) & (contrast >= contrast_threshold)


class TimestampOCR:
    def __init__(
        self,
        ffmpeg: str,
        seek_preroll: float = 10.0,
        ffmpeg_threads: int = 0,
        gpu_index: int | None = None,
    ):
        try:
            import numpy  # noqa: F401
            from rapidocr import RapidOCR  # noqa: F401
        except ImportError as exc:
            raise CatalogError(
                "RapidOCR is required. Install it with: python -m pip install rapidocr onnxruntime"
            ) from exc
        raw = default_layout()
        self.ffmpeg = ffmpeg
        self.seek_preroll = seek_preroll
        self.ffmpeg_threads = ffmpeg_threads
        self.gpu_index = gpu_index
        self.reference_width = int(raw["reference_width"])
        self.reference_height = int(raw["reference_height"])
        self.roi = tuple(int(value) for value in raw["roi"])
        self.cell_width = int(raw["cell_width"])
        self.cell_height = int(raw["cell_height"])
        self.date_cells = tuple(tuple(cell) for cell in raw["date_cells"])
        self.time_cells = tuple(tuple(cell) for cell in raw["time_cells"])
        self._thread_local = threading.local()

    def cpu_copy(self) -> "TimestampOCR":
        return TimestampOCR(self.ffmpeg, self.seek_preroll, self.ffmpeg_threads)

    def decoder_input_arguments(self) -> list[str]:
        arguments: list[str] = []
        if self.ffmpeg_threads:
            arguments.extend(["-threads", str(self.ffmpeg_threads)])
        if self.gpu_index is not None:
            arguments.extend(
                [
                    "-hwaccel", "cuda",
                    "-hwaccel_device", str(self.gpu_index),
                    "-hwaccel_output_format", "cuda",
                ]
            )
        return arguments

    def software_filter_prefix(self) -> list[str]:
        # OCR runs on CPU. Download NVDEC frames once, before the ordinary
        # scale/crop/grayscale filters, when CUDA decoding is enabled.
        return ["hwdownload", "format=nv12"] if self.gpu_index is not None else []

    def _engine(self) -> Any:
        engine = getattr(self._thread_local, "engine", None)
        if engine is None:
            from rapidocr import RapidOCR
            engine = RapidOCR()
            self._thread_local.engine = engine
        return engine

    def extract_osd(self, video: Path, offset: float) -> tuple[int, int, bytes]:
        input_seek = max(0.0, offset - self.seek_preroll)
        accurate_seek = offset - input_seek
        command = [self.ffmpeg, "-hide_banner", "-loglevel", "error"]
        if input_seek:
            command.extend(["-ss", f"{input_seek:.6f}"])
        command.extend(self.decoder_input_arguments())
        command.extend(["-i", str(video)])
        if accurate_seek:
            command.extend(["-ss", f"{accurate_seek:.6f}"])
        x, y, width, height = self.roi
        filters = self.software_filter_prefix()
        filters.extend(
            [
                f"scale={self.reference_width}:{self.reference_height}:flags=neighbor",
                f"crop={width}:{height}:{x}:{y}",
                "format=gray",
            ]
        )
        video_filter = ",".join(filters)
        command.extend(["-frames:v", "1", "-vf", video_filter, "-f", "image2pipe", "-vcodec", "pgm", "-"])
        completed = run_command(command, f"extract OSD clock from {video} at {offset:.3f}s")
        return parse_pgm(completed.stdout)

    def read(self, video: Path, offset: float, timezone: dt.tzinfo) -> OCRReading:
        width, height, pixels = self.extract_osd(video, offset)
        return self.read_pixels(pixels, width, height, offset, timezone)

    def read_pixels(
        self,
        pixels: bytes,
        width: int,
        height: int,
        offset: float,
        timezone: dt.tzinfo,
        expected_timestamp: dt.datetime | None = None,
    ) -> OCRReading:
        import numpy as np

        if (width, height) != (self.roi[2], self.roi[3]):
            raise CatalogError(f"Unexpected OCR strip size {width}x{height}")
        gray = np.frombuffer(pixels, dtype=np.uint8).reshape((height, width))

        def recognize(left: int, right: int) -> tuple[str, float]:
            crop = gray[:, left:right]
            crop = np.repeat(np.repeat(crop, 2, axis=0), 2, axis=1)
            crop = np.repeat(crop[:, :, None], 3, axis=2)
            result = self._engine()(crop, use_det=False, use_cls=False, use_rec=True)
            texts = tuple(getattr(result, "txts", ()) or ())
            scores = tuple(getattr(result, "scores", ()) or ())
            if not texts or not scores:
                raise CatalogError(f"RapidOCR returned no text at video offset {offset:.3f}s")
            return str(texts[0]).strip(), float(scores[0])

        raw_date, date_confidence = recognize(30, 520)
        raw_time, time_confidence = recognize(735, width)
        date_match = re.search(r"(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日", raw_date)
        parsed_time = parse_hikvision_time(raw_time)
        if not date_match:
            raise CatalogError(
                f"OCR did not match Hikvision timestamp grammar at {offset:.3f}s: "
                f"date={raw_date!r}, time={raw_time!r}. Expected YYYY年MM月DD日 and six clock digits HHMMSS."
            )
        year, month, day = (int(value) for value in date_match.groups())
        context_corrected = False
        timestamp: dt.datetime | None = None
        text: str
        if parsed_time is not None:
            hour, minute, second = parsed_time
            text = f"{year:04d}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}:{second:02d}"
            try:
                timestamp = dt.datetime.strptime(text, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone)
            except ValueError:
                timestamp = None
        else:
            text = f"{year:04d}-{month:02d}-{day:02d} {raw_time}"

        observed_timestamp = timestamp

        # A person, weather, or a bright background behind the outlined OSD can
        # corrupt one clock character.  At a candidate boundary temporal
        # context can propose exactly one clock-digit edit.  When the raw value
        # is itself valid, full indexing retains it on the reading and confirms
        # raw-vs-context on the immediately following frame, so genuine skips
        # and rollbacks remain observable.
        if expected_timestamp is not None and timestamp != expected_timestamp:
            expected_local = expected_timestamp.astimezone(timezone)
            clock_digits = "".join(re.findall(r"\d", raw_time))
            expected_hm = expected_local.strftime("%H%M")
            expected_clock = expected_local.strftime("%H%M%S")
            same_date = (year, month, day) == (
                expected_local.year,
                expected_local.month,
                expected_local.day,
            )
            seconds_digits_match = len(clock_digits) >= 2 and clock_digits[-2:] == expected_local.strftime("%S")
            one_hm_edit = differs_by_one_character_edit(clock_digits[:-2], expected_hm)
            # RapidOCR can append, omit, or substitute one foreground-looking
            # digit (for example 16:04:07 -> 16:04:072 or 16:04:02).  A valid
            # substituted raw clock remains attached to the reading; full-mode
            # indexing holds that correction for one tick and rejects it if
            # the raw alternative persists as a genuine clock jump.
            one_full_clock_edit = differs_by_one_character_edit(
                clock_digits,
                expected_clock,
            )
            if same_date and (
                (seconds_digits_match and one_hm_edit)
                or one_full_clock_edit
            ):
                timestamp = expected_local
                text = expected_local.strftime("%Y-%m-%d %H:%M:%S")
                context_corrected = True

        if timestamp is None:
            if parsed_time is None:
                raise CatalogError(
                    f"OCR did not match Hikvision timestamp grammar at {offset:.3f}s: "
                    f"date={raw_date!r}, time={raw_time!r}. Expected YYYY年MM月DD日 and six clock digits HHMMSS."
                )
            raise CatalogError(
                f"OCR produced an invalid timestamp {text!r} at {offset:.3f}s; "
                f"raw date={raw_date!r}, raw time={raw_time!r}."
            )
        confidence = min(date_confidence, time_confidence)
        return OCRReading(
            offset,
            timestamp,
            confidence,
            text,
            raw_date,
            raw_time,
            context_corrected,
            observed_timestamp=observed_timestamp,
        )

    def second_units_pixels(self, pixels: bytes, width: int, height: int) -> bytes:
        return bytes(extract_patch(pixels, width, height, self.time_cells[-1]))

    def timestamp_change_score(
        self,
        previous_pixels: bytes,
        current_pixels: bytes,
        width: int,
        height: int,
    ) -> float:
        """Return the largest per-digit change across the six clock digits.

        Comparing only the seconds units cell misses recorder clock corrections
        that alter an hour or minute while leaving SS unchanged.  Taking the
        maximum rather than averaging all cells preserves the established
        transition-threshold scale for an individual changing glyph.
        """
        return max(self.timestamp_change_scores(previous_pixels, current_pixels, width, height))

    def timestamp_change_scores(
        self,
        previous_pixels: bytes,
        current_pixels: bytes,
        width: int,
        height: int,
    ) -> tuple[float, ...]:
        """Return the pixel-change score for each HHMMSS digit cell."""
        return tuple(
            mean_absolute_difference(
                bytes(extract_patch(previous_pixels, width, height, cell)),
                bytes(extract_patch(current_pixels, width, height, cell)),
            )
            for cell in self.time_cells
        )

    def read_seconds_high_threshold(
        self,
        pixels: bytes,
        width: int,
        height: int,
        offset: float,
    ) -> tuple[int, float, str] | None:
        """Retry only the seconds suffix with bright OSD strokes isolated."""
        import numpy as np

        if (width, height) != (self.roi[2], self.roi[3]):
            raise CatalogError(f"Unexpected OCR strip size {width}x{height}")
        gray = np.frombuffer(pixels, dtype=np.uint8).reshape((height, width))
        crop = (gray[:, 735:width] > 200).astype(np.uint8) * 255
        crop = np.repeat(np.repeat(crop, 2, axis=0), 2, axis=1)
        crop = np.repeat(crop[:, :, None], 3, axis=2)
        result = self._engine()(crop, use_det=False, use_cls=False, use_rec=True)
        texts = tuple(getattr(result, "txts", ()) or ())
        scores = tuple(getattr(result, "scores", ()) or ())
        if not texts or not scores:
            return None
        raw = str(texts[0]).strip()
        digits = "".join(re.findall(r"\d", raw))
        if len(digits) < 2:
            return None
        second = int(digits[-2:])
        if second > 59:
            return None
        return second, float(scores[0]), raw


class GlyphTimestampOCR(TimestampOCR):
    """Recognize the fixed Hikvision timestamp with calibrated glyph masks.

    The template stores, for each digit and cell pixel, the empirical
    probability that the camera rendered an opaque white stroke there.  Only
    pixels which distinguish at least two digits are probed.  Scene pixels
    outside those locations are ignored.
    """

    def __init__(
        self,
        ffmpeg: str,
        template_path: Path | None,
        seek_preroll: float = 10.0,
        ffmpeg_threads: int = 0,
        gpu_index: int | None = None,
    ):
        import numpy as np

        raw = default_layout()
        self.ffmpeg = ffmpeg
        self.seek_preroll = seek_preroll
        self.ffmpeg_threads = ffmpeg_threads
        self.gpu_index = gpu_index
        self.reference_width = int(raw["reference_width"])
        self.reference_height = int(raw["reference_height"])
        self.roi = tuple(int(value) for value in raw["roi"])
        self.cell_width = int(raw["cell_width"])
        self.cell_height = int(raw["cell_height"])
        self.date_cells = tuple(tuple(cell) for cell in raw["date_cells"])
        self.time_cells = tuple(tuple(cell) for cell in raw["time_cells"])
        self._thread_local = threading.local()
        self.template_path = (
            Path(template_path).resolve()
            if template_path is not None
            else None
        )
        if self.template_path is not None and not self.template_path.is_file():
            raise CatalogError(
                f"Glyph template file does not exist: {self.template_path}. "
                "Create it with the build-templates command."
            )
        try:
            source = self.template_path or bundled_glyph_templates()
            with np.load(source, allow_pickle=False) as archive:
                probabilities = np.asarray(archive["white_probability"], dtype=np.float32)
                probe_indices = np.asarray(archive["probe_indices"], dtype=np.int32)
                threshold = int(np.asarray(archive["white_threshold"]).item())
                contrast_threshold = int(np.asarray(archive["contrast_threshold"]).item())
                outline_radius = int(np.asarray(archive["outline_radius"]).item())
                cell_width = int(np.asarray(archive["cell_width"]).item())
                cell_height = int(np.asarray(archive["cell_height"]).item())
                cell_offsets = np.asarray(archive["cell_offsets"], dtype=np.int16)
        except (OSError, KeyError, ValueError) as exc:
            label = self.template_path or "the bundled glyph archive"
            raise CatalogError(f"Cannot load glyph templates from {label}: {exc}") from exc
        expected_shape = (10, self.cell_width * self.cell_height)
        if probabilities.shape != expected_shape:
            raise CatalogError(
                f"Glyph template probability shape is {probabilities.shape}; expected {expected_shape}"
            )
        if (cell_width, cell_height) != (self.cell_width, self.cell_height):
            raise CatalogError(
                f"Glyph templates use {cell_width}x{cell_height} cells but this layout uses "
                f"{self.cell_width}x{self.cell_height}"
            )
        if probe_indices.ndim != 1 or not len(probe_indices):
            raise CatalogError("Glyph template contains no discriminating probe pixels")
        if int(probe_indices.min()) < 0 or int(probe_indices.max()) >= self.cell_width * self.cell_height:
            raise CatalogError("Glyph template probe indices lie outside the configured cell")
        self.white_threshold = threshold
        self.contrast_threshold = contrast_threshold
        self.outline_radius = outline_radius
        self.probe_indices = probe_indices
        if cell_offsets.shape != (14, 2):
            raise CatalogError(f"Glyph template cell offsets have shape {cell_offsets.shape}; expected (14, 2)")
        self.cell_offsets = cell_offsets
        probe_probabilities = np.clip(probabilities[:, probe_indices], 0.02, 0.98)
        self._log_white = np.log(probe_probabilities)
        self._log_not_white = np.log1p(-probe_probabilities)
        probe_rows = probe_indices // self.cell_width
        probe_columns = probe_indices % self.cell_width
        self._position_probes: list[tuple[Any, Any, Any]] = []
        for x_offset, y_offset in cell_offsets:
            rows = probe_rows + int(y_offset)
            columns = probe_columns + int(x_offset)
            valid = (
                (rows >= 0)
                & (rows < self.cell_height)
                & (columns >= 0)
                & (columns < self.cell_width)
            )
            self._position_probes.append((rows[valid], columns[valid], np.flatnonzero(valid)))
        self._date_cache: dict[bytes, tuple[tuple[int, int, int], float, float]] = {}

    def cpu_copy(self) -> "GlyphTimestampOCR":
        return GlyphTimestampOCR(
            self.ffmpeg,
            self.template_path,
            self.seek_preroll,
            self.ffmpeg_threads,
        )

    def _cell_costs(self, gray: Any, cell: Sequence[int], position: int) -> Any:
        x, y, width, height = (int(value) for value in cell)
        features = outlined_white_features(
            gray[y:y + height, x:x + width],
            self.white_threshold,
            self.contrast_threshold,
            self.outline_radius,
        )
        rows, columns, template_indices = self._position_probes[position]
        return self._probe_costs(features[rows, columns], template_indices)

    def _probe_costs(self, observed_values: Any, template_indices: Any) -> Any:
        import numpy as np

        observed = observed_values.astype(np.float32)
        return -np.mean(
            observed[None, :] * self._log_white[:, template_indices]
            + (1.0 - observed[None, :]) * self._log_not_white[:, template_indices],
            axis=1,
        )

    def _cell_costs_from_features(self, features: Any, cell: Sequence[int], position: int) -> Any:
        import numpy as np

        x, y, width, height = (int(value) for value in cell)
        patch = features[y:y + height, x:x + width]
        rows, columns, template_indices = self._position_probes[position]
        return self._probe_costs(patch[rows, columns], template_indices)

    @staticmethod
    def _best_sequence(costs: Any, values: Sequence[tuple[int, str]]) -> tuple[int, str, float, float]:
        import numpy as np

        totals = np.asarray(
            [sum(float(costs[position, int(digit)]) for position, digit in enumerate(text)) for _, text in values],
            dtype=np.float64,
        )
        order = np.argsort(totals)
        best_index = int(order[0])
        second_index = int(order[1]) if len(order) > 1 else best_index
        value, text = values[best_index]
        return value, text, float(totals[best_index]), float(totals[second_index] - totals[best_index])

    @staticmethod
    def _confidence(best_cost: float, margin: float, positions: int) -> float:
        # The probabilistic score is averaged per probe and then summed across
        # positions.  Require both an absolute template fit and separation from
        # the next legal value; the constants are intentionally conservative
        # and are validated against the supplied failure recordings.
        import math

        average_cost = best_cost / max(positions, 1)
        fit = math.exp(-max(0.0, average_cost - 0.04) * 1.8)
        separation = 1.0 - math.exp(-max(0.0, margin) * 5.0)
        return max(0.0, min(0.999, fit * separation))

    def _decode_date(self, gray: Any, costs: Any) -> tuple[tuple[int, int, int], float, float]:
        import numpy as np

        signature_parts: list[bytes] = []
        for position, cell in enumerate(self.date_cells):
            x, y, width, height = (int(value) for value in cell)
            patch = gray[y:y + height, x:x + width]
            features = outlined_white_features(
                patch,
                self.white_threshold,
                self.contrast_threshold,
                self.outline_radius,
            )
            rows, columns, _ = self._position_probes[position]
            signature_parts.append(np.packbits(features[rows, columns]).tobytes())
        signature = b"".join(signature_parts)
        cached = self._date_cache.get(signature)
        if cached is not None:
            return cached

        year, _, year_best, year_margin = self._best_sequence(
            costs[:4], [(value, f"{value:04d}") for value in range(2000, 2100)]
        )
        month, _, month_best, month_margin = self._best_sequence(
            costs[4:6], [(value, f"{value:02d}") for value in range(1, 13)]
        )
        following_month = dt.date(year + (month == 12), month % 12 + 1, 1)
        maximum_day = (following_month - dt.timedelta(days=1)).day
        day, _, day_best, day_margin = self._best_sequence(
            costs[6:8], [(value, f"{value:02d}") for value in range(1, maximum_day + 1)]
        )
        result = (
            (year, month, day),
            year_best + month_best + day_best,
            min(year_margin, month_margin, day_margin),
        )
        if len(self._date_cache) > 64:
            self._date_cache.clear()
        self._date_cache[signature] = result
        return result

    def read_pixels(
        self,
        pixels: bytes,
        width: int,
        height: int,
        offset: float,
        timezone: dt.tzinfo,
        expected_timestamp: dt.datetime | None = None,
    ) -> OCRReading:
        import numpy as np

        if (width, height) != (self.roi[2], self.roi[3]):
            raise CatalogError(f"Unexpected glyph strip size {width}x{height}")
        # A single bootstrap read establishes the calendar date and initial
        # clock.  All subsequent adjacent-frame verification uses only the
        # deterministic glyph model.  This keeps the experimental fork safe
        # while the available May recordings do not contain all ten digits in
        # every proportional date-field position.
        if expected_timestamp is None:
            initial = super().read_pixels(pixels, width, height, offset, timezone)
            self._thread_local.bootstrap_date = initial.timestamp.date()
            return initial
        gray = np.frombuffer(pixels, dtype=np.uint8).reshape((height, width))
        time_costs = np.stack(
            [
                self._cell_costs(gray, cell, position + len(self.date_cells))
                for position, cell in enumerate(self.time_cells)
            ]
        )
        expected_local = expected_timestamp.astimezone(timezone)
        preceding_local = expected_local - dt.timedelta(seconds=1)

        def clock_cost(value: dt.datetime) -> float:
            return sum(
                float(time_costs[position, int(digit)])
                for position, digit in enumerate(value.strftime("%H%M%S"))
            )

        expected_cost = clock_cost(expected_local)
        preceding_cost = clock_cost(preceding_local)
        timestamp = expected_local if expected_cost <= preceding_cost else preceding_local
        margin = abs(expected_cost - preceding_cost)
        # Reject a closed-set answer when neither candidate resembles the
        # seconds-unit glyph.  That position supplied the canonical training
        # templates and is therefore safe for an absolute open-set check;
        # other proportional clock positions are used only comparatively.
        # This catches a real :57 -> :01 jump which would otherwise be forced
        # to :58 merely because :58 is the less-bad of two wrong choices.
        expected_unit = int(expected_local.strftime("%S")[-1])
        preceding_unit = int(preceding_local.strftime("%S")[-1])
        candidate_unit_cost = min(
            float(time_costs[5, expected_unit]),
            float(time_costs[5, preceding_unit]),
        )
        candidate_penalty = max(
            0.0,
            candidate_unit_cost - float(np.min(time_costs[5])),
        )
        raw_date = timestamp.strftime("%Y年%m月%d日")
        raw_time = timestamp.strftime("%H:%M:%S")
        separation = 1.0 - float(np.exp(-margin * 8.0))
        # The closest wrong successor in the supplied cameras can be only
        # about 0.08 NLL/probe worse than the actually displayed digit (the
        # verified :07 -> :09 skip is one example).  A 0.05 grace margin keeps
        # ordinary compression variation on the finite fast path while making
        # that wrong closed-set answer invoke the contextual OCR fallback.
        open_set_fit = float(np.exp(-max(0.0, candidate_penalty - 0.05) * 8.0))
        confidence = max(0.0, min(0.999, max(0.80, separation) * open_set_fit))
        return OCRReading(
            offset=offset,
            timestamp=timestamp,
            confidence=confidence,
            text=timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            raw_date=raw_date,
            raw_time=raw_time,
            observed_timestamp=timestamp,
        )

    def read_exception_pixels(
        self,
        pixels: bytes,
        width: int,
        height: int,
        offset: float,
        timezone: dt.tzinfo,
        expected_timestamp: dt.datetime | None = None,
    ) -> OCRReading:
        """Use neural OCR only after a non-successor cell change is observed."""
        return super().read_pixels(
            pixels,
            width,
            height,
            offset,
            timezone,
            expected_timestamp,
        )

    def read_seconds_high_threshold(
        self,
        pixels: bytes,
        width: int,
        height: int,
        offset: float,
    ) -> tuple[int, float, str] | None:
        # The glyph decoder already thresholds only calibrated stroke probes;
        # the neural recognizer's separate high-threshold retry is unnecessary.
        return None

    def timestamp_change_scores(
        self,
        previous_pixels: bytes,
        current_pixels: bytes,
        width: int,
        height: int,
    ) -> tuple[float, ...]:
        # Full cells are still tiny (6 * 36 * 56 bytes) and proved more
        # sensitive to every compressed glyph transition than the sparse
        # recognition probes.  Only recognition—not change detection—uses the
        # learned subset.
        return super().timestamp_change_scores(
            previous_pixels,
            current_pixels,
            width,
            height,
        )


def build_glyph_templates(
    videos: Sequence[Path],
    output: Path,
    ffmpeg: str,
    sample_seconds: float,
    sample_fps: float,
    minimum_confidence: float,
) -> None:
    """Calibrate stable digit-stroke probabilities from OCR-labelled frames."""
    import numpy as np

    if sample_seconds <= 0 or sample_fps <= 0:
        raise CatalogError("Template sample duration and rate must be positive")
    recognizer = TimestampOCR(ffmpeg)
    samples: list[list[Any]] = [[] for _ in range(10)]
    position_samples: list[list[tuple[int, Any]]] = [[] for _ in range(14)]
    accepted_frames = 0
    rejected_frames = 0
    roi_x, roi_y, roi_width, roi_height = recognizer.roi
    frame_bytes = roi_width * roi_height
    maximum_frames = max(1, int(sample_seconds * sample_fps + 0.5))
    for raw_video in videos:
        video = raw_video.resolve()
        if not video.is_file():
            raise CatalogError(f"Template training video does not exist: {video}")
        LOG.info("Sampling glyphs from %s", video.name)
        filters = [
            f"scale={recognizer.reference_width}:{recognizer.reference_height}:flags=neighbor",
            f"crop={roi_width}:{roi_height}:{roi_x}:{roi_y}",
            f"fps={sample_fps:.6f}",
            "format=gray",
        ]
        command = [
            ffmpeg,
            "-hide_banner", "-loglevel", "warning",
            "-i", str(video),
            "-t", f"{sample_seconds:.6f}",
            "-map", "0:v:0",
            "-vf", ",".join(filters),
            "-pix_fmt", "gray",
            "-f", "rawvideo", "-",
        ]
        stderr_file = tempfile.TemporaryFile()
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=stderr_file)
        except FileNotFoundError as exc:
            stderr_file.close()
            raise CatalogError(f"FFmpeg executable not found: {ffmpeg!r}") from exc
        assert process.stdout is not None
        try:
            for frame_index in range(maximum_frames):
                pixels = read_exact(process.stdout, frame_bytes)
                if not pixels:
                    break
                if len(pixels) != frame_bytes:
                    raise CatalogError(
                        f"FFmpeg emitted a partial training frame for {video}: "
                        f"{len(pixels)}/{frame_bytes} bytes"
                    )
                try:
                    reading = recognizer.read_pixels(
                        pixels,
                        roi_width,
                        roi_height,
                        frame_index / sample_fps,
                        UTC,
                    )
                except CatalogError:
                    rejected_frames += 1
                    continue
                if reading.confidence < minimum_confidence:
                    rejected_frames += 1
                    continue
                accepted_frames += 1
                gray = np.frombuffer(pixels, dtype=np.uint8).reshape((roi_height, roi_width))
                labels = reading.timestamp.strftime("%Y%m%d%H%M%S")
                cells = (*recognizer.date_cells, *recognizer.time_cells)
                for position, (digit, cell) in enumerate(zip(labels, cells)):
                    x, y, width, height = (int(value) for value in cell)
                    patch = gray[y:y + height, x:x + width].copy()
                    position_samples[position].append((int(digit), patch))
                    if position == len(cells) - 1:
                        samples[int(digit)].append(patch)
            process.stdout.close()
            return_code = process.wait(timeout=max(60.0, sample_seconds * 3.0))
            if return_code:
                stderr_file.seek(0)
                tail = stderr_file.read().decode("utf-8", "replace")[-4000:]
                raise CatalogError(
                    f"FFmpeg failed while sampling {video} with exit code {return_code}: {tail}"
                )
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            stderr_file.close()

    counts = np.asarray([len(values) for values in samples], dtype=np.int32)
    if int(counts.min()) < 12:
        raise CatalogError(
            "Not enough trustworthy examples to calibrate every digit; "
            f"counts={counts.tolist()}, accepted_frames={accepted_frames}, rejected_frames={rejected_frames}"
        )
    white_threshold = 90
    contrast_threshold = 55
    outline_radius = 2
    probabilities = np.stack(
        [
            np.mean(
                np.stack(
                    [
                        outlined_white_features(value, white_threshold, contrast_threshold, outline_radius).reshape(-1)
                        for value in values
                    ],
                    axis=0,
                ),
                axis=0,
                dtype=np.float64,
            )
            for values in samples
        ]
    ).astype(np.float32)
    spread = probabilities.max(axis=0) - probabilities.min(axis=0)
    probe_indices = np.flatnonzero(
        (spread >= 0.45) & (probabilities.max(axis=0) >= 0.65)
    ).astype(np.int32)
    if len(probe_indices) < 32:
        raise CatalogError(
            f"Calibration found only {len(probe_indices)} discriminating glyph pixels; "
            f"maximum probability={float(probabilities.max()):.3f}, "
            f"maximum cross-digit spread={float(spread.max()):.3f}, counts={counts.tolist()}; "
            "use more or more varied training videos"
        )
    binary_templates = probabilities[:, probe_indices] >= 0.5
    minimum_pair_distance = min(
        int(np.count_nonzero(binary_templates[left] != binary_templates[right]))
        for left in range(10)
        for right in range(left + 1, 10)
    )
    if minimum_pair_distance < 6:
        raise CatalogError(
            f"Calibrated digit templates are separated by only {minimum_pair_distance} probes; "
            "use more varied training frames"
        )
    probe_rows = probe_indices // recognizer.cell_width
    probe_columns = probe_indices % recognizer.cell_width
    log_white = np.log(np.clip(probabilities[:, probe_indices], 0.02, 0.98))
    log_not_white = np.log1p(-np.clip(probabilities[:, probe_indices], 0.02, 0.98))
    cell_offsets: list[tuple[int, int]] = []
    for position, values in enumerate(position_samples):
        # Thirty varied samples are enough to locate a fixed cell while keeping
        # one-time calibration fast.  Every score uses the known OCR label,
        # never the best-looking alternative digit.
        stride = max(1, len(values) // 30)
        selected = values[::stride][:30]
        prepared = [
            (
                digit,
                outlined_white_features(
                    patch,
                    white_threshold,
                    contrast_threshold,
                    outline_radius,
                ),
            )
            for digit, patch in selected
        ]
        best_offset: tuple[float, int, int] | None = None
        for y_offset in range(-3, 4):
            for x_offset in range(-10, 11):
                rows = probe_rows + y_offset
                columns = probe_columns + x_offset
                valid = (
                    (rows >= 0)
                    & (rows < recognizer.cell_height)
                    & (columns >= 0)
                    & (columns < recognizer.cell_width)
                )
                if int(np.count_nonzero(valid)) < len(probe_indices) * 0.65:
                    continue
                template_indices = np.flatnonzero(valid)
                total = 0.0
                for digit, features in prepared:
                    observed = features[rows[valid], columns[valid]].astype(np.float32)
                    total += float(
                        -np.mean(
                            observed * log_white[digit, template_indices]
                            + (1.0 - observed) * log_not_white[digit, template_indices]
                        )
                    )
                candidate = (total / max(len(prepared), 1), x_offset, y_offset)
                if best_offset is None or candidate < best_offset:
                    best_offset = candidate
        if best_offset is None:
            raise CatalogError(f"Could not calibrate glyph alignment for timestamp cell {position}")
        cell_offsets.append((best_offset[1], best_offset[2]))
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata = {
        "format": 1,
        "source_video_count": len(videos),
        "accepted_frames": accepted_frames,
        "rejected_frames": rejected_frames,
        "counts": counts.tolist(),
        "probe_count": int(len(probe_indices)),
        "minimum_pair_distance": minimum_pair_distance,
        "cell_offsets": cell_offsets,
        "created_utc": utc_now_text(),
    }
    np.savez_compressed(
        output,
        white_probability=probabilities,
        probe_indices=probe_indices,
        white_threshold=np.asarray(white_threshold, dtype=np.int16),
        contrast_threshold=np.asarray(contrast_threshold, dtype=np.int16),
        outline_radius=np.asarray(outline_radius, dtype=np.int16),
        cell_width=np.asarray(recognizer.cell_width, dtype=np.int16),
        cell_height=np.asarray(recognizer.cell_height, dtype=np.int16),
        counts=counts,
        cell_offsets=np.asarray(cell_offsets, dtype=np.int16),
        metadata=np.asarray(json.dumps(metadata, sort_keys=True)),
    )
    LOG.info(
        "Wrote %s with %d probes from %d accepted frames; per-digit samples=%s, minimum pair distance=%d",
        output,
        len(probe_indices),
        accepted_frames,
        counts.tolist(),
        minimum_pair_distance,
    )


def command_build_templates(args: argparse.Namespace) -> int:
    build_glyph_templates(
        args.videos,
        args.output,
        args.ffmpeg,
        args.sample_seconds,
        args.sample_fps,
        args.minimum_confidence,
    )
    return 0


def frame_pts(video: Path, ffprobe: str, ffmpeg_threads: int = 0) -> list[float]:
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    completed = run_command(
        [
            ffprobe,
            "-v", "error",
            *thread_arguments,
            "-select_streams", "v:0",
            "-show_frames",
            "-show_entries", "frame=best_effort_timestamp_time",
            "-of", "json",
            str(video),
        ],
        f"enumerate presentation timestamps in {video}",
        timeout=900,
    )
    try:
        frames = json.loads(completed.stdout).get("frames", [])
        result = [float(item["best_effort_timestamp_time"]) for item in frames]
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CatalogError(f"FFprobe returned unusable frame timestamps for {video}") from exc
    if not result:
        raise CatalogError(f"FFprobe found no timestamped video frames in {video}")
    if any(right < left for left, right in zip(result, result[1:])):
        raise CatalogError(f"FFprobe returned non-monotonic presentation timestamps for {video}")
    return result


def showinfo_pts_seconds(stderr: bytes, context: str) -> list[float]:
    """Read exact timestamps from FFmpeg's ``showinfo`` diagnostics.

    FFmpeg 6.1 can render ``pts_time`` with too few significant digits when an
    MPEG clock is already tens of thousands of seconds from zero. The integer
    ``pts`` and declared time base remain exact, so derive seconds from them.
    """
    text = stderr.decode("utf-8", "replace")
    time_base = re.search(r"\bconfig in time_base:\s*(-?\d+)\s*/\s*(\d+)", text)
    if not time_base:
        raise CatalogError(f"FFmpeg showinfo did not declare a time base while attempting to {context}")
    numerator, denominator = (int(value) for value in time_base.groups())
    if numerator <= 0 or denominator <= 0:
        raise CatalogError(
            f"FFmpeg showinfo returned invalid time base {numerator}/{denominator} "
            f"while attempting to {context}"
        )
    integer_pts = [int(value) for value in re.findall(r"\bn:\s*\d+\s+pts:\s*(-?\d+)\b", text)]
    if not integer_pts:
        raise CatalogError(f"FFmpeg showinfo returned no integer frame PTS while attempting to {context}")
    scale = numerator / denominator
    return [value * scale for value in integer_pts]


_SHOWINFO_END = object()


class ShowInfoPTSStream:
    """Drain FFmpeg stderr and expose exact showinfo PTS values in frame order."""

    def __init__(self, stream: Any, context: str):
        self.stream = stream
        self.context = context
        self.values: "queue.Queue[float | object]" = queue.Queue()
        self.count = 0
        self.error: Exception | None = None
        self.tail: "collections.deque[str]" = collections.deque(maxlen=40)
        self.thread = threading.Thread(target=self._read, name="showinfo-pts", daemon=True)
        self.thread.start()

    def _read(self) -> None:
        scale: float | None = None
        try:
            for raw_line in self.stream:
                line = raw_line.decode("utf-8", "replace")
                self.tail.append(line.rstrip())
                time_base = re.search(r"\bconfig in time_base:\s*(-?\d+)\s*/\s*(\d+)", line)
                if time_base:
                    numerator, denominator = (int(value) for value in time_base.groups())
                    if numerator <= 0 or denominator <= 0:
                        raise CatalogError(
                            f"FFmpeg showinfo returned invalid time base {numerator}/{denominator} "
                            f"while attempting to {self.context}"
                        )
                    scale = numerator / denominator
                frame_pts = re.search(r"\bn:\s*\d+\s+pts:\s*(-?\d+)\b", line)
                if frame_pts:
                    if scale is None:
                        raise CatalogError(
                            f"FFmpeg showinfo emitted a frame before declaring its time base "
                            f"while attempting to {self.context}"
                        )
                    self.values.put(int(frame_pts.group(1)) * scale)
                    self.count += 1
        except Exception as exc:
            self.error = exc
        finally:
            self.values.put(_SHOWINFO_END)

    def next(self, timeout: float = 180.0) -> float:
        try:
            value = self.values.get(timeout=timeout)
        except queue.Empty as exc:
            raise CatalogError(
                f"Timed out waiting for FFmpeg frame PTS while attempting to {self.context}"
            ) from exc
        if value is _SHOWINFO_END:
            if self.error is not None:
                raise CatalogError(str(self.error)) from self.error
            raise CatalogError(
                f"FFmpeg showinfo ended before the corresponding raw frame while attempting to {self.context}"
            )
        return float(value)

    def finish(self) -> None:
        self.thread.join(timeout=120)
        if self.thread.is_alive():
            raise CatalogError(f"Timed out draining FFmpeg diagnostics while attempting to {self.context}")
        if self.error is not None:
            raise CatalogError(str(self.error)) from self.error

    def stderr_tail(self) -> str:
        return "\n".join(self.tail)[-4000:]


def video_packet_pts(
    video: Path,
    ffprobe: str,
    ffmpeg_threads: int = 0,
) -> list[tuple[float, bool]]:
    """Enumerate video packet PTS/keyframe flags without decoding the stream."""
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    completed = run_command(
        [
            ffprobe,
            "-v", "error",
            *thread_arguments,
            "-select_streams", "v:0",
            "-show_packets",
            "-show_entries", "packet=pts_time,flags",
            "-of", "csv=p=0",
            str(video),
        ],
        f"enumerate video packets in {video}",
        timeout=900,
    )
    packets: list[tuple[float, bool]] = []
    for line_number, line in enumerate(completed.stdout.decode("utf-8", "replace").splitlines(), 1):
        columns = [value.strip() for value in line.split(",")]
        if len(columns) < 2 or columns[0] in {"", "N/A"}:
            raise CatalogError(f"Unusable packet row {line_number} for {video}: {line!r}")
        try:
            pts = float(columns[0])
        except ValueError as exc:
            raise CatalogError(f"Invalid packet PTS in row {line_number} for {video}: {line!r}") from exc
        packets.append((pts, "K" in columns[1]))
    if not packets:
        raise CatalogError(f"FFprobe found no video packets in {video}")
    packets.sort(key=lambda item: item[0])
    absolute_pts = [item[0] for item in packets]
    if any(right <= left for left, right in zip(absolute_pts, absolute_pts[1:])):
        raise CatalogError(
            f"Video packet PTS values are duplicated or non-monotonic in {video}; "
            "a stable presentation-frame sequence cannot be built."
        )
    return packets


def build_packet_index(
    video: Path,
    ffprobe: str,
    ffmpeg_threads: int = 0,
    ffmpeg: str | None = None,
) -> PacketIndex:
    """Enumerate compressed access-unit timestamps without decoding pixels."""
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    packets = video_packet_pts(video, ffprobe, ffmpeg_threads)
    absolute_pts = [item[0] for item in packets]
    packet_origin = absolute_pts[0]
    relative = tuple(value - packet_origin for value in absolute_pts)
    keyframes = tuple(value - packet_origin for value, is_keyframe in packets if is_keyframe)
    if not keyframes or keyframes[0] > 0.00002:
        keyframes = (0.0, *keyframes)
    if ffmpeg:
        # Use the same decoder/filter path as projected extraction. Parse the
        # integer showinfo PTS below because FFmpeg 6.1's human-readable
        # pts_time text loses precision for large MPEG timestamps.
        first_frame = run_command(
            [
                ffmpeg,
                "-hide_banner", "-loglevel", "info",
                *thread_arguments,
                "-copyts", "-i", str(video),
                "-map", "0:v:0",
                "-vf", "showinfo",
                "-frames:v", "1",
                "-fps_mode", "passthrough",
                "-f", "null", "-",
            ],
            f"read first decoded-frame timestamp in {video}",
            timeout=120,
        )
        decoded_origin = showinfo_pts_seconds(
            first_frame.stderr,
            f"read the first decoded-frame timestamp in {video}",
        )[0]
    else:
        # Kept for library callers and inexpensive isolated tests.
        first_frame = run_command(
            [
                ffprobe,
                "-v", "error",
                *thread_arguments,
                "-select_streams", "v:0",
                "-read_intervals", "%+#1",
                "-show_frames",
                "-show_entries", "frame=best_effort_timestamp_time",
                "-of", "csv=p=0",
                str(video),
            ],
            f"read first decoded-frame timestamp in {video}",
            timeout=120,
        )
        try:
            decoded_origin = float(first_frame.stdout.decode("utf-8", "replace").splitlines()[0].strip())
        except (IndexError, ValueError) as exc:
            raise CatalogError(f"FFprobe returned no usable first decoded-frame PTS for {video}") from exc
    return PacketIndex(relative, keyframes, decoded_origin, packet_origin)


def build_frame_index(video: Path, ffprobe: str, ffmpeg_threads: int = 0) -> PacketIndex:
    """Enumerate frames FFmpeg can decode in exact presentation ``n`` order.

    Hikvision exports can contain HEVC packets that the decoder drops. Packet
    ordinal is therefore not necessarily FFmpeg's frame number. ``show_frames``
    performs a decoder pass but emits metadata only, not image pixels.
    """
    thread_arguments = ["-threads", str(ffmpeg_threads)] if ffmpeg_threads else []
    completed = run_command(
        [
            ffprobe,
            "-v", "error",
            *thread_arguments,
            "-select_streams", "v:0",
            "-show_frames",
            "-show_entries", "frame=best_effort_timestamp_time,key_frame",
            "-of", "json",
            str(video),
        ],
        f"enumerate decoded presentation frames in {video}",
        timeout=900,
    )
    try:
        rows = json.loads(completed.stdout).get("frames", [])
        frames = [
            (float(row["best_effort_timestamp_time"]), bool(int(row.get("key_frame", 0))))
            for row in rows
        ]
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CatalogError(f"FFprobe returned unusable decoded-frame metadata for {video}") from exc
    if not frames:
        raise CatalogError(f"FFprobe decoded no timestamped video frames in {video}")
    absolute_pts = [item[0] for item in frames]
    if any(right <= left for left, right in zip(absolute_pts, absolute_pts[1:])):
        raise CatalogError(
            f"Decoded video-frame PTS values are duplicated or non-monotonic in {video}; "
            "projected integer frame numbering is unsafe. Use --index-mode full."
        )
    origin = absolute_pts[0]
    relative = tuple(value - origin for value in absolute_pts)
    keyframes = tuple(value - origin for value, is_keyframe in frames if is_keyframe)
    if not keyframes or keyframes[0] > 0.00002:
        keyframes = (0.0, *keyframes)
    return PacketIndex(relative, keyframes, origin, origin)


def read_exact(stream: Any, byte_count: int) -> bytes:
    chunks: list[bytes] = []
    remaining = byte_count
    while remaining:
        chunk = stream.read(remaining)
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def mean_absolute_difference(left: bytes, right: bytes) -> float:
    if len(left) != len(right):
        raise CatalogError(f"Cannot compare OCR cells of different sizes: {len(left)} != {len(right)}")
    return sum(abs(a - b) for a, b in zip(left, right)) / max(1, len(left))


def extract_osd_window(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    packet_index: PacketIndex,
    start_seconds: float,
    end_seconds: float,
    seek_preroll: float | None = None,
) -> list[tuple[float, bytes]]:
    """Random-access a narrow presentation-time window and return OSD crops."""
    start_seconds = max(0.0, start_seconds)
    end_seconds = min(packet_index.pts_seconds[-1] + 0.0001, end_seconds)
    left = bisect.bisect_left(packet_index.pts_seconds, start_seconds - 0.00002)
    right = bisect.bisect_left(packet_index.pts_seconds, end_seconds - 0.00002)
    expected_pts = packet_index.pts_seconds[left:right]
    if not expected_pts:
        raise CatalogError(
            f"Projected OCR window {start_seconds:.3f}..{end_seconds:.3f}s contains no decoded frames in {video}"
        )
    keyframe = packet_index.preceding_keyframe(start_seconds)
    effective_preroll = 0.1 if seek_preroll is None else max(0.1, seek_preroll)
    input_seek = max(0.0, keyframe - effective_preroll)
    # Input ``-ss`` is an offset from the container start unless
    # ``-seek_timestamp`` is used. Translate the desired native video PTS to
    # that offset; audio or metadata streams may begin earlier than video.
    input_seek_offset = max(
        0.0,
        packet_index.origin_seconds + input_seek - probe.start_time,
    )
    absolute_start = packet_index.origin_seconds + start_seconds
    absolute_end = packet_index.origin_seconds + end_seconds
    x, y, roi_width, roi_height = ocr.roi
    filters = [f"trim=start={absolute_start:.6f}:end={absolute_end:.6f}"]
    if (probe.width, probe.height) != (ocr.reference_width, ocr.reference_height):
        filters.append(f"scale={ocr.reference_width}:{ocr.reference_height}:flags=neighbor")
    filters.extend([f"crop={roi_width}:{roi_height}:{x}:{y}", "format=gray", "showinfo"])
    command = [ocr.ffmpeg, "-hide_banner", "-loglevel", "info"]
    if ocr.ffmpeg_threads:
        command.extend(["-threads", str(ocr.ffmpeg_threads)])
    if input_seek_offset:
        command.extend(["-ss", f"{input_seek_offset:.6f}"])
    command.extend(
        [
            # Keep the stream's native PTS origin. ``-start_at_zero`` shifts
            # against the container/input start time, which is not guaranteed
            # to equal the first video-frame PTS in every Hikvision export.
            "-copyts", "-i", str(video),
            "-map", "0:v:0",
            "-vf", ",".join(filters),
            "-frames:v", str(len(expected_pts)),
            "-fps_mode", "passthrough",
            "-pix_fmt", "gray",
            "-f", "rawvideo",
            "-",
        ]
    )
    completed = run_command(
        command,
        f"decode projected OSD window {start_seconds:.3f}..{end_seconds:.3f}s from {video}",
        timeout=180,
    )
    absolute_pts_values = showinfo_pts_seconds(
        completed.stderr,
        f"decode projected OSD window {start_seconds:.3f}..{end_seconds:.3f}s from {video}",
    )
    pts_values = [value - packet_index.origin_seconds for value in absolute_pts_values]
    frame_bytes = roi_width * roi_height
    if len(completed.stdout) % frame_bytes:
        raise CatalogError(
            f"FFmpeg emitted a partial raw OCR frame for {video}: "
            f"{len(completed.stdout)} bytes is not divisible by {frame_bytes}"
        )
    frames = [
        completed.stdout[index:index + frame_bytes]
        for index in range(0, len(completed.stdout), frame_bytes)
    ]

    def retry_with_safe_preroll(reason: str) -> list[tuple[float, bytes]]:
        if seek_preroll is None and input_seek > 0 and ocr.seek_preroll > effective_preroll:
            diagnostic_event(
                "assumption_failed_recoverable",
                video=video,
                assumption="A marked keyframe can independently decode the requested GOP window.",
                details={
                    "recovery": "retry_with_longer_preroll",
                    "reason": reason,
                    "window_start_seconds": start_seconds,
                    "window_end_seconds": end_seconds,
                    "preceding_keyframe_pts_seconds": keyframe,
                    "short_preroll_seconds": effective_preroll,
                    "retry_preroll_seconds": ocr.seek_preroll,
                    "input_seek_offset_seconds": input_seek_offset,
                    "native_video_pts_origin_seconds": packet_index.origin_seconds,
                    "first_packet_pts_seconds": packet_index.packet_origin_seconds,
                    "decoded_minus_packet_origin_seconds": (
                        packet_index.origin_seconds - packet_index.packet_origin_seconds
                        if packet_index.packet_origin_seconds is not None else None
                    ),
                    "container_start_time_seconds": probe.start_time,
                    "expected_indexed_frames": len(expected_pts),
                    "decoded_raw_frames": len(frames),
                    "decoded_showinfo_frames": len(pts_values),
                    "expected_first_pts_seconds": expected_pts[0] if expected_pts else None,
                    "expected_last_pts_seconds": expected_pts[-1] if expected_pts else None,
                    "decoded_first_pts_seconds": pts_values[0] if pts_values else None,
                    "decoded_last_pts_seconds": pts_values[-1] if pts_values else None,
                },
            )
            LOG.warning(
                "Short keyframe seek was not independently decodable in %s at %.3fs (%s); "
                "retrying this GOP with %.1fs preroll",
                video.name,
                start_seconds,
                reason,
                ocr.seek_preroll,
            )
            return extract_osd_window(
                video,
                probe,
                ocr,
                packet_index,
                start_seconds,
                end_seconds,
                ocr.seek_preroll,
            )
        raise CatalogError(reason)

    if len(frames) != len(pts_values) or len(frames) != len(expected_pts):
        return retry_with_safe_preroll(
            f"Projected decode count mismatch for {video} at {start_seconds:.3f}s: "
            f"raw_frames={len(frames)}, showinfo={len(pts_values)}, indexed_frames={len(expected_pts)}. "
            "Use --index-mode full for this file."
        )
    for decoded, expected in zip(pts_values, expected_pts):
        if abs(decoded - expected) > 0.00002:
            return retry_with_safe_preroll(
                f"Projected decode PTS mismatch for {video}: decoded={decoded:.6f}, "
                f"indexed_frame={expected:.6f}, native_origin={packet_index.origin_seconds:.6f}. "
                "Use --index-mode full."
            )
    return list(zip(pts_values, frames))


def locate_projected_boundary(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    packet_index: PacketIndex,
    timezone: dt.tzinfo,
    target_timestamp: dt.datetime,
    projection: float,
    search_seconds: float,
    minimum_confidence: float,
    transition_threshold: float,
) -> SecondFrame:
    window = extract_osd_window(
        video,
        probe,
        ocr,
        packet_index,
        projection - search_seconds,
        projection + search_seconds,
    )
    return verify_projected_boundary(
        video,
        ocr,
        packet_index,
        timezone,
        target_timestamp,
        projection,
        search_seconds,
        minimum_confidence,
        transition_threshold,
        window,
    )


def verify_projected_boundary(
    video: Path,
    ocr: TimestampOCR,
    packet_index: PacketIndex,
    timezone: dt.tzinfo,
    target_timestamp: dt.datetime,
    projection: float,
    search_seconds: float,
    minimum_confidence: float,
    transition_threshold: float,
    decoded_window: Sequence[tuple[float, bytes]],
) -> SecondFrame:
    """Verify one projected transition inside an already decoded GOP batch."""
    pts = [item[0] for item in decoded_window]
    left = bisect.bisect_left(pts, projection - search_seconds - 0.00002)
    right = bisect.bisect_left(pts, projection + search_seconds - 0.00002)
    window = decoded_window[left:right]
    diagnostics: list[str] = []
    for (previous_pts, previous_pixels), (current_pts, current_pixels) in zip(window, window[1:]):
        previous_units = ocr.second_units_pixels(previous_pixels, ocr.roi[2], ocr.roi[3])
        current_units = ocr.second_units_pixels(current_pixels, ocr.roi[2], ocr.roi[3])
        difference = mean_absolute_difference(previous_units, current_units)
        if difference < transition_threshold:
            continue
        try:
            previous = ocr.read_pixels(previous_pixels, ocr.roi[2], ocr.roi[3], previous_pts, timezone)
            current = ocr.read_pixels(current_pixels, ocr.roi[2], ocr.roi[3], current_pts, timezone)
        except CatalogError as exc:
            diagnostics.append(f"pixel_delta={difference:.3f}: {exc}")
            continue
        diagnostics.append(
            f"pixel_delta={difference:.3f}: {previous.text} ({previous.confidence:.3f}) -> "
            f"{current.text} ({current.confidence:.3f})"
        )
        if (
            previous.confidence >= minimum_confidence
            and current.confidence >= minimum_confidence
            and current.timestamp == target_timestamp
            and current.timestamp == previous.timestamp + dt.timedelta(seconds=1)
        ):
            previous_number = packet_index.frame_number(previous_pts)
            current_number = packet_index.frame_number(current_pts)
            if current_number != previous_number + 1:
                raise CatalogError(
                    f"Verified timestamp transition {target_timestamp.isoformat()} spans non-adjacent packet frames "
                    f"{previous_number}->{current_number} in {video}"
                )
            return SecondFrame(
                current.timestamp,
                current_number,
                previous_number,
                current_pts,
                previous_pts,
                current.text,
                previous.text,
                current.confidence,
                previous.confidence,
            )
    raise CatalogError(
        f"Could not verify projected boundary {target_timestamp.isoformat()} near {projection:.3f}s in {video}; "
        f"window={projection - search_seconds:.3f}..{projection + search_seconds:.3f}s, "
        f"candidates={diagnostics[:6]}"
    )


def locate_projected_group(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    packet_index: PacketIndex,
    timezone: dt.tzinfo,
    projected_targets: Sequence[tuple[dt.datetime, float]],
    search_seconds: float,
    minimum_confidence: float,
    transition_threshold: float,
    expanded: bool = False,
) -> list[SecondFrame]:
    """Decode a GOP once and verify all projected second boundaries in it."""
    start = min(projection for _, projection in projected_targets) - search_seconds
    end = max(projection for _, projection in projected_targets) + search_seconds
    window = extract_osd_window(video, probe, ocr, packet_index, start, end)
    try:
        return [
            verify_projected_boundary(
                video,
                ocr,
                packet_index,
                timezone,
                target,
                projection,
                search_seconds,
                minimum_confidence,
                transition_threshold,
                window,
            )
            for target, projection in projected_targets
        ]
    except CatalogError as exc:
        if expanded or search_seconds >= 0.75:
            raise
        expanded_search = max(0.75, search_seconds * 3.0)
        diagnostic_event(
            "assumption_failed_recoverable",
            video=video,
            assumption=(
                "The endpoint-fitted overlay clock predicts every local second transition "
                "within the configured narrow search radius."
            ),
            details={
                "recovery": "retry_gop_with_expanded_boundary_window",
                "reason": str(exc),
                "targets": [target.isoformat() for target, _ in projected_targets],
                "initial_search_seconds": search_seconds,
                "expanded_search_seconds": expanded_search,
            },
        )
        return locate_projected_group(
            video,
            probe,
            ocr,
            packet_index,
            timezone,
            projected_targets,
            expanded_search,
            minimum_confidence,
            transition_threshold,
            True,
        )


def index_second_frames_projected(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    ffprobe: str,
    timezone: dt.tzinfo,
    minimum_confidence: float,
    transition_threshold: float,
    search_seconds: float,
    boundary_workers: int,
    decoded_index: bool = False,
) -> tuple[tuple[SecondFrame, ...], FrameObservation, FrameObservation]:
    packet_index = (
        build_frame_index(video, ffprobe, ocr.ffmpeg_threads)
        if decoded_index
        else build_packet_index(video, ffprobe, ocr.ffmpeg_threads, ocr.ffmpeg)
    )
    last_pts = packet_index.pts_seconds[-1]
    try:
        first_window = extract_osd_window(video, probe, ocr, packet_index, 0.0, 0.35)
        last_window = extract_osd_window(
            video,
            probe,
            ocr,
            packet_index,
            max(0.0, last_pts - 0.35),
            last_pts + 0.0001,
        )
    except CatalogError as exc:
        mismatch = "decode PTS mismatch" in str(exc) or "decode count mismatch" in str(exc)
        if mismatch and not decoded_index:
            diagnostic_event(
                "assumption_failed_recoverable",
                video=video,
                assumption=(
                    "Packet-relative timestamps and decoded-frame-relative timestamps "
                    "remain aligned across the complete video."
                ),
                details={
                    "recovery": "rebuild_index_from_decoded_frame_metadata",
                    "reason": str(exc),
                    "packet_index_entries": len(packet_index.pts_seconds),
                    "keyframe_entries": len(packet_index.keyframe_pts_seconds),
                    "first_decoded_frame_pts_seconds": packet_index.origin_seconds,
                    "first_packet_pts_seconds": packet_index.packet_origin_seconds,
                    "decoded_minus_packet_origin_seconds": (
                        packet_index.origin_seconds - packet_index.packet_origin_seconds
                        if packet_index.packet_origin_seconds is not None else None
                    ),
                    "container_start_time_seconds": probe.start_time,
                },
            )
            LOG.warning(
                "Packet-relative timing does not match decoded frames for %s; "
                "rebuilding this file's exact frame index from decoded metadata",
                video.name,
            )
            return index_second_frames_projected(
                video,
                probe,
                ocr,
                ffprobe,
                timezone,
                minimum_confidence,
                transition_threshold,
                search_seconds,
                boundary_workers,
                True,
            )
        raise
    first_pts, first_pixels = first_window[0]
    final_pts, final_pixels = last_window[-1]
    first_reading = ocr.read_pixels(first_pixels, ocr.roi[2], ocr.roi[3], first_pts, timezone)
    last_reading = ocr.read_pixels(final_pixels, ocr.roi[2], ocr.roi[3], final_pts, timezone)
    if min(first_reading.confidence, last_reading.confidence) < minimum_confidence:
        raise CatalogError(
            f"Endpoint OCR confidence is too low for {video}: "
            f"first={first_reading.confidence:.3f}, last={last_reading.confidence:.3f}"
        )
    targets: list[dt.datetime] = []
    timestamp = first_reading.timestamp + dt.timedelta(seconds=1)
    while timestamp <= last_reading.timestamp:
        targets.append(timestamp)
        timestamp += dt.timedelta(seconds=1)
    if not targets:
        raise CatalogError(
            f"The OSD did not advance by a complete second in {video}: "
            f"first={first_reading.text!r}, last={last_reading.text!r}"
        )

    # Establish the affine relationship between the recorder's burned-in clock
    # and the container PTS clock from two verified transitions.  They are not
    # assumed to run at exactly the same rate: real Hikvision exports can drift
    # enough for a simple start+N projection to miss a narrow window.
    anchor_search = max(1.25, search_seconds)
    first_anchor = locate_projected_boundary(
        video,
        probe,
        ocr,
        packet_index,
        timezone,
        targets[0],
        min(1.0, last_pts),
        anchor_search,
        minimum_confidence,
        transition_threshold,
    )
    if len(targets) == 1:
        anchors = {targets[0]: first_anchor}
        seconds_per_osd_second = 1.0
    else:
        last_anchor = locate_projected_boundary(
            video,
            probe,
            ocr,
            packet_index,
            timezone,
            targets[-1],
            max(0.0, last_pts - 0.5),
            anchor_search,
            minimum_confidence,
            transition_threshold,
        )
        osd_span = (last_anchor.timestamp - first_anchor.timestamp).total_seconds()
        pts_span = last_anchor.pts_seconds - first_anchor.pts_seconds
        if osd_span <= 0 or pts_span <= 0:
            raise CatalogError(
                f"Invalid OSD/PTS anchors for {video}: "
                f"{first_anchor.timestamp.isoformat()}@{first_anchor.pts_seconds:.6f} -> "
                f"{last_anchor.timestamp.isoformat()}@{last_anchor.pts_seconds:.6f}"
            )
        seconds_per_osd_second = pts_span / osd_span
        anchors = {targets[0]: first_anchor, targets[-1]: last_anchor}
    LOG.info(
        "Projected OSD clock for %s from verified anchors at %.6fs and %.6fs "
        "(PTS seconds per OSD second %.9f)",
        video.name,
        first_anchor.pts_seconds,
        anchors[targets[-1]].pts_seconds,
        seconds_per_osd_second,
    )

    boundaries: list[SecondFrame] = []
    failures: list[str] = []
    boundaries.extend(anchors.values())
    projected_targets = [
        (
            target,
            first_anchor.pts_seconds
            + (target - first_anchor.timestamp).total_seconds() * seconds_per_osd_second,
        )
        for target in targets
        if target not in anchors
    ]
    groups: dict[float, list[tuple[dt.datetime, float]]] = {}
    for target, projection in projected_targets:
        # Seeking has to decode from the preceding keyframe. Boundaries sharing
        # that dependency are therefore cheaper and safer to decode as one job.
        keyframe = packet_index.preceding_keyframe(max(0.0, projection - search_seconds))
        groups.setdefault(keyframe, []).append((target, projection))
    workers = min(max(1, boundary_workers), max(1, len(groups)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="boundary") as pool:
        futures = {
            pool.submit(
                locate_projected_group,
                video,
                probe,
                ocr,
                packet_index,
                timezone,
                group,
                search_seconds,
                minimum_confidence,
                transition_threshold,
            ): group
            for group in groups.values()
        }
        for future in concurrent.futures.as_completed(futures):
            group = futures[future]
            try:
                boundaries.extend(future.result())
            except Exception as exc:
                labels = [target.isoformat() for target, _ in group]
                failures.append(f"group {labels}: {exc}")
    boundaries.sort(key=lambda item: item.timestamp)
    if failures or [item.timestamp for item in boundaries] != targets:
        mismatch = any(
            "decode PTS mismatch" in failure or "decode count mismatch" in failure
            for failure in failures
        )
        if mismatch and not decoded_index:
            diagnostic_event(
                "assumption_failed_recoverable",
                video=video,
                assumption="One compressed video packet corresponds to one FFmpeg presentation frame.",
                details={
                    "recovery": "rebuild_index_from_decoded_frame_metadata",
                    "first_failures": failures[:20],
                    "verified_boundaries_before_retry": len(boundaries),
                    "expected_boundaries": len(targets),
                    "packet_index_entries": len(packet_index.pts_seconds),
                    "keyframe_entries": len(packet_index.keyframe_pts_seconds),
                    "native_video_pts_origin_seconds": packet_index.origin_seconds,
                    "first_packet_pts_seconds": packet_index.packet_origin_seconds,
                    "decoded_minus_packet_origin_seconds": (
                        packet_index.origin_seconds - packet_index.packet_origin_seconds
                        if packet_index.packet_origin_seconds is not None else None
                    ),
                    "container_start_time_seconds": probe.start_time,
                    "boundary_search_seconds": search_seconds,
                    "boundary_workers": boundary_workers,
                },
            )
            LOG.warning(
                "Packet timestamps do not describe FFmpeg's decoded-frame sequence for %s; "
                "rebuilding this file's exact frame index from decoded metadata",
                video.name,
            )
            return index_second_frames_projected(
                video,
                probe,
                ocr,
                ffprobe,
                timezone,
                minimum_confidence,
                transition_threshold,
                search_seconds,
                boundary_workers,
                True,
            )
        raise CatalogError(
            f"Projected per-second verification failed for {video}: "
            f"verified={len(boundaries)}/{len(targets)}, first failures={failures[:8]}. "
            "Increase --boundary-search-seconds or use --index-mode full."
        )
    LOG.info(
        "Verified %d first-frames-of-second in %d GOP batches across %d decoded frames in %s",
        len(boundaries), len(groups) + min(2, len(targets)), len(packet_index.pts_seconds), video.name,
    )
    first_observation = FrameObservation(
        first_reading.timestamp,
        packet_index.frame_number(first_pts),
        first_pts,
        first_reading.text,
        first_reading.confidence,
    )
    last_observation = FrameObservation(
        last_reading.timestamp,
        packet_index.frame_number(final_pts),
        final_pts,
        last_reading.text,
        last_reading.confidence,
    )
    return tuple(boundaries), first_observation, last_observation


def gpu_packet_sequence_diagnostics(
    packets: Sequence[float],
    decoded_frames: Sequence[float],
    gpu_index: int,
    tolerance: float = 0.00002,
) -> tuple[bool, dict[str, Any]]:
    """Compare packet and NVDEC presentation sequences after removing PTS origin."""
    packet_origin = packets[0] if packets else None
    decoded_origin = decoded_frames[0] if decoded_frames else None
    packet_relative = [value - packet_origin for value in packets] if packet_origin is not None else []
    decoded_relative = (
        [value - decoded_origin for value in decoded_frames] if decoded_origin is not None else []
    )
    paired = min(len(packet_relative), len(decoded_relative))
    deltas = [decoded_relative[index] - packet_relative[index] for index in range(paired)]
    mismatches = [index for index, delta in enumerate(deltas) if abs(delta) > tolerance]
    first_mismatch = mismatches[0] if mismatches else (paired if len(packets) != len(decoded_frames) else None)
    classification = "match"
    if first_mismatch is not None:
        index = first_mismatch
        if (
            index < len(decoded_relative)
            and index + 1 < len(packet_relative)
            and abs(decoded_relative[index] - packet_relative[index + 1]) <= tolerance
        ):
            classification = "gpu_missing_packet_frame"
        elif (
            index < len(packet_relative)
            and index + 1 < len(decoded_relative)
            and abs(decoded_relative[index + 1] - packet_relative[index]) <= tolerance
        ):
            classification = "gpu_extra_frame"
        elif len(decoded_frames) < len(packets):
            classification = "gpu_frame_count_short"
        elif len(decoded_frames) > len(packets):
            classification = "gpu_frame_count_long"
        else:
            classification = "pts_or_order_mismatch"

    def neighborhood(values: Sequence[float], index: int | None) -> list[float]:
        if index is None:
            return []
        start = max(0, index - 2)
        return [round(value, 9) for value in values[start:min(len(values), index + 3)]]

    details: dict[str, Any] = {
        "gpu_index": gpu_index,
        "comparison": "demuxed_video_packet_pts_vs_nvdec_showinfo_pts",
        "tolerance_seconds": tolerance,
        "packet_count": len(packets),
        "gpu_decoded_frame_count": len(decoded_frames),
        "packet_pts_origin_seconds": packet_origin,
        "gpu_pts_origin_seconds": decoded_origin,
        "packet_relative_last_seconds": packet_relative[-1] if packet_relative else None,
        "gpu_relative_last_seconds": decoded_relative[-1] if decoded_relative else None,
        "mismatched_paired_positions": len(mismatches),
        "maximum_absolute_paired_delta_seconds": max((abs(value) for value in deltas), default=None),
        "first_mismatch_frame_offset": first_mismatch,
        "classification": classification,
        "packet_relative_pts_near_first_mismatch": neighborhood(packet_relative, first_mismatch),
        "gpu_relative_pts_near_first_mismatch": neighborhood(decoded_relative, first_mismatch),
    }
    valid = first_mismatch is None
    return valid, details


def iter_full_index_frames(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    ffprobe: str,
) -> Iterator[tuple[int, float, bytes]]:
    """Yield cropped frames and exact PTS values from a sequential decode.

    CPU mode retains FFprobe's independent decoded-frame enumeration as a
    cross-check. CUDA mode deliberately uses one NVDEC/FFmpeg process: its
    showinfo integer PTS and raw OCR crop are consumed together in filter order.
    """
    pts_values = None if ocr.gpu_index is not None else frame_pts(video, ffprobe, ocr.ffmpeg_threads)
    packet_pts_values: list[float] | None = None
    if ocr.gpu_index is not None:
        try:
            packet_pts_values = [
                value for value, _ in video_packet_pts(video, ffprobe, ocr.ffmpeg_threads)
            ]
        except CatalogError as exc:
            raise GPUFrameSequenceConcern(
                f"Could not build the demuxed packet sequence required to validate NVDEC for {video}: {exc}",
                {
                    "gpu_index": ocr.gpu_index,
                    "comparison": "demuxed_video_packet_pts_vs_nvdec_showinfo_pts",
                    "classification": "packet_sequence_unavailable",
                    "packet_count": None,
                    "gpu_decoded_frame_count": None,
                    "first_mismatch_frame_offset": None,
                    "packet_enumeration_error": str(exc),
                },
            ) from exc
    x, y, roi_width, roi_height = ocr.roi
    filters = ocr.software_filter_prefix()
    if (probe.width, probe.height) != (ocr.reference_width, ocr.reference_height):
        filters.append(f"scale={ocr.reference_width}:{ocr.reference_height}:flags=neighbor")
    filters.extend([f"crop={roi_width}:{roi_height}:{x}:{y}", "format=gray"])
    if ocr.gpu_index is not None:
        filters.append("showinfo")
    command = [
        ocr.ffmpeg,
        "-hide_banner",
        "-loglevel", "info" if ocr.gpu_index is not None else "warning",
        *ocr.decoder_input_arguments(),
        "-i", str(video),
        "-map", "0:v:0",
        "-vf", ",".join(filters),
        "-fps_mode", "passthrough",
        "-pix_fmt", "gray",
        "-f", "rawvideo",
        "-",
    ]
    frame_bytes = roi_width * roi_height
    stderr_file = tempfile.TemporaryFile() if ocr.gpu_index is None else None
    stderr_target: Any = stderr_file if stderr_file is not None else subprocess.PIPE
    try:
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=stderr_target)
        except FileNotFoundError as exc:
            raise CatalogError(f"FFmpeg executable not found: {ocr.ffmpeg!r}") from exc
        assert process.stdout is not None
        pts_stream: ShowInfoPTSStream | None = None
        if ocr.gpu_index is not None:
            assert process.stderr is not None
            pts_stream = ShowInfoPTSStream(process.stderr, f"GPU full-index {video}")
        frame_number = 0
        decoded_pts_values: list[float] = []
        reached_eof = False
        try:
            while True:
                pixels = read_exact(process.stdout, frame_bytes)
                if not pixels:
                    reached_eof = True
                    break
                if len(pixels) != frame_bytes:
                    raise CatalogError(
                        f"FFmpeg emitted a partial OCR frame for {video}: {len(pixels)}/{frame_bytes} bytes"
                    )
                if pts_stream is not None:
                    offset = pts_stream.next()
                    decoded_pts_values.append(offset)
                else:
                    assert pts_values is not None
                    if frame_number >= len(pts_values):
                        raise CatalogError(
                            f"FFmpeg decoded more frames than FFprobe enumerated for {video} "
                            f"({frame_number + 1} > {len(pts_values)})"
                        )
                    offset = pts_values[frame_number]
                yield frame_number, offset, pixels
                frame_number += 1
        finally:
            process.stdout.close()
            if not reached_eof:
                process.kill()
        try:
            return_code = process.wait(timeout=120)
        except subprocess.TimeoutExpired as exc:
            process.kill()
            raise CatalogError(f"Timed out waiting for FFmpeg sequential decode of {video}") from exc
        if pts_stream is not None:
            pts_stream.finish()
            stderr = pts_stream.stderr_tail()
            if pts_stream.count != frame_number:
                raise CatalogError(
                    f"GPU frame/PTS count mismatch for {video}: raw_frames={frame_number}, "
                    f"showinfo_frames={pts_stream.count}. A stable integer frame index cannot be promised."
                )
        else:
            assert stderr_file is not None and pts_values is not None
            stderr_file.seek(0)
            stderr = stderr_file.read().decode("utf-8", "replace")
            if frame_number != len(pts_values):
                raise CatalogError(
                    f"Frame enumeration mismatch for {video}: FFmpeg decoded {frame_number}, "
                    f"FFprobe enumerated {len(pts_values)}. A stable integer frame index cannot be promised."
                )
        if return_code:
            raise CatalogError(
                f"FFmpeg sequential OCR decode failed for {video} (exit {return_code}): {stderr[-4000:]}"
            )
        if pts_stream is not None:
            assert packet_pts_values is not None and ocr.gpu_index is not None
            valid, details = gpu_packet_sequence_diagnostics(
                packet_pts_values,
                decoded_pts_values,
                ocr.gpu_index,
            )
            if not valid:
                raise GPUFrameSequenceConcern(
                    f"NVDEC frame sequence differs from demuxed video packets for {video}: "
                    f"classification={details['classification']}, "
                    f"packets={details['packet_count']}, "
                    f"gpu_frames={details['gpu_decoded_frame_count']}, "
                    f"first_mismatch={details['first_mismatch_frame_offset']}",
                    details,
                )
            diagnostic_event(
                "gpu_frame_sequence_validated",
                video=video,
                assumption="NVDEC emits one presentation frame per demuxed video packet in identical PTS order.",
                details=details,
            )
    finally:
        if stderr_file is not None:
            stderr_file.close()


def index_second_frames_full(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
    ffprobe: str,
    timezone: dt.tzinfo,
    minimum_confidence: float,
    transition_threshold: float,
) -> tuple[tuple[SecondFrame, ...], FrameObservation, FrameObservation]:
    """Decode in presentation order and OCR both sides of every OSD second transition.

    ``frame_number`` is the zero-based FFmpeg filter ``n`` for the decoded video
    stream.  ``previous_frame_number`` is always exactly one less, which makes
    the definition and its verification explicit in the database.
    """
    _, _, roi_width, roi_height = ocr.roi
    boundaries: list[SecondFrame] = []
    rejected_candidates: list[str] = []
    previous_pixels: bytes | None = None
    previous_units: bytes | None = None
    previous_pts: float | None = None
    first_reading: OCRReading | None = None
    seen_timestamps: set[dt.datetime] = set()
    verified_forward_gaps: list[tuple[dt.datetime, dt.datetime]] = []
    discontinuity_count = 0
    contextual_correction_count = 0
    alternate_correction_count = 0
    last_displayed_timestamp: dt.datetime | None = None
    last_pixels: bytes | None = None
    first_pts: float | None = None
    last_pts: float | None = None
    decoded_frames = 0
    pending_context: PendingContextTransition | None = None
    pending_discontinuity: PendingDiscontinuityTransition | None = None
    pending_early_successor: PendingDiscontinuityTransition | None = None
    pending_confirmation_attempts = 0
    glyph_fallback_attempts = 0
    glyph_fallback_transitions = 0
    last_boundary_pts: float | None = None

    def as_observed(reading: OCRReading) -> OCRReading:
        if reading.observed_timestamp is None or reading.observed_timestamp == reading.timestamp:
            return reading
        return dataclasses.replace(
            reading,
            timestamp=reading.observed_timestamp,
            text=reading.observed_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            context_corrected=False,
        )

    def commit_transition(
        previous_reading: OCRReading,
        current_reading: OCRReading,
        frame_number: int,
        previous_frame_pts: float,
        frame_pts: float,
        pixel_delta: float,
    ) -> None:
        nonlocal discontinuity_count, contextual_correction_count, last_displayed_timestamp, last_boundary_pts
        delta_seconds = int(
            (current_reading.timestamp - previous_reading.timestamp).total_seconds()
        )
        for role, reading in (("previous", previous_reading), ("current", current_reading)):
            if reading.context_corrected:
                contextual_correction_count += 1
                diagnostic_event(
                    "ocr_temporal_context_correction",
                    video=video,
                    assumption=(
                        "A single corrupted clock glyph may be corrected only when the OCR date "
                        "matches temporal context and the raw alternative does not persist into "
                        "the next decoded frame."
                    ),
                    details={
                        "role": role,
                        "frame_offset": frame_number - (1 if role == "previous" else 0),
                        "pts_seconds": reading.offset,
                        "raw_date": reading.raw_date,
                        "raw_time": reading.raw_time,
                        "corrected_timestamp": reading.timestamp.isoformat(),
                    },
                )
        already_seen = current_reading.timestamp in seen_timestamps
        if delta_seconds != 1:
            discontinuity_count += 1
            diagnostic_event(
                "assumption_failed_recoverable",
                video=video,
                assumption=(
                    "The burned-in OSD clock advances by exactly one second "
                    "at every displayed timestamp transition."
                ),
                details={
                    "recovery": (
                        "retain_earliest_frame_for_repeated_second"
                        if already_seen
                        else "record_first_observed_frame_and_leave_undisplayed_seconds_absent"
                    ),
                    "previous_timestamp": previous_reading.timestamp.isoformat(),
                    "current_timestamp": current_reading.timestamp.isoformat(),
                    "delta_seconds": delta_seconds,
                    "frame_offset": frame_number,
                    "previous_frame_offset": frame_number - 1,
                    "pts_seconds": frame_pts,
                    "previous_pts_seconds": previous_frame_pts,
                    "pixel_delta": pixel_delta,
                    "current_already_seen": already_seen,
                },
            )
        if delta_seconds > 1:
            verified_forward_gaps.append(
                (previous_reading.timestamp, current_reading.timestamp)
            )
        if not already_seen:
            boundaries.append(
                SecondFrame(
                    current_reading.timestamp,
                    frame_number,
                    frame_number - 1,
                    frame_pts,
                    previous_frame_pts,
                    current_reading.text,
                    previous_reading.text,
                    current_reading.confidence,
                    previous_reading.confidence,
                )
            )
            seen_timestamps.add(current_reading.timestamp)
            last_boundary_pts = frame_pts
        last_displayed_timestamp = current_reading.timestamp

    def record_transition(
        previous_reading: OCRReading,
        current_reading: OCRReading,
        frame_number: int,
        previous_frame_pts: float,
        frame_pts: float,
        pixel_delta: float,
    ) -> None:
        """Commit an adjacent tick, but require a clock jump to persist.

        Foreground/background changes can make two independent OCR paths agree
        on a legal but nonexistent timestamp for a handful of frames.  A real
        recorder-clock jump continues as a normal +1 sequence on the following
        displayed tick; a transient reading returns to the expected successor.
        """
        nonlocal pending_discontinuity
        if not isinstance(ocr, GlyphTimestampOCR):
            commit_transition(
                previous_reading,
                current_reading,
                frame_number,
                previous_frame_pts,
                frame_pts,
                pixel_delta,
            )
            return
        assert last_displayed_timestamp is not None
        expected_current = last_displayed_timestamp + dt.timedelta(seconds=1)

        if current_reading.timestamp == expected_current:
            if pending_discontinuity is not None:
                diagnostic_event(
                    "ocr_discontinuity_candidate_discarded",
                    video=video,
                    assumption=(
                        "A non-successor OSD clock reading is real only if its sequence "
                        "persists through the following displayed-second transition."
                    ),
                    details={
                        "candidate_frame_offset": pending_discontinuity.frame_number,
                        "candidate_timestamp": pending_discontinuity.current.timestamp.isoformat(),
                        "replacement_frame_offset": frame_number,
                        "replacement_timestamp": current_reading.timestamp.isoformat(),
                        "recovery": "record_expected_successor_and_discard_transient_jump",
                    },
                )
                pending_discontinuity = None
            if previous_reading.timestamp != last_displayed_timestamp:
                previous_reading = dataclasses.replace(
                    previous_reading,
                    timestamp=last_displayed_timestamp,
                    text=last_displayed_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                    context_corrected=False,
                    observed_timestamp=last_displayed_timestamp,
                )
            commit_transition(
                previous_reading,
                current_reading,
                frame_number,
                previous_frame_pts,
                frame_pts,
                pixel_delta,
            )
            return

        if pending_discontinuity is not None:
            pending = pending_discontinuity
            confirmation_elapsed = frame_pts - pending.pts_seconds
            if (
                confirmation_elapsed >= 0.5
                and previous_reading.timestamp == pending.current.timestamp
                and current_reading.timestamp
                == pending.current.timestamp + dt.timedelta(seconds=1)
            ):
                pending_discontinuity = None
                commit_transition(
                    pending.previous,
                    pending.current,
                    pending.frame_number,
                    pending.previous_pts_seconds,
                    pending.pts_seconds,
                    pending.pixel_delta,
                )
                commit_transition(
                    previous_reading,
                    current_reading,
                    frame_number,
                    previous_frame_pts,
                    frame_pts,
                    pixel_delta,
                )
                diagnostic_event(
                    "ocr_discontinuity_candidate_confirmed",
                    video=video,
                    assumption=(
                        "A non-successor clock reading is OCR contamination unless "
                        "its sequence advances normally on the following OSD tick."
                    ),
                    details={
                        "candidate_frame_offset": pending.frame_number,
                        "candidate_timestamp": pending.current.timestamp.isoformat(),
                        "confirmation_frame_offset": frame_number,
                        "confirmation_timestamp": current_reading.timestamp.isoformat(),
                        "elapsed_seconds": confirmation_elapsed,
                        "recovery": "retain_persistent_clock_jump",
                    },
                )
            return

        pending_discontinuity = PendingDiscontinuityTransition(
            previous_reading,
            current_reading,
            frame_number,
            previous_frame_pts,
            frame_pts,
            pixel_delta,
        )
        diagnostic_event(
            "ocr_discontinuity_candidate_deferred",
            video=video,
            assumption=(
                "A non-successor clock reading is OCR contamination unless "
                "its sequence advances normally on the following OSD tick."
            ),
            details={
                "frame_offset": frame_number,
                "pts_seconds": frame_pts,
                "previous_timestamp": previous_reading.timestamp.isoformat(),
                "candidate_timestamp": current_reading.timestamp.isoformat(),
                "recovery": "wait_for_next_displayed_tick",
            },
        )

    for frame_number, offset, pixels in iter_full_index_frames(video, probe, ocr, ffprobe):
        decoded_frames = frame_number + 1
        if first_pts is None:
            first_pts = offset
        last_pts = offset
        units = ocr.second_units_pixels(pixels, roi_width, roi_height)
        if frame_number == 0:
            first_reading = ocr.read_pixels(pixels, roi_width, roi_height, offset, timezone)
            if first_reading.confidence < minimum_confidence:
                raise CatalogError(
                    f"First-frame OCR confidence is only {first_reading.confidence:.3f} for {video}"
                )
            seen_timestamps.add(first_reading.timestamp)
            last_displayed_timestamp = first_reading.timestamp
            last_boundary_pts = offset
        elif previous_pixels is not None and previous_units is not None and previous_pts is not None:
            score_reader = getattr(ocr, "timestamp_change_scores", None)
            if score_reader is not None:
                digit_change_scores = score_reader(
                    previous_pixels,
                    pixels,
                    roi_width,
                    roi_height,
                )
                difference = max(digit_change_scores)
            else:
                change_reader = getattr(ocr, "timestamp_change_score", None)
                difference = (
                    change_reader(previous_pixels, pixels, roi_width, roi_height)
                    if change_reader is not None
                    else mean_absolute_difference(previous_units, units)
                )
                digit_change_scores = (difference,) * 6
            if difference >= transition_threshold:
                try:
                    assert last_displayed_timestamp is not None
                    if isinstance(ocr, GlyphTimestampOCR) and pending_context is not None:
                        # Once a targeted fallback observes a possible real
                        # skip/jump, use an independent neural pair on the next
                        # tick.  Pairwise successor scoring cannot confirm an
                        # alternative sequence which deliberately diverged from
                        # temporal context.
                        previous_reading = ocr.read_exception_pixels(
                            previous_pixels,
                            roi_width,
                            roi_height,
                            previous_pts,
                            timezone,
                            last_displayed_timestamp,
                        )
                        current_reading = ocr.read_exception_pixels(
                            pixels,
                            roi_width,
                            roi_height,
                            offset,
                            timezone,
                            last_displayed_timestamp + dt.timedelta(seconds=1),
                        )
                    else:
                        previous_reading = ocr.read_pixels(
                            previous_pixels,
                            roi_width,
                            roi_height,
                            previous_pts,
                            timezone,
                            last_displayed_timestamp,
                        )
                        current_reading = ocr.read_pixels(
                            pixels,
                            roi_width,
                            roi_height,
                            offset,
                            timezone,
                            last_displayed_timestamp + dt.timedelta(seconds=1),
                        )
                except CatalogError as exc:
                    if len(rejected_candidates) < 20:
                        rejected_candidates.append(
                            f"frame {frame_number} pixel_delta={difference:.3f}: {exc}"
                        )
                    previous_pixels = pixels
                    previous_units = units
                    previous_pts = offset
                    last_pixels = pixels
                    continue
                confident = (
                    previous_reading.confidence >= minimum_confidence
                    and current_reading.confidence >= minimum_confidence
                )
                changed = current_reading.timestamp != previous_reading.timestamp
                # Foreground motion can make both recognizers propose the next
                # second before its glyph is actually visible.  Defer only an
                # unusually early +1 successor.  Real non-successor clock jumps
                # use the separate persistence check, while damaged streams can
                # legitimately contain several short displayed seconds after a
                # run of undecodable frames.
                early_successor_candidate = (
                    confident
                    and changed
                    and not previous_reading.context_corrected
                    and not current_reading.context_corrected
                    and current_reading.timestamp
                    == last_displayed_timestamp + dt.timedelta(seconds=1)
                    and last_boundary_pts is not None
                    and offset - last_boundary_pts < 0.85
                )
                if isinstance(ocr, GlyphTimestampOCR) and (
                    not confident or not changed or early_successor_candidate
                ):
                    glyph_fallback_attempts += 1
                    try:
                        neural_previous = ocr.read_exception_pixels(
                            previous_pixels,
                            roi_width,
                            roi_height,
                            previous_pts,
                            timezone,
                            last_displayed_timestamp,
                        )
                        neural_current = ocr.read_exception_pixels(
                            pixels,
                            roi_width,
                            roi_height,
                            offset,
                            timezone,
                            last_displayed_timestamp + dt.timedelta(seconds=1),
                        )
                    except CatalogError as exc:
                        if len(rejected_candidates) < 20:
                            rejected_candidates.append(
                                f"frame {frame_number} pixel_delta={difference:.3f}: "
                                f"glyph ambiguity fallback failed: {exc}"
                            )
                    else:
                        neural_confident = (
                            neural_previous.confidence >= minimum_confidence
                            and neural_current.confidence >= minimum_confidence
                        )
                        neural_changed = neural_current.timestamp != neural_previous.timestamp
                        if neural_confident:
                            previous_reading = neural_previous
                            current_reading = neural_current
                            confident = True
                            changed = neural_changed
                            if neural_changed:
                                glyph_fallback_transitions += 1
                                diagnostic_event(
                                    "glyph_pair_ambiguity_resolved_by_ocr",
                                    video=video,
                                    assumption=(
                                        "The deterministic current-versus-successor glyph comparison "
                                        "resolves every strong full-cell transition."
                                    ),
                                    details={
                                        "frame_offset": frame_number,
                                        "pts_seconds": offset,
                                        "pixel_delta": difference,
                                        "previous_timestamp": neural_previous.timestamp.isoformat(),
                                        "current_timestamp": neural_current.timestamp.isoformat(),
                                        "recovery": "targeted_neural_ocr_for_ambiguous_pair",
                                    },
                                )
                if (
                    isinstance(ocr, GlyphTimestampOCR)
                    and confident
                    and changed
                    and not current_reading.context_corrected
                    and current_reading.timestamp
                    == last_displayed_timestamp + dt.timedelta(seconds=1)
                ):
                    previous_digits = last_displayed_timestamp.strftime("%H%M%S")
                    current_digits = current_reading.timestamp.strftime("%H%M%S")
                    changed_positions = [
                        index
                        for index, (previous_digit, current_digit) in enumerate(
                            zip(previous_digits, current_digits)
                        )
                        if previous_digit != current_digit
                    ]
                    changed_cell_scores = [
                        digit_change_scores[index] for index in changed_positions
                    ]
                    if not any(
                        score >= transition_threshold for score in changed_cell_scores
                    ):
                        diagnostic_event(
                            "glyph_successor_without_cell_change_rejected",
                            video=video,
                            assumption=(
                                "A neural successor reading is a real clock transition only "
                                "when at least one clock cell that must change has changed."
                            ),
                            details={
                                "frame_offset": frame_number,
                                "pts_seconds": offset,
                                "previous_timestamp": last_displayed_timestamp.isoformat(),
                                "candidate_timestamp": current_reading.timestamp.isoformat(),
                                "changed_positions": changed_positions,
                                "changed_cell_scores": changed_cell_scores,
                                "transition_threshold": transition_threshold,
                                "recovery": "wait_for_visual_change_in_required_clock_cell",
                            },
                        )
                        if len(rejected_candidates) < 20:
                            rejected_candidates.append(
                                f"frame {frame_number} pixel_delta={difference:.3f}: "
                                "successor OCR had no change in a required clock cell"
                            )
                        previous_pixels = pixels
                        previous_units = units
                        previous_pts = offset
                        last_pixels = pixels
                        continue
                early_successor_candidate = (
                    confident
                    and changed
                    and not previous_reading.context_corrected
                    and not current_reading.context_corrected
                    and current_reading.timestamp
                    == last_displayed_timestamp + dt.timedelta(seconds=1)
                    and last_boundary_pts is not None
                    and offset - last_boundary_pts < 0.85
                )
                pending_early_confirmation = False
                if pending_early_successor is not None and confident and changed:
                    pending_raw_previous = as_observed(previous_reading)
                    pending_raw_current = as_observed(current_reading)
                    pending_early_confirmation = (
                        offset - pending_early_successor.pts_seconds >= 0.35
                        and pending_raw_previous.timestamp
                        == pending_early_successor.current.timestamp
                        and pending_raw_current.timestamp
                        == pending_early_successor.current.timestamp
                        + dt.timedelta(seconds=1)
                    )
                if (
                    isinstance(ocr, GlyphTimestampOCR)
                    and early_successor_candidate
                    and bool(boundaries)
                    and confident
                    and changed
                    and not pending_early_confirmation
                ):
                    if pending_early_successor is None:
                        pending_early_successor = PendingDiscontinuityTransition(
                            previous_reading,
                            current_reading,
                            frame_number,
                            previous_pts,
                            offset,
                            difference,
                        )
                    diagnostic_event(
                        "glyph_early_successor_deferred",
                        video=video,
                        assumption=(
                            "An unusually early +1 glyph proposal must either reappear at "
                            "the normal phase or advance coherently on a later OSD tick."
                        ),
                        details={
                            "frame_offset": frame_number,
                            "pts_seconds": offset,
                            "seconds_since_previous_boundary": offset - last_boundary_pts,
                            "previous_timestamp": previous_reading.timestamp.isoformat(),
                            "current_timestamp": current_reading.timestamp.isoformat(),
                            "recovery": "retain_first_candidate_pending_temporal_confirmation",
                        },
                    )
                    if len(rejected_candidates) < 20:
                        rejected_candidates.append(
                            f"frame {frame_number} pixel_delta={difference:.3f}: "
                            "successor arrived unusually early and is pending confirmation"
                        )
                    previous_pixels = pixels
                    previous_units = units
                    previous_pts = offset
                    last_pixels = pixels
                    continue
                if (
                    isinstance(ocr, GlyphTimestampOCR)
                    and pending_early_successor is not None
                    and confident
                    and changed
                ):
                    pending = pending_early_successor
                    confirmation_elapsed = offset - pending.pts_seconds
                    raw_previous = as_observed(previous_reading)
                    raw_current = as_observed(current_reading)
                    if (
                        confirmation_elapsed >= 0.35
                        and raw_previous.timestamp == pending.current.timestamp
                        and raw_current.timestamp
                        == pending.current.timestamp + dt.timedelta(seconds=1)
                    ):
                        pending_early_successor = None
                        record_transition(
                            pending.previous,
                            pending.current,
                            pending.frame_number,
                            pending.previous_pts_seconds,
                            pending.pts_seconds,
                            pending.pixel_delta,
                        )
                        record_transition(
                            raw_previous,
                            raw_current,
                            frame_number,
                            previous_pts,
                            offset,
                            difference,
                        )
                        diagnostic_event(
                            "glyph_early_successor_confirmed",
                            video=video,
                            assumption=(
                                "An unusually early +1 glyph proposal is real only if the "
                                "following displayed tick advances from it coherently."
                            ),
                            details={
                                "candidate_frame_offset": pending.frame_number,
                                "candidate_timestamp": pending.current.timestamp.isoformat(),
                                "confirmation_frame_offset": frame_number,
                                "confirmation_timestamp": raw_current.timestamp.isoformat(),
                                "elapsed_seconds": confirmation_elapsed,
                                "recovery": "retain_short_but_coherent_displayed_seconds",
                            },
                        )
                        previous_pixels = pixels
                        previous_units = units
                        previous_pts = offset
                        last_pixels = pixels
                        continue
                    if current_reading.timestamp != last_displayed_timestamp + dt.timedelta(seconds=1):
                        previous_pixels = pixels
                        previous_units = units
                        previous_pts = offset
                        last_pixels = pixels
                        continue
                if (
                    isinstance(ocr, GlyphTimestampOCR)
                    and confident
                    and not changed
                    and current_reading.timestamp
                    == last_displayed_timestamp + dt.timedelta(seconds=1)
                    and last_boundary_pts is not None
                    and offset - last_boundary_pts >= 0.85
                ):
                    # A deferred foreground-contaminated candidate becomes the
                    # previous side of the next adjacent comparison.  If both
                    # OCR reads then agree on the expected successor at the
                    # proper one-second phase, the current frame is the first
                    # independently safe place to record that successor.
                    previous_reading = dataclasses.replace(
                        previous_reading,
                        timestamp=last_displayed_timestamp,
                        text=last_displayed_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                        context_corrected=False,
                        observed_timestamp=last_displayed_timestamp,
                    )
                    changed = True
                    if pending_early_successor is not None:
                        diagnostic_event(
                            "glyph_early_successor_repositioned",
                            video=video,
                            assumption=(
                                "An early successor proposal is foreground contamination when "
                                "the same successor first becomes independently safe at normal phase."
                            ),
                            details={
                                "discarded_frame_offset": pending_early_successor.frame_number,
                                "replacement_frame_offset": frame_number,
                                "timestamp": current_reading.timestamp.isoformat(),
                                "recovery": "record_later_verified_successor",
                            },
                        )
                        pending_early_successor = None
                    diagnostic_event(
                        "glyph_deferred_transition_recovered",
                        video=video,
                        assumption=(
                            "A foreground-contaminated early proposal is followed by a clean "
                            "expected successor at the established one-second phase."
                        ),
                        details={
                            "frame_offset": frame_number,
                            "pts_seconds": offset,
                            "seconds_since_previous_boundary": offset - last_boundary_pts,
                            "previous_timestamp": previous_reading.timestamp.isoformat(),
                            "current_timestamp": current_reading.timestamp.isoformat(),
                            "recovery": "record_current_frame_with_contextual_previous_second",
                        },
                    )
                if (
                    isinstance(ocr, GlyphTimestampOCR)
                    and pending_early_successor is not None
                    and confident
                    and changed
                    and current_reading.timestamp
                    == last_displayed_timestamp + dt.timedelta(seconds=1)
                ):
                    diagnostic_event(
                        "glyph_early_successor_repositioned",
                        video=video,
                        assumption=(
                            "An early successor proposal is foreground contamination when "
                            "the same successor first becomes independently safe at normal phase."
                        ),
                        details={
                            "discarded_frame_offset": pending_early_successor.frame_number,
                            "replacement_frame_offset": frame_number,
                            "timestamp": current_reading.timestamp.isoformat(),
                            "recovery": "record_later_verified_successor",
                        },
                    )
                    pending_early_successor = None
                if isinstance(ocr, GlyphTimestampOCR):
                    LOG.debug(
                        "Glyph candidate frame=%d pts=%.6f state=%s pair=%s(%.3f)->%s(%.3f) "
                        "changed=%s pending=%s pixel_delta=%.3f",
                        frame_number,
                        offset,
                        last_displayed_timestamp.isoformat(),
                        previous_reading.timestamp.isoformat(),
                        previous_reading.confidence,
                        current_reading.timestamp.isoformat(),
                        current_reading.confidence,
                        changed,
                        pending_context is not None,
                        difference,
                    )
                if confident and changed:
                    delta_seconds = int(
                        (current_reading.timestamp - previous_reading.timestamp).total_seconds()
                    )
                    alternate_reader = getattr(ocr, "read_seconds_high_threshold", None)
                    if delta_seconds != 1 and alternate_reader is not None:
                        corrected_pair: list[tuple[str, OCRReading, bytes, set[dt.datetime]]] = [
                            (
                                "previous",
                                previous_reading,
                                previous_pixels,
                                {last_displayed_timestamp},
                            ),
                            (
                                "current",
                                current_reading,
                                pixels,
                                {
                                    last_displayed_timestamp,
                                    last_displayed_timestamp + dt.timedelta(seconds=1),
                                },
                            ),
                        ]
                        resolved: dict[str, OCRReading] = {}
                        for role, reading, reading_pixels, allowed in corrected_pair:
                            alternate = alternate_reader(
                                reading_pixels,
                                roi_width,
                                roi_height,
                                reading.offset,
                            )
                            if alternate is None:
                                continue
                            alternate_second, alternate_confidence, alternate_raw = alternate
                            candidate = reading.timestamp.replace(second=alternate_second)
                            if (
                                candidate != reading.timestamp
                                and candidate in allowed
                                and alternate_confidence >= minimum_confidence
                            ):
                                resolved[role] = dataclasses.replace(
                                    reading,
                                    timestamp=candidate,
                                    text=candidate.strftime("%Y-%m-%d %H:%M:%S"),
                                    confidence=min(reading.confidence, alternate_confidence),
                                    alternate_raw_time=alternate_raw,
                                    alternate_corrected=True,
                                )
                        previous_reading = resolved.get("previous", previous_reading)
                        current_reading = resolved.get("current", current_reading)
                        for role, reading in resolved.items():
                            alternate_correction_count += 1
                            diagnostic_event(
                                "ocr_alternate_preprocessing_correction",
                                video=video,
                                assumption=(
                                    "A high-threshold seconds-only OCR retry may reject foreground "
                                    "contamination only when it resolves to the current or next displayed second."
                                ),
                                details={
                                    "role": role,
                                    "frame_offset": frame_number - (1 if role == "previous" else 0),
                                    "pts_seconds": reading.offset,
                                    "primary_raw_time": reading.raw_time,
                                    "alternate_raw_time": reading.alternate_raw_time,
                                    "corrected_timestamp": reading.timestamp.isoformat(),
                                },
                            )
                        changed = current_reading.timestamp != previous_reading.timestamp
                        delta_seconds = int(
                            (current_reading.timestamp - previous_reading.timestamp).total_seconds()
                        )
                    if not changed:
                        if len(rejected_candidates) < 20:
                            rejected_candidates.append(
                                f"frame {frame_number} pixel_delta={difference:.3f}: "
                                "alternate seconds OCR confirmed no timestamp transition"
                            )
                        previous_pixels = pixels
                        previous_units = units
                        previous_pts = offset
                        last_pixels = pixels
                        continue
                    # A valid raw HH:MM alternative that differs from context
                    # by one glyph is ambiguous: it can be OCR damage, or a
                    # real recorder-clock jump exactly on a second boundary.
                    # Hold it for one displayed tick and decide from whether
                    # the corrected or raw sequence persists.
                    if pending_context is not None:
                        raw_previous = as_observed(previous_reading)
                        raw_current = as_observed(current_reading)
                        pending_raw = pending_context.current.observed_timestamp
                        confirmation_elapsed = offset - pending_context.pts_seconds
                        if (
                            confirmation_elapsed < 0.5
                            and raw_current.timestamp == pending_context.current.timestamp
                        ):
                            # The glyph finished rendering (or OCR recovered)
                            # within the same displayed second.  This is not an
                            # independent clock tick, so retain context.
                            record_transition(
                                pending_context.previous,
                                pending_context.current,
                                pending_context.frame_number,
                                pending_context.previous_pts_seconds,
                                pending_context.pts_seconds,
                                pending_context.pixel_delta,
                            )
                        elif raw_current.timestamp == pending_context.current.timestamp:
                            # Context became visible only after a substantial
                            # delay.  The pending pixel change was background
                            # noise, not the clock boundary; discard it and let
                            # the current adjacent pair be recorded below.
                            diagnostic_event(
                                "ocr_temporal_context_candidate_repositioned",
                                video=video,
                                assumption=(
                                    "A disputed digit stabilizes within half a second of its first-frame boundary."
                                ),
                                details={
                                    "discarded_frame_offset": pending_context.frame_number,
                                    "replacement_frame_offset": frame_number,
                                    "elapsed_seconds": confirmation_elapsed,
                                    "raw_timestamp": pending_raw.isoformat() if pending_raw else None,
                                    "context_timestamp": pending_context.current.timestamp.isoformat(),
                                    "recovery": "record_later_verified_adjacent_pair",
                                },
                            )
                        elif (
                            raw_previous.timestamp == pending_context.current.timestamp
                            and raw_current.timestamp
                            == pending_context.current.timestamp + dt.timedelta(seconds=1)
                        ):
                            # The next clean observation returned to the
                            # expected sequence: the pending raw value was a
                            # transient OCR error.
                            record_transition(
                                pending_context.previous,
                                pending_context.current,
                                pending_context.frame_number,
                                pending_context.previous_pts_seconds,
                                pending_context.pts_seconds,
                                pending_context.pixel_delta,
                            )
                        elif (
                            pending_raw is not None
                            and confirmation_elapsed >= 0.5
                            and raw_previous.timestamp == pending_raw
                            and raw_current.timestamp == pending_raw + dt.timedelta(seconds=1)
                        ):
                            # The alternative advanced normally for another
                            # displayed tick, proving that it is the actual OSD clock.
                            observed_pending = as_observed(pending_context.current)
                            record_transition(
                                pending_context.previous,
                                observed_pending,
                                pending_context.frame_number,
                                pending_context.previous_pts_seconds,
                                pending_context.pts_seconds,
                                pending_context.pixel_delta,
                            )
                            diagnostic_event(
                                "ocr_temporal_context_rejected_as_clock_jump",
                                video=video,
                                assumption=(
                                    "A valid one-glyph hour/minute alternative is OCR corruption."
                                ),
                                details={
                                    "frame_offset": pending_context.frame_number,
                                    "raw_timestamp": pending_raw.isoformat(),
                                    "context_timestamp": pending_context.current.timestamp.isoformat(),
                                    "confirmation_timestamp": raw_current.timestamp.isoformat(),
                                    "recovery": "retain_persistent_raw_clock_sequence",
                                },
                            )
                        else:
                            # Bright-background changes can trigger several OCR
                            # candidates while the displayed clock is still on
                            # the same second.  They are not independent clock
                            # transitions and must not consume confirmation
                            # attempts.
                            if raw_current.timestamp != raw_previous.timestamp:
                                pending_confirmation_attempts += 1
                                if pending_confirmation_attempts >= 3:
                                    raise CatalogError(
                                        f"Could not resolve temporal OCR ambiguity in {video} after "
                                        f"{pending_confirmation_attempts} later advancing clock candidates: "
                                        f"candidate_raw={pending_raw}, "
                                        f"candidate_context={pending_context.current.timestamp.isoformat()}, "
                                        f"latest_raw_pair={raw_previous.timestamp.isoformat()} -> "
                                        f"{raw_current.timestamp.isoformat()}"
                                    )
                            if len(rejected_candidates) < 20:
                                rejected_candidates.append(
                                    f"frame {frame_number} pixel_delta={difference:.3f}: "
                                    "waiting to resolve ambiguous temporal OCR correction"
                                )
                            previous_pixels = pixels
                            previous_units = units
                            previous_pts = offset
                            last_pixels = pixels
                            continue
                        pending_context = None
                        pending_confirmation_attempts = 0
                        previous_reading = raw_previous
                        current_reading = raw_current

                    context_requires_next_tick = False
                    repeated_raw_candidate = False
                    if current_reading.timestamp == last_displayed_timestamp:
                        # A sub-second stabilization frame confirmed the
                        # already-recorded pending boundary.
                        pass
                    elif (
                        pending_context is None
                        and current_reading.context_corrected
                        and current_reading.observed_timestamp is not None
                        and current_reading.observed_timestamp != current_reading.timestamp
                    ):
                        observed_digits = current_reading.observed_timestamp.strftime("%H%M%S")
                        context_digits = current_reading.timestamp.strftime("%H%M%S")
                        mismatch_positions = [
                            index
                            for index, (observed_digit, context_digit) in enumerate(
                                zip(observed_digits, context_digits)
                            )
                            if observed_digit != context_digit
                        ]
                        disputed_cell_changed = any(
                            digit_change_scores[index] >= transition_threshold
                            for index in mismatch_positions
                        )
                        raw_repeats_previous = (
                            current_reading.observed_timestamp == previous_reading.timestamp
                            or current_reading.observed_timestamp == last_displayed_timestamp
                            or (
                                previous_reading.observed_timestamp is not None
                                and current_reading.observed_timestamp
                                == previous_reading.observed_timestamp
                            )
                        )
                        # Pixel/background motion is not allowed to advance the
                        # catalogue while OCR still independently reads the
                        # previous clock.  Wait for a later adjacent pair whose
                        # raw observation actually changes.
                        repeated_raw_candidate = raw_repeats_previous
                        context_requires_next_tick = disputed_cell_changed and not raw_repeats_previous
                    if current_reading.timestamp == last_displayed_timestamp:
                        pass
                    elif repeated_raw_candidate:
                        if len(rejected_candidates) < 20:
                            rejected_candidates.append(
                                f"frame {frame_number} pixel_delta={difference:.3f}: "
                                "temporal proposal rejected because raw OCR still matches the previous clock"
                            )
                    elif context_requires_next_tick:
                        pending_context = PendingContextTransition(
                            previous_reading,
                            current_reading,
                            frame_number,
                            previous_pts,
                            offset,
                            difference,
                        )
                        pending_confirmation_attempts = 0
                    else:
                        record_transition(
                            previous_reading,
                            current_reading,
                            frame_number,
                            previous_pts,
                            offset,
                            difference,
                        )
                elif (not confident or not changed) and len(rejected_candidates) < 20:
                    rejected_candidates.append(
                        f"frame {frame_number} pixel_delta={difference:.3f}: "
                        f"{previous_reading.text} ({previous_reading.confidence:.3f}) -> "
                        f"{current_reading.text} ({current_reading.confidence:.3f})"
                    )
        previous_pixels = pixels
        previous_units = units
        previous_pts = offset
        last_pixels = pixels

    if first_reading is None or last_pixels is None or first_pts is None or last_pts is None:
        raise CatalogError(f"No frames were decoded from {video}")
    assert last_displayed_timestamp is not None
    if isinstance(ocr, GlyphTimestampOCR):
        last_reading = ocr.read_exception_pixels(
            last_pixels,
            roi_width,
            roi_height,
            last_pts,
            timezone,
        )
    else:
        last_reading = ocr.read_pixels(
            last_pixels,
            roi_width,
            roi_height,
            last_pts,
            timezone,
            last_displayed_timestamp,
        )
    if last_reading.confidence < minimum_confidence:
        raise CatalogError(f"Last-frame OCR confidence is only {last_reading.confidence:.3f} for {video}")
    if pending_early_successor is not None:
        pending = pending_early_successor
        if (
            last_reading.timestamp == pending.current.timestamp
            and last_pts - pending.pts_seconds >= 0.5
        ):
            record_transition(
                pending.previous,
                pending.current,
                pending.frame_number,
                pending.previous_pts_seconds,
                pending.pts_seconds,
                pending.pixel_delta,
            )
            diagnostic_event(
                "glyph_early_successor_confirmed_at_end",
                video=video,
                assumption=(
                    "An unusually early final successor is real only if it remains "
                    "visible for at least half a second through the final frame."
                ),
                details={
                    "candidate_frame_offset": pending.frame_number,
                    "candidate_timestamp": pending.current.timestamp.isoformat(),
                    "last_frame_offset": decoded_frames - 1,
                    "visible_seconds": last_pts - pending.pts_seconds,
                    "recovery": "retain_sustained_final_successor",
                },
            )
        else:
            diagnostic_event(
                "glyph_early_successor_discarded_at_end",
                video=video,
                assumption=(
                    "An unusually early final successor is real only if it remains "
                    "visible for at least half a second through the final frame."
                ),
                details={
                    "candidate_frame_offset": pending.frame_number,
                    "candidate_timestamp": pending.current.timestamp.isoformat(),
                    "last_timestamp": last_reading.timestamp.isoformat(),
                    "visible_seconds": last_pts - pending.pts_seconds,
                    "recovery": "discard_unconfirmed_final_successor",
                },
            )
        pending_early_successor = None
    if pending_discontinuity is not None:
        pending = pending_discontinuity
        if (
            last_reading.timestamp == pending.current.timestamp
            and last_pts - pending.pts_seconds >= 0.5
        ):
            commit_transition(
                pending.previous,
                pending.current,
                pending.frame_number,
                pending.previous_pts_seconds,
                pending.pts_seconds,
                pending.pixel_delta,
            )
            diagnostic_event(
                "ocr_discontinuity_candidate_confirmed_at_end",
                video=video,
                assumption=(
                    "A final non-successor clock reading is real only if it remains "
                    "visible for at least half a second through the final frame."
                ),
                details={
                    "candidate_frame_offset": pending.frame_number,
                    "candidate_timestamp": pending.current.timestamp.isoformat(),
                    "last_frame_offset": decoded_frames - 1,
                    "visible_seconds": last_pts - pending.pts_seconds,
                    "recovery": "retain_sustained_final_clock_jump",
                },
            )
        else:
            diagnostic_event(
                "ocr_discontinuity_candidate_discarded_at_end",
                video=video,
                assumption=(
                    "A final non-successor clock reading is real only if it remains "
                    "visible for at least half a second through the final frame."
                ),
                details={
                    "candidate_frame_offset": pending.frame_number,
                    "candidate_timestamp": pending.current.timestamp.isoformat(),
                    "last_timestamp": last_reading.timestamp.isoformat(),
                    "visible_seconds": last_pts - pending.pts_seconds,
                    "recovery": "discard_unconfirmed_final_clock_jump",
                },
            )
        pending_discontinuity = None
    if pending_context is not None:
        raise CatalogError(
            f"The final clock transition in {video} has an unresolved one-glyph OCR ambiguity: "
            f"candidate_raw={pending_context.current.observed_timestamp}, "
            f"candidate_context={pending_context.current.timestamp.isoformat()}. "
            "No following displayed-second transition exists to confirm either sequence."
        )
    if last_reading.timestamp not in seen_timestamps:
        raise CatalogError(
            f"The last displayed OSD second {last_reading.timestamp.isoformat()} in {video} "
            "was not found at a verified adjacent-frame transition. "
            f"First rejected candidates={rejected_candidates[:5]}."
        )
    expected: set[dt.datetime] = set()
    timestamp = first_reading.timestamp
    while timestamp <= last_reading.timestamp:
        expected.add(timestamp)
        timestamp += dt.timedelta(seconds=1)
    verified_undisplayed = {
        timestamp
        for timestamp in expected
        if timestamp not in seen_timestamps
        and any(left < timestamp < right for left, right in verified_forward_gaps)
    }
    missing = sorted(expected - seen_timestamps - verified_undisplayed)
    if missing:
        raise CatalogError(
            f"Per-second frame verification is incomplete for {video}: "
            f"{len(missing)} displayed transition(s) were not detected; "
            f"first missing={[value.isoformat() for value in missing[:5]]}. "
            f"First rejected candidates={rejected_candidates[:5]}. "
            "Lower --transition-threshold only after reviewing the relevant adjacent frames."
        )
    if discontinuity_count:
        LOG.warning(
            "Accepted %d verified OSD clock discontinuity/discontinuities in %s; "
            "seconds never displayed by any frame are intentionally absent from the frame table",
            discontinuity_count,
            video.name,
        )
    if contextual_correction_count:
        LOG.warning(
            "Applied %d narrowly constrained temporal OCR correction(s) in %s; details are in the diagnostic log",
            contextual_correction_count,
            video.name,
        )
    if alternate_correction_count:
        LOG.warning(
            "Applied %d seconds-only alternate OCR correction(s) in %s; details are in the diagnostic log",
            alternate_correction_count,
            video.name,
        )
    if glyph_fallback_attempts:
        LOG.info(
            "Deterministic glyph verification used neural fallback for %d ambiguous candidate(s), "
            "%d of which were timestamp transitions in %s",
            glyph_fallback_attempts,
            glyph_fallback_transitions,
            video.name,
        )
    LOG.info(
        "Verified %d first-frames-of-second across %d decoded frames in %s",
        len(boundaries), decoded_frames, video.name,
    )
    first_observation = FrameObservation(
        first_reading.timestamp, 0, first_pts, first_reading.text, first_reading.confidence
    )
    last_observation = FrameObservation(
        last_reading.timestamp,
        decoded_frames - 1,
        last_pts,
        last_reading.text,
        last_reading.confidence,
    )
    return tuple(boundaries), first_observation, last_observation


def sample_offsets(duration: float, samples_per_edge: int, edge_seconds: float) -> list[float]:
    if duration < 2.0:
        raise CatalogError(f"Video is too short for reliable timestamp OCR ({duration:.3f}s)")
    edge = min(edge_seconds, duration / 3.0)
    first = max(0.25, min(3.0, edge / max(samples_per_edge, 1)))
    start = [first + index * max(1.0, (edge - first) / max(samples_per_edge - 1, 1)) for index in range(samples_per_edge)]
    end = [duration - value for value in reversed(start)]
    result = sorted({round(max(0.1, min(duration - 0.1, value)), 3) for value in (*start, *end)})
    return result


def decode_endpoint_osd_frames(
    video: Path,
    probe: Probe,
    ocr: TimestampOCR,
) -> tuple[bytes, bytes]:
    """Decode only enough pixels to obtain the exact first and final OSD frames."""
    x, y, roi_width, roi_height = ocr.roi
    tail_seconds = min(probe.duration, max(2.0, ocr.seek_preroll))
    input_seek = max(0.0, probe.duration - tail_seconds)
    filters = ocr.software_filter_prefix()
    if (probe.width, probe.height) != (ocr.reference_width, ocr.reference_height):
        filters.append(f"scale={ocr.reference_width}:{ocr.reference_height}:flags=neighbor")
    filters.extend([f"crop={roi_width}:{roi_height}:{x}:{y}", "format=gray"])
    command = [ocr.ffmpeg, "-hide_banner", "-loglevel", "warning"]
    if input_seek:
        command.extend(["-ss", f"{input_seek:.6f}"])
    command.extend(ocr.decoder_input_arguments())
    command.extend(
        [
            "-i", str(video),
            "-map", "0:v:0",
            "-vf", ",".join(filters),
            "-fps_mode", "passthrough",
            "-pix_fmt", "gray",
            "-f", "rawvideo",
            "-",
        ]
    )
    frame_bytes = roi_width * roi_height
    stderr_file = tempfile.TemporaryFile()
    try:
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=stderr_file)
        except FileNotFoundError as exc:
            raise CatalogError(f"FFmpeg executable not found: {ocr.ffmpeg!r}") from exc
        assert process.stdout is not None
        first_pixels: bytes | None = None
        last_pixels: bytes | None = None
        decoded_frames = 0
        while True:
            pixels = read_exact(process.stdout, frame_bytes)
            if not pixels:
                break
            if len(pixels) != frame_bytes:
                process.kill()
                raise CatalogError(
                    f"FFmpeg emitted a partial endpoint OCR frame for {video}: "
                    f"{len(pixels)}/{frame_bytes} bytes"
                )
            if first_pixels is None:
                first_pixels = pixels
            last_pixels = pixels
            decoded_frames += 1
        process.stdout.close()
        try:
            return_code = process.wait(timeout=120)
        except subprocess.TimeoutExpired as exc:
            process.kill()
            raise CatalogError(f"Timed out waiting for endpoint decode of {video}") from exc
        stderr_file.seek(0)
        stderr = stderr_file.read().decode("utf-8", "replace")
        if return_code:
            raise CatalogError(
                f"FFmpeg endpoint decode failed for {video} (exit {return_code}): {stderr[-4000:]}"
            )
        if first_pixels is None or last_pixels is None:
            raise CatalogError(f"FFmpeg decoded no endpoint frames from {video}: {stderr[-4000:]}")

        # If the tail decode began after zero, its first frame is not the file's
        # first frame. Fetch that one independently; the final frame above is exact.
        if input_seek:
            width, height, first_pixels = ocr.extract_osd(video, 0.0)
            if (width, height) != (roi_width, roi_height):
                raise CatalogError(
                    f"Unexpected first-frame OCR strip size {width}x{height} for {video}"
                )
        LOG.info(
            "Inspected endpoint OCR using %d tail frame(s) from %.3fs in %s",
            decoded_frames,
            input_seek,
            video.name,
        )
        return first_pixels, last_pixels
    finally:
        stderr_file.close()


def analyse_video_registration(
    path: Path,
    fingerprint: str,
    ocr: TimestampOCR,
    ffprobe: str,
    timezone: dt.tzinfo,
    minimum_confidence: float,
) -> Registration:
    """Inspect endpoints only, so the rotating source name can be secured early."""
    before = path.stat()
    probe = probe_video(path, ffprobe, ocr.ffmpeg_threads)
    first_pixels, last_pixels = decode_endpoint_osd_frames(path, probe, ocr)
    roi_width, roi_height = ocr.roi[2:]
    if isinstance(ocr, GlyphTimestampOCR):
        first = ocr.read_exception_pixels(first_pixels, roi_width, roi_height, 0.0, timezone)
        last = ocr.read_exception_pixels(
            last_pixels, roi_width, roi_height, probe.duration, timezone
        )
    else:
        first = ocr.read_pixels(first_pixels, roi_width, roi_height, 0.0, timezone)
        last = ocr.read_pixels(last_pixels, roi_width, roi_height, probe.duration, timezone)
    if min(first.confidence, last.confidence) < minimum_confidence:
        raise CatalogError(
            f"Endpoint OCR confidence is too low for {path}: "
            f"first={first.confidence:.3f}, last={last.confidence:.3f}"
        )
    if last.timestamp < first.timestamp:
        raise CatalogError(
            f"Final OSD timestamp precedes the first in {path}: "
            f"{first.timestamp.isoformat()} -> {last.timestamp.isoformat()}"
        )
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise CatalogError(
            f"File changed while its endpoints were being inspected; "
            f"it is probably still being copied: {path}"
        )
    return Registration(
        path,
        fingerprint,
        before.st_size,
        before.st_mtime_ns,
        probe,
        first.timestamp,
        last.timestamp,
        (first, last),
        0.0,
    )


def analyse_video(
    path: Path,
    fingerprint: str,
    ocr: TimestampOCR,
    ffprobe: str,
    timezone: dt.tzinfo,
    samples_per_edge: int,
    edge_seconds: float,
    minimum_confidence: float,
    maximum_timing_spread: float,
    transition_threshold: float,
    index_mode: str,
    boundary_search_seconds: float,
    boundary_workers: int,
) -> Analysis:
    before = path.stat()
    probe = probe_video(path, ffprobe, ocr.ffmpeg_threads)
    readings: list[OCRReading] = []
    spread = 0.0
    sampled_start: dt.datetime | None = None
    sampled_end: dt.datetime | None = None
    if index_mode == "projected":
        failures: list[str] = []
        for offset in sample_offsets(probe.duration, samples_per_edge, edge_seconds):
            try:
                reading = ocr.read(path, offset, timezone)
            except CatalogError as exc:
                failures.append(str(exc))
                continue
            if reading.confidence < minimum_confidence:
                failures.append(
                    f"low OCR confidence {reading.confidence:.3f} for {reading.text} at {offset:.3f}s"
                )
                continue
            readings.append(reading)
        minimum_readings = max(2, samples_per_edge)
        if len(readings) < minimum_readings:
            detail = " | ".join(failures[:3])
            raise CatalogError(
                f"Only {len(readings)}/{len(readings) + len(failures)} OCR samples were trustworthy for {path}; "
                f"need {minimum_readings}. {detail}"
            )
        inferred_starts = [reading.timestamp.timestamp() - reading.offset for reading in readings]
        median_start = statistics.median(inferred_starts)
        spread = max(abs(value - median_start) for value in inferred_starts)
        if spread > maximum_timing_spread:
            detail = ", ".join(
                f"{reading.text}@{reading.offset:.3f}s=>{value - median_start:+.3f}s"
                for reading, value in zip(readings, inferred_starts)
            )
            raise CatalogError(
                f"OCR samples for {path} disagree by as much as {spread:.3f}s "
                f"(limit {maximum_timing_spread:.3f}s): {detail}"
            )
        start_epoch = round(median_start)
        sampled_start = dt.datetime.fromtimestamp(start_epoch, timezone)
        sampled_end = dt.datetime.fromtimestamp(round(start_epoch + probe.duration), timezone)
        second_frames, first_frame, last_frame = index_second_frames_projected(
            path,
            probe,
            ocr,
            ffprobe,
            timezone,
            minimum_confidence,
            transition_threshold,
            boundary_search_seconds,
            boundary_workers,
        )
    else:
        try:
            second_frames, first_frame, last_frame = index_second_frames_full(
                path,
                probe,
                ocr,
                ffprobe,
                timezone,
                minimum_confidence,
                transition_threshold,
            )
        except GPUFrameSequenceConcern as exc:
            if ocr.gpu_index is None:
                raise
            diagnostic_event(
                "assumption_failed_recoverable",
                video=path,
                assumption="NVDEC emits one presentation frame per demuxed video packet in identical PTS order.",
                details={
                    **exc.details,
                    "recovery": "retry_full_index_on_cpu",
                    "reason": str(exc),
                },
            )
            LOG.warning(
                "GPU %d frame sequence is not packet-identical for %s; retrying full indexing on CPU",
                ocr.gpu_index,
                path.name,
            )
            cpu_ocr = ocr.cpu_copy()
            second_frames, first_frame, last_frame = index_second_frames_full(
                path,
                probe,
                cpu_ocr,
                ffprobe,
                timezone,
                minimum_confidence,
                transition_threshold,
            )
    if (
        sampled_start is not None
        and abs((first_frame.timestamp - sampled_start).total_seconds()) > maximum_timing_spread + 1.0
    ):
        raise CatalogError(
            f"First sequential-frame OCR {first_frame.timestamp.isoformat()} disagrees with "
            f"sampled start {sampled_start.isoformat()} for {path}"
        )
    start = first_frame.timestamp
    # Catalogue names use the first and last OSD seconds actually present,
    # both inclusive. This also matches the recorder search metadata here.
    end = last_frame.timestamp
    if (
        sampled_end is not None
        and abs((end - sampled_end).total_seconds()) > maximum_timing_spread + 1.0
    ):
        raise CatalogError(
            f"Last sequential-frame OCR implies end {end.isoformat()}, which disagrees with "
            f"sampled/probed end {sampled_end.isoformat()} for {path}"
        )
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise CatalogError(f"File changed while it was being inspected; it is probably still being copied: {path}")
    return Analysis(
        path,
        fingerprint,
        before.st_size,
        before.st_mtime_ns,
        probe,
        start,
        end,
        tuple(readings),
        spread,
        second_frames,
        first_frame,
        last_frame,
    )


class CatalogDB:
    def __init__(self, path: Path | str):
        self.path = path
        self.connection = sqlite3.connect(str(path), timeout=30)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self._initialize()

    def _table_exists(self, name: str) -> bool:
        return self.connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
        ).fetchone() is not None

    @staticmethod
    def _unix(value: str | float | int) -> float:
        if isinstance(value, (int, float)):
            return float(value)
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()

    def _initialize(self) -> None:
        legacy = self._table_exists("videos")
        with self.connection:
            self.connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS video (
                    id INTEGER PRIMARY KEY,
                    old_name TEXT NOT NULL,
                    new_name TEXT NOT NULL,
                    start REAL NOT NULL,
                    end REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS video_interval
                    ON video(start,end);
                CREATE INDEX IF NOT EXISTS video_interval_end
                    ON video(end,start);
                CREATE TABLE IF NOT EXISTS frame (
                    video INTEGER NOT NULL REFERENCES video(id) ON DELETE CASCADE,
                    second INTEGER NOT NULL,
                    frame_offset INTEGER NOT NULL,
                    PRIMARY KEY(video, second)
                );
                CREATE INDEX IF NOT EXISTS frame_second ON frame(second);
                """
            )
            if legacy:
                self._migrate_legacy_schema()
            self.connection.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    def _migrate_legacy_schema(self) -> None:
        """Losslessly reduce the former verbose catalogue to the two public tables."""
        id_by_fingerprint: dict[str, int] = {}
        migrated_videos = 0
        migrated_frames = 0
        rows = self.connection.execute(
            """
            SELECT fingerprint,path,original_name,start_time,end_time
            FROM videos
            WHERE status='cataloged' AND start_time IS NOT NULL AND end_time IS NOT NULL
            ORDER BY start_time,fingerprint
            """
        ).fetchall()
        for row in rows:
            cursor = self.connection.execute(
                "INSERT INTO video(old_name,new_name,start,end) VALUES(?,?,?,?)",
                (
                    row["original_name"],
                    Path(row["path"]).name,
                    self._unix(row["start_time"]),
                    self._unix(row["end_time"]),
                ),
            )
            id_by_fingerprint[row["fingerprint"]] = int(cursor.lastrowid)
            migrated_videos += 1
        if self._table_exists("second_frames"):
            for row in self.connection.execute(
                "SELECT fingerprint,timestamp,frame_number FROM second_frames ORDER BY timestamp"
            ):
                video_id = id_by_fingerprint.get(row["fingerprint"])
                if video_id is None:
                    continue
                self.connection.execute(
                    "INSERT OR REPLACE INTO frame(video,second,frame_offset) VALUES(?,?,?)",
                    (video_id, round(self._unix(row["timestamp"])), row["frame_number"]),
                )
                migrated_frames += 1
            self.connection.execute("DROP TABLE second_frames")
        self.connection.execute("DROP TABLE videos")
        if self._table_exists("metadata"):
            self.connection.execute("DROP TABLE metadata")
        diagnostic_event(
            "database_schema_migrated",
            details={
                "database": str(self.path),
                "videos": migrated_videos,
                "frames": migrated_frames,
                "new_schema": "video(id,old_name,new_name,start,end); "
                "frame(video,second,frame_offset)",
            },
        )

    def close(self) -> None:
        self.connection.close()

    def import_known_names(self, source_path: Path) -> None:
        """Copy catalogue state into the disposable in-memory dry-run database."""
        source = sqlite3.connect(source_path.resolve().as_uri() + "?mode=ro", uri=True, timeout=30)
        source.row_factory = sqlite3.Row
        try:
            tables = {
                row[0]
                for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")
            }
            if "video" in tables:
                videos = source.execute(
                    "SELECT id,old_name,new_name,start,end FROM video"
                ).fetchall()
                frames = source.execute(
                    "SELECT video,second,frame_offset FROM frame"
                ).fetchall()
                with self.connection:
                    self.connection.executemany(
                        "INSERT INTO video(id,old_name,new_name,start,end) VALUES(?,?,?,?,?)",
                        [
                            (
                                row["id"],
                                row["old_name"],
                                row["new_name"],
                                row["start"],
                                row["end"],
                            )
                            for row in videos
                        ],
                    )
                    self.connection.executemany(
                        "INSERT INTO frame(video,second,frame_offset) VALUES(?,?,?)",
                        [
                            (row["video"], row["second"], row["frame_offset"])
                            for row in frames
                        ],
                    )
                return
            elif "videos" in tables:
                names = [
                    Path(row[0]).name
                    for row in source.execute(
                        "SELECT path FROM videos WHERE status='cataloged' AND path IS NOT NULL"
                    )
                ]
            else:
                names = []
            with self.connection:
                self.connection.executemany(
                    "INSERT INTO video(old_name,new_name,start,end) VALUES(?,?,0,0)",
                    [(name, name) for name in names],
                )
        finally:
            source.close()

    def known(self, fingerprint: str, path: Path) -> bool:
        del fingerprint  # Content identity is intentionally not persisted in the minimal schema.
        return self.connection.execute(
            "SELECT 1 FROM video WHERE new_name=? LIMIT 1", (path.name,)
        ).fetchone() is not None

    def register_video(self, analysis: Registration, destination: Path) -> int:
        """Durably register an already-renamed video without claiming its frames are indexed."""
        values = (
            analysis.source.name,
            destination.name,
            analysis.start.timestamp(),
            analysis.end.timestamp(),
        )
        with self.connection:
            row = self.connection.execute(
                "SELECT id FROM video WHERE new_name=? ORDER BY id LIMIT 1",
                (destination.name,),
            ).fetchone()
            if row is None:
                cursor = self.connection.execute(
                    "INSERT INTO video(old_name,new_name,start,end) VALUES(?,?,?,?)",
                    values,
                )
                return int(cursor.lastrowid)
            video_id = int(row["id"])
            self.connection.execute(
                "UPDATE video SET old_name=?,new_name=?,start=?,end=? WHERE id=?",
                (*values, video_id),
            )
            return video_id

    def pending_videos(self) -> list[CatalogVideo]:
        """Return videos lacking a completed per-second index via an indexed anti-join."""
        rows = self.connection.execute(
            """
            SELECT v.id,v.old_name,v.new_name,v.start,v.end
            FROM video AS v
            LEFT JOIN frame AS f
              ON f.video=v.id AND f.frame_offset<>0
            WHERE f.video IS NULL
            ORDER BY v.start,v.id
            """
        ).fetchall()
        return [
            CatalogVideo(
                int(row["id"]),
                str(row["old_name"]),
                str(row["new_name"]),
                float(row["start"]),
                float(row["end"]),
            )
            for row in rows
        ]

    def implausible_jump_videos(
        self,
        threshold_seconds: int,
    ) -> list[CatalogVideo]:
        if threshold_seconds < 2:
            raise CatalogError(
                "The implausible-jump threshold must be at least 2 seconds"
            )
        rows = self.connection.execute(
            """
            WITH ordered AS (
                SELECT
                    video,
                    second,
                    LAG(second) OVER (
                        PARTITION BY video
                        ORDER BY frame_offset,second
                    ) AS previous_second
                FROM frame
                WHERE frame_offset<>0
            ),
            suspect AS (
                SELECT DISTINCT video
                FROM ordered
                WHERE previous_second IS NOT NULL
                  AND (
                    second<=previous_second
                    OR second-previous_second>?
                  )
            )
            SELECT v.id,v.old_name,v.new_name,v.start,v.end
            FROM video AS v
            JOIN suspect AS s ON s.video=v.id
            ORDER BY v.start,v.id
            """,
            (threshold_seconds,),
        ).fetchall()
        return [
            CatalogVideo(
                int(row["id"]),
                str(row["old_name"]),
                str(row["new_name"]),
                float(row["start"]),
                float(row["end"]),
            )
            for row in rows
        ]

    def clear_frame_indexes(self, video_ids: Iterable[int]) -> None:
        with self.connection:
            self.connection.executemany(
                "DELETE FROM frame WHERE video=?",
                [(int(video_id),) for video_id in video_ids],
            )

    def update_video_interval(
        self,
        video_id: int,
        destination: Path,
        start: dt.datetime,
        end: dt.datetime,
    ) -> None:
        with self.connection:
            self.connection.execute(
                "UPDATE video SET new_name=?,start=?,end=? WHERE id=?",
                (destination.name, start.timestamp(), end.timestamp(), video_id),
            )

    def record_frames(self, video_id: int, second_frames: Sequence[SecondFrame]) -> None:
        with self.connection:
            self.connection.execute("DELETE FROM frame WHERE video=?", (video_id,))
            self.connection.executemany(
                "INSERT INTO frame(video,second,frame_offset) VALUES(?,?,?)",
                [
                    (video_id, round(item.timestamp.timestamp()), item.frame_number)
                    for item in second_frames
                ],
            )
            self._reconcile_cross_file_boundaries()

    def record_success(self, analysis: Analysis, destination: Path, timezone_name: str) -> None:
        del timezone_name  # Unix timestamps are timezone-independent.
        with self.connection:
            row = self.connection.execute(
                "SELECT id FROM video WHERE new_name=? ORDER BY id LIMIT 1", (destination.name,)
            ).fetchone()
            values = (
                analysis.source.name,
                destination.name,
                analysis.start.timestamp(),
                analysis.end.timestamp(),
            )
            if row is None:
                cursor = self.connection.execute(
                    "INSERT INTO video(old_name,new_name,start,end) VALUES(?,?,?,?)", values
                )
                video_id = int(cursor.lastrowid)
            else:
                video_id = int(row["id"])
                self.connection.execute(
                    "UPDATE video SET old_name=?,new_name=?,start=?,end=? WHERE id=?",
                    (*values, video_id),
                )
                self.connection.execute("DELETE FROM frame WHERE video=?", (video_id,))
            self.connection.executemany(
                "INSERT INTO frame(video,second,frame_offset) VALUES(?,?,?)",
                [
                    (video_id, round(item.timestamp.timestamp()), item.frame_number)
                    for item in analysis.second_frames
                ],
            )
            self._reconcile_cross_file_boundaries()

    def _reconcile_cross_file_boundaries(self) -> None:
        """Rebuild offset-zero rows when a chronologically earlier file arrives later."""
        self.connection.execute("DELETE FROM frame WHERE frame_offset=0")
        rows = self.connection.execute(
            "SELECT id,start,end FROM video ORDER BY start,id"
        ).fetchall()
        for previous, current in zip(rows, rows[1:]):
            if abs(float(current["start"]) - (float(previous["end"]) + 1.0)) > 0.001:
                continue
            completed = self.connection.execute(
                "SELECT 1 FROM frame WHERE video=? AND frame_offset<>0 LIMIT 1",
                (current["id"],),
            ).fetchone()
            if completed is None:
                continue
            self.connection.execute(
                "INSERT OR REPLACE INTO frame(video,second,frame_offset) VALUES(?,?,0)",
                (current["id"], round(float(current["start"]))),
            )


def time_for_filename(value: dt.datetime) -> str:
    base = value.strftime("%Y%m%dT%H%M%S")
    offset = value.utcoffset()
    if offset == dt.timedelta(0):
        return base + "Z"
    return base + value.strftime("%z")


def destination_for(analysis: Analysis | Registration, target_dir: Path) -> Path:
    extension = analysis.source.suffix.lower() or ".video"
    base = f"{time_for_filename(analysis.start)}--{time_for_filename(analysis.end)}"
    destination = target_dir / f"{base}{extension}"
    if destination == analysis.source:
        return destination
    if not destination.exists():
        return destination
    return target_dir / f"{base}__{analysis.fingerprint[:10]}{extension}"


def scan_paths(root: Path, recursive: bool, extensions: set[str], excluded: set[Path]) -> list[Path]:
    iterator: Iterable[Path] = root.rglob("*") if recursive else root.iterdir()
    result: list[Path] = []
    for path in iterator:
        if not path.is_file() or path.suffix.lower() not in extensions:
            continue
        if path in excluded or path.name.endswith((".part", ".tmp", ".download")):
            continue
        result.append(path)
    return sorted(result, key=lambda item: str(item))


@contextlib.contextmanager
def run_lock(path: Path, force: bool = False) -> Iterable[None]:
    if force:
        with contextlib.suppress(FileNotFoundError):
            path.unlink()
    try:
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        try:
            owner = path.read_text(encoding="utf-8").strip()
        except OSError:
            owner = "unknown"
        raise CatalogError(
            f"Another catalogue run may be active (lock {path}, owner {owner!r}). "
            "If the previous run crashed, rerun once with --force-unlock."
        ) from exc
    try:
        os.write(descriptor, f"pid={os.getpid()} started={utc_now_text()}\n".encode())
        os.close(descriptor)
        yield
    finally:
        with contextlib.suppress(FileNotFoundError):
            path.unlink()


def load_timezone(name: str) -> dt.tzinfo:
    if name.upper() == "UTC":
        return UTC
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise CatalogError(
            f"Unknown timezone {name!r}. On Windows install the 'tzdata' Python package."
        ) from exc


def parse_gpu_indices(value: str) -> tuple[int, ...]:
    try:
        indices = tuple(int(item.strip()) for item in value.split(",") if item.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("GPU indices must be comma-separated non-negative integers") from exc
    if not indices:
        raise argparse.ArgumentTypeError("At least one GPU index is required")
    if any(index < 0 for index in indices):
        raise argparse.ArgumentTypeError("GPU indices cannot be negative")
    if len(set(indices)) != len(indices):
        raise argparse.ArgumentTypeError("GPU indices cannot contain duplicates")
    return indices


def command_scan(args: argparse.Namespace) -> int:
    global _DIAGNOSTICS
    root = args.folder.resolve()
    if not root.is_dir():
        raise CatalogError(f"Video folder does not exist or is not a directory: {root}")
    if args.index_mode != "full":
        LOG.info("Deterministic glyph verification requires presentation-order frames; forcing --index-mode full")
        args.index_mode = "full"
    if args.gpu_indices:
        if args.index_mode != "full":
            LOG.info("GPU indices were supplied; forcing --index-mode full")
        args.index_mode = "full"
    db_path = (args.database or root / "video_catalog.sqlite3").resolve()
    hash_cache_path = (args.hash_cache or root / ".hikvision_sha256_cache.sqlite3").resolve()
    if hash_cache_path == db_path:
        raise CatalogError("--hash-cache must not point to the catalogue database")
    diagnostic_path = (args.diagnostic_log or root / "video_catalog_diagnostics.log").resolve()
    argument_snapshot = {
        key: value for key, value in vars(args).items() if key != "function"
    }
    _DIAGNOSTICS = DiagnosticLog(
        diagnostic_path,
        {
            "arguments": argument_snapshot,
            "python_version": sys.version,
            "python_executable": sys.executable,
            "platform": platform.platform(),
            "machine": platform.machine(),
            "cpu_count": os.cpu_count(),
            "working_directory": str(Path.cwd()),
        },
    )
    diagnostic_event("run_started", details=_DIAGNOSTICS.run_context)
    LOG.info("Diagnostic events will be appended to %s", diagnostic_path)
    lock_path = db_path.with_suffix(db_path.suffix + ".lock")
    extensions = {value.strip().lower() for value in args.extensions.split(",") if value.strip()}
    extensions = {value if value.startswith(".") else "." + value for value in extensions}
    timezone = load_timezone(args.timezone)
    template_path = (
        args.glyph_templates.resolve()
        if args.glyph_templates is not None
        else None
    )
    if args.gpu_indices:
        ocr_by_gpu = {
            index: GlyphTimestampOCR(
                args.ffmpeg,
                template_path,
                args.seek_preroll,
                args.ffmpeg_threads,
                index,
            )
            for index in args.gpu_indices
        }
        LOG.info(
            "CUDA single-pass full indexing enabled on GPU(s) %s",
            ",".join(str(index) for index in args.gpu_indices),
        )
    else:
        cpu_ocr = GlyphTimestampOCR(
            args.ffmpeg,
            template_path,
            args.seek_preroll,
            args.ffmpeg_threads,
        )
    target_dir = (args.target_dir or root).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg_version = executable_version(args.ffmpeg)
    ffprobe_version = executable_version(args.ffprobe)
    diagnostic_event(
        "tool_versions",
        details={"ffmpeg": ffmpeg_version, "ffprobe": ffprobe_version},
    )
    LOG.info("Local SHA-256 cache: %s", hash_cache_path)

    with run_lock(lock_path, args.force_unlock):
        hash_cache = SHA256Cache(hash_cache_path)
        db = CatalogDB(":memory:" if args.dry_run else db_path)
        if args.dry_run and db_path.exists():
            db.import_known_names(db_path)
        try:
            if args.reindex_jump_threshold is not None:
                suspect = db.implausible_jump_videos(
                    args.reindex_jump_threshold
                )
                for video in suspect:
                    LOG.info(
                        "%sreindex %s after detecting an implausible "
                        "timestamp jump",
                        "Would " if args.dry_run else "Will ",
                        video.new_name,
                    )
                db.clear_frame_indexes(video.id for video in suspect)
                diagnostic_event(
                    "implausible_jump_reindex_selected",
                    details={
                        "threshold_seconds": args.reindex_jump_threshold,
                        "count": len(suspect),
                        "files": [video.new_name for video in suspect],
                        "dry_run": args.dry_run,
                    },
                )
            paths = scan_paths(
                root,
                args.recursive,
                extensions,
                {db_path, hash_cache_path, lock_path},
            )
            now = time.time()
            candidates: list[tuple[Path, os.stat_result]] = []
            skipped_young = 0
            skipped_known = 0
            for path in paths:
                stat = path.stat()
                if db.known("", path):
                    skipped_known += 1
                elif now - stat.st_mtime < args.min_age:
                    skipped_young += 1
                    LOG.info(
                        "Waiting for file to become stable (age %.1fs < %.1fs): %s",
                        now - stat.st_mtime,
                        args.min_age,
                        path,
                    )
                else:
                    candidates.append((path, stat))

            failures = 0
            registered_count = 0
            indexed_count = 0
            hash_cache_hits = 0
            hash_cache_misses = 0
            failed_files: list[str] = []
            dry_run_jobs: list[tuple[CatalogVideo, Path, str]] = []
            fingerprint_by_video: dict[int, str] = {}

            def gpu_for(sequence: int) -> int | None:
                if not args.gpu_indices:
                    return None
                return args.gpu_indices[sequence % len(args.gpu_indices)]

            def ocr_for(gpu_index: int | None) -> GlyphTimestampOCR:
                return ocr_by_gpu[gpu_index] if gpu_index is not None else cpu_ocr

            def report_failure(
                video: Path,
                fingerprint: str,
                gpu_index: int | None,
                stage: str,
                exc: Exception,
            ) -> None:
                nonlocal failures
                failures += 1
                failed_files.append(str(video.resolve(strict=False)))
                message = (
                    str(exc)
                    if isinstance(exc, CatalogError)
                    else "".join(traceback.format_exception(exc))
                )
                LOG.error("Could not %s %s: %s", stage, video, message)
                diagnostic_event(
                    "file_failed",
                    video=video,
                    assumption=(
                        "Endpoint registration succeeds before the independent "
                        "per-second frame index is committed."
                    ),
                    details={
                        "stage": stage,
                        "content_fingerprint_sha256": fingerprint or None,
                        "error_type": type(exc).__name__,
                        "error": message,
                        "gpu_index": gpu_index,
                        "traceback": (
                            None
                            if isinstance(exc, CatalogError)
                            else "".join(traceback.format_exception(exc))
                        ),
                        "media": (
                            diagnostic_media_snapshot(
                                video, args.ffprobe, args.ffmpeg_threads
                            )
                            if video.exists()
                            else {"probe_error": "file no longer exists"}
                        ),
                    },
                )

            LOG.info(
                "Found %d video(s): %d unregistered, %d already registered, %d too recent",
                len(paths),
                len(candidates),
                skipped_known,
                skipped_young,
            )

            # Phase 1: endpoint OCR and rename. Full indexing is intentionally
            # not submitted until every currently visible rotating name has
            # either been secured or produced an explicit registration error.
            registration_workers = min(max(1, args.workers), max(1, len(candidates)))
            registration_futures: dict[
                concurrent.futures.Future[Registration],
                tuple[Path, str, int | None],
            ] = {}

            def handle_registration(
                future: concurrent.futures.Future[Registration],
            ) -> None:
                nonlocal registered_count
                path, fingerprint, gpu_index = registration_futures.pop(future)
                destination: Path | None = None
                try:
                    registration = future.result()
                    destination = destination_for(registration, target_dir)
                    if destination != path and destination.exists():
                        counter = 2
                        stem, suffix = destination.stem, destination.suffix
                        while destination.exists():
                            destination = destination.with_name(
                                f"{stem}__{counter}{suffix}"
                            )
                            counter += 1
                    if args.dry_run:
                        video_id = -(len(dry_run_jobs) + 1)
                        dry_run_jobs.append(
                            (
                                CatalogVideo(
                                    video_id,
                                    path.name,
                                    destination.name,
                                    registration.start.timestamp(),
                                    registration.end.timestamp(),
                                ),
                                path,
                                fingerprint,
                            )
                        )
                        LOG.info(
                            "DRY RUN register %s -> %s [%s .. %s]",
                            path.name,
                            destination.name,
                            registration.start.isoformat(),
                            registration.end.isoformat(),
                        )
                    else:
                        # Rename first. If the following SQLite transaction
                        # fails, the next scan rediscovers the interval-named
                        # file; the collision-prone recorder name is still safe.
                        if destination != path:
                            path.rename(destination)
                        video_id = db.register_video(registration, destination)
                        fingerprint_by_video[video_id] = fingerprint
                        LOG.info(
                            "Registered and secured %s -> %s [%s .. %s]; "
                            "per-second indexing is pending",
                            path.name,
                            destination.name,
                            registration.start.isoformat(),
                            registration.end.isoformat(),
                        )
                    registered_count += 1
                except Exception as exc:
                    failed_video = (
                        destination
                        if destination is not None and destination.exists()
                        else path
                    )
                    report_failure(
                        failed_video, fingerprint, gpu_index, "register video endpoints", exc
                    )

            with concurrent.futures.ThreadPoolExecutor(
                max_workers=registration_workers,
                thread_name_prefix="register",
            ) as pool:
                submitted = 0
                for candidate_index, (path, discovered_stat) in enumerate(candidates, 1):
                    try:
                        before_hash = path.stat()
                    except OSError as exc:
                        skipped_young += 1
                        LOG.warning(
                            "Could not stat candidate before hashing; retrying next run: %s: %s",
                            path,
                            exc,
                        )
                        continue
                    if (
                        discovered_stat.st_size,
                        discovered_stat.st_mtime_ns,
                    ) != (before_hash.st_size, before_hash.st_mtime_ns):
                        skipped_young += 1
                        LOG.warning(
                            "File changed before hashing and will be retried next run: %s",
                            path,
                        )
                        continue
                    size_mib = before_hash.st_size / (1024 * 1024)
                    timestamp_source, creation_ns = local_creation_timestamp(before_hash)
                    fingerprint = hash_cache.get(
                        path.name, timestamp_source, creation_ns
                    )
                    cache_hit = fingerprint is not None
                    hash_elapsed: float | None = None
                    if cache_hit:
                        hash_cache_hits += 1
                        LOG.info(
                            "SHA-256 cache hit for candidate %d/%d: %s",
                            candidate_index,
                            len(candidates),
                            path.name,
                        )
                    else:
                        hash_cache_misses += 1
                        LOG.info(
                            "Hashing candidate %d/%d (%.1f MiB): %s",
                            candidate_index,
                            len(candidates),
                            size_mib,
                            path.name,
                        )
                        started = time.monotonic()
                        fingerprint = content_fingerprint(path)
                        hash_elapsed = max(0.000001, time.monotonic() - started)
                    after_hash = path.stat()
                    after_source, after_creation_ns = local_creation_timestamp(after_hash)
                    if (
                        before_hash.st_size,
                        before_hash.st_mtime_ns,
                        timestamp_source,
                        creation_ns,
                    ) != (
                        after_hash.st_size,
                        after_hash.st_mtime_ns,
                        after_source,
                        after_creation_ns,
                    ):
                        skipped_young += 1
                        LOG.warning(
                            "File changed while hashing and will be retried next run: %s",
                            path,
                        )
                        continue
                    assert fingerprint is not None
                    if not cache_hit:
                        hash_cache.put(
                            path.name, timestamp_source, creation_ns, fingerprint
                        )
                    gpu_index = gpu_for(submitted)
                    future = pool.submit(
                        analyse_video_registration,
                        path,
                        fingerprint,
                        ocr_for(gpu_index),
                        args.ffprobe,
                        timezone,
                        args.minimum_confidence,
                    )
                    registration_futures[future] = (
                        path,
                        fingerprint,
                        gpu_index,
                    )
                    submitted += 1
                    executor_name = (
                        f"GPU {gpu_index}" if gpu_index is not None else "CPU"
                    )
                    if cache_hit:
                        LOG.info(
                            "Submitted cached %s for endpoint registration on %s",
                            path.name,
                            executor_name,
                        )
                    else:
                        assert hash_elapsed is not None
                        LOG.info(
                            "Hashed %s in %.1fs (%.1f MiB/s); submitted endpoint "
                            "registration on %s",
                            path.name,
                            hash_elapsed,
                            size_mib / hash_elapsed,
                            executor_name,
                        )
                    for done in [
                        item for item in registration_futures if item.done()
                    ]:
                        handle_registration(done)
                for future in concurrent.futures.as_completed(
                    tuple(registration_futures)
                ):
                    handle_registration(future)

            # Phase 2: the anti-join includes both newly registered files and
            # unfinished rows from any earlier interrupted/failed run.
            pending_jobs: list[tuple[CatalogVideo, Path, str]] = []
            for video in db.pending_videos():
                path = target_dir / video.new_name
                if not path.exists():
                    matches = [item for item in paths if item.name == video.new_name]
                    if len(matches) == 1:
                        path = matches[0]
                pending_jobs.append(
                    (video, path, fingerprint_by_video.get(video.id, ""))
                )
            pending_jobs.extend(dry_run_jobs)
            LOG.info(
                "Registration phase complete: %d newly registered; "
                "%d video(s) need per-second indexing",
                registered_count,
                len(pending_jobs),
            )

            index_workers = min(max(1, args.workers), max(1, len(pending_jobs)))
            index_futures: dict[
                concurrent.futures.Future[Analysis],
                tuple[CatalogVideo, Path, str, int | None],
            ] = {}
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=index_workers,
                thread_name_prefix="index",
            ) as pool:
                for sequence, (video, path, fingerprint) in enumerate(pending_jobs):
                    if not path.exists():
                        report_failure(
                            path,
                            fingerprint,
                            None,
                            "index registered video (file missing)",
                            CatalogError(
                                f"Registered file is missing: {path}; "
                                f"database video id={video.id}, old_name={video.old_name!r}"
                            ),
                        )
                        continue
                    gpu_index = gpu_for(sequence)
                    future = pool.submit(
                        analyse_video,
                        path,
                        fingerprint,
                        ocr_for(gpu_index),
                        args.ffprobe,
                        timezone,
                        args.samples_per_edge,
                        args.edge_seconds,
                        args.minimum_confidence,
                        args.maximum_timing_spread,
                        args.transition_threshold,
                        "full",
                        args.boundary_search_seconds,
                        args.boundary_workers,
                    )
                    index_futures[future] = (
                        video,
                        path,
                        fingerprint,
                        gpu_index,
                    )

                for future in concurrent.futures.as_completed(index_futures):
                    video, path, fingerprint, gpu_index = index_futures[future]
                    try:
                        analysis = future.result()
                        expected_start = dt.datetime.fromtimestamp(video.start, timezone)
                        expected_end = dt.datetime.fromtimestamp(video.end, timezone)
                        destination = path
                        if (
                            analysis.start != expected_start
                            or analysis.end != expected_end
                        ):
                            corrected_fingerprint = (
                                fingerprint or content_fingerprint(path)
                            )
                            corrected = dataclasses.replace(
                                analysis,
                                fingerprint=corrected_fingerprint,
                                source=path,
                            )
                            destination = destination_for(corrected, target_dir)
                            if destination != path and destination.exists():
                                counter = 2
                                stem, suffix = destination.stem, destination.suffix
                                while destination.exists():
                                    destination = destination.with_name(
                                        f"{stem}__{counter}{suffix}"
                                    )
                                    counter += 1
                            diagnostic_event(
                                "endpoint_interval_corrected",
                                video=path,
                                assumption=(
                                    "Fast endpoint OCR and full sequential OCR identify "
                                    "the same first and final displayed seconds."
                                ),
                                details={
                                    "registered_start": expected_start.isoformat(),
                                    "registered_end": expected_end.isoformat(),
                                    "indexed_start": analysis.start.isoformat(),
                                    "indexed_end": analysis.end.isoformat(),
                                    "corrected_name": destination.name,
                                },
                            )
                            LOG.warning(
                                "Full indexing corrected endpoint interval for %s: "
                                "[%s .. %s] -> [%s .. %s]",
                                path.name,
                                expected_start.isoformat(),
                                expected_end.isoformat(),
                                analysis.start.isoformat(),
                                analysis.end.isoformat(),
                            )
                            if not args.dry_run:
                                if destination != path:
                                    path.rename(destination)
                                db.update_video_interval(
                                    video.id,
                                    destination,
                                    analysis.start,
                                    analysis.end,
                                )
                        if args.dry_run:
                            LOG.info(
                                "DRY RUN index %s: %d verified first-frames-of-second",
                                destination.name,
                                len(analysis.second_frames),
                            )
                        else:
                            db.record_frames(video.id, analysis.second_frames)
                            LOG.info(
                                "Indexed %s: %d verified first-frames-of-second",
                                destination.name,
                                len(analysis.second_frames),
                            )
                        indexed_count += 1
                    except Exception as exc:
                        report_failure(
                            path,
                            fingerprint,
                            gpu_index,
                            "build per-second frame index",
                            exc,
                        )

            LOG.info(
                "Catalogue run finished: %d registered, %d indexed, %d failed",
                registered_count,
                indexed_count,
                failures,
            )
            diagnostic_event(
                "run_finished",
                details={
                    "registered": registered_count,
                    "indexed": indexed_count,
                    "succeeded": indexed_count,
                    "failed": failures,
                    "failed_files": failed_files,
                    "pending_after_run": len(db.pending_videos())
                    if not args.dry_run
                    else None,
                    "sha256_cache_hits": hash_cache_hits,
                    "sha256_cache_misses": hash_cache_misses,
                },
            )
            return 1 if failures else 0
        finally:
            db.close()
            hash_cache.close()


def default_layout() -> dict[str, Any]:
    # Coordinates are relative to the ROI after the input is normalized to 2560x2560.
    # The supplied camera writes a fixed 32x44 pixel outlined OSD font.
    roi_y = 110
    cell_y = 20
    cell_width = 36
    cell_height = 56
    centers = [76, 108, 139, 170, 262, 293, 387, 419]
    time_centers = [778, 816, 879, 917, 979, 1017]
    return {
        "description": "Hikvision 2560x2560 upper-left Chinese date/time OSD",
        "reference_width": 2560,
        "reference_height": 2560,
        "roi": [0, roi_y, 1050, 100],
        "cell_width": cell_width,
        "cell_height": cell_height,
        "date_cells": [[center - cell_width // 2, cell_y, cell_width, cell_height] for center in centers],
        "time_cells": [[center - cell_width // 2, cell_y, cell_width, cell_height] for center in time_centers],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Rename Hikvision videos by their on-screen time interval and catalogue them in SQLite."
    )
    parser.add_argument("--verbose", action="store_true", help="show debug diagnostics")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan = subparsers.add_parser("scan", help="process new or changed videos in a folder")
    scan.add_argument("folder", type=Path, help="folder containing downloaded videos")
    scan.add_argument(
        "--glyph-templates",
        type=Path,
        default=None,
        help="custom calibrated glyph archive (default: bundled)",
    )
    scan.add_argument("--database", type=Path, help="SQLite path (default: FOLDER/video_catalog.sqlite3)")
    scan.add_argument(
        "--hash-cache",
        type=Path,
        help="local SHA-256 cache path (default: FOLDER/.hikvision_sha256_cache.sqlite3)",
    )
    scan.add_argument(
        "--diagnostic-log",
        type=Path,
        help="append JSON-lines diagnostics here (default: FOLDER/video_catalog_diagnostics.log)",
    )
    scan.add_argument("--target-dir", type=Path, help="rename/move catalogued files here (default: in place)")
    scan.add_argument("--timezone", default="UTC", help="timezone displayed by the camera, e.g. UTC or Asia/Shanghai")
    scan.add_argument("--extensions", default=DEFAULT_EXTENSIONS, help="comma-separated video extensions")
    scan.add_argument("--recursive", action="store_true", help="scan subdirectories too")
    scan.add_argument("--min-age", type=float, default=120.0, help="ignore files modified more recently than this")
    scan.add_argument(
        "--reindex-jump-threshold",
        type=int,
        metavar="SECONDS",
        help=(
            "discard and rebuild frame indexes containing a forward jump "
            "larger than this or any backwards jump"
        ),
    )
    scan.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1), help="parallel video analyses")
    scan.add_argument(
        "--ffmpeg-threads",
        type=int,
        default=0,
        help="decoder threads per FFmpeg/FFprobe process (0 lets FFmpeg choose)",
    )
    scan.add_argument(
        "--gpu-indices",
        type=parse_gpu_indices,
        default=(),
        metavar="LIST",
        help=(
            "comma-separated NVIDIA GPU indices; enables CUDA/NVDEC, forces full indexing, "
            "and assigns videos round-robin (example: 0,1,2,3)"
        ),
    )
    scan.add_argument("--ffmpeg", default="ffmpeg")
    scan.add_argument("--ffprobe", default="ffprobe")
    scan.add_argument("--seek-preroll", type=float, default=10.0)
    scan.add_argument("--samples-per-edge", type=int, default=3)
    scan.add_argument("--edge-seconds", type=float, default=25.0)
    scan.add_argument("--minimum-confidence", type=float, default=0.75)
    scan.add_argument("--maximum-timing-spread", type=float, default=1.25)
    scan.add_argument(
        "--transition-threshold",
        type=float,
        default=2.5,
        help="mean pixel change that triggers OCR of adjacent frames (default: 2.5)",
    )
    scan.add_argument(
        "--index-mode",
        choices=("projected", "full"),
        default="projected",
        help="project narrow random-access windows (default) or decode every frame",
    )
    scan.add_argument(
        "--boundary-search-seconds",
        type=float,
        default=0.25,
        help="half-width of each projected timestamp-transition search window (default: 0.25)",
    )
    scan.add_argument(
        "--boundary-workers",
        type=int,
        default=min(8, os.cpu_count() or 1),
        help="parallel projected GOP batches per video",
    )
    scan.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "analyze and report without renaming or changing the catalogue database "
            "(the disposable local hash cache may be updated)"
        ),
    )
    scan.add_argument("--force-unlock", action="store_true", help="remove a stale run lock before starting")
    scan.set_defaults(function=command_scan)

    calibration = subparsers.add_parser(
        "build-templates",
        help="one-time RapidOCR calibration of deterministic digit templates",
    )
    calibration.add_argument("output", type=Path, help="output .npz template archive")
    calibration.add_argument("videos", nargs="+", type=Path, help="representative camera videos")
    calibration.add_argument("--ffmpeg", default="ffmpeg")
    calibration.add_argument(
        "--sample-seconds",
        type=float,
        default=60.0,
        help="seconds sampled from the beginning of each training video (default: 60)",
    )
    calibration.add_argument(
        "--sample-fps",
        type=float,
        default=1.0,
        help="training frames per source-video second (default: 1)",
    )
    calibration.add_argument(
        "--minimum-confidence",
        type=float,
        default=0.85,
        help="minimum RapidOCR confidence for a calibration frame (default: 0.85)",
    )
    calibration.set_defaults(function=command_build_templates)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    try:
        if getattr(args, "workers", 1) < 1:
            raise CatalogError("--workers must be at least 1")
        if getattr(args, "ffmpeg_threads", 0) < 0:
            raise CatalogError("--ffmpeg-threads cannot be negative")
        if getattr(args, "samples_per_edge", 1) < 1:
            raise CatalogError("--samples-per-edge must be at least 1")
        if getattr(args, "boundary_workers", 1) < 1:
            raise CatalogError("--boundary-workers must be at least 1")
        if getattr(args, "boundary_search_seconds", 1.0) <= 0:
            raise CatalogError("--boundary-search-seconds must be positive")
        return int(args.function(args))
    except CatalogError as exc:
        diagnostic_event(
            "run_failed",
            assumption="Catalogue startup and run-level invariants hold.",
            details={"error_type": type(exc).__name__, "error": str(exc)},
        )
        LOG.error("%s", exc)
        return 1
    except KeyboardInterrupt:
        LOG.warning("Interrupted")
        return 130
    except Exception:
        diagnostic_event(
            "run_failed",
            assumption="No unexpected program exception occurs.",
            details={"error_type": "unexpected", "traceback": traceback.format_exc()},
        )
        LOG.exception("Unexpected failure")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
