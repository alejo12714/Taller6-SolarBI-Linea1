"""Typed configuration shared by the command-line entry points."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Mapping

from .errors import ConfigurationError


def deep_merge(base: Mapping[str, Any], override: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


DEFAULT_CONFIG: dict[str, Any] = {
    "media": {
        "ffmpeg": "ffmpeg",
        "ffprobe": "ffprobe",
        "accelerator": "auto",
        "devices": [],
        "decoder_threads": 0,
        "workers": 4,
        "seek_preroll_seconds": 10.0,
    },
    "models": {
        "cache": ".models",
        "ocr_size": "auto",
    },
    "archive": {
        "root": "output",
        "timezone": "UTC",
        "video_database": "video_catalog.sqlite3",
        "frame_database": "state.sqlite3",
        "glyph_templates": None,
        "jpeg_quality": 5,
        "max_width": 0,
        "max_height": 0,
    },
    "privacy": {
        "work_dir": "human_review_scan",
        "candidate_count": 2500,
        "second_pass_count": 4200,
        "workers": 6,
    },
}


@dataclass(frozen=True)
class MediaSettings:
    ffmpeg: str = "ffmpeg"
    ffprobe: str = "ffprobe"
    accelerator: str = "auto"
    devices: tuple[int, ...] = ()
    decoder_threads: int = 0
    workers: int = 4
    seek_preroll_seconds: float = 10.0


@dataclass(frozen=True)
class ModelSettings:
    cache: Path = Path(".models")
    ocr_size: str = "auto"


@dataclass(frozen=True)
class ArchiveSettings:
    root: Path = Path("output")
    timezone: str = "UTC"
    video_database: Path = Path("video_catalog.sqlite3")
    frame_database: Path = Path("state.sqlite3")
    glyph_templates: Path | None = None
    jpeg_quality: int = 5
    max_width: int = 0
    max_height: int = 0

    def under_root(self, path: Path) -> Path:
        return path if path.is_absolute() else self.root / path


@dataclass(frozen=True)
class PrivacySettings:
    work_dir: Path = Path("human_review_scan")
    candidate_count: int = 2500
    second_pass_count: int = 4200
    workers: int = 6


@dataclass(frozen=True)
class PipelineConfig:
    media: MediaSettings = field(default_factory=MediaSettings)
    models: ModelSettings = field(default_factory=ModelSettings)
    archive: ArchiveSettings = field(default_factory=ArchiveSettings)
    privacy: PrivacySettings = field(default_factory=PrivacySettings)

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "PipelineConfig":
        merged = deep_merge(DEFAULT_CONFIG, values)
        media = merged["media"]
        models = merged["models"]
        archive = merged["archive"]
        privacy = merged["privacy"]
        config = cls(
            media=MediaSettings(
                ffmpeg=str(media["ffmpeg"]),
                ffprobe=str(media["ffprobe"]),
                accelerator=str(media["accelerator"]).casefold(),
                devices=tuple(int(item) for item in media.get("devices", ())),
                decoder_threads=int(media["decoder_threads"]),
                workers=int(media["workers"]),
                seek_preroll_seconds=float(media["seek_preroll_seconds"]),
            ),
            models=ModelSettings(
                cache=Path(models["cache"]),
                ocr_size=str(models["ocr_size"]).casefold(),
            ),
            archive=ArchiveSettings(
                root=Path(archive["root"]),
                timezone=str(archive["timezone"]),
                video_database=Path(archive["video_database"]),
                frame_database=Path(archive["frame_database"]),
                glyph_templates=(
                    Path(archive["glyph_templates"])
                    if archive.get("glyph_templates")
                    else None
                ),
                jpeg_quality=int(archive["jpeg_quality"]),
                max_width=int(archive["max_width"]),
                max_height=int(archive["max_height"]),
            ),
            privacy=PrivacySettings(
                work_dir=Path(privacy["work_dir"]),
                candidate_count=int(privacy["candidate_count"]),
                second_pass_count=int(privacy["second_pass_count"]),
                workers=int(privacy["workers"]),
            ),
        )
        config.validate()
        return config

    def validate(self) -> None:
        if self.media.accelerator not in {
            "auto", "cpu", "cuda", "videotoolbox", "d3d11va"
        }:
            raise ConfigurationError(f"Unknown media accelerator: {self.media.accelerator}")
        if self.media.decoder_threads < 0:
            raise ConfigurationError("media.decoder_threads cannot be negative")
        if self.media.workers < 1 or self.privacy.workers < 1:
            raise ConfigurationError("worker counts must be positive")
        if self.media.seek_preroll_seconds < 0:
            raise ConfigurationError("media.seek_preroll_seconds cannot be negative")
        if not 2 <= self.archive.jpeg_quality <= 31:
            raise ConfigurationError("archive.jpeg_quality must be between 2 and 31")
        dimensions = (
            self.archive.max_width,
            self.archive.max_height,
        )
        if any(value < 0 for value in dimensions):
            raise ConfigurationError(
                "archive maximum dimensions cannot be negative"
            )
        if bool(dimensions[0]) != bool(dimensions[1]):
            raise ConfigurationError(
                "archive.max_width and archive.max_height must both be zero "
                "or both be positive"
            )
        if self.models.ocr_size not in {"auto", "tiny", "small", "medium"}:
            raise ConfigurationError("models.ocr_size must be auto, tiny, small, or medium")


def load_config(path: Path | None = None) -> PipelineConfig:
    if path is None:
        return PipelineConfig.from_mapping({})
    try:
        supplied = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigurationError(f"Configuration file does not exist: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(supplied, dict):
        raise ConfigurationError("The top-level configuration value must be an object")
    return PipelineConfig.from_mapping(supplied)
