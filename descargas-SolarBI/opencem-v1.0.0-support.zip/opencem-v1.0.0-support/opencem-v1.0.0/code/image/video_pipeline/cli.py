"""Command-line adapters for the reusable library."""

from __future__ import annotations

import argparse
import dataclasses
import logging
import os
from pathlib import Path
import shlex
import subprocess
import sys
from typing import Sequence
from urllib.parse import urlparse

from .acquisition import AcquisitionStore
from .catalogs import merge_catalog_folders
from .config import PipelineConfig, load_config
from .errors import PipelineError
from .frames import (
    FrameArchive,
    JPEGSettings,
    MinuteFrameExtractor,
)
from .hardware import detect_hardware
from .indexing import (
    CatalogRepository,
    CatalogService,
    FingerprintCache,
    HikvisionOverlayBackend,
)
from .media import MediaTools
from .models import (
    download_artifact,
    load_manifest,
    pip_install_command,
    prepare_rapidocr,
    runtime_plan,
    select_artifact,
)
from .privacy import (
    AppleVisionScanner,
    OnnxPersonScanner,
    apply_human_decisions,
    load_decisions,
    load_scores,
    rank_candidates,
    write_candidates,
    write_second_pass_indices,
)


def _common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--config", type=Path)
    parser.add_argument("--ffmpeg")
    parser.add_argument("--ffprobe")
    parser.add_argument(
        "--accelerator",
        choices=("auto", "cpu", "cuda", "videotoolbox", "d3d11va"),
    )
    parser.add_argument("--devices", help="comma-separated CUDA device indices")
    parser.add_argument("--decoder-threads", type=int)
    parser.add_argument("--workers", type=int)
    parser.add_argument("--verbose", action="store_true")


def _configuration(args: argparse.Namespace) -> PipelineConfig:
    config = load_config(args.config)
    devices = (
        tuple(int(item) for item in args.devices.split(",") if item.strip())
        if getattr(args, "devices", None)
        else config.media.devices
    )
    media = dataclasses.replace(
        config.media,
        ffmpeg=args.ffmpeg or config.media.ffmpeg,
        ffprobe=args.ffprobe or config.media.ffprobe,
        accelerator=args.accelerator or config.media.accelerator,
        devices=devices,
        decoder_threads=(
            args.decoder_threads
            if args.decoder_threads is not None
            else config.media.decoder_threads
        ),
        workers=args.workers or config.media.workers,
    )
    result = dataclasses.replace(config, media=media)
    result.validate()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    return result


def _media(config: PipelineConfig):
    hardware = detect_hardware(
        config.media.ffmpeg,
        config.media.accelerator,
        config.media.devices,
    )
    tools = MediaTools(
        config.media.ffmpeg,
        config.media.ffprobe,
        hardware,
        config.media.decoder_threads,
        config.media.seek_preroll_seconds,
    )
    logging.info(
        "Media accelerator: %s (%s/%s)",
        hardware.accelerator.value,
        hardware.system,
        hardware.machine,
    )
    return hardware, tools


def acquire_frames_main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Extract full-minute JPEGs using the persistent presentation-frame index."
        )
    )
    _common(parser)
    parser.add_argument(
        "--database",
        type=Path,
        help="frame and exclusion state database",
    )
    parser.add_argument(
        "--catalog-database",
        type=Path,
        help="video/frame index database",
    )
    parser.add_argument(
        "--video-dir",
        type=Path,
        help="directory containing the indexed local video files",
    )
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--templates", type=Path)
    parser.add_argument("--timezone")
    parser.add_argument("--diagnostic-log", type=Path)
    args = parser.parse_args(argv)
    try:
        config = _configuration(args)
        hardware, media = _media(config)
        root = (args.output_root or config.archive.root).resolve()
        database = (
            args.database or config.archive.under_root(
                config.archive.frame_database
            )
        ).resolve()
        catalog_database = (
            args.catalog_database
            or config.archive.under_root(config.archive.video_database)
        ).resolve()
        video_dir = (args.video_dir or root / "videos").resolve()
        if not video_dir.is_dir():
            raise PipelineError(
                f"Video directory does not exist or is not a directory: {video_dir}"
            )
        template_value = args.templates or config.archive.glyph_templates
        templates = (
            template_value.resolve()
            if template_value is not None
            else None
        )
        timezone = args.timezone or config.archive.timezone
        backend = HikvisionOverlayBackend(
            ffmpeg=config.media.ffmpeg,
            ffprobe=config.media.ffprobe,
            templates=templates,
            timezone=timezone,
            hardware=hardware,
            model_cache=config.models.cache.resolve(),
            ocr_size=config.models.ocr_size,
            decoder_threads=config.media.decoder_threads,
            seek_preroll=config.media.seek_preroll_seconds,
            diagnostic_log=(
                args.diagnostic_log
                or root / "frame_index_diagnostics.log"
            ).resolve(),
        )
        extractor = MinuteFrameExtractor(
            media,
            JPEGSettings(
                quality=config.archive.jpeg_quality,
                max_width=config.archive.max_width,
                max_height=config.archive.max_height,
                timezone=timezone,
            ),
        )
        extracted = 0
        completed = 0
        with (
            AcquisitionStore(database) as store,
            CatalogRepository(catalog_database) as catalog,
        ):
            archive = FrameArchive(store)
            for video in catalog.all_videos():
                path = video_dir / video.new_name
                if not path.is_file():
                    fallback = video_dir / video.old_name
                    path = fallback if fallback.is_file() else path
                if not path.is_file():
                    raise PipelineError(
                        f"Catalogued video file is missing: {path}"
                    )
                count = extractor.extract(
                    path,
                    segment_id=f"catalog:{video.id}",
                    root=root,
                    archive=archive,
                    catalog=catalog,
                    backend=backend,
                    worker=completed,
                )
                extracted += count
                completed += 1
        logging.info(
            "Completed %d segment(s); wrote %d JPEG(s)",
            completed,
            extracted,
        )
        return 0
    except PipelineError as exc:
        logging.error("%s", exc)
        return 1


def index_videos_main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Rename videos by overlay interval and build a full frame index."
    )
    _common(parser)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--target", type=Path)
    parser.add_argument("--database", type=Path)
    parser.add_argument("--hash-cache", type=Path)
    parser.add_argument("--diagnostic-log", type=Path)
    parser.add_argument("--templates", type=Path)
    parser.add_argument("--timezone")
    parser.add_argument("--recursive", action="store_true")
    parser.add_argument("--min-age", type=float, default=120)
    parser.add_argument(
        "--reindex-jump-threshold",
        type=int,
        metavar="SECONDS",
        help=(
            "discard and rebuild frame indexes containing a forward jump "
            "larger than this or any backwards jump"
        ),
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    try:
        config = _configuration(args)
        hardware, _ = _media(config)
        root = args.folder.resolve()
        if not root.is_dir():
            hint = (
                ' Paths containing spaces should be quoted without a '
                'backslash, for example "/path/to/video archive".'
                if "\\" in str(root)
                else ""
            )
            raise PipelineError(
                f"Video folder does not exist or is not a directory: "
                f"{root}.{hint}"
            )
        target = (args.target or root).resolve()
        database = (
            args.database
            or config.archive.under_root(config.archive.video_database)
        ).resolve()
        cache_path = (
            args.hash_cache
            or database.with_name(".video_sha256_cache.sqlite3")
        ).resolve()
        template_value = args.templates or config.archive.glyph_templates
        templates = (
            template_value.resolve()
            if template_value is not None
            else None
        )
        timezone = args.timezone or config.archive.timezone
        backend = HikvisionOverlayBackend(
            ffmpeg=config.media.ffmpeg,
            ffprobe=config.media.ffprobe,
            templates=templates,
            timezone=timezone,
            hardware=hardware,
            model_cache=config.models.cache.resolve(),
            ocr_size=config.models.ocr_size,
            decoder_threads=config.media.decoder_threads,
            seek_preroll=config.media.seek_preroll_seconds,
            diagnostic_log=(
                args.diagnostic_log or root / "video_catalog_diagnostics.log"
            ).resolve(),
        )
        repository = CatalogRepository(database)
        cache = FingerprintCache(cache_path)
        try:
            report = CatalogService(
                repository,
                backend,
                cache,
                workers=config.media.workers,
                timezone=timezone,
            ).scan(
                root,
                target=target,
                recursive=args.recursive,
                min_age=args.min_age,
                dry_run=args.dry_run,
                reindex_jump_threshold=args.reindex_jump_threshold,
            )
        finally:
            cache.close()
            repository.close()
        logging.info(
            "Discovered %d; registered %d; indexed %d; "
            "removed %d duplicate(s); already complete %d",
            report.discovered,
            report.registered,
            report.indexed,
            report.duplicates_removed,
            report.skipped_complete,
        )
        if report.anomaly_reindexes:
            logging.info(
                "Selected %d catalogue video(s) for full reindexing",
                report.anomaly_reindexes,
            )
        for failure in report.failures:
            logging.error("%s", failure)
        backend.diagnostic(
            "run_finished",
            {
                "discovered": report.discovered,
                "registered": report.registered,
                "indexed": report.indexed,
                "duplicates_removed": report.duplicates_removed,
                "anomaly_reindexes": report.anomaly_reindexes,
                "already_complete": report.skipped_complete,
                "failed": len(report.failures),
                "failed_files": list(report.failures),
            },
        )
        return 1 if report.failures else 0
    except PipelineError as exc:
        logging.error("%s", exc)
        return 1


def privacy_main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Scan, rank, and apply local frame-privacy review."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    scan = subparsers.add_parser("scan")
    _common(scan)
    scan.add_argument("--root", type=Path)
    scan.add_argument("--output", type=Path)
    scan.add_argument("--model", type=Path)
    scan.add_argument("--qnn-model", action="store_true")
    scan.add_argument("--body-pose", action="store_true")
    scan.add_argument("--swift-source", type=Path)
    scan.add_argument("--indices-file", type=Path)
    scan.add_argument("--perimeter-tiles", action="store_true")
    scan.add_argument("--mask", type=Path)
    scan.add_argument("--build-mask", type=Path)
    scan.add_argument("--mask-samples", type=int)
    scan.add_argument("--skip-change", action="store_true")

    rank = subparsers.add_parser("rank")
    _common(rank)
    rank.add_argument("--raw", type=Path, required=True)
    rank.add_argument("--tiled", type=Path)
    rank.add_argument("--output-dir", type=Path)
    rank.add_argument("--count", type=int)
    rank.add_argument("--prepare-indices", type=Path)
    rank.add_argument("--second-pass-count", type=int)

    apply = subparsers.add_parser("apply")
    _common(apply)
    apply.add_argument("--review", type=Path, required=True)
    apply.add_argument("--scores", type=Path, required=True)
    apply.add_argument("--output-root", type=Path)
    apply.add_argument("--database", type=Path)
    apply.add_argument("--dry-run", action="store_true")

    args = parser.parse_args(argv)
    try:
        config = _configuration(args)
        if args.command == "scan":
            hardware, _ = _media(config)
            root = args.root or config.archive.root / "frames"
            output = args.output or (
                config.archive.root
                / config.privacy.work_dir
                / "raw_scores.csv"
            )
            if hardware.apple_silicon and args.model is None:
                source = (
                    args.swift_source
                    or Path(__file__).with_name("swift")
                    / "vision_human_scan.swift"
                )
                binary = config.archive.root / ".tools" / "vision_human_scan"
                extra: list[str] = []
                for option, value in (
                    ("--indices-file", args.indices_file),
                    ("--mask", args.mask),
                    ("--build-mask", args.build_mask),
                    ("--mask-samples", args.mask_samples),
                ):
                    if value is not None:
                        extra.extend([option, str(value)])
                if args.skip_change:
                    extra.append("--skip-change")
                AppleVisionScanner(source, binary).scan(
                    root,
                    output,
                    workers=config.privacy.workers,
                    body_pose=args.body_pose,
                    perimeter_tiles=args.perimeter_tiles,
                    extra_arguments=extra,
                )
            else:
                if args.model is None:
                    raise PipelineError(
                        "--model is required for non-Apple privacy scanning"
                    )
                plan = runtime_plan(
                    hardware,
                    ocr_size=config.models.ocr_size,
                    qnn_quantized_model=args.qnn_model,
                )
                OnnxPersonScanner(args.model, plan).scan(root, output)
            logging.info("Wrote privacy scores to %s", output)
        elif args.command == "rank":
            raw_rows = load_scores(args.raw)
            if args.prepare_indices:
                destination = write_second_pass_indices(
                    raw_rows,
                    args.prepare_indices,
                    args.second_pass_count
                    or config.privacy.second_pass_count,
                )
                logging.info("Wrote second-pass indices to %s", destination)
            if args.output_dir:
                rows = rank_candidates(
                    raw_rows,
                    load_scores(args.tiled) if args.tiled else [],
                    count=args.count or config.privacy.candidate_count,
                )
                csv_path, html_path = write_candidates(rows, args.output_dir)
                logging.info("Wrote %s and %s", csv_path, html_path)
            if not args.prepare_indices and not args.output_dir:
                raise PipelineError(
                    "Specify --prepare-indices and/or --output-dir"
                )
        else:
            root = (args.output_root or config.archive.root).resolve()
            database = (
                args.database
                or config.archive.under_root(config.archive.frame_database)
            )
            decisions = load_decisions(args.review, args.scores)
            flagged = apply_human_decisions(
                decisions,
                output_root=root,
                database=database,
                dry_run=args.dry_run,
            )
            logging.info("Applied %d human exclusion(s)", len(flagged))
        return 0
    except PipelineError as exc:
        logging.error("%s", exc)
        return 1


def merge_catalogs_main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Merge indexed input folders into the final output folder. "
            "The last positional path is the output."
        )
    )
    parser.add_argument(
        "folders",
        nargs="+",
        type=Path,
        metavar="FOLDER",
        help="one or more inputs followed by the output folder",
    )
    parser.add_argument(
        "--database-name",
        default="video_catalog.sqlite3",
        help="catalogue filename used in every folder",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    try:
        if len(args.folders) < 2:
            raise PipelineError(
                "Specify at least one input folder followed by the output folder"
            )
        report = merge_catalog_folders(
            args.folders[:-1],
            args.folders[-1],
            database_name=args.database_name,
            dry_run=args.dry_run,
        )
        action = "Would import" if args.dry_run else "Imported"
        logging.info(
            "%s %d of %d source video(s); %d duplicate(s); "
            "%d destination index repair(s)",
            action,
            report.imported,
            report.discovered,
            report.duplicates,
            report.repaired_indexes,
        )
        for failure in report.failures:
            logging.error("%s", failure)
        return 1 if report.failures else 0
    except PipelineError as exc:
        logging.error("%s", exc)
        return 1


def prepare_models_main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Select and prepare ONNX runtimes and models for this machine."
    )
    _common(parser)
    parser.add_argument("--install-runtime", action="store_true")
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--model-name")
    parser.add_argument("--model-output", type=Path)
    parser.add_argument("--qnn-model", action="store_true")
    args = parser.parse_args(argv)
    try:
        config = _configuration(args)
        hardware, _ = _media(config)
        plan = runtime_plan(
            hardware,
            device=hardware.device() or 0,
            ocr_size=config.models.ocr_size,
            qnn_quantized_model=args.qnn_model,
        )
        command = pip_install_command(plan, sys.executable)
        print(f"accelerator={hardware.accelerator.value}")
        print(f"onnx_provider={plan.provider}")
        print(f"ocr_model_size={plan.rapidocr_size}")
        display_command = (
            subprocess.list2cmdline(command)
            if os.name == "nt"
            else shlex.join(command)
        )
        print("install=" + display_command)
        if plan.note:
            print("note=" + plan.note)
        if args.install_runtime:
            completed = subprocess.run(command, check=False)
            if completed.returncode:
                raise PipelineError(
                    f"Runtime installation exited with {completed.returncode}"
                )
        if args.prepare:
            prepare_rapidocr(plan, config.models.cache.resolve())
            print(f"model_cache={config.models.cache.resolve()}")
        if args.manifest or args.model_name or args.model_output:
            if not args.manifest or not args.model_name:
                raise PipelineError(
                    "--manifest and --model-name must be supplied together"
                )
            artifact = select_artifact(
                load_manifest(args.manifest),
                args.model_name,
                plan,
            )
            destination = args.model_output or (
                config.models.cache.resolve()
                / args.model_name
                / artifact.variant
                / (
                    Path(urlparse(artifact.url).path).name
                    or f"{args.model_name}.onnx"
                )
            )
            download_artifact(artifact, destination)
            print(f"model={destination.resolve()}")
            print(f"model_variant={artifact.variant}")
        return 0
    except PipelineError as exc:
        logging.error("%s", exc)
        return 1
