"""Reusable video acquisition, indexing, frame extraction, and review tools."""

from .config import PipelineConfig, load_config
from .hardware import Accelerator, HardwareProfile, detect_hardware

__all__ = [
    "Accelerator",
    "HardwareProfile",
    "PipelineConfig",
    "detect_hardware",
    "load_config",
]

__version__ = "0.1.0"
