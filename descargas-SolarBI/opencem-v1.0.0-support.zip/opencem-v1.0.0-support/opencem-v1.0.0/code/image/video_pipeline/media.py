"""Portable FFmpeg and FFprobe command construction."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import subprocess
from typing import Any, Sequence

from .errors import MediaError
from .hardware import HardwareProfile


@dataclass(frozen=True)
class VideoInfo:
    duration: float
    size: int
    codec: str
    width: int
    height: int
    start_time: float = 0.0


class MediaTools:
    def __init__(
        self,
        ffmpeg: str,
        ffprobe: str,
        hardware: HardwareProfile,
        decoder_threads: int = 0,
        seek_preroll: float = 10.0,
    ):
        self.ffmpeg = ffmpeg
        self.ffprobe = ffprobe
        self.hardware = hardware
        self.decoder_threads = decoder_threads
        self.seek_preroll = seek_preroll

    def run(
        self,
        command: Sequence[str],
        purpose: str,
        *,
        timeout: float | None = 120,
    ) -> subprocess.CompletedProcess[bytes]:
        try:
            completed = subprocess.run(
                list(command),
                capture_output=True,
                check=False,
                timeout=timeout,
            )
        except FileNotFoundError as exc:
            raise MediaError(f"Executable not found while trying to {purpose}: {command[0]}") from exc
        except subprocess.TimeoutExpired as exc:
            raise MediaError(f"Timed out while trying to {purpose}") from exc
        if completed.returncode:
            raise MediaError(
                f"Could not {purpose} (exit {completed.returncode}). "
                f"Command: {list(command)!r}. stderr: "
                f"{completed.stderr[-4000:].decode('utf-8', 'replace')}"
            )
        return completed

    def probe(self, path: Path) -> VideoInfo:
        thread_args = ["-threads", str(self.decoder_threads)] if self.decoder_threads else []
        completed = self.run(
            [
                self.ffprobe,
                "-v", "error",
                *thread_args,
                "-select_streams", "v:0",
                "-show_entries",
                "format=duration,size,start_time:stream=codec_name,width,height",
                "-of", "json",
                str(path),
            ],
            f"probe video {path}",
        )
        try:
            data = json.loads(completed.stdout)
            stream = data["streams"][0]
            container = data["format"]
            info = VideoInfo(
                duration=float(container["duration"]),
                size=int(container.get("size", path.stat().st_size)),
                codec=str(stream["codec_name"]),
                width=int(stream["width"]),
                height=int(stream["height"]),
                start_time=float(container.get("start_time", 0.0)),
            )
        except (IndexError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise MediaError(f"FFprobe returned unusable metadata for {path}") from exc
        if info.duration <= 0 or info.width <= 0 or info.height <= 0:
            raise MediaError(f"FFprobe returned invalid dimensions or duration for {path}: {info}")
        return info

    def decoder_args(self, sequence: int = 0) -> list[str]:
        args: list[str] = []
        if self.decoder_threads:
            args.extend(["-threads", str(self.decoder_threads)])
        args.extend(self.hardware.decoder_input_args(sequence))
        return args

    def seek_input_args(
        self,
        video: Path,
        offset: float,
        sequence: int = 0,
    ) -> list[str]:
        if offset < 0:
            raise MediaError(f"Cannot seek to negative video offset {offset:.6f}s")
        input_seek = max(0.0, offset - self.seek_preroll)
        accurate_seek = offset - input_seek
        args: list[str] = []
        if input_seek:
            args.extend(["-ss", f"{input_seek:.6f}"])
        args.extend(self.decoder_args(sequence))
        args.extend(["-i", str(video)])
        if accurate_seek:
            args.extend(["-ss", f"{accurate_seek:.6f}"])
        return args

    def software_filters(self, filters: Sequence[str]) -> str:
        return ",".join([*self.hardware.software_filter_prefix(), *filters])
