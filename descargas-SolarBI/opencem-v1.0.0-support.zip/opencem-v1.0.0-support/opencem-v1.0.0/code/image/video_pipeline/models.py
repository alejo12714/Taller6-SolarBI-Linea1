"""Hardware-aware ONNX runtime and model provisioning."""

from __future__ import annotations

import ctypes
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import tempfile
from typing import Any, Mapping
from urllib.request import urlopen

from .errors import ConfigurationError
from .hardware import Accelerator, HardwareProfile


@dataclass(frozen=True)
class RuntimePlan:
    pip_package: str
    provider: str
    model_variant: str
    rapidocr_size: str
    rapidocr_parameters: dict[str, Any]
    note: str = ""


def runtime_plan(
    hardware: HardwareProfile,
    *,
    device: int = 0,
    ocr_size: str = "auto",
    qnn_quantized_model: bool = False,
) -> RuntimePlan:
    if hardware.accelerator is Accelerator.CUDA:
        size = "medium" if ocr_size == "auto" else ocr_size
        if hardware.cuda_major is not None and hardware.cuda_major >= 13:
            package = "onnxruntime-gpu[cuda,cudnn]>=1.27,<2"
            note = "CUDA 13 detected; selecting ONNX Runtime 1.27 or newer."
        else:
            package = "onnxruntime-gpu[cuda,cudnn]>=1.21,<1.27"
            note = (
                "Selecting the CUDA 12.8/cuDNN 9 ONNX Runtime series"
                if hardware.cuda_major == 12
                else
                "CUDA major version was not detected; defaulting to the "
                "CUDA 12.8/cuDNN 9 ONNX Runtime series"
            )
        return RuntimePlan(
            package,
            "CUDAExecutionProvider",
            "cuda-fp16",
            size,
            {
                "EngineConfig.onnxruntime.use_cuda": True,
                "EngineConfig.onnxruntime.cuda_ep_cfg.device_id": device,
            },
            note,
        )
    if hardware.apple_silicon:
        size = "small" if ocr_size == "auto" else ocr_size
        return RuntimePlan(
            "onnxruntime",
            "CoreMLExecutionProvider",
            "coreml-fp16",
            size,
            {
                "EngineConfig.onnxruntime.use_coreml": True,
                "EngineConfig.onnxruntime.coreml_ep_cfg.ModelFormat": "MLProgram",
                "EngineConfig.onnxruntime.coreml_ep_cfg.MLComputeUnits": "ALL",
            },
        )
    if hardware.windows_arm and qnn_quantized_model:
        size = "tiny" if ocr_size == "auto" else ocr_size
        return RuntimePlan(
            "onnxruntime-qnn",
            "QNNExecutionProvider",
            "qnn-int8",
            size,
            {},
            "QNN requires a compatible quantized QDQ model; RapidOCR uses its CPU fallback.",
        )
    if hardware.windows_arm:
        size = "tiny" if ocr_size == "auto" else ocr_size
        return RuntimePlan(
            "onnxruntime",
            "CPUExecutionProvider",
            "arm64-fp32",
            size,
            {},
            "The OCR model is not QNN-quantized; FFmpeg decoding still uses D3D11VA.",
        )
    size = "small" if ocr_size == "auto" else ocr_size
    return RuntimePlan(
        "onnxruntime",
        "CPUExecutionProvider",
        "cpu-fp32",
        size,
        {},
    )


def pip_install_command(plan: RuntimePlan, python: str = "python") -> list[str]:
    return [
        python,
        "-m",
        "pip",
        "install",
        "rapidocr>=3.9,<4",
        plan.pip_package,
    ]


def prepare_rapidocr(
    plan: RuntimePlan,
    cache: Path,
) -> Any:
    """Instantiate RapidOCR, downloading the selected official model if needed."""
    preload_onnxruntime(plan)
    try:
        from rapidocr import ModelType, RapidOCR
    except ImportError as exc:
        raise ConfigurationError(
            "RapidOCR runtime is not installed; run video-models "
            "--install-runtime"
        ) from exc
    cache.mkdir(parents=True, exist_ok=True)
    model_type = getattr(ModelType, plan.rapidocr_size.upper())
    parameters = {
        "Det.model_type": model_type,
        "Rec.model_type": model_type,
        **plan.rapidocr_parameters,
    }
    try:
        return RapidOCR(params=parameters, model_root_dir=str(cache))
    except Exception as exc:
        raise ConfigurationError(
            f"Could not prepare the {plan.rapidocr_size} OCR model: {exc}"
        ) from exc


def preload_onnxruntime(plan: RuntimePlan) -> None:
    if plan.provider != "CUDAExecutionProvider":
        return
    try:
        import onnxruntime as ort
    except ImportError:
        return
    preload = getattr(ort, "preload_dlls", None)
    if preload is not None:
        try:
            preload(directory="")
        except TypeError:
            preload()
    capi = Path(ort.__file__).resolve().parent / "capi"
    names = (
        "onnxruntime_providers_cuda.dll"
        if hasattr(ctypes, "WinDLL")
        else "libonnxruntime_providers_cuda.so"
    )
    libraries = list(capi.glob(names))
    if not libraries:
        raise ConfigurationError(
            "The installed ONNX Runtime package has no CUDA provider library"
        )
    try:
        ctypes.CDLL(str(libraries[0]))
    except OSError as exc:
        raise ConfigurationError(
            "ONNX Runtime's CUDA provider could not load its CUDA/cuDNN "
            f"dependencies: {exc}. Re-run video-models --install-runtime."
        ) from exc


@dataclass(frozen=True)
class ModelArtifact:
    name: str
    variant: str
    url: str
    sha256: str


def select_artifact(
    manifest: Mapping[str, Any],
    model_name: str,
    plan: RuntimePlan,
) -> ModelArtifact:
    try:
        variants = manifest["models"][model_name]["variants"]
    except (KeyError, TypeError) as exc:
        raise ConfigurationError(f"Model {model_name!r} is absent from the manifest") from exc
    preferences = [
        plan.model_variant,
        "arm64-fp32" if plan.model_variant == "qnn-int8" else "",
        "cpu-fp32",
    ]
    for variant in preferences:
        if variant and variant in variants:
            values = variants[variant]
            return ModelArtifact(
                model_name,
                variant,
                str(values["url"]),
                str(values["sha256"]).casefold(),
            )
    raise ConfigurationError(
        f"Model {model_name!r} has no suitable variant for {plan.model_variant}"
    )


def load_manifest(path: Path) -> dict[str, Any]:
    try:
        values = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigurationError(f"Could not read model manifest {path}: {exc}") from exc
    if not isinstance(values, dict) or not isinstance(values.get("models"), dict):
        raise ConfigurationError(f"Invalid model manifest: {path}")
    return values


def download_artifact(artifact: ModelArtifact, destination: Path) -> Path:
    """Download atomically and verify the configured SHA-256 digest."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and _sha256(destination) == artifact.sha256:
        return destination
    with tempfile.NamedTemporaryFile(
        prefix=destination.name + ".",
        suffix=".part",
        dir=destination.parent,
        delete=False,
    ) as temporary:
        temporary_path = Path(temporary.name)
        try:
            with urlopen(artifact.url, timeout=120) as response:
                while chunk := response.read(1024 * 1024):
                    temporary.write(chunk)
        except Exception as exc:
            temporary_path.unlink(missing_ok=True)
            raise ConfigurationError(
                f"Could not download {artifact.name}/{artifact.variant} "
                f"from {artifact.url}: {exc}"
            ) from exc
    digest = _sha256(temporary_path)
    if digest != artifact.sha256:
        temporary_path.unlink(missing_ok=True)
        raise ConfigurationError(
            f"Checksum mismatch for {artifact.name}/{artifact.variant}: "
            f"expected {artifact.sha256}, got {digest}"
        )
    temporary_path.replace(destination)
    return destination


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()
