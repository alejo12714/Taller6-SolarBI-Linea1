# Video pipeline package

This directory contains the public Python implementation, publication-safe
calibrated overlay glyph data, Apple Vision source, and the end-to-end local
video example required by the installed package. Runtime paths do not refer to
repository-root scripts or assets.

Install the project with one ONNX runtime extra suitable for the machine:

```sh
python -m pip install '.[cpu]'       # CPU, Apple Silicon, or Windows ARM
python -m pip install '.[cuda]'      # CUDA 12
python -m pip install '.[cuda13]'    # CUDA 13
python -m pip install '.[qnn]'       # Snapdragon QNN model execution
```

Python dependencies are declared in `pyproject.toml`. The media operations
also require `ffmpeg` and `ffprobe` on `PATH`, or explicit executable paths in
the configuration. Apple Vision privacy scanning requires macOS, the system
Vision framework, and the Xcode command-line Swift compiler (`xcrun swiftc`).
CUDA operation requires a compatible NVIDIA driver.

RapidOCR downloads its selected official model into the configured model
cache. Non-Apple privacy scanning additionally requires a compatible
YOLO-style person-detection ONNX model supplied with `--model` or downloaded
from a checksum-pinned manifest.

Installed commands are:

```text
video-index
frame-acquire
video-merge
frame-privacy
video-models
```

`example_full_pipeline.sh` starts from local video files and demonstrates full
indexing, release-configured minute extraction, privacy candidate generation,
and application of completed review decisions. Component-specific recorder
authentication, search, and download code is not distributed.
