import Foundation
import Vision
import ImageIO
import CoreGraphics

struct Options {
    var root = "output/frames"
    var output = "output/human_review_scan/raw_scores.csv"
    var workers = 6
    var startIndex = 0
    var limit = 0
    var stride = 1
    var thumbnailSize = 256
    var includeBodyPose = false
    var skipChange = false
    var mask = ""
    var buildMask = ""
    var maskSamples = 800
    var indicesFile = ""
    var perimeterTiles = false
}

struct ChangeScore {
    var tileMean: Double = 0
    var changedFraction: Double = 0
    var reliable = false
}

struct DetectionScore {
    let index: Int
    let path: String
    let humanFullCount: Int
    let humanUpperCount: Int
    let faceCount: Int
    let poseCount: Int
    let humanFullConfidence: Float
    let humanUpperConfidence: Float
    let faceConfidence: Float
    let poseConfidence: Float
    let edgeTouch: Bool
    let change: ChangeScore
    let error: String
}

func parseOptions() -> Options {
    var options = Options()
    var index = 1
    let arguments = CommandLine.arguments
    while index < arguments.count {
        let argument = arguments[index]
        func value() -> String {
            guard index + 1 < arguments.count else {
                fputs("Missing value after \(argument)\n", stderr)
                exit(2)
            }
            index += 1
            return arguments[index]
        }
        switch argument {
        case "--root": options.root = value()
        case "--output": options.output = value()
        case "--workers": options.workers = Int(value()) ?? 0
        case "--start-index": options.startIndex = Int(value()) ?? 0
        case "--limit": options.limit = Int(value()) ?? 0
        case "--stride": options.stride = Int(value()) ?? 0
        case "--thumbnail-size": options.thumbnailSize = Int(value()) ?? 0
        case "--body-pose": options.includeBodyPose = true
        case "--skip-change": options.skipChange = true
        case "--mask": options.mask = value()
        case "--build-mask": options.buildMask = value()
        case "--mask-samples": options.maskSamples = Int(value()) ?? 0
        case "--indices-file": options.indicesFile = value()
        case "--perimeter-tiles": options.perimeterTiles = true
        case "--help":
            print("""
            Usage: vision_human_scan [options]
              --root PATH            Frame archive root
              --output PATH          Raw CSV destination
              --workers N            Concurrent Vision workers (default 6)
              --start-index N        Start at this sorted archive index
              --limit N              Process at most N selected images
              --stride N             Select every Nth image
              --thumbnail-size N     Change-analysis size (default 256)
              --body-pose            Also run human body-pose detection
              --skip-change          Do not calculate temporal change scores
              --mask PATH            PGM stable-perimeter mask for change analysis
              --build-mask PATH      Learn and write a PGM mask before scanning
              --mask-samples N       Frames used to learn the mask (default 800)
              --indices-file PATH    Scan only archive indices listed in a text file
              --perimeter-tiles      Run eight overlapping magnified edge tiles
            """)
            exit(0)
        default:
            fputs("Unknown argument: \(argument)\n", stderr)
            exit(2)
        }
        index += 1
    }
    guard options.workers > 0, options.stride > 0, options.thumbnailSize >= 64, options.maskSamples > 1 else {
        fputs("workers and stride must be positive; thumbnail size must be at least 64\n", stderr)
        exit(2)
    }
    return options
}

func discoverImages(root: URL) -> [URL] {
    guard let enumerator = FileManager.default.enumerator(
        at: root,
        includingPropertiesForKeys: [.isRegularFileKey],
        options: [.skipsHiddenFiles]
    ) else {
        return []
    }
    var images: [URL] = []
    for case let url as URL in enumerator where url.pathExtension.lowercased() == "jpg" {
        images.append(url)
    }
    return images.sorted { $0.path < $1.path }
}

func timestamp(from url: URL) -> Date? {
    let stem = url.deletingPathExtension().lastPathComponent
    guard stem.count >= 15 else { return nil }
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.timeZone = TimeZone(secondsFromGMT: 0)
    formatter.dateFormat = "yyyyMMdd'T'HHmmssX"
    return formatter.date(from: stem)
}

func grayscaleThumbnail(url: URL, size: Int) -> [UInt8]? {
    let options: [CFString: Any] = [
        kCGImageSourceCreateThumbnailFromImageAlways: true,
        kCGImageSourceCreateThumbnailWithTransform: true,
        kCGImageSourceThumbnailMaxPixelSize: size,
        kCGImageSourceShouldCacheImmediately: true,
    ]
    guard
        let source = CGImageSourceCreateWithURL(url as CFURL, nil),
        let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    else {
        return nil
    }
    var pixels = [UInt8](repeating: 0, count: size * size)
    guard let context = CGContext(
        data: &pixels,
        width: size,
        height: size,
        bitsPerComponent: 8,
        bytesPerRow: size,
        space: CGColorSpaceCreateDeviceGray(),
        bitmapInfo: CGImageAlphaInfo.none.rawValue
    ) else {
        return nil
    }
    context.interpolationQuality = .low
    context.draw(image, in: CGRect(x: 0, y: 0, width: size, height: size))
    return pixels
}

func adjacent(_ first: URL, _ second: URL) -> Bool {
    guard let firstDate = timestamp(from: first), let secondDate = timestamp(from: second) else {
        return false
    }
    let difference = abs(secondDate.timeIntervalSince(firstDate))
    return difference >= 50 && difference <= 130
}

func writePGM(path: URL, pixels: [UInt8], size: Int) throws {
    var data = Data("P5\n\(size) \(size)\n255\n".utf8)
    data.append(contentsOf: pixels)
    try FileManager.default.createDirectory(
        at: path.deletingLastPathComponent(),
        withIntermediateDirectories: true
    )
    try data.write(to: path, options: .atomic)
}

func readPGM(path: URL, expectedSize: Int) throws -> [UInt8] {
    let data = try Data(contentsOf: path)
    let marker = Data("\n255\n".utf8)
    guard let markerRange = data.range(of: marker) else {
        throw NSError(domain: "VisionHumanScan", code: 1, userInfo: [
            NSLocalizedDescriptionKey: "Unsupported PGM header in \(path.path)"
        ])
    }
    let pixels = Array(data[markerRange.upperBound...])
    guard pixels.count == expectedSize * expectedSize else {
        throw NSError(domain: "VisionHumanScan", code: 2, userInfo: [
            NSLocalizedDescriptionKey:
                "PGM \(path.path) contains \(pixels.count) pixels, expected \(expectedSize * expectedSize)"
        ])
    }
    return pixels
}

func buildStableMask(files: [URL], size: Int, sampleCount: Int) -> [UInt8] {
    let count = size * size
    var sums = [Double](repeating: 0, count: count)
    var squaredSums = [Double](repeating: 0, count: count)
    let actualSamples = min(sampleCount, files.count)
    var loaded = 0
    for sample in 0..<actualSamples {
        let index = actualSamples == 1 ? 0 : sample * (files.count - 1) / (actualSamples - 1)
        autoreleasepool {
            guard let pixels = grayscaleThumbnail(url: files[index], size: size) else { return }
            for pixel in 0..<count {
                let value = Double(pixels[pixel])
                sums[pixel] += value
                squaredSums[pixel] += value * value
            }
            loaded += 1
        }
        if (sample + 1) % 100 == 0 || sample + 1 == actualSamples {
            fputs("Mask learning \(sample + 1)/\(actualSamples)\n", stderr)
        }
    }
    guard loaded > 1 else { return [UInt8](repeating: 0, count: count) }
    let center = Double(size - 1) / 2.0
    let radius = Double(size) / 2.0
    var base = [UInt8](repeating: 0, count: count)
    for y in 0..<size {
        for x in 0..<size {
            let pixel = y * size + x
            let mean = sums[pixel] / Double(loaded)
            let variance = max(0, squaredSums[pixel] / Double(loaded) - mean * mean)
            let deviation = sqrt(variance)
            let dx = (Double(x) - center) / radius
            let dy = (Double(y) - center) / radius
            let radial = sqrt(dx * dx + dy * dy)
            let timestampOverlay = y < Int(Double(size) * 0.13) && x < Int(Double(size) * 0.48)
            if radial >= 0.56 && radial <= 1.06
                && mean >= 8 && deviation <= 24 && !timestampOverlay {
                base[pixel] = 255
            }
        }
    }

    // Expand a few pixels into adjacent sky so protruding heads and limbs remain measurable.
    var dilated = base
    let dilationRadius = max(2, size / 96)
    for y in 0..<size {
        for x in 0..<size where base[y * size + x] > 0 {
            for offsetY in -dilationRadius...dilationRadius {
                for offsetX in -dilationRadius...dilationRadius {
                    let targetX = x + offsetX
                    let targetY = y + offsetY
                    if targetX >= 0 && targetX < size && targetY >= 0 && targetY < size {
                        dilated[targetY * size + targetX] = 255
                    }
                }
            }
        }
    }
    return dilated
}

func changeScore(
    previous: [UInt8]?,
    current: [UInt8],
    next: [UInt8]?,
    size: Int,
    hasPrevious: Bool,
    hasNext: Bool,
    mask: [UInt8]?
) -> ChangeScore {
    guard hasPrevious || hasNext else { return ChangeScore() }
    let count = size * size
    let center = Double(size - 1) / 2.0
    let radius = Double(size) / 2.0
    var roiIndices: [Int] = []
    roiIndices.reserveCapacity(count / 2)
    for y in 0..<size {
        for x in 0..<size {
            let dx = (Double(x) - center) / radius
            let dy = (Double(y) - center) / radius
            let radial = sqrt(dx * dx + dy * dy)
            let pixel = y * size + x
            let included = mask.map { $0[pixel] > 0 } ?? (radial >= 0.58 && radial <= 1.03)
            if included {
                roiIndices.append(pixel)
            }
        }
    }

    func exposureDelta(_ neighbor: [UInt8]?) -> Int {
        guard let neighbor else { return 0 }
        var total = 0
        for pixel in roiIndices {
            total += Int(current[pixel]) - Int(neighbor[pixel])
        }
        return roiIndices.isEmpty ? 0 : total / roiIndices.count
    }

    let previousDelta = exposureDelta(previous)
    let nextDelta = exposureDelta(next)
    let tileSize = max(8, size / 16)
    var maximumMean = 0.0
    var maximumFraction = 0.0

    for tileY in stride(from: 0, to: size, by: tileSize) {
        for tileX in stride(from: 0, to: size, by: tileSize) {
            var totalDifference = 0
            var changed = 0
            var pixelsInTile = 0
            var includedPixels = 0
            let endY = min(size, tileY + tileSize)
            let endX = min(size, tileX + tileSize)
            for y in tileY..<endY {
                for x in tileX..<endX {
                    let pixel = y * size + x
                    let dx = (Double(x) - center) / radius
                    let dy = (Double(y) - center) / radius
                    let radial = sqrt(dx * dx + dy * dy)
                    let included = mask.map { $0[pixel] > 0 } ?? (radial >= 0.58 && radial <= 1.03)
                    if !included { continue }
                    includedPixels += 1
                    let previousDifference: Int
                    if hasPrevious, let previous {
                        previousDifference = abs(Int(current[pixel]) - Int(previous[pixel]) - previousDelta)
                    } else {
                        previousDifference = 255
                    }
                    let nextDifference: Int
                    if hasNext, let next {
                        nextDifference = abs(Int(current[pixel]) - Int(next[pixel]) - nextDelta)
                    } else {
                        nextDifference = 255
                    }
                    let difference = hasPrevious && hasNext
                        ? min(previousDifference, nextDifference)
                        : min(previousDifference, nextDifference)
                    totalDifference += difference
                    if difference >= 20 { changed += 1 }
                    pixelsInTile += 1
                }
            }
            let tileArea = (endY - tileY) * (endX - tileX)
            guard pixelsInTile > 0, includedPixels * 8 >= tileArea else { continue }
            maximumMean = max(maximumMean, Double(totalDifference) / Double(pixelsInTile))
            maximumFraction = max(maximumFraction, Double(changed) / Double(pixelsInTile))
        }
    }
    return ChangeScore(tileMean: maximumMean, changedFraction: maximumFraction, reliable: true)
}

func calculateChanges(
    files: [URL],
    selectedIndices: [Int],
    size: Int,
    mask: [UInt8]?
) -> [Int: ChangeScore] {
    var results: [Int: ChangeScore] = [:]
    let total = selectedIndices.count
    let contiguous = selectedIndices.indices.dropFirst().allSatisfy {
        selectedIndices[$0] == selectedIndices[$0 - 1] + 1
    }
    if contiguous, let first = selectedIndices.first, let last = selectedIndices.last {
        var previous = first > 0 ? grayscaleThumbnail(url: files[first - 1], size: size) : nil
        var current = grayscaleThumbnail(url: files[first], size: size)
        var next = first < files.count - 1
            ? grayscaleThumbnail(url: files[first + 1], size: size)
            : nil
        for index in first...last {
            autoreleasepool {
                guard let current else {
                    results[index] = ChangeScore()
                    return
                }
                let hasPrevious = index > 0 && adjacent(files[index - 1], files[index])
                let hasNext = index + 1 < files.count && adjacent(files[index], files[index + 1])
                results[index] = changeScore(
                    previous: hasPrevious ? previous : nil,
                    current: current,
                    next: hasNext ? next : nil,
                    size: size,
                    hasPrevious: hasPrevious,
                    hasNext: hasNext,
                    mask: mask
                )
            }
            previous = current
            current = next
            let following = index + 2
            next = following < files.count
                ? grayscaleThumbnail(url: files[following], size: size)
                : nil
            let position = index - first + 1
            if position % 1000 == 0 || position == total {
                fputs("Change analysis \(position)/\(total)\n", stderr)
            }
        }
        return results
    }

    for (position, index) in selectedIndices.enumerated() {
        autoreleasepool {
            guard let current = grayscaleThumbnail(url: files[index], size: size) else {
                results[index] = ChangeScore()
                return
            }
            let hasPrevious = index > 0 && adjacent(files[index - 1], files[index])
            let hasNext = index + 1 < files.count && adjacent(files[index], files[index + 1])
            let previous = hasPrevious ? grayscaleThumbnail(url: files[index - 1], size: size) : nil
            let next = hasNext ? grayscaleThumbnail(url: files[index + 1], size: size) : nil
            results[index] = changeScore(
                previous: previous,
                current: current,
                next: next,
                size: size,
                hasPrevious: hasPrevious,
                hasNext: hasNext,
                mask: mask
            )
        }
        if (position + 1) % 500 == 0 || position + 1 == total {
            fputs("Change analysis \(position + 1)/\(total)\n", stderr)
        }
    }
    return results
}

func touchesEdge(_ rectangle: CGRect, margin: CGFloat = 0.035) -> Bool {
    rectangle.minX <= margin || rectangle.minY <= margin
        || rectangle.maxX >= 1.0 - margin || rectangle.maxY >= 1.0 - margin
}

func scanChunk(
    worker: Int,
    selected: [(position: Int, archiveIndex: Int, url: URL)],
    changes: [Int: ChangeScore],
    includeBodyPose: Bool,
    perimeterTiles: Bool,
    callback: (Int, DetectionScore) -> Void
) {
    let fullBody = VNDetectHumanRectanglesRequest()
    fullBody.upperBodyOnly = false
    let upperBody = VNDetectHumanRectanglesRequest()
    upperBody.upperBodyOnly = true
    let faces = VNDetectFaceRectanglesRequest()
    let poses = includeBodyPose ? VNDetectHumanBodyPoseRequest() : nil
    var requests: [VNRequest] = [fullBody, upperBody, faces]
    if let poses { requests.append(poses) }
    let regions: [CGRect] = perimeterTiles
        ? [
            CGRect(x: 0.00, y: 0.58, width: 0.42, height: 0.42),
            CGRect(x: 0.29, y: 0.58, width: 0.42, height: 0.42),
            CGRect(x: 0.58, y: 0.58, width: 0.42, height: 0.42),
            CGRect(x: 0.00, y: 0.29, width: 0.42, height: 0.42),
            CGRect(x: 0.58, y: 0.29, width: 0.42, height: 0.42),
            CGRect(x: 0.00, y: 0.00, width: 0.42, height: 0.42),
            CGRect(x: 0.29, y: 0.00, width: 0.42, height: 0.42),
            CGRect(x: 0.58, y: 0.00, width: 0.42, height: 0.42),
        ]
        : [CGRect(x: 0, y: 0, width: 1, height: 1)]

    for (localPosition, item) in selected.enumerated() {
        let result: DetectionScore = autoreleasepool {
            do {
                let handler = VNImageRequestHandler(url: item.url, orientation: .up, options: [:])
                var fullCount = 0
                var upperCount = 0
                var faceCount = 0
                var poseCount = 0
                var fullConfidence: Float = 0
                var upperConfidence: Float = 0
                var faceConfidence: Float = 0
                var poseConfidence: Float = 0
                var edgeTouch = false
                for region in regions {
                    fullBody.regionOfInterest = region
                    upperBody.regionOfInterest = region
                    faces.regionOfInterest = region
                    poses?.regionOfInterest = region
                    try handler.perform(requests)
                    let fullResults = fullBody.results ?? []
                    let upperResults = upperBody.results ?? []
                    let faceResults = faces.results ?? []
                    let poseResults = poses?.results ?? []
                    fullCount += fullResults.count
                    upperCount += upperResults.count
                    faceCount += faceResults.count
                    poseCount += poseResults.count
                    fullConfidence = max(fullConfidence, fullResults.map(\.confidence).max() ?? 0)
                    upperConfidence = max(upperConfidence, upperResults.map(\.confidence).max() ?? 0)
                    faceConfidence = max(faceConfidence, faceResults.map(\.confidence).max() ?? 0)
                    poseConfidence = max(poseConfidence, poseResults.map(\.confidence).max() ?? 0)
                    let outerLeft = region.minX <= 0.001
                    let outerRight = region.maxX >= 0.999
                    let outerBottom = region.minY <= 0.001
                    let outerTop = region.maxY >= 0.999
                    let allRectangles =
                        fullResults.map(\.boundingBox)
                        + upperResults.map(\.boundingBox)
                        + faceResults.map(\.boundingBox)
                    if allRectangles.contains(where: { rectangle in
                        (outerLeft && rectangle.minX <= 0.035)
                            || (outerRight && rectangle.maxX >= 0.965)
                            || (outerBottom && rectangle.minY <= 0.035)
                            || (outerTop && rectangle.maxY >= 0.965)
                    }) {
                        edgeTouch = true
                    }
                }
                return DetectionScore(
                    index: item.archiveIndex,
                    path: item.url.path,
                    humanFullCount: fullCount,
                    humanUpperCount: upperCount,
                    faceCount: faceCount,
                    poseCount: poseCount,
                    humanFullConfidence: fullConfidence,
                    humanUpperConfidence: upperConfidence,
                    faceConfidence: faceConfidence,
                    poseConfidence: poseConfidence,
                    edgeTouch: edgeTouch,
                    change: changes[item.archiveIndex] ?? ChangeScore(),
                    error: ""
                )
            } catch {
                return DetectionScore(
                    index: item.archiveIndex,
                    path: item.url.path,
                    humanFullCount: 0,
                    humanUpperCount: 0,
                    faceCount: 0,
                    poseCount: 0,
                    humanFullConfidence: 0,
                    humanUpperConfidence: 0,
                    faceConfidence: 0,
                    poseConfidence: 0,
                    edgeTouch: false,
                    change: changes[item.archiveIndex] ?? ChangeScore(),
                    error: String(describing: error)
                )
            }
        }
        callback(item.position, result)
        if (localPosition + 1) % 250 == 0 {
            fputs("Vision worker \(worker): \(localPosition + 1)/\(selected.count)\n", stderr)
        }
    }
}

func csvField(_ value: String) -> String {
    if value.contains(",") || value.contains("\"") || value.contains("\n") {
        return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
    return value
}

let options = parseOptions()
let root = URL(fileURLWithPath: options.root).standardizedFileURL
let files = discoverImages(root: root)
guard !files.isEmpty else {
    fputs("No JPEG files found below \(root.path)\n", stderr)
    exit(1)
}

var selectedIndices: [Int]
if !options.indicesFile.isEmpty {
    let contents = try String(
        contentsOf: URL(fileURLWithPath: options.indicesFile).standardizedFileURL,
        encoding: .utf8
    )
    selectedIndices = contents.split(whereSeparator: \.isNewline).compactMap {
        Int($0.trimmingCharacters(in: .whitespaces))
    }.filter { $0 >= 0 && $0 < files.count }
    selectedIndices = Array(Set(selectedIndices)).sorted()
} else {
    selectedIndices = Array(stride(from: max(0, options.startIndex), to: files.count, by: options.stride))
}
if options.limit > 0 {
    selectedIndices = Array(selectedIndices.prefix(options.limit))
}
fputs("Archive images: \(files.count); selected: \(selectedIndices.count)\n", stderr)

var stableMask: [UInt8]? = nil
if !options.buildMask.isEmpty {
    let learned = buildStableMask(
        files: files,
        size: options.thumbnailSize,
        sampleCount: options.maskSamples
    )
    let maskURL = URL(fileURLWithPath: options.buildMask).standardizedFileURL
    try writePGM(path: maskURL, pixels: learned, size: options.thumbnailSize)
    stableMask = learned
    fputs("Wrote stable-perimeter mask to \(maskURL.path)\n", stderr)
} else if !options.mask.isEmpty {
    let maskURL = URL(fileURLWithPath: options.mask).standardizedFileURL
    stableMask = try readPGM(path: maskURL, expectedSize: options.thumbnailSize)
    fputs("Loaded stable-perimeter mask from \(maskURL.path)\n", stderr)
}

let changes = options.skipChange
    ? [Int: ChangeScore]()
    : calculateChanges(
        files: files,
        selectedIndices: selectedIndices,
        size: options.thumbnailSize,
        mask: stableMask
    )

let selected = selectedIndices.enumerated().map {
    (position: $0.offset, archiveIndex: $0.element, url: files[$0.element])
}
var results = [DetectionScore?](repeating: nil, count: selected.count)
let lock = NSLock()
let group = DispatchGroup()
let workerCount = min(options.workers, max(1, selected.count))

for worker in 0..<workerCount {
    let chunk = selected.enumerated().compactMap { offset, item in
        offset % workerCount == worker ? item : nil
    }
    group.enter()
    DispatchQueue.global(qos: .userInitiated).async {
        scanChunk(
            worker: worker,
            selected: chunk,
            changes: changes,
            includeBodyPose: options.includeBodyPose,
            perimeterTiles: options.perimeterTiles
        ) { position, score in
            lock.lock()
            results[position] = score
            lock.unlock()
        }
        group.leave()
    }
}
group.wait()

let output = URL(fileURLWithPath: options.output).standardizedFileURL
try FileManager.default.createDirectory(
    at: output.deletingLastPathComponent(),
    withIntermediateDirectories: true
)
var csv = """
archive_index,path,human_full_count,human_upper_count,face_count,pose_count,human_full_confidence,human_upper_confidence,face_confidence,pose_confidence,edge_touch,change_tile_mean,change_fraction,change_reliable,error

"""
for result in results.compactMap({ $0 }) {
    csv += [
        String(result.index),
        csvField(result.path),
        String(result.humanFullCount),
        String(result.humanUpperCount),
        String(result.faceCount),
        String(result.poseCount),
        String(format: "%.6f", result.humanFullConfidence),
        String(format: "%.6f", result.humanUpperConfidence),
        String(format: "%.6f", result.faceConfidence),
        String(format: "%.6f", result.poseConfidence),
        result.edgeTouch ? "1" : "0",
        String(format: "%.6f", result.change.tileMean),
        String(format: "%.6f", result.change.changedFraction),
        result.change.reliable ? "1" : "0",
        csvField(result.error),
    ].joined(separator: ",") + "\n"
}
try csv.write(to: output, atomically: true, encoding: .utf8)
fputs("Wrote \(results.compactMap({ $0 }).count) rows to \(output.path)\n", stderr)
