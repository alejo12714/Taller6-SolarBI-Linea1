# Apple Vision human scanner

`vision_human_scan.swift` provides the macOS image-scanning executable used by
`video_pipeline.privacy.AppleVisionScanner`. It recursively enumerates JPEG
files and evaluates Apple Vision requests for:

- human rectangles;
- upper-body rectangles;
- faces;
- body pose when `--body-pose` is enabled.

Results are written as CSV in archive order. Each row contains the source
path, detection counts, maximum confidences, edge-contact status, and any
per-image error.

The scanner also supports a learned static-scene mask, temporal-change
features, index-selected rescans, and magnified perimeter tiles. The Python
wrapper compiles this packaged source with `xcrun swiftc` when no compiled
binary is available.

```text
vision_human_scan --root PATH --output PATH [--workers N] [--body-pose]
  [--mask PATH] [--build-mask PATH] [--mask-samples N]
  [--indices-file PATH] [--perimeter-tiles] [--skip-change]
```
