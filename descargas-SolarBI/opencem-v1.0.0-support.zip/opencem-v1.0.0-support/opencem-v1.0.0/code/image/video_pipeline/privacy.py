"""Local privacy scanning, candidate ranking, and reviewed-frame removal."""

from __future__ import annotations

from dataclasses import dataclass
import csv
import datetime as dt
import html
import logging
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
from typing import Any, Iterable

from .acquisition import AcquisitionStore
from .errors import ConfigurationError, PrivacyReviewError
from .models import RuntimePlan, preload_onnxruntime


LOG = logging.getLogger(__name__)
INTEGER_FIELDS = {
    "archive_index",
    "human_full_count",
    "human_upper_count",
    "face_count",
    "pose_count",
    "edge_touch",
    "change_reliable",
}
FLOAT_FIELDS = {
    "human_full_confidence",
    "human_upper_confidence",
    "face_confidence",
    "pose_confidence",
    "change_tile_mean",
    "change_fraction",
}


def load_scores(path: Path) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows: list[dict[str, Any]] = list(csv.DictReader(handle))
    for row in rows:
        for field in INTEGER_FIELDS:
            row[field] = int(row.get(field, 0) or 0)
        for field in FLOAT_FIELDS:
            row[field] = float(row.get(field, 0) or 0)
    return rows


def _percentiles(
    rows: list[dict[str, Any]],
    field: str,
    output: str,
) -> None:
    ordered = sorted(range(len(rows)), key=lambda index: rows[index][field])
    denominator = max(1, len(ordered) - 1)
    for rank, index in enumerate(ordered):
        rows[index][output] = rank / denominator


def add_change_risk(rows: list[dict[str, Any]]) -> None:
    reliable = [row for row in rows if row["change_reliable"]]
    _percentiles(reliable, "change_tile_mean", "change_mean_percentile")
    _percentiles(reliable, "change_fraction", "change_fraction_percentile")
    for row in rows:
        mean = row.get("change_mean_percentile", 0.0)
        fraction = row.get("change_fraction_percentile", 0.0)
        row["change_risk"] = (
            0.75 * max(mean, fraction)
            + 0.125 * (mean + fraction)
        )


def _signal(row: dict[str, Any] | None) -> tuple[bool, bool, float, str]:
    if row is None:
        return False, False, 0.0, ""
    labels = [
        label
        for label, field in (
            ("full_body", "human_full_count"),
            ("upper_body", "human_upper_count"),
            ("face", "face_count"),
            ("body_pose", "pose_count"),
        )
        if row[field]
    ]
    strong = bool(
        row["human_full_count"]
        or row["human_upper_count"]
        or row["face_count"]
    )
    confidence = max(
        row["human_full_confidence"],
        row["human_upper_confidence"],
        row["face_confidence"],
        row["pose_confidence"],
    )
    return bool(labels), strong, confidence, "+".join(labels)


def rank_candidates(
    raw_rows: list[dict[str, Any]],
    tiled_rows: list[dict[str, Any]] | None = None,
    *,
    count: int = 2500,
) -> list[dict[str, Any]]:
    tiled_rows = tiled_rows or []
    add_change_risk(raw_rows)
    tiled_by_index = {row["archive_index"]: row for row in tiled_rows}
    strong_indices = {
        row["archive_index"]
        for row in tiled_rows
        if _signal(row)[1]
    }
    candidates: list[dict[str, Any]] = []
    for row in raw_rows:
        raw_positive, raw_strong, raw_confidence, raw_labels = _signal(row)
        tiled = tiled_by_index.get(row["archive_index"])
        tiled_positive, tiled_strong, tiled_confidence, tiled_labels = _signal(tiled)
        pose_only = bool(
            tiled_positive
            and not tiled_strong
            and tiled
            and tiled["pose_count"]
        )
        neighbor_distance = min(
            (
                abs(row["archive_index"] - index)
                for index in strong_indices
            ),
            default=999,
        )
        strong_neighbor = 0 < neighbor_distance <= 3
        reasons: list[str] = []
        if tiled_positive:
            reasons.append("tiled_" + tiled_labels)
        if raw_positive:
            reasons.append("fullframe_" + raw_labels)
        if strong_neighbor:
            reasons.append(f"near_strong_detection_{neighbor_distance}m")
        if row["change_reliable"]:
            reasons.append("perimeter_change")
        score = row["change_risk"]
        if raw_strong:
            score = max(score, 1.8 + raw_confidence)
        elif raw_positive:
            score = max(score, 1.05 + 0.15 * raw_confidence)
        if tiled_strong:
            score = max(score, 2.0 + tiled_confidence)
        elif pose_only:
            score = max(score, 1.05 + 0.15 * tiled_confidence)
        if strong_neighbor:
            score = max(score, 1.65 - 0.1 * neighbor_distance)
        combined = dict(row)
        combined.update(
            candidate_score=score,
            reasons="+".join(reasons),
            vision_positive=int(raw_positive or tiled_positive),
            strong_vision_positive=int(raw_strong or tiled_strong),
            pose_only_positive=int(pose_only),
            strong_neighbor=int(strong_neighbor),
            priority_tier=(
                1
                if raw_strong or tiled_strong or strong_neighbor
                else 2
                if pose_only or raw_positive
                else 3
            ),
        )
        candidates.append(combined)
    forced = [
        row
        for row in candidates
        if row["vision_positive"] or row["strong_neighbor"]
    ]
    remainder = sorted(
        (
            row
            for row in candidates
            if not row["vision_positive"] and not row["strong_neighbor"]
        ),
        key=lambda row: row["candidate_score"],
        reverse=True,
    )
    selected = forced + remainder[: max(0, count - len(forced))]
    selected.sort(key=lambda row: row["candidate_score"], reverse=True)
    for rank, row in enumerate(selected, 1):
        row["rank"] = rank
    return selected


def write_candidates(
    rows: list[dict[str, Any]],
    output_dir: Path,
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "human_review_candidates.csv"
    html_path = output_dir / "human_review_candidates.html"
    fieldnames = list(
        dict.fromkeys(
            [
                "rank",
                "priority_tier",
                "candidate_score",
                "reasons",
                "archive_index",
                "path",
                *(
                    key
                    for row in rows
                    for key in row
                ),
            ]
        )
    )
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)
    cards = []
    for row in rows:
        image = Path(str(row["path"])).resolve()
        cards.append(
            "<article class='card' data-index='{}'>"
            "<img loading='lazy' src='{}' alt='{}'>"
            "<p>#{} · Tier {} · {}</p>"
            "<button data-label='human'>Human</button>"
            "<button data-label='partial'>Partial</button>"
            "<button data-label='none'>None</button>"
            "<button data-label='uncertain'>Uncertain</button>"
            "</article>".format(
                row["archive_index"],
                html.escape(image.as_uri(), quote=True),
                html.escape(image.stem),
                row["rank"],
                row["priority_tier"],
                html.escape(str(row["reasons"])),
            )
        )
    html_path.write_text(
        """<!doctype html><meta charset="utf-8">
<title>Privacy review</title>
<style>
body{font:14px system-ui;background:#151515;color:#eee}
#grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:10px}
.card{background:#252525;padding:8px;border:2px solid transparent}
.card img{width:100%;aspect-ratio:1;object-fit:contain;background:#000}
.card[data-choice=human],.card[data-choice=partial]{border-color:#e85d5d}
.card[data-choice=none]{opacity:.6;border-color:#4aa86c}
button{margin:3px;padding:7px}
</style>
<button id="export">Export review CSV</button><span id="progress"></span>
<main id="grid">"""
        + "".join(cards)
        + """</main><script>
const key="video-pipeline-privacy-review-v1";
const state=JSON.parse(localStorage.getItem(key)||"{}");
const cards=[...document.querySelectorAll(".card")];
function update(){let n=0;for(const card of cards){const v=state[card.dataset.index]||"";
card.dataset.choice=v;if(v)n++;}progress.textContent=` ${n}/${cards.length}`;
localStorage.setItem(key,JSON.stringify(state));}
document.addEventListener("click",e=>{const b=e.target.closest("button[data-label]");
if(!b)return;const c=b.closest(".card");state[c.dataset.index]=b.dataset.label;update();});
export.onclick=()=>{const lines=["archive_index,review",...Object.entries(state).map(x=>x.join(","))];
const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([lines.join("\\n")+"\\n"]));
a.download="human_review_results.csv";a.click();};update();</script>""",
        encoding="utf-8",
    )
    return csv_path, html_path


def write_second_pass_indices(
    rows: list[dict[str, Any]],
    destination: Path,
    count: int,
) -> Path:
    add_change_risk(rows)
    selected = sorted(
        rows,
        key=lambda row: row["change_risk"],
        reverse=True,
    )[:count]
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        "".join(f"{row['archive_index']}\n" for row in selected),
        encoding="utf-8",
    )
    return destination


@dataclass(frozen=True)
class ReviewDecision:
    archive_index: int
    label: str
    path: Path


def load_decisions(review: Path, scores: Path) -> list[ReviewDecision]:
    with review.open(newline="", encoding="utf-8-sig") as handle:
        decisions = {
            int(row["archive_index"]): row["review"].strip().casefold()
            for row in csv.DictReader(handle)
        }
    with scores.open(newline="", encoding="utf-8") as handle:
        paths = {
            int(row["archive_index"]): Path(row["path"]).resolve()
            for row in csv.DictReader(handle)
        }
    unknown = set(decisions) - set(paths)
    if unknown:
        raise PrivacyReviewError(
            f"Review contains unknown archive indices: {sorted(unknown)[:20]}"
        )
    return [
        ReviewDecision(index, label, paths[index])
        for index, label in sorted(decisions.items())
    ]


def timestamp_from_frame(path: Path) -> dt.datetime:
    value = path.stem
    if value.endswith("Z"):
        value = value[:-1] + "+0000"
    try:
        return dt.datetime.strptime(
            value, "%Y%m%dT%H%M%S%z"
        ).astimezone(dt.timezone.utc)
    except ValueError as exc:
        raise PrivacyReviewError(
            f"Cannot derive UTC timestamp from frame filename: {path}"
        ) from exc


def backup_database(path: Path, label: str) -> Path:
    suffix = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}.{label}.{suffix}{path.suffix}")
    source = sqlite3.connect(path, timeout=30)
    target = sqlite3.connect(backup)
    try:
        source.backup(target)
    finally:
        target.close()
        source.close()
    return backup


def apply_human_decisions(
    decisions: Iterable[ReviewDecision],
    *,
    output_root: Path,
    database: Path,
    dry_run: bool = False,
) -> list[ReviewDecision]:
    frames_root = (output_root / "frames").resolve()
    flagged = [
        decision
        for decision in decisions
        if decision.label == "human"
    ]
    for decision in flagged:
        try:
            decision.path.resolve().relative_to(frames_root)
        except ValueError as exc:
            raise PrivacyReviewError(
                f"Flagged frame lies outside the archive: {decision.path}"
            ) from exc
    if dry_run or not flagged:
        return flagged
    backup_database(database, "before_privacy_review")
    staging = Path(
        tempfile.mkdtemp(prefix=".privacy-review-", dir=output_root)
    )
    moved: list[tuple[Path, Path]] = []
    try:
        for decision in flagged:
            if not decision.path.is_file():
                continue
            target = staging / decision.path.relative_to(frames_root)
            target.parent.mkdir(parents=True, exist_ok=True)
            decision.path.replace(target)
            moved.append((decision.path, target))
        with AcquisitionStore(database) as store:
            store.connection.execute("BEGIN IMMEDIATE")
            try:
                for decision in flagged:
                    timestamp = timestamp_from_frame(decision.path)
                    key = timestamp.strftime("%Y-%m-%dT%H:%M:%SZ")
                    store.connection.execute(
                        """
                        INSERT INTO excluded_frames(
                            timestamp_utc,path,reason,excluded_at
                        ) VALUES(?,?,?,?)
                        ON CONFLICT(timestamp_utc) DO UPDATE SET
                            path=excluded.path,
                            reason=excluded.reason,
                            excluded_at=excluded.excluded_at
                        """,
                        (
                            key,
                            store.stored_path(decision.path),
                            "privacy review label=human",
                            dt.datetime.now(dt.timezone.utc).strftime(
                                "%Y-%m-%dT%H:%M:%SZ"
                            ),
                        ),
                    )
                    store.connection.execute(
                        "DELETE FROM frames WHERE timestamp_utc=?",
                        (key,),
                    )
                integrity = store.connection.execute(
                    "PRAGMA integrity_check"
                ).fetchone()
                if not integrity or integrity[0] != "ok":
                    raise PrivacyReviewError(
                        f"SQLite integrity check failed: {integrity}"
                    )
                store.connection.commit()
            except Exception:
                store.connection.rollback()
                raise
        shutil.rmtree(staging)
    except Exception:
        for source, staged in reversed(moved):
            if staged.exists() and not source.exists():
                source.parent.mkdir(parents=True, exist_ok=True)
                staged.replace(source)
        raise
    return flagged


class AppleVisionScanner:
    """Build and invoke the small Swift Vision scanner."""

    def __init__(self, source: Path, binary: Path):
        self.source = source
        self.binary = binary

    def build(self) -> Path:
        self.binary.parent.mkdir(parents=True, exist_ok=True)
        command = [
            "xcrun",
            "swiftc",
            "-swift-version", "5",
            "-O",
            "-module-cache-path", str(self.binary.parent / "swift-module-cache"),
            "-framework", "Vision",
            "-framework", "ImageIO",
            "-framework", "CoreGraphics",
            str(self.source),
            "-o", str(self.binary),
        ]
        completed = subprocess.run(
            command, capture_output=True, text=True, check=False
        )
        if completed.returncode:
            raise PrivacyReviewError(
                f"Could not build Apple Vision scanner: {completed.stderr[-4000:]}"
            )
        return self.binary

    def scan(
        self,
        root: Path,
        output: Path,
        *,
        workers: int = 6,
        body_pose: bool = True,
        perimeter_tiles: bool = False,
        extra_arguments: Iterable[str] = (),
    ) -> Path:
        if not self.binary.is_file():
            self.build()
        command = [
            str(self.binary),
            "--root", str(root),
            "--output", str(output),
            "--workers", str(workers),
        ]
        if body_pose:
            command.append("--body-pose")
        if perimeter_tiles:
            command.append("--perimeter-tiles")
        command.extend(extra_arguments)
        completed = subprocess.run(command, check=False)
        if completed.returncode:
            raise PrivacyReviewError(
                f"Apple Vision scanner exited with {completed.returncode}"
            )
        return output


class OnnxPersonScanner:
    """COCO-person scanner for common YOLO ONNX export layouts."""

    def __init__(
        self,
        model: Path,
        runtime: RuntimePlan,
        *,
        confidence: float = 0.25,
        input_size: int = 640,
    ):
        try:
            import onnxruntime as ort
        except ImportError as exc:
            raise ConfigurationError(
                f"Install {runtime.pip_package} before using ONNX privacy scanning"
            ) from exc
        preload_onnxruntime(runtime)
        if runtime.provider == "QNNExecutionProvider":
            providers: list[Any] = [
                (
                    "QNNExecutionProvider",
                    {
                        "backend_path": "QnnHtp.dll",
                        "htp_performance_mode": "burst",
                    },
                ),
                "CPUExecutionProvider",
            ]
        else:
            providers = [runtime.provider, "CPUExecutionProvider"]
        self.session = ort.InferenceSession(str(model), providers=providers)
        self.input_name = self.session.get_inputs()[0].name
        self.confidence = confidence
        self.input_size = input_size

    def scan(self, root: Path, output: Path) -> Path:
        try:
            import cv2
            import numpy as np
        except ImportError as exc:
            raise ConfigurationError(
                "ONNX privacy scanning requires numpy and opencv-python-headless"
            ) from exc
        images = sorted(root.rglob("*.jpg"))
        output.parent.mkdir(parents=True, exist_ok=True)
        fieldnames = [
            "archive_index", "path", "human_full_count", "human_upper_count",
            "face_count", "pose_count", "human_full_confidence",
            "human_upper_confidence", "face_confidence", "pose_confidence",
            "edge_touch", "change_tile_mean", "change_fraction",
            "change_reliable", "error",
        ]
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for index, path in enumerate(images):
                row = {field: 0 for field in fieldnames}
                row.update(archive_index=index, path=str(path.resolve()), error="")
                try:
                    image = cv2.imread(str(path))
                    if image is None:
                        raise PrivacyReviewError("OpenCV could not read image")
                    height, width = image.shape[:2]
                    resized = cv2.resize(
                        image,
                        (self.input_size, self.input_size),
                        interpolation=cv2.INTER_LINEAR,
                    )
                    tensor = resized[:, :, ::-1].transpose(2, 0, 1)
                    tensor = np.ascontiguousarray(tensor, dtype=np.float32)[None] / 255.0
                    output_value = self.session.run(
                        None, {self.input_name: tensor}
                    )[0]
                    detections = self._person_detections(
                        output_value, width, height
                    )
                    row["human_full_count"] = len(detections)
                    row["human_full_confidence"] = max(
                        (item[4] for item in detections),
                        default=0.0,
                    )
                    row["edge_touch"] = int(
                        any(
                            x1 <= 0.02
                            or y1 <= 0.02
                            or x2 >= 0.98
                            or y2 >= 0.98
                            for x1, y1, x2, y2, _ in detections
                        )
                    )
                except Exception as exc:
                    row["error"] = str(exc)
                writer.writerow(row)
        return output

    def _person_detections(
        self,
        value: Any,
        width: int,
        height: int,
    ) -> list[tuple[float, float, float, float, float]]:
        import numpy as np

        array = np.asarray(value)
        if array.ndim == 3 and array.shape[1] < array.shape[2]:
            array = array[0].T
        elif array.ndim == 3:
            array = array[0]
        result = []
        for row in array:
            if len(row) >= 84:
                score = (
                    float(row[4])
                    if len(row) == 84
                    else float(row[4]) * float(row[5])
                )
                x, y, w, h = map(float, row[:4])
                person_score = score
                if person_score < self.confidence:
                    continue
                result.append(
                    (
                        max(0.0, (x - w / 2) / self.input_size),
                        max(0.0, (y - h / 2) / self.input_size),
                        min(1.0, (x + w / 2) / self.input_size),
                        min(1.0, (y + h / 2) / self.input_size),
                        person_score,
                    )
                )
            elif len(row) >= 6 and int(row[5]) == 0:
                score = float(row[4])
                if score >= self.confidence:
                    x1, y1, x2, y2 = map(float, row[:4])
                    result.append(
                        (
                            x1 / width,
                            y1 / height,
                            x2 / width,
                            y2 / height,
                            score,
                        )
                    )
        return result
