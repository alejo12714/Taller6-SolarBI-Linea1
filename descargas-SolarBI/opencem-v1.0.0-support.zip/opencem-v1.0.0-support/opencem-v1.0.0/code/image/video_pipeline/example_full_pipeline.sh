#!/usr/bin/env bash
set -euo pipefail

CONFIG="${CONFIG:-pipeline_config.json}"
OUTPUT_ROOT="${OUTPUT_ROOT:-output}"
VIDEO_DIR="${VIDEO_DIR:-$OUTPUT_ROOT/videos}"
STATE_DB="$OUTPUT_ROOT/state.sqlite3"
CATALOG_DB="$OUTPUT_ROOT/video_catalog.sqlite3"
PRIVACY_DIR="$OUTPUT_ROOT/human_review_scan"

video-index "$VIDEO_DIR" --config "$CONFIG" \
  --database "$CATALOG_DB" --min-age 0

frame-acquire --config "$CONFIG" --output-root "$OUTPUT_ROOT" \
  --database "$STATE_DB" --catalog-database "$CATALOG_DB" \
  --video-dir "$VIDEO_DIR"

privacy_model=()
if [[ -n "${PRIVACY_MODEL:-}" ]]; then
  privacy_model=(--model "$PRIVACY_MODEL")
fi
frame-privacy scan --config "$CONFIG" \
  --root "$OUTPUT_ROOT/frames" --output "$PRIVACY_DIR/raw_scores.csv" \
  "${privacy_model[@]}"
frame-privacy rank --config "$CONFIG" \
  --raw "$PRIVACY_DIR/raw_scores.csv" --output-dir "$PRIVACY_DIR/review"

REVIEW_RESULTS="$PRIVACY_DIR/review/human_review_results.csv"
if [[ -f "$REVIEW_RESULTS" ]]; then
  frame-privacy apply --config "$CONFIG" \
    --review "$REVIEW_RESULTS" --scores "$PRIVACY_DIR/raw_scores.csv" \
    --output-root "$OUTPUT_ROOT" --database "$STATE_DB"
else
  echo "Review candidates in $PRIVACY_DIR/review, then run this script again."
fi
