"""Library exceptions with operator-facing messages."""


class PipelineError(RuntimeError):
    """Base class for expected pipeline failures."""


class ConfigurationError(PipelineError):
    """Invalid or incomplete configuration."""


class MediaError(PipelineError):
    """FFmpeg, FFprobe, or media validation failure."""


class AcquisitionError(PipelineError):
    """Remote search, authentication, or download failure."""


class IndexingError(PipelineError):
    """Video or frame catalogue failure."""


class PrivacyReviewError(PipelineError):
    """Privacy scan, ranking, or decision application failure."""
