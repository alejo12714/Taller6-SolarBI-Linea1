"""Two-phase video registration and full presentation-frame indexing."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
import datetime as dt
import hashlib
import logging
import os
from pathlib import Path
import sqlite3
from typing import Iterable, Protocol
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .errors import ConfigurationError, IndexingError
from .hardware import Accelerator, HardwareProfile
from .models import prepare_rapidocr, runtime_plan


LOG = logging.getLogger(__name__)
DEFAULT_EXTENSIONS = frozenset({".mp4", ".mov", ".mkv", ".avi"})


@dataclass(frozen=True)
class EndpointInspection:
    source: Path
    fingerprint: str
    size: int
    mtime_ns: int
    start: dt.datetime
    end: dt.datetime
    duration: float


@dataclass(frozen=True)
class IndexedFrame:
    second: int
    frame_offset: int


@dataclass(frozen=True)
class FrameIndex:
    source: Path
    start: dt.datetime
    end: dt.datetime
    frames: tuple[IndexedFrame, ...]


@dataclass(frozen=True)
class CatalogVideo:
    id: int
    old_name: str
    new_name: str
    start: float
    end: float


@dataclass(frozen=True)
class ScanReport:
    discovered: int
    registered: int
    indexed: int
    duplicates_removed: int
    anomaly_reindexes: int
    skipped_complete: int
    failures: tuple[str, ...]


class IndexBackend(Protocol):
    def inspect_endpoints(
        self,
        path: Path,
        fingerprint: str,
        worker: int = 0,
    ) -> EndpointInspection: ...

    def index(
        self,
        path: Path,
        worker: int = 0,
    ) -> FrameIndex: ...


class CatalogRepository:
    """Minimal public schema with an anti-join as the completion state."""

    def __init__(self, path: Path | str, *, readonly: bool = False):
        self.path = path
        self.readonly = readonly
        if readonly:
            if not isinstance(path, Path):
                path = Path(path)
            if not path.is_file():
                raise IndexingError(
                    f"Catalogue database does not exist: {path}"
                )
            uri = path.resolve().as_uri() + "?mode=ro&immutable=1"
            self.connection = sqlite3.connect(
                uri,
                timeout=30,
                uri=True,
            )
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA foreign_keys=ON")
            return
        if isinstance(path, Path):
            path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(path), timeout=30)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS video (
                id INTEGER PRIMARY KEY,
                old_name TEXT NOT NULL,
                new_name TEXT NOT NULL,
                start REAL NOT NULL,
                end REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS video_interval
                ON video(start,end);
            CREATE INDEX IF NOT EXISTS video_interval_end
                ON video(end,start);
            CREATE TABLE IF NOT EXISTS frame (
                video INTEGER NOT NULL
                    REFERENCES video(id) ON DELETE CASCADE,
                second INTEGER NOT NULL,
                frame_offset INTEGER NOT NULL,
                PRIMARY KEY(video,second)
            );
            CREATE INDEX IF NOT EXISTS frame_second ON frame(second);
            """
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "CatalogRepository":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def known_name(self, name: str) -> bool:
        return self.connection.execute(
            "SELECT 1 FROM video WHERE new_name=? LIMIT 1", (name,)
        ).fetchone() is not None

    @staticmethod
    def _video(row: sqlite3.Row) -> CatalogVideo:
        return CatalogVideo(
            int(row["id"]),
            str(row["old_name"]),
            str(row["new_name"]),
            float(row["start"]),
            float(row["end"]),
        )

    def video(self, video_id: int) -> CatalogVideo:
        row = self.connection.execute(
            """
            SELECT id,old_name,new_name,start,end
            FROM video WHERE id=?
            """,
            (video_id,),
        ).fetchone()
        if row is None:
            raise IndexingError(f"Unknown catalogue video id: {video_id}")
        return self._video(row)

    def video_by_name(self, name: str) -> CatalogVideo | None:
        row = self.connection.execute(
            """
            SELECT id,old_name,new_name,start,end
            FROM video WHERE new_name=? ORDER BY id LIMIT 1
            """,
            (name,),
        ).fetchone()
        return self._video(row) if row is not None else None

    def video_by_old_name(self, name: str) -> CatalogVideo | None:
        row = self.connection.execute(
            """
            SELECT id,old_name,new_name,start,end
            FROM video WHERE old_name=? ORDER BY id DESC LIMIT 1
            """,
            (name,),
        ).fetchone()
        return self._video(row) if row is not None else None

    def overlapping(
        self,
        start: dt.datetime,
        end: dt.datetime,
    ) -> list[CatalogVideo]:
        rows = self.connection.execute(
            """
            SELECT id,old_name,new_name,start,end
            FROM video
            WHERE start<=? AND end>=?
            ORDER BY start,id
            """,
            (end.timestamp(), start.timestamp()),
        ).fetchall()
        return [self._video(row) for row in rows]

    def all_videos(self) -> list[CatalogVideo]:
        rows = self.connection.execute(
            """
            SELECT id,old_name,new_name,start,end
            FROM video ORDER BY start,id
            """
        ).fetchall()
        return [self._video(row) for row in rows]

    def frames_for(self, video_id: int) -> tuple[IndexedFrame, ...]:
        return tuple(
            IndexedFrame(int(row["second"]), int(row["frame_offset"]))
            for row in self.connection.execute(
                """
                SELECT second,frame_offset FROM frame
                WHERE video=? ORDER BY frame_offset,second
                """,
                (video_id,),
            )
        )

    def minute_frames(self, video_id: int) -> tuple[IndexedFrame, ...]:
        """Return first-frame offsets for full overlay-clock minutes."""
        return tuple(
            IndexedFrame(int(row["second"]), int(row["frame_offset"]))
            for row in self.connection.execute(
                """
                SELECT second,frame_offset FROM frame
                WHERE video=? AND second % 60=0
                ORDER BY frame_offset,second
                """,
                (video_id,),
            )
        )

    def has_verified_frames(self, video_id: int) -> bool:
        return self.connection.execute(
            """
            SELECT 1 FROM frame
            WHERE video=? AND frame_offset<>0 LIMIT 1
            """,
            (video_id,),
        ).fetchone() is not None

    def implausible_jump_videos(
        self,
        threshold_seconds: int,
    ) -> list[CatalogVideo]:
        if threshold_seconds < 2:
            raise ConfigurationError(
                "The implausible-jump threshold must be at least 2 seconds"
            )
        rows = self.connection.execute(
            """
            WITH ordered AS (
                SELECT
                    video,
                    second,
                    LAG(second) OVER (
                        PARTITION BY video
                        ORDER BY frame_offset,second
                    ) AS previous_second
                FROM frame
                WHERE frame_offset<>0
            ),
            suspect AS (
                SELECT DISTINCT video
                FROM ordered
                WHERE previous_second IS NOT NULL
                  AND (
                    second<=previous_second
                    OR second-previous_second>?
                  )
            )
            SELECT v.id,v.old_name,v.new_name,v.start,v.end
            FROM video AS v
            JOIN suspect AS s ON s.video=v.id
            ORDER BY v.start,v.id
            """,
            (threshold_seconds,),
        ).fetchall()
        return [self._video(row) for row in rows]

    def clear_frames(self, video_ids: Iterable[int]) -> None:
        rows = [(int(video_id),) for video_id in video_ids]
        with self.connection:
            self.connection.executemany(
                "DELETE FROM frame WHERE video=?",
                rows,
            )

    def import_video(
        self,
        video: CatalogVideo,
        new_name: str,
        frames: Iterable[IndexedFrame],
    ) -> int:
        rows = tuple(frames)
        if not any(row.frame_offset != 0 for row in rows):
            raise IndexingError(
                f"Source video {video.new_name} has no verified frame index"
            )
        with self.connection:
            cursor = self.connection.execute(
                """
                INSERT INTO video(old_name,new_name,start,end)
                VALUES(?,?,?,?)
                """,
                (video.old_name, new_name, video.start, video.end),
            )
            video_id = int(cursor.lastrowid)
            self.connection.executemany(
                """
                INSERT INTO frame(video,second,frame_offset)
                VALUES(?,?,?)
                """,
                [
                    (video_id, row.second, row.frame_offset)
                    for row in rows
                ],
            )
            self._reconcile_boundaries()
        return video_id

    def register(
        self,
        inspection: EndpointInspection,
        destination: Path,
    ) -> int:
        with self.connection:
            row = self.connection.execute(
                "SELECT id FROM video WHERE new_name=? ORDER BY id LIMIT 1",
                (destination.name,),
            ).fetchone()
            values = (
                inspection.source.name,
                destination.name,
                inspection.start.timestamp(),
                inspection.end.timestamp(),
            )
            if row is None:
                cursor = self.connection.execute(
                    "INSERT INTO video(old_name,new_name,start,end) VALUES(?,?,?,?)",
                    values,
                )
                return int(cursor.lastrowid)
            video_id = int(row["id"])
            self.connection.execute(
                """
                UPDATE video SET old_name=?,new_name=?,start=?,end=?
                WHERE id=?
                """,
                (*values, video_id),
            )
            return video_id

    def pending(self) -> list[CatalogVideo]:
        rows = self.connection.execute(
            """
            SELECT v.id,v.old_name,v.new_name,v.start,v.end
            FROM video AS v
            LEFT JOIN frame AS f
              ON f.video=v.id AND f.frame_offset<>0
            WHERE f.video IS NULL
            ORDER BY v.start,v.id
            """
        ).fetchall()
        return [self._video(row) for row in rows]

    def update_interval(
        self,
        video_id: int,
        destination: Path,
        start: dt.datetime,
        end: dt.datetime,
    ) -> None:
        with self.connection:
            self.connection.execute(
                "UPDATE video SET new_name=?,start=?,end=? WHERE id=?",
                (destination.name, start.timestamp(), end.timestamp(), video_id),
            )

    def record_frames(
        self,
        video_id: int,
        frames: Iterable[IndexedFrame],
    ) -> None:
        rows = tuple(frames)
        if not any(row.frame_offset != 0 for row in rows):
            raise IndexingError(
                f"Video {video_id} has no verified nonzero frame offsets"
            )
        with self.connection:
            self.connection.execute("DELETE FROM frame WHERE video=?", (video_id,))
            self.connection.executemany(
                "INSERT INTO frame(video,second,frame_offset) VALUES(?,?,?)",
                [
                    (video_id, row.second, row.frame_offset)
                    for row in rows
                ],
            )
            self._reconcile_boundaries()

    def _reconcile_boundaries(self) -> None:
        self.connection.execute("DELETE FROM frame WHERE frame_offset=0")
        videos = self.connection.execute(
            "SELECT id,start,end FROM video ORDER BY start,id"
        ).fetchall()
        for previous, current in zip(videos, videos[1:]):
            if abs(float(current["start"]) - float(previous["end"]) - 1.0) > 0.001:
                continue
            complete = self.connection.execute(
                """
                SELECT 1 FROM frame
                WHERE video=? AND frame_offset<>0 LIMIT 1
                """,
                (current["id"],),
            ).fetchone()
            if complete:
                self.connection.execute(
                    """
                    INSERT OR REPLACE INTO frame(video,second,frame_offset)
                    VALUES(?,?,0)
                    """,
                    (current["id"], round(float(current["start"]))),
                )


class FingerprintCache:
    """Machine-local cache keyed by source name and creation timestamp."""

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, timeout=30)
        self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS sha256_cache(
                name TEXT NOT NULL,
                creation_ns INTEGER NOT NULL,
                digest TEXT NOT NULL,
                PRIMARY KEY(name,creation_ns)
            )
            """
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "FingerprintCache":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    @staticmethod
    def creation_ns(stat: os.stat_result) -> int:
        return int(
            getattr(stat, "st_birthtime_ns", None)
            or getattr(stat, "st_birthtime", 0) * 1_000_000_000
            or stat.st_ctime_ns
        )

    def digest(self, path: Path) -> str:
        stat = path.stat()
        creation_ns = self.creation_ns(stat)
        row = self.connection.execute(
            "SELECT digest FROM sha256_cache WHERE name=? AND creation_ns=?",
            (path.name, creation_ns),
        ).fetchone()
        if row:
            return str(row[0])
        digest = content_fingerprint(path)
        with self.connection:
            self.connection.execute(
                """
                INSERT OR REPLACE INTO sha256_cache(name,creation_ns,digest)
                VALUES(?,?,?)
                """,
                (path.name, creation_ns, digest),
            )
        return digest


def content_fingerprint(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(4 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def ensure_indexed_video(
    repository: CatalogRepository,
    backend: IndexBackend,
    path: Path,
    worker: int = 0,
) -> CatalogVideo:
    """Return a catalogued video, building and persisting its frame index if needed."""
    video = repository.video_by_name(path.name)
    if video is not None and repository.has_verified_frames(video.id):
        return video

    LOG.info("Building missing frame index for %s", path)
    result = backend.index(path, worker)
    if video is None:
        stat = path.stat()
        video_id = repository.register(
            EndpointInspection(
                source=path,
                fingerprint="",
                size=stat.st_size,
                mtime_ns=stat.st_mtime_ns,
                start=result.start,
                end=result.end,
                duration=max(
                    0.0,
                    (result.end - result.start).total_seconds(),
                ),
            ),
            path,
        )
    else:
        video_id = video.id
        repository.update_interval(
            video_id,
            path,
            result.start,
            result.end,
        )
    repository.record_frames(video_id, result.frames)
    return repository.video(video_id)


def filename_time(value: dt.datetime) -> str:
    base = value.strftime("%Y%m%dT%H%M%S")
    return base + (
        "Z"
        if value.utcoffset() == dt.timedelta(0)
        else value.strftime("%z")
    )


def destination_for(
    source: Path,
    start: dt.datetime,
    end: dt.datetime,
    target: Path,
    fingerprint: str,
) -> Path:
    extension = source.suffix.casefold() or ".video"
    stem = f"{filename_time(start)}--{filename_time(end)}"
    base = target / f"{stem}{extension}"
    if base == source or not base.exists():
        return base
    candidate = target / f"{stem}__{fingerprint[:10]}{extension}"
    counter = 2
    while candidate.exists() and candidate != source:
        candidate = target / f"{stem}__{fingerprint[:10]}__{counter}{extension}"
        counter += 1
    return candidate


class CatalogService:
    def __init__(
        self,
        repository: CatalogRepository,
        backend: IndexBackend,
        fingerprint_cache: FingerprintCache,
        *,
        workers: int = 1,
        timezone: str = "UTC",
    ):
        self.repository = repository
        self.backend = backend
        self.fingerprint_cache = fingerprint_cache
        self.workers = max(1, workers)
        try:
            self.timezone = ZoneInfo(timezone)
        except ZoneInfoNotFoundError as exc:
            raise ConfigurationError(f"Unknown overlay timezone: {timezone}") from exc

    def scan(
        self,
        root: Path,
        *,
        target: Path | None = None,
        recursive: bool = False,
        extensions: Iterable[str] = DEFAULT_EXTENSIONS,
        min_age: float = 120,
        dry_run: bool = False,
        reindex_jump_threshold: int | None = None,
    ) -> ScanReport:
        target = target or root
        target.mkdir(parents=True, exist_ok=True)
        allowed = {
            item.casefold() if item.startswith(".") else "." + item.casefold()
            for item in extensions
        }
        iterator = root.rglob("*") if recursive else root.iterdir()
        paths = sorted(
            (
                path
                for path in iterator
                if path.is_file()
                and path.suffix.casefold() in allowed
                and not path.name.endswith((".part", ".tmp", ".download"))
            ),
            key=str,
        )
        now = dt.datetime.now().timestamp()
        new_paths = [
            path
            for path in paths
            if not self.repository.known_name(path.name)
            and now - path.stat().st_mtime >= min_age
        ]
        complete = sum(
            self.repository.known_name(path.name)
            for path in paths
        )
        failures: list[str] = []
        registered = 0
        duplicates_removed = 0
        anomaly_reindexes = 0
        if reindex_jump_threshold is not None:
            suspect = self.repository.implausible_jump_videos(
                reindex_jump_threshold
            )
            for video in suspect:
                LOG.info(
                    "%sreindex %s after detecting an implausible timestamp jump",
                    "Would " if dry_run else "Will ",
                    video.new_name,
                )
            if not dry_run:
                self.repository.clear_frames(
                    video.id for video in suspect
                )
                anomaly_reindexes = len(suspect)

        # Secure all source names before scheduling any full decode.
        with ThreadPoolExecutor(
            max_workers=min(self.workers, max(1, len(new_paths))),
            thread_name_prefix="register",
        ) as executor:
            futures = {}
            for worker, path in enumerate(new_paths):
                try:
                    fingerprint = self.fingerprint_cache.digest(path)
                except Exception as exc:
                    failures.append(f"{path}: fingerprint: {exc}")
                    continue
                future = executor.submit(
                    self.backend.inspect_endpoints,
                    path,
                    fingerprint,
                    worker,
                )
                futures[future] = (path, fingerprint)
            for future in as_completed(futures):
                path, fingerprint = futures[future]
                try:
                    inspection = future.result()
                    identical_to: Path | None = None
                    for overlap in self.repository.overlapping(
                        inspection.start,
                        inspection.end,
                    ):
                        existing = target / overlap.new_name
                        if (
                            existing == path
                            or not existing.is_file()
                            or existing.stat().st_size != inspection.size
                        ):
                            continue
                        if self.fingerprint_cache.digest(existing) == fingerprint:
                            identical_to = existing
                            break
                    if identical_to is not None:
                        if dry_run:
                            LOG.info(
                                "Would remove duplicate %s; identical to %s",
                                path,
                                identical_to,
                            )
                        else:
                            path.unlink()
                            duplicates_removed += 1
                            LOG.info(
                                "Removed duplicate %s; identical to %s",
                                path,
                                identical_to,
                            )
                        continue
                    destination = destination_for(
                        path,
                        inspection.start,
                        inspection.end,
                        target,
                        fingerprint,
                    )
                    if dry_run:
                        LOG.info("Would register %s as %s", path, destination)
                        continue
                    if destination != path:
                        path.rename(destination)
                    self.repository.register(inspection, destination)
                    registered += 1
                except Exception as exc:
                    failures.append(f"{path}: endpoint registration: {exc}")

        indexed = 0
        if not dry_run:
            pending = self.repository.pending()
            with ThreadPoolExecutor(
                max_workers=min(self.workers, max(1, len(pending))),
                thread_name_prefix="index",
            ) as executor:
                futures = {}
                for worker, video in enumerate(pending):
                    path = target / video.new_name
                    if not path.is_file():
                        failures.append(
                            f"{path}: registered video {video.id} is missing"
                        )
                        continue
                    futures[
                        executor.submit(self.backend.index, path, worker)
                    ] = (video, path)
                for future in as_completed(futures):
                    video, path = futures[future]
                    try:
                        result = future.result()
                        expected_start = dt.datetime.fromtimestamp(
                            video.start, self.timezone
                        )
                        expected_end = dt.datetime.fromtimestamp(
                            video.end, self.timezone
                        )
                        destination = path
                        if (
                            result.start != expected_start
                            or result.end != expected_end
                        ):
                            fingerprint = self.fingerprint_cache.digest(path)
                            destination = destination_for(
                                path,
                                result.start,
                                result.end,
                                target,
                                fingerprint,
                            )
                            if destination != path:
                                path.rename(destination)
                            self.repository.update_interval(
                                video.id,
                                destination,
                                result.start,
                                result.end,
                            )
                        self.repository.record_frames(video.id, result.frames)
                        indexed += 1
                    except Exception as exc:
                        failures.append(f"{path}: frame index: {exc}")
        return ScanReport(
            discovered=len(paths),
            registered=registered,
            indexed=indexed,
            duplicates_removed=duplicates_removed,
            anomaly_reindexes=anomaly_reindexes,
            skipped_complete=complete,
            failures=tuple(failures),
        )


class HikvisionOverlayBackend:
    """Adapter for the fixed-overlay glyph indexer."""

    def __init__(
        self,
        *,
        ffmpeg: str,
        ffprobe: str,
        templates: Path | None,
        timezone: str,
        hardware: HardwareProfile,
        model_cache: Path,
        ocr_size: str = "auto",
        decoder_threads: int = 0,
        seek_preroll: float = 10.0,
        minimum_confidence: float = 0.75,
        transition_threshold: float = 2.5,
        diagnostic_log: Path | None = None,
    ):
        from . import hikvision_overlay as engine
        try:
            timezone_value = ZoneInfo(timezone)
        except ZoneInfoNotFoundError as exc:
            raise ConfigurationError(f"Unknown overlay timezone: {timezone}") from exc
        self.engine = engine
        self.ffmpeg = ffmpeg
        self.ffprobe = ffprobe
        self.templates = templates
        self.timezone = timezone_value
        self.hardware = hardware
        self.model_cache = model_cache
        self.ocr_size = ocr_size
        self.decoder_threads = decoder_threads
        self.seek_preroll = seek_preroll
        self.minimum_confidence = minimum_confidence
        self.transition_threshold = transition_threshold
        if diagnostic_log is not None:
            engine._DIAGNOSTICS = engine.DiagnosticLog(
                diagnostic_log,
                {
                    "component": "video_pipeline.indexing",
                    "accelerator": hardware.accelerator.value,
                    "devices": list(hardware.devices),
                    "workers_use_full_index": True,
                    "timezone": timezone,
                    "ffmpeg": ffmpeg,
                    "ffprobe": ffprobe,
                },
            )
            engine.diagnostic_event(
                "run_started",
                details=engine._DIAGNOSTICS.run_context,
            )

    def diagnostic(self, event: str, details: dict) -> None:
        self.engine.diagnostic_event(event, details=details)

    def _ocr(self, worker: int):
        engine = self.engine
        profile = self.hardware
        device = profile.device(worker)
        plan = runtime_plan(
            profile,
            device=device or 0,
            ocr_size=self.ocr_size,
        )
        cache = self.model_cache

        class PortableGlyphOCR(engine.GlyphTimestampOCR):
            def decoder_input_arguments(self) -> list[str]:
                arguments: list[str] = []
                if self.ffmpeg_threads:
                    arguments.extend(["-threads", str(self.ffmpeg_threads)])
                arguments.extend(profile.decoder_input_args(worker))
                return arguments

            def software_filter_prefix(self) -> list[str]:
                return profile.software_filter_prefix()

            def _engine(self):
                value = getattr(self._thread_local, "engine", None)
                if value is None:
                    value = prepare_rapidocr(plan, cache)
                    self._thread_local.engine = value
                return value

        return PortableGlyphOCR(
            self.ffmpeg,
            self.templates,
            self.seek_preroll,
            self.decoder_threads,
            device if profile.accelerator is Accelerator.CUDA else None,
        )

    def inspect_endpoints(
        self,
        path: Path,
        fingerprint: str,
        worker: int = 0,
    ) -> EndpointInspection:
        try:
            result = self.engine.analyse_video_registration(
                path,
                fingerprint,
                self._ocr(worker),
                self.ffprobe,
                self.timezone,
                self.minimum_confidence,
            )
        except self.engine.CatalogError as exc:
            raise IndexingError(str(exc)) from exc
        return EndpointInspection(
            source=path,
            fingerprint=fingerprint,
            size=result.original_size,
            mtime_ns=result.original_mtime_ns,
            start=result.start,
            end=result.end,
            duration=result.probe.duration,
        )

    def index(self, path: Path, worker: int = 0) -> FrameIndex:
        try:
            result = self.engine.analyse_video(
                path,
                "",
                self._ocr(worker),
                self.ffprobe,
                self.timezone,
                1,
                1.0,
                self.minimum_confidence,
                1.25,
                self.transition_threshold,
                "full",
                0.25,
                1,
            )
        except self.engine.CatalogError as exc:
            raise IndexingError(str(exc)) from exc
        return FrameIndex(
            source=path,
            start=result.start,
            end=result.end,
            frames=tuple(
                IndexedFrame(
                    round(frame.timestamp.timestamp()),
                    frame.frame_number,
                )
                for frame in result.second_frames
            ),
        )
