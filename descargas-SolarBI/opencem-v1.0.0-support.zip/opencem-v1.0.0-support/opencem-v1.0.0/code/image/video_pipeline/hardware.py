"""Hardware detection and FFmpeg decoder selection."""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
import platform
import re
import shutil
import subprocess
from typing import Iterable

from .errors import ConfigurationError


class Accelerator(str, Enum):
    CPU = "cpu"
    CUDA = "cuda"
    VIDEOTOOLBOX = "videotoolbox"
    D3D11VA = "d3d11va"


@dataclass(frozen=True)
class HardwareProfile:
    system: str
    machine: str
    accelerator: Accelerator
    devices: tuple[int, ...] = ()
    ffmpeg_accelerators: frozenset[str] = frozenset()
    cuda_major: int | None = None

    @property
    def apple_silicon(self) -> bool:
        return self.system == "Darwin" and self.machine in {"arm64", "aarch64"}

    @property
    def windows_arm(self) -> bool:
        return self.system == "Windows" and self.machine in {"arm64", "aarch64"}

    def device(self, sequence: int = 0) -> int | None:
        if self.accelerator is not Accelerator.CUDA:
            return None
        devices = self.devices or (0,)
        return devices[sequence % len(devices)]

    def decoder_input_args(self, sequence: int = 0) -> list[str]:
        if self.accelerator is Accelerator.CUDA:
            device = self.device(sequence)
            return [
                "-hwaccel", "cuda",
                "-hwaccel_device", str(device),
                "-hwaccel_output_format", "cuda",
            ]
        if self.accelerator is Accelerator.VIDEOTOOLBOX:
            return ["-hwaccel", "videotoolbox"]
        if self.accelerator is Accelerator.D3D11VA:
            # System-memory output keeps ordinary crop/scale filters portable.
            return ["-hwaccel", "d3d11va"]
        return []

    def software_filter_prefix(self) -> list[str]:
        if self.accelerator is Accelerator.CUDA:
            return ["hwdownload", "format=nv12"]
        return []


def ffmpeg_accelerators(ffmpeg: str = "ffmpeg") -> frozenset[str]:
    try:
        completed = subprocess.run(
            [ffmpeg, "-hide_banner", "-hwaccels"],
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return frozenset()
    if completed.returncode:
        return frozenset()
    names = {
        line.strip().casefold()
        for line in completed.stdout.splitlines()
        if line.strip() and not line.casefold().startswith("hardware acceleration")
    }
    return frozenset(names)


def _has_nvidia_runtime() -> bool:
    executable = shutil.which("nvidia-smi")
    if executable is None:
        return False
    try:
        return subprocess.run(
            [executable, "-L"],
            capture_output=True,
            check=False,
            timeout=10,
        ).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def cuda_version_from_text(value: str) -> int | None:
    match = re.search(r"CUDA Version:\s*(\d+)(?:\.\d+)?", value)
    return int(match.group(1)) if match else None


def nvidia_cuda_major() -> int | None:
    executable = shutil.which("nvidia-smi")
    if executable is None:
        return None
    try:
        completed = subprocess.run(
            [executable],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return cuda_version_from_text(completed.stdout + completed.stderr)


def select_accelerator(
    requested: str,
    *,
    system: str,
    machine: str,
    available: Iterable[str],
    nvidia_runtime: bool,
) -> Accelerator:
    available_set = {item.casefold() for item in available}
    normalized = requested.casefold()
    if normalized != "auto":
        selected = Accelerator(normalized)
        if selected is not Accelerator.CPU and selected.value not in available_set:
            raise ConfigurationError(
                f"FFmpeg does not report requested accelerator {selected.value!r}"
            )
        return selected
    machine = machine.casefold()
    if "cuda" in available_set and nvidia_runtime:
        return Accelerator.CUDA
    if (
        system == "Darwin"
        and machine in {"arm64", "aarch64"}
        and "videotoolbox" in available_set
    ):
        return Accelerator.VIDEOTOOLBOX
    if (
        system == "Windows"
        and machine in {"arm64", "aarch64"}
        and "d3d11va" in available_set
    ):
        return Accelerator.D3D11VA
    return Accelerator.CPU


def detect_hardware(
    ffmpeg: str = "ffmpeg",
    requested: str = "auto",
    devices: Iterable[int] = (),
) -> HardwareProfile:
    system = platform.system()
    machine = platform.machine().casefold()
    available = ffmpeg_accelerators(ffmpeg)
    accelerator = select_accelerator(
        requested,
        system=system,
        machine=machine,
        available=available,
        nvidia_runtime=_has_nvidia_runtime(),
    )
    profile = HardwareProfile(
        system=system,
        machine=machine,
        accelerator=accelerator,
        devices=tuple(int(item) for item in devices),
        ffmpeg_accelerators=available,
        cuda_major=(
            nvidia_cuda_major()
            if accelerator is Accelerator.CUDA
            else None
        ),
    )
    if profile.accelerator is not Accelerator.CUDA and profile.devices:
        profile = replace(profile, devices=())
    return profile
