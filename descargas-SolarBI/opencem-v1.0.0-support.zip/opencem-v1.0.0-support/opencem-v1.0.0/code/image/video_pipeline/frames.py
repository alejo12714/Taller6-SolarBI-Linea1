"""Minute-frame JPEG extraction backed by the persistent video frame index."""

from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
from pathlib import Path
import tempfile
from typing import Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .acquisition import AcquisitionStore, UTC, format_time
from .errors import ConfigurationError, IndexingError, MediaError
from .indexing import (
    CatalogRepository,
    IndexBackend,
    IndexedFrame,
    ensure_indexed_video,
)
from .media import MediaTools


def frame_path(root: Path, timestamp: dt.datetime, timezone: str) -> Path:
    try:
        local = timestamp.astimezone(ZoneInfo(timezone))
    except ZoneInfoNotFoundError as exc:
        raise ConfigurationError(f"Unknown archive timezone: {timezone!r}") from exc
    suffix = "Z" if local.utcoffset() == dt.timedelta(0) else local.strftime("%z")
    filename = local.strftime("%Y%m%dT%H%M%S") + suffix + ".jpg"
    return root / "frames" / local.strftime("%Y/%m/%d") / filename


class FrameArchive:
    def __init__(self, store: AcquisitionStore):
        self.store = store

    def exists(self, timestamp: dt.datetime) -> bool:
        key = format_time(timestamp)
        excluded = self.store.connection.execute(
            "SELECT 1 FROM excluded_frames WHERE timestamp_utc=?", (key,)
        ).fetchone()
        if excluded:
            return True
        row = self.store.connection.execute(
            "SELECT path FROM frames WHERE timestamp_utc=?", (key,)
        ).fetchone()
        return bool(row and self.store.resolve_path(str(row["path"])).is_file())

    def add(
        self,
        timestamp: dt.datetime,
        segment_id: str,
        path: Path,
    ) -> None:
        key = format_time(timestamp)
        excluded = self.store.connection.execute(
            "SELECT 1 FROM excluded_frames WHERE timestamp_utc=?", (key,)
        ).fetchone()
        if excluded:
            path.unlink(missing_ok=True)
            return
        with self.store.connection:
            self.store.connection.execute(
                """
                INSERT INTO frames(timestamp_utc,segment_id,path,created_at)
                VALUES(?,?,?,?)
                ON CONFLICT(timestamp_utc) DO UPDATE SET
                    segment_id=excluded.segment_id,
                    path=excluded.path
                """,
                (
                    key,
                    segment_id,
                    self.store.stored_path(path),
                    format_time(dt.datetime.now(UTC)),
                ),
            )

    def exclude(
        self,
        timestamp: dt.datetime,
        path: Path,
        reason: str,
    ) -> None:
        key = format_time(timestamp)
        with self.store.connection:
            self.store.connection.execute(
                """
                INSERT INTO excluded_frames(timestamp_utc,path,reason,excluded_at)
                VALUES(?,?,?,?)
                ON CONFLICT(timestamp_utc) DO UPDATE SET
                    path=excluded.path,
                    reason=excluded.reason,
                    excluded_at=excluded.excluded_at
                """,
                (
                    key,
                    self.store.stored_path(path),
                    reason,
                    format_time(dt.datetime.now(UTC)),
                ),
            )
            self.store.connection.execute(
                "DELETE FROM frames WHERE timestamp_utc=?", (key,)
            )


@dataclass(frozen=True)
class JPEGSettings:
    quality: int = 5
    max_width: int = 0
    max_height: int = 0
    timezone: str = "UTC"


class MinuteFrameExtractor:
    """Extract indexed full-minute frames in one presentation-order decode."""

    def __init__(self, media: MediaTools, settings: JPEGSettings):
        self.media = media
        self.settings = settings

    def extract(
        self,
        video: Path,
        *,
        segment_id: str,
        root: Path,
        archive: FrameArchive,
        catalog: CatalogRepository,
        backend: IndexBackend,
        worker: int = 0,
    ) -> int:
        catalog_video = ensure_indexed_video(
            catalog,
            backend,
            video,
            worker,
        )
        indexed = catalog.minute_frames(catalog_video.id)
        jobs = [
            (frame, dt.datetime.fromtimestamp(frame.second, UTC))
            for frame in indexed
            if not archive.exists(dt.datetime.fromtimestamp(frame.second, UTC))
        ]
        if not jobs:
            return 0
        self._validate_offsets(frame for frame, _timestamp in jobs)
        return self._extract_batch(
            video,
            jobs,
            segment_id,
            root,
            archive,
            worker,
        )

    @staticmethod
    def _validate_offsets(frames: Iterable[IndexedFrame]) -> None:
        offsets = [frame.frame_offset for frame in frames]
        if any(offset < 0 for offset in offsets):
            raise IndexingError("Frame offsets cannot be negative")
        if len(offsets) != len(set(offsets)):
            raise IndexingError(
                "Multiple requested clock minutes refer to the same frame offset"
            )

    @staticmethod
    def _selection(frames: list[tuple[IndexedFrame, dt.datetime]]) -> str:
        return "select=" + "+".join(
            f"eq(n\\,{frame.frame_offset})"
            for frame, _timestamp in frames
        )

    def _extract_batch(
        self,
        video: Path,
        jobs: list[tuple[IndexedFrame, dt.datetime]],
        segment_id: str,
        root: Path,
        archive: FrameArchive,
        sequence: int,
    ) -> int:
        frame_root = root / "frames"
        frame_root.mkdir(parents=True, exist_ok=True)
        scale = (
            f"scale={self.settings.max_width}:{self.settings.max_height}:"
            "force_original_aspect_ratio=decrease:force_divisible_by=2"
            if self.settings.max_width > 0 and self.settings.max_height > 0
            else "null"
        )
        with tempfile.TemporaryDirectory(
            prefix=".minute-frames-",
            dir=frame_root,
        ) as folder:
            staging = Path(folder)
            pattern = staging / "%08d.jpg"
            command = [
                self.media.ffmpeg,
                "-hide_banner",
                "-loglevel", "warning",
                *self.media.decoder_args(sequence),
                "-i", str(video),
                "-map", "0:v:0",
                "-vf", self.media.software_filters(
                    [self._selection(jobs), scale]
                ),
                "-frames:v", str(len(jobs)),
                "-fps_mode", "passthrough",
                "-q:v", str(self.settings.quality),
                "-start_number", "0",
                "-y", str(pattern),
            ]
            self.media.run(
                command,
                f"extract {len(jobs)} indexed minute frame(s) from {video}",
                timeout=None,
            )
            outputs = sorted(staging.glob("*.jpg"))
            if len(outputs) != len(jobs):
                raise MediaError(
                    f"FFmpeg produced {len(outputs)} of {len(jobs)} indexed "
                    f"minute frames from {video}"
                )
            for source, (_frame, timestamp) in zip(outputs, jobs):
                destination = frame_path(
                    root,
                    timestamp,
                    self.settings.timezone,
                )
                destination.parent.mkdir(parents=True, exist_ok=True)
                source.replace(destination)
                archive.add(timestamp, segment_id, destination)
        return len(jobs)
