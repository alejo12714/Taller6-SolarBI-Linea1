"""Bundled fixed-overlay glyph templates."""

from __future__ import annotations

from importlib.resources import files
from io import BytesIO


def bundled_glyph_templates() -> BytesIO:
    """Return the calibrated NPZ archive with publication-safe metadata."""
    archive = files(__package__).joinpath("hikvision_glyph_templates.npz")
    return BytesIO(archive.read_bytes())
