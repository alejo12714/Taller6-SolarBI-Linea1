"""Verified merging of independently indexed video catalogues."""

from __future__ import annotations

from contextlib import closing, ExitStack
from dataclasses import dataclass
import datetime as dt
import hashlib
import logging
from pathlib import Path
import shutil
import sqlite3
import tempfile
from typing import Iterable
import uuid

from .errors import ConfigurationError, IndexingError
from .indexing import (
    CatalogRepository,
    CatalogVideo,
    FingerprintCache,
    content_fingerprint,
)


LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class MergeReport:
    discovered: int
    imported: int
    duplicates: int
    repaired_indexes: int
    failures: tuple[str, ...]


REQUIRED_CATALOG_COLUMNS = {
    "video": {"id", "old_name", "new_name", "start", "end"},
    "frame": {"video", "second", "frame_offset"},
}


def _read_only_connection(path: Path) -> sqlite3.Connection:
    uri = path.resolve().as_uri() + "?mode=ro&immutable=1"
    connection = sqlite3.connect(uri, uri=True, timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def validate_catalog_folder(
    folder: Path,
    database_name: str = "video_catalog.sqlite3",
) -> Path:
    """Validate a complete indexed catalog without modifying its folder."""
    database = folder / database_name
    if not database.is_file():
        raise ConfigurationError(
            f"Catalogue database does not exist: {database}"
        )
    try:
        with closing(_read_only_connection(database)) as connection:
            quick_check = connection.execute("PRAGMA quick_check").fetchone()
            if quick_check is None or str(quick_check[0]).casefold() != "ok":
                raise ConfigurationError(
                    f"SQLite integrity check failed for {database}: "
                    f"{quick_check[0] if quick_check else 'no result'}"
                )
            tables = {
                str(row["name"])
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            missing_tables = REQUIRED_CATALOG_COLUMNS.keys() - tables
            if missing_tables:
                raise ConfigurationError(
                    f"Catalogue database {database} is missing table(s): "
                    f"{', '.join(sorted(missing_tables))}"
                )
            for table, required in REQUIRED_CATALOG_COLUMNS.items():
                columns = {
                    str(row["name"])
                    for row in connection.execute(
                        f"PRAGMA table_info({table})"
                    )
                }
                missing = required - columns
                if missing:
                    raise ConfigurationError(
                        f"Catalogue table {table} in {database} is missing "
                        f"column(s): {', '.join(sorted(missing))}"
                    )

            videos = connection.execute(
                "SELECT id,new_name,start,end FROM video ORDER BY id"
            ).fetchall()
            frame_count = int(
                connection.execute("SELECT COUNT(*) FROM frame").fetchone()[0]
            )
            if not videos or frame_count == 0:
                raise ConfigurationError(
                    f"Catalogue database {database} contains no indexed videos"
                )
            orphan_count = int(
                connection.execute(
                    """
                    SELECT COUNT(*) FROM frame AS f
                    LEFT JOIN video AS v ON v.id=f.video
                    WHERE v.id IS NULL
                    """
                ).fetchone()[0]
            )
            if orphan_count:
                raise ConfigurationError(
                    f"Catalogue database {database} contains {orphan_count} "
                    "orphaned frame row(s)"
                )
            incomplete = [
                int(row["id"])
                for row in connection.execute(
                    """
                    SELECT v.id FROM video AS v
                    WHERE NOT EXISTS(
                        SELECT 1 FROM frame AS f
                        WHERE f.video=v.id AND f.frame_offset<>0
                    )
                    ORDER BY v.id
                    """
                )
            ]
            if incomplete:
                raise ConfigurationError(
                    f"Catalogue database {database} has video(s) without a "
                    f"complete frame index: {incomplete}"
                )
            duplicate_names = connection.execute(
                """
                SELECT new_name FROM video
                GROUP BY new_name HAVING COUNT(*)>1
                LIMIT 1
                """
            ).fetchone()
            if duplicate_names is not None:
                raise ConfigurationError(
                    f"Catalogue database {database} contains duplicate video "
                    f"name {duplicate_names['new_name']!r}"
                )
    except ConfigurationError:
        raise
    except sqlite3.DatabaseError as exc:
        raise ConfigurationError(
            f"Invalid SQLite catalogue database {database}: {exc}"
        ) from exc

    for video in videos:
        name = str(video["new_name"])
        if Path(name).name != name or Path(name).is_absolute():
            raise ConfigurationError(
                f"Catalogue database {database} contains unsafe video name "
                f"{name!r}"
            )
        if float(video["end"]) < float(video["start"]):
            raise ConfigurationError(
                f"Catalogue video {name!r} has an invalid time interval"
            )
        if not (folder / name).is_file():
            raise ConfigurationError(
                f"Catalogued video is missing from {folder}: {name}"
            )
    return database


def _unique_destination(
    folder: Path,
    name: str,
    fingerprint: str,
    repository: CatalogRepository,
) -> Path:
    candidate = folder / name
    if not candidate.exists() and not repository.known_name(candidate.name):
        return candidate
    source = Path(name)
    stem = source.stem
    suffix = source.suffix
    candidate = folder / f"{stem}__{fingerprint[:10]}{suffix}"
    counter = 2
    while candidate.exists() or repository.known_name(candidate.name):
        candidate = folder / (
            f"{stem}__{fingerprint[:10]}__{counter}{suffix}"
        )
        counter += 1
    return candidate


def _copy_verified(
    source: Path,
    destination: Path,
    fingerprint: str,
) -> None:
    temporary = destination.with_name(
        f".{destination.name}.{uuid.uuid4().hex}.merge.part"
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(source, temporary)
        if temporary.stat().st_size != source.stat().st_size:
            raise IndexingError(
                f"Copied size mismatch for {source} -> {destination}"
            )
        copied_fingerprint = content_fingerprint(temporary)
        if copied_fingerprint != fingerprint:
            raise IndexingError(
                f"Copied SHA-256 mismatch for {source} -> {destination}"
            )
        temporary.replace(destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


class CatalogMerger:
    """Copy indexed videos and remap their frame rows into one catalogue."""

    def __init__(
        self,
        source_repository: CatalogRepository,
        destination_repository: CatalogRepository,
        source_cache: FingerprintCache,
        destination_cache: FingerprintCache,
    ):
        self.source_repository = source_repository
        self.destination_repository = destination_repository
        self.source_cache = source_cache
        self.destination_cache = destination_cache

    def merge(
        self,
        source_folder: Path,
        destination_folder: Path,
        *,
        dry_run: bool = False,
    ) -> MergeReport:
        source_folder = source_folder.resolve()
        destination_folder = destination_folder.resolve()
        if source_folder == destination_folder:
            raise ConfigurationError(
                "Source and destination catalogue folders must differ"
            )
        if not dry_run:
            destination_folder.mkdir(parents=True, exist_ok=True)
        videos = self.source_repository.all_videos()
        imported = 0
        duplicates = 0
        repaired = 0
        catalogued_names = {video.new_name for video in videos}
        failures = [
            f"{path.name}: MP4 is not represented in the source catalogue"
            for path in sorted(source_folder.glob("*.mp4"))
            if path.name not in catalogued_names
        ]
        for video in videos:
            source = source_folder / video.new_name
            created: Path | None = None
            try:
                if not source.is_file():
                    raise IndexingError(
                        f"Catalogued source video is missing: {source}"
                    )
                frames = self.source_repository.frames_for(video.id)
                if not any(frame.frame_offset != 0 for frame in frames):
                    raise IndexingError(
                        f"Source video is not fully indexed: {source}"
                    )
                fingerprint = self.source_cache.digest(source)
                duplicate = self._overlapping_identical(
                    video,
                    source.stat().st_size,
                    fingerprint,
                    destination_folder,
                )
                if duplicate is not None:
                    duplicates += 1
                    if (
                        not dry_run
                        and not self.destination_repository.has_verified_frames(
                            duplicate.id
                        )
                    ):
                        self.destination_repository.record_frames(
                            duplicate.id,
                            frames,
                        )
                        repaired += 1
                    LOG.info(
                        "%sduplicate %s; destination has %s",
                        "Would skip " if dry_run else "Skipped ",
                        source,
                        duplicate.new_name,
                    )
                    continue

                destination = destination_folder / video.new_name
                if destination.is_file():
                    if (
                        destination.stat().st_size == source.stat().st_size
                        and self.destination_cache.digest(destination)
                        == fingerprint
                        and not self.destination_repository.known_name(
                            destination.name
                        )
                    ):
                        LOG.info(
                            "Adopting existing unregistered file %s",
                            destination,
                        )
                    else:
                        destination = _unique_destination(
                            destination_folder,
                            video.new_name,
                            fingerprint,
                            self.destination_repository,
                        )
                elif self.destination_repository.known_name(destination.name):
                    destination = _unique_destination(
                        destination_folder,
                        video.new_name,
                        fingerprint,
                        self.destination_repository,
                    )

                if dry_run:
                    LOG.info("Would merge %s as %s", source, destination)
                    imported += 1
                    continue
                if not destination.exists():
                    _copy_verified(source, destination, fingerprint)
                    created = destination
                self.destination_repository.import_video(
                    video,
                    destination.name,
                    frames,
                )
                imported += 1
                LOG.info("Merged %s as %s", source, destination)
            except Exception as exc:
                if created is not None:
                    created.unlink(missing_ok=True)
                failures.append(f"{video.new_name}: {exc}")
        return MergeReport(
            discovered=len(videos),
            imported=imported,
            duplicates=duplicates,
            repaired_indexes=repaired,
            failures=tuple(failures),
        )

    def _overlapping_identical(
        self,
        source: CatalogVideo,
        source_size: int,
        fingerprint: str,
        destination_folder: Path,
    ) -> CatalogVideo | None:
        start = dt.datetime.fromtimestamp(source.start, dt.timezone.utc)
        end = dt.datetime.fromtimestamp(source.end, dt.timezone.utc)
        for candidate in self.destination_repository.overlapping(start, end):
            path = destination_folder / candidate.new_name
            if not path.is_file() or path.stat().st_size != source_size:
                continue
            if self.destination_cache.digest(path) == fingerprint:
                return candidate
        return None


def merge_catalog_folders(
    inputs: Iterable[Path],
    output: Path,
    *,
    database_name: str = "video_catalog.sqlite3",
    dry_run: bool = False,
) -> MergeReport:
    """Merge multiple immutable input archives into a validated output archive."""
    if not database_name or Path(database_name).name != database_name:
        raise ConfigurationError(
            "The catalogue database name must be a filename"
        )
    output = output.resolve()
    if output.exists() and not output.is_dir():
        raise ConfigurationError(
            f"Output catalogue path is not a directory: {output}"
        )
    output_empty = not output.exists() or not any(output.iterdir())

    supplied: list[Path] = []
    seen: set[Path] = set()
    for item in inputs:
        folder = item.resolve()
        if folder in seen:
            continue
        seen.add(folder)
        supplied.append(folder)
    if not supplied:
        raise ConfigurationError("At least one input folder is required")

    sources = [folder for folder in supplied if folder != output]
    if output_empty and len(sources) < 2:
        raise ConfigurationError(
            "An empty output folder requires at least two distinct input folders"
        )
    for source in sources:
        if not source.is_dir():
            raise ConfigurationError(
                f"Input catalogue folder does not exist: {source}"
            )
        validate_catalog_folder(source, database_name)

    destination_database = output / database_name
    if not output_empty:
        validate_catalog_folder(output, database_name)
    if not sources:
        return MergeReport(0, 0, 0, 0, ())

    discovered = 0
    imported = 0
    duplicates = 0
    repaired = 0
    failures: list[str] = []
    with ExitStack() as stack:
        if dry_run:
            temporary = Path(
                stack.enter_context(
                    tempfile.TemporaryDirectory(prefix="catalog-merge-")
                )
            )
            if output_empty:
                destination_repository = stack.enter_context(
                    CatalogRepository(":memory:")
                )
                cache_root = temporary
            else:
                destination_repository = stack.enter_context(
                    CatalogRepository(
                        destination_database,
                        readonly=True,
                    )
                )
                cache_root = temporary
        else:
            output.mkdir(parents=True, exist_ok=True)
            destination_repository = stack.enter_context(
                CatalogRepository(destination_database)
            )
            cache_root = output / ".merge-cache"
            cache_root.mkdir(parents=True, exist_ok=True)

        destination_cache = stack.enter_context(
            FingerprintCache(
                cache_root / "destination_sha256.sqlite3"
            )
        )
        for source in sources:
            source_key = hashlib.sha256(
                str(source).encode("utf-8")
            ).hexdigest()[:16]
            source_repository = stack.enter_context(
                CatalogRepository(
                    source / database_name,
                    readonly=True,
                )
            )
            source_cache = stack.enter_context(
                FingerprintCache(
                    cache_root / f"source_{source_key}_sha256.sqlite3"
                )
            )
            report = CatalogMerger(
                source_repository,
                destination_repository,
                source_cache,
                destination_cache,
            ).merge(source, output, dry_run=dry_run)
            discovered += report.discovered
            imported += report.imported
            duplicates += report.duplicates
            repaired += report.repaired_indexes
            failures.extend(
                f"{source}: {failure}"
                for failure in report.failures
            )
    return MergeReport(
        discovered,
        imported,
        duplicates,
        repaired,
        tuple(failures),
    )
