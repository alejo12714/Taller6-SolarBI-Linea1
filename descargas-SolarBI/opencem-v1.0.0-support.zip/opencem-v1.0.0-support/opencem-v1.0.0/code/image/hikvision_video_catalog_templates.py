#!/usr/bin/env python3
"""Compatibility entry point for the packaged fixed-overlay indexer."""

from __future__ import annotations

import sys

from video_pipeline import hikvision_overlay as _engine


if __name__ == "__main__":
    raise SystemExit(_engine.main())

sys.modules[__name__] = _engine
