# Electrical snapshot acquisition

`record_inverter_snapshots.py` is a sanitized copy of the script used to record the released electrical time series. The polling, timeout, error, carry-forward, and snapshot-writing behavior is retained for reproducibility.

Only machine-local serial and output paths have been parameterized, and the private component register dictionary has been replaced by one non-operational entry showing its structure.

The recorder uses Modbus RTU at 9600 baud, 8 data bits, no parity, one stop bit, unit identifier 1, and a one-second client timeout. Every cycle reads the first 33 ordered register blocks and one rotating group of ten remaining blocks. It waits 0.2 seconds before each block, queries inverter 1 and then inverter 2, and waits another 0.2 seconds between complete cycles. Response latency and timeouts therefore contribute directly to the irregular spacing of snapshot timestamps. These timeouts have been fine-tuned on our installation (highest read frequency without frequent read failures) and ideal timeouts may be different for other inverters.

The two output dictionaries persist between cycles. Registers outside the current rotating group retain their most recently read values. A Modbus error response stores `NaN` for that block, while an exception leaves the preceding value unchanged. Both inverter JSON files are written after polling with one shared Unix timestamp. These details are important when interpreting field freshness and inter-record intervals in the released data.

Set `OPENCEM_INVERTER1_PORT`, `OPENCEM_INVERTER2_PORT`, `OPENCEM_INVERTER1_OUTPUT`, and `OPENCEM_INVERTER2_OUTPUT` for a local system. The two configured output directories must already exist, matching the behavior of the deployed recorder. The script uses the synchronous client API from the 2.x series of `pymodbus`. Before execution, replace the dummy `modbus_addresses` entry with an ordered map derived from documentation for the component being recorded.
