#!/usr/bin/env python3
"""Sanitized copy of the recorder used to acquire the OpenCEM snapshots.

The original polling and snapshot logic is retained. The component-specific
register map is replaced by one non-operational example entry because it was
transcribed from documentation that is not redistributed with the dataset.
"""

from pymodbus.client.sync import ModbusSerialClient
import json
import logging
import math
import os
from pathlib import Path
import re
import schedule
import time


# The deployed machine used two local serial-device names. Environment variables
# replace those machine-specific values in this public copy.
PORT1 = os.environ.get("OPENCEM_INVERTER1_PORT", "SERIAL_PORT_INVERTER_1")
PORT2 = os.environ.get("OPENCEM_INVERTER2_PORT", "SERIAL_PORT_INVERTER_2")
OUTPUT_DIR1 = Path(os.environ.get("OPENCEM_INVERTER1_OUTPUT", "raw_measurements/inverter1"))
OUTPUT_DIR2 = Path(os.environ.get("OPENCEM_INVERTER2_OUTPUT", "raw_measurements/inverter2"))

BAUDRATE = 9600
PARITY = "N"
BYTESIZE = 8
STOPBITS = 1
UNIT = 1


# The full ordered list is component-specific. This dummy entry shows every key
# consumed by the acquisition loop; replace the list from documentation for the
# component being recorded. The primary/rotating schedule depends on list order.
modbus_addresses = [
    {
        "address": 0x0000,
        "unit": "example-unit",
        "scale": 1,
        "value_count": 1,
        "format_string": "%d",
        "zh_label": "example-label",
        "en_label": "ExampleRegister",
        "zh_description": "Non-operational structural example",
    }
]


def extract_float(s):
    match = re.search(r"[-+]?\d*\.\d+|\d+", s)
    return float(match.group()) if match else None


def extract_int(s):
    match = re.search(r"[-+]?\d*\.\d+|\d+", s)
    return int(match.group()) if match else None


SCALE_VOLT = 0.1

records1 = {}
records2 = {}


def main(chunk):
    if len(modbus_addresses) == 1 and modbus_addresses[0]["en_label"] == "ExampleRegister":
        raise RuntimeError(
            "The public file contains only a structural register-map example. "
            "Provide a component-specific ordered register map before recording."
        )

    logging.basicConfig()
    log = logging.getLogger()
    log.setLevel(logging.INFO)

    client1 = ModbusSerialClient(
        method="rtu",
        port=PORT1,
        baudrate=BAUDRATE,
        parity=PARITY,
        bytesize=BYTESIZE,
        stopbits=STOPBITS,
        timeout=1,
    )
    client2 = ModbusSerialClient(
        method="rtu",
        port=PORT2,
        baudrate=BAUDRATE,
        parity=PARITY,
        bytesize=BYTESIZE,
        stopbits=STOPBITS,
        timeout=1,
    )

    if not client1.connect():
        log.error(f"Unable to open serial port {PORT1}")
        return
    if not client2.connect():
        log.error(f"Unable to open serial port {PORT2}")
        return

    chunk_mod = chunk % math.ceil((len(modbus_addresses) - 33) / 10)
    addresses_to_read = (
        modbus_addresses[0:33]
        + modbus_addresses[33 + 10 * chunk_mod : 33 + 10 * (chunk_mod + 1)]
    )

    for address in addresses_to_read:
        time.sleep(0.2)
        try:
            params = address
            rr1 = client1.read_holding_registers(
                address=params["address"], count=params["value_count"], unit=UNIT
            )
            if rr1.isError():
                records1[params["address"]] = [float("NaN")]
                log.error(
                    f"Failed on inverter1 to read at {hex(params['address'])}: {rr1}"
                )
            else:
                read_values1 = []
                for i in range(params["value_count"]):
                    raw1 = rr1.registers[i]
                    value1 = raw1 * params["scale"]
                    print(
                        params["address"],
                        ": ",
                        params["format_string"] % value1,
                        f"{params['unit']}",
                    )
                    read_values1.append(
                        extract_int(params["format_string"] % value1)
                        if params["scale"] == 1
                        else extract_float(params["format_string"] % value1)
                    )
                records1[params["address"]] = read_values1
        except Exception:
            print("Failure on inverter1 to read " + str(address))
        try:
            params = address
            rr2 = client2.read_holding_registers(
                address=params["address"], count=params["value_count"], unit=UNIT
            )
            if rr2.isError():
                records2[params["address"]] = [float("NaN")]
                log.error(
                    f"Failed on inverter2 to read at {hex(params['address'])}: {rr2}"
                )
            else:
                read_values2 = []
                for i in range(params["value_count"]):
                    raw2 = rr2.registers[i]
                    value2 = raw2 * params["scale"]
                    print(
                        params["address"],
                        ": ",
                        params["format_string"] % value2,
                        f"{params['unit']}",
                    )
                    read_values2.append(
                        extract_int(params["format_string"] % value2)
                        if params["scale"] == 1
                        else extract_float(params["format_string"] % value2)
                    )
                records2[params["address"]] = read_values2
        except Exception:
            print("Failure on inverter2 to read " + str(address))

    timestamp = time.time()
    with (OUTPUT_DIR1 / ("data_" + str(timestamp) + ".json")).open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(records1, f, ensure_ascii=False, indent=4)
    with (OUTPUT_DIR2 / ("data_" + str(timestamp) + ".json")).open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(records2, f, ensure_ascii=False, indent=4)
    client1.close()
    client2.close()


if __name__ == "__main__":
    i = 0
    while True:
        main(i)
        time.sleep(0.2)
        i = i + 1
