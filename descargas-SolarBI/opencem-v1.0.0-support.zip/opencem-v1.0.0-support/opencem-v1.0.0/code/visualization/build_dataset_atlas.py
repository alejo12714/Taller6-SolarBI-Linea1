#!/usr/bin/env python3
"""Builds separate vector-PDF atlas panels for the OpenCEM descriptor."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from textwrap import fill

os.environ.setdefault("MPLCONFIGDIR", "/tmp/opencem_mpl_cache")

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
from PIL import Image, ImageOps


MANUSCRIPT = Path(__file__).resolve().parents[1]
RESULTS_PATH = MANUSCRIPT / "technical_validation" / "outputs" / "validation_results.json"
OUTPUT_DIR = MANUSCRIPT / "images"

PHYSICAL_IMAGES = (
    MANUSCRIPT / "images" / "installation_photos" / "rooftop_oblique.jpg",
    MANUSCRIPT / "images" / "installation_photos" / "rooftop_overhead.jpg",
)

PANEL_OUTPUTS = {
    "installation": OUTPUT_DIR / "01_dataset_atlas_a_installation",
    "release": OUTPUT_DIR / "01_dataset_atlas_b_release_construction",
    "modalities": OUTPUT_DIR / "01_dataset_atlas_c_modalities",
    "footprint": OUTPUT_DIR / "01_dataset_atlas_d_table_footprint",
}

TABLE_ORDER = (
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
    "context",
)

COLORS = {
    "ink": "#17202A",
    "muted": "#5B677A",
    "hairline": "#D6DEE8",
    "panel": "#F7FAFC",
    "blue": "#2878B5",
    "teal": "#00A6A6",
    "green": "#5AA469",
    "gold": "#F2B134",
    "red": "#E06C5C",
    "purple": "#8E6C8A",
    "slate": "#4B5563",
    "olive": "#7A9E7E",
}

def fmt_int(value: float | int) -> str:
    return f"{int(value):,}"


def fmt_compact(value: float | int) -> str:
    value = float(value)
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if value >= 1_000:
        return f"{value / 1_000:.1f}k"
    return f"{int(value)}"


def short_date(value: str) -> str:
    if "," in value:
        return value.split(",", maxsplit=1)[0]
    try:
        return datetime.fromisoformat(value).strftime("%d %b %Y").lstrip("0")
    except ValueError:
        return value[:12].strip()


def load_results() -> dict:
    with RESULTS_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def crop_image(path: Path, aspect: float, max_width: int = 3200) -> np.ndarray:
    image = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    width, height = image.size
    current = width / height
    if current > aspect:
        new_width = int(height * aspect)
        left = (width - new_width) // 2
        image = image.crop((left, 0, left + new_width, height))
    else:
        new_height = int(width / aspect)
        top = (height - new_height) // 2
        image = image.crop((0, top, width, top + new_height))
    if image.size[0] > max_width:
        new_height = int(max_width / aspect)
        image = image.resize((max_width, new_height), Image.Resampling.LANCZOS)
    return np.asarray(image)


def setup_panel(figsize: tuple[float, float]) -> tuple[plt.Figure, plt.Axes]:
    fig = plt.figure(figsize=figsize, constrained_layout=False)
    ax = fig.add_axes((0.0, 0.0, 1.0, 1.0))
    ax.set_axis_off()
    ax.add_patch(
        FancyBboxPatch(
            (0.012, 0.018),
            0.976,
            0.964,
            boxstyle="round,pad=0.008,rounding_size=0.018",
            facecolor=COLORS["panel"],
            edgecolor=COLORS["hairline"],
            linewidth=1.0,
            transform=ax.transAxes,
        )
    )
    return fig, ax


def add_label(ax: plt.Axes, text: str, x: float, y: float, **kwargs) -> None:
    defaults = {
        "fontsize": 9,
        "color": COLORS["ink"],
        "ha": "left",
        "va": "center",
        "transform": ax.transAxes,
    }
    defaults.update(kwargs)
    ax.text(x, y, text, **defaults)


def add_photo(
    ax: plt.Axes,
    image_path: Path,
    rect: tuple[float, float, float, float],
    tag: str,
    caption: str,
) -> None:
    image_ax = ax.inset_axes(rect)
    fig_width, fig_height = ax.figure.get_size_inches()
    physical_aspect = rect[2] * fig_width / (rect[3] * fig_height)
    image = crop_image(image_path, aspect=physical_aspect)
    image_ax.imshow(image)
    image_ax.set_axis_off()
    image_ax.add_patch(
        Rectangle(
            (0, 0),
            1,
            1,
            transform=image_ax.transAxes,
            facecolor="none",
            edgecolor="white",
            linewidth=1.5,
        )
    )
    image_ax.add_patch(
        Rectangle(
            (0, 0),
            1,
            0.28,
            transform=image_ax.transAxes,
            facecolor=(0, 0, 0, 0.55),
            edgecolor="none",
        )
    )
    image_ax.text(
        0.045,
        0.185,
        tag,
        transform=image_ax.transAxes,
        color="white",
        fontsize=8.5,
        fontweight="bold",
        va="center",
    )
    image_ax.text(
        0.045,
        0.075,
        caption,
        transform=image_ax.transAxes,
        color="white",
        fontsize=8.5,
        va="center",
    )


def rounded_box(
    ax: plt.Axes,
    x: float,
    y: float,
    width: float,
    height: float,
    title: str,
    body: str,
    color: str,
    wrap: int = 20,
) -> None:
    header_height = 0.14
    ax.add_patch(
        FancyBboxPatch(
            (x, y),
            width,
            height,
            boxstyle="round,pad=0.010,rounding_size=0.018",
            facecolor="#FFFFFF",
            edgecolor=color,
            linewidth=1.1,
            transform=ax.transAxes,
        )
    )
    ax.add_patch(
        Rectangle(
            (x, y + height - header_height),
            width,
            header_height,
            transform=ax.transAxes,
            facecolor=color,
            edgecolor="none",
        )
    )
    add_label(
        ax,
        title,
        x + 0.022,
        y + height - header_height / 2,
        fontsize=9.0,
        color="white",
        fontweight="bold",
    )
    add_label(
        ax,
        fill(body, wrap),
        x + 0.022,
        y + height - header_height - 0.045,
        fontsize=8.0,
        color=COLORS["ink"],
        va="top",
        linespacing=1.08,
    )


def add_arrow(ax: plt.Axes, start: tuple[float, float], end: tuple[float, float]) -> None:
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            transform=ax.transAxes,
            arrowstyle="-|>",
            mutation_scale=11,
            linewidth=1.1,
            color=COLORS["slate"],
            shrinkA=4,
            shrinkB=4,
        )
    )


def add_chip(ax: plt.Axes, x: float, title: str, value: str, width: float = 0.255) -> None:
    ax.add_patch(
        FancyBboxPatch(
            (x, 0.07),
            width,
            0.22,
            boxstyle="round,pad=0.012,rounding_size=0.018",
            facecolor="white",
            edgecolor=COLORS["hairline"],
            linewidth=0.9,
            transform=ax.transAxes,
        )
    )
    add_label(ax, title, x + 0.02, 0.225, fontsize=8.0, color=COLORS["muted"], fontweight="bold")
    add_label(ax, value, x + 0.02, 0.135, fontsize=8.2, color=COLORS["ink"])


def add_modality_card(
    ax: plt.Axes,
    y: float,
    title: str,
    metric: str,
    description: str,
    color: str,
    height: float = 0.205,
    wrap: int = 30,
) -> None:
    card_x = 0.05
    card_width = 0.90
    text_x = 0.105
    ax.add_patch(
        FancyBboxPatch(
            (card_x, y),
            card_width,
            height,
            boxstyle="round,pad=0.014,rounding_size=0.018",
            facecolor="white",
            edgecolor=COLORS["hairline"],
            linewidth=1.0,
            transform=ax.transAxes,
        )
    )
    ax.add_patch(
        Rectangle(
            (card_x, y),
            0.022,
            height,
            transform=ax.transAxes,
            facecolor=color,
            edgecolor="none",
        )
    )
    add_label(ax, title, text_x, y + height - 0.050, fontsize=8.5, fontweight="bold")
    add_label(ax, metric, text_x, y + height - 0.105, fontsize=10.5, fontweight="bold", color=color)
    add_label(
        ax,
        fill(description, wrap),
        text_x,
        y + height - 0.158,
        fontsize=8.0,
        color=COLORS["muted"],
        va="top",
        linespacing=1.06,
    )


def save_panel(fig: plt.Figure, output_stem: Path) -> None:
    output_stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_stem.with_suffix(".pdf"), dpi=600, bbox_inches="tight", pad_inches=0.01)
    fig.savefig(output_stem.with_suffix(".png"), dpi=220, bbox_inches="tight", pad_inches=0.01)
    plt.close(fig)


def build_installation_panel() -> None:
    fig, ax = setup_panel((4.15, 1.25))
    photos = [
        (PHYSICAL_IMAGES[0], (0.035, 0.075, 0.455, 0.85), "Rooftop PV array", "Campus installation"),
        (PHYSICAL_IMAGES[1], (0.510, 0.075, 0.455, 0.85), "Array layout", "Near-vertical view"),
    ]
    for image_path, rect, tag, caption in photos:
        add_photo(ax, image_path, rect, tag, caption)
    save_panel(fig, PANEL_OUTPUTS["installation"])


def build_release_panel(results: dict) -> None:
    fig, ax = setup_panel((4.15, 1.25))
    margin = 0.055
    gap = 0.035
    width = (1 - 2 * margin - 3 * gap) / 4
    y = 0.39
    height = 0.50
    boxes = [
        ("Raw logs", "Modbus JSON, context, and images", COLORS["blue"]),
        ("Staging", "PostgreSQL cleanup and validation", COLORS["teal"]),
        ("Release DB", "Compressed SQLite with public names", COLORS["green"]),
        ("Companion", "Sky archive; weather/news code", COLORS["gold"]),
    ]
    centers = []
    for index, (title, body, color) in enumerate(boxes):
        x = margin + index * (width + gap)
        rounded_box(ax, x, y, width, height, title, body, color, wrap=15)
        centers.append((x + width / 2, y + height / 2))
    for left, right in zip(centers[:-1], centers[1:]):
        add_arrow(ax, (left[0] + width / 2 - 0.012, left[1]), (right[0] - width / 2 + 0.012, right[1]))

    add_chip(ax, 0.055, "Location", "22.693N, 114.211E", width=0.255)
    add_chip(
        ax,
        0.355,
        "Electrical span",
        "Jul 2025–Jul 2026",
        width=0.29,
    )
    add_chip(
        ax,
        0.69,
        "Sky-image span",
        "Mar–Jul 2026",
        width=0.255,
    )
    save_panel(fig, PANEL_OUTPUTS["release"])


def build_modalities_panel(results: dict) -> None:
    fig, ax = setup_panel((4.15, 2.30))
    tables = results["database"]["tables"]
    measurement_rows = sum(tables[table]["rows"] for table in TABLE_ORDER if table != "context")
    measurement_columns = sum(tables[table]["data_columns"] for table in TABLE_ORDER if table != "context")
    context_rows = tables["context"]["rows"]
    context_types = results.get("context", {}).get("context_types", 55)
    source_families = results.get("context", {}).get("source_families", 7)
    add_modality_card(
        ax,
        0.765,
        "Inverter registers",
        f"{fmt_compact(measurement_rows)} rows",
        f"{measurement_columns} fields across seven tables",
        COLORS["blue"],
        wrap=60,
    )
    add_modality_card(
        ax,
        0.520,
        "Context intervals",
        f"{fmt_int(context_rows)} records",
        f"{context_types} types; {source_families} source families",
        COLORS["purple"],
        wrap=60,
    )
    add_modality_card(
        ax,
        0.275,
        "Sky images",
        "1-min frames",
        "Upward JPEGs; Mar–Jul 2026",
        COLORS["gold"],
        wrap=60,
    )
    add_modality_card(
        ax,
        0.030,
        "External enrichment code",
        "Weather + news",
        "Open-Meteo + news code",
        COLORS["teal"],
        wrap=60,
    )
    save_panel(fig, PANEL_OUTPUTS["modalities"])


def build_footprint_panel(results: dict) -> None:
    fig, ax_panel = setup_panel((4.15, 2.30))

    ax = fig.add_axes((0.275, 0.17, 0.375, 0.72))
    tables = results["database"]["tables"]
    rows = np.array([tables[table]["rows"] for table in TABLE_ORDER], dtype=float)
    columns = np.array([tables[table]["data_columns"] for table in TABLE_ORDER], dtype=float)
    y = np.arange(len(TABLE_ORDER))
    palette = [
        COLORS["blue"],
        COLORS["teal"],
        COLORS["green"],
        COLORS["gold"],
        COLORS["red"],
        COLORS["purple"],
        COLORS["slate"],
        COLORS["olive"],
    ]
    ax.barh(y, np.log10(rows), color=palette, height=0.58)
    ax.set_yticks(y, [table.replace("_", " ") for table in TABLE_ORDER])
    ax.invert_yaxis()
    ax.set_xlim(4.0, 6.5)
    ax.set_xticks([4, 5, 6], ["10k", "100k", "1M"])
    ax.set_xlabel("")
    ax.grid(axis="x", color="#E6EAF0", linewidth=0.8)
    ax.tick_params(axis="both", labelsize=8.0)
    ax.xaxis.label.set_size(8.5)
    for spine in ax.spines.values():
        spine.set_visible(False)

    add_label(ax_panel, "Rows per table", 0.465, 0.065, fontsize=8.5, ha="center")

    label_ax = fig.add_axes((0.70, 0.18, 0.25, 0.70))
    label_ax.set_axis_off()
    label_ax.text(0.0, 1.02, "Rows", transform=label_ax.transAxes, fontsize=8.0, color=COLORS["muted"], fontweight="bold")
    label_ax.text(0.99, 1.02, "Fields", transform=label_ax.transAxes, fontsize=8.0, color=COLORS["muted"], fontweight="bold", ha="right")
    for index, (row_count, col_count, color) in enumerate(zip(rows, columns, palette)):
        y_pos = 1.0 - (index + 0.5) / len(TABLE_ORDER)
        label_ax.text(
            0.0,
            y_pos,
            fmt_int(row_count),
            transform=label_ax.transAxes,
            va="center",
            ha="left",
            fontsize=8.0,
            color=COLORS["ink"],
        )
        label_ax.text(
            0.99,
            y_pos,
            str(int(col_count)),
            transform=label_ax.transAxes,
            va="center",
            ha="right",
            fontsize=8.0,
            color=color,
            fontweight="bold",
        )
    save_panel(fig, PANEL_OUTPUTS["footprint"])


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.edgecolor": COLORS["hairline"],
            "axes.labelcolor": COLORS["ink"],
            "xtick.color": COLORS["muted"],
            "ytick.color": COLORS["muted"],
            "figure.facecolor": "white",
        }
    )


def main() -> int:
    results = load_results()
    configure_style()
    build_installation_panel()
    build_release_panel(results)
    build_modalities_panel(results)
    build_footprint_panel(results)
    for output in PANEL_OUTPUTS.values():
        print(f"Wrote {output.with_suffix('.pdf')}")
        print(f"Wrote {output.with_suffix('.png')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
