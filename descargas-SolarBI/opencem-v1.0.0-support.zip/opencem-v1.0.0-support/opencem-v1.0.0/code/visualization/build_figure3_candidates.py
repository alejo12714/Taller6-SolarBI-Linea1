#!/usr/bin/env python3
"""Build three readability candidates for manuscript Figure 3."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from build_context_gallery import query


OUT = Path(__file__).resolve().parent / "figure3_candidates"
OUT.mkdir(parents=True, exist_ok=True)

START = pd.Timestamp("2025-11-24")
END = pd.Timestamp("2026-02-01")
FIGURE_WIDTH_IN = 7.3


def load_heatmaps() -> tuple[pd.DataFrame, pd.DataFrame]:
    frame = query(
        """
        WITH h AS (
            SELECT
                date_trunc('hour', read_ts AT TIME ZONE 'Asia/Shanghai') AS hour_local,
                inverter,
                avg(COALESCE(pv1power,0) + COALESCE(pv2power,0) + COALESCE(pv3power,0))::float AS pv_w,
                avg(outsumw)::float AS load_w
            FROM measurement.analog_measurement_fixed
            WHERE read_ts >= timestamptz '2025-11-24 00:00:00+08'
              AND read_ts <  timestamptz '2026-02-01 00:00:00+08'
            GROUP BY 1, 2
        )
        SELECT * FROM h WHERE inverter = 2 ORDER BY hour_local;
        """
    )
    frame["hour_local"] = pd.to_datetime(frame["hour_local"])
    frame["date"] = frame["hour_local"].dt.normalize()
    frame["hour"] = frame["hour_local"].dt.hour
    days = pd.date_range(START, END - pd.Timedelta(days=1), freq="D")
    hours = pd.Index(range(24), name="hour")
    pv = frame.pivot_table(index="date", columns="hour", values="pv_w", aggfunc="mean")
    load = frame.pivot_table(index="date", columns="hour", values="load_w", aggfunc="mean")
    return pv.reindex(index=days, columns=hours), load.reindex(index=days, columns=hours)


def set_theme(font_size: float) -> None:
    sns.set_theme(
        context="paper",
        style="white",
        font="Times New Roman",
        rc={
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "font.size": font_size,
            "axes.labelsize": font_size,
            "xtick.labelsize": font_size,
            "ytick.labelsize": font_size,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        },
    )


def format_heatmap_axis(
    ax: plt.Axes,
    days: pd.DatetimeIndex,
    font_size: float,
    *,
    show_y: bool,
    show_x: bool = True,
) -> None:
    x_positions = np.arange(0.5, 24, 2)
    ax.set_xticks(x_positions)
    ax.set_xticklabels([str(hour) for hour in range(0, 24, 2)], rotation=0)
    ax.tick_params(axis="x", labelbottom=show_x, length=3, width=0.6, pad=3, labelsize=font_size)
    ax.set_xlabel("Hour of day" if show_x else "", labelpad=5, fontsize=font_size)

    weekly = np.arange(0, len(days), 7)
    ax.set_yticks(weekly + 0.5)
    if show_y:
        ax.set_yticklabels([days[index].strftime("%b %d") for index in weekly], rotation=0)
        ax.set_ylabel("Date", labelpad=7, fontsize=font_size)
        ax.tick_params(axis="y", labelleft=True, length=0, pad=4, labelsize=font_size)
    else:
        ax.set_yticklabels([])
        ax.set_ylabel("")
        ax.tick_params(axis="y", labelleft=False, length=0)

    for boundary in range(1, len(days)):
        weekly_boundary = boundary % 7 == 0
        ax.axhline(
            boundary,
            color="#BFC3C7" if weekly_boundary else "#D9DDE1",
            linewidth=0.55 if weekly_boundary else 0.28,
            zorder=4,
        )
    for spine in ax.spines.values():
        spine.set_visible(False)


def style_colorbar(colorbar, font_size: float, label: str, *, orientation: str) -> None:
    colorbar.ax.tick_params(labelsize=font_size, width=0.5, length=2.5)
    colorbar.set_label(label, fontsize=font_size, labelpad=5)
    if orientation == "horizontal":
        colorbar.ax.xaxis.set_label_position("bottom")


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.pdf", facecolor="white", transparent=False)
    fig.savefig(OUT / f"{stem}.png", dpi=180, facecolor="white", transparent=False)
    plt.close(fig)


def candidate_a(pv: pd.DataFrame, load: pd.DataFrame) -> None:
    """Balanced side-by-side panels with conventional vertical colorbars."""
    font_size = 9.5
    set_theme(font_size)
    fig, axes = plt.subplots(1, 2, figsize=(FIGURE_WIDTH_IN, 4.75), sharey=False)
    fig.subplots_adjust(left=0.12, right=0.96, bottom=0.12, top=0.98, wspace=0.27)
    pv_plot = sns.heatmap(
        pv,
        cmap="YlOrBr",
        ax=axes[0],
        vmin=0,
        vmax=float(np.nanmax(pv.to_numpy())),
        cbar_kws={"fraction": 0.052, "pad": 0.025},
    )
    load_plot = sns.heatmap(
        load,
        cmap="mako_r",
        ax=axes[1],
        vmin=0,
        vmax=float(np.nanmax(load.to_numpy())),
        cbar_kws={"fraction": 0.052, "pad": 0.025},
    )
    format_heatmap_axis(axes[0], pv.index, font_size, show_y=True)
    format_heatmap_axis(axes[1], pv.index, font_size, show_y=False)
    style_colorbar(pv_plot.collections[0].colorbar, font_size, "PV power (W)", orientation="vertical")
    style_colorbar(load_plot.collections[0].colorbar, font_size, "Load power (W)", orientation="vertical")
    save(fig, "figure3_attempt_a_balanced")


def candidate_b(pv: pd.DataFrame, load: pd.DataFrame) -> None:
    """Wider side-by-side panels with compact horizontal colorbars."""
    font_size = 10.0
    set_theme(font_size)
    fig = plt.figure(figsize=(FIGURE_WIDTH_IN, 4.75))
    grid = fig.add_gridspec(
        2,
        2,
        height_ratios=(1, 0.045),
        left=0.12,
        right=0.99,
        bottom=0.13,
        top=0.98,
        hspace=0.22,
        wspace=0.16,
    )
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    color_axes = [fig.add_subplot(grid[1, 0]), fig.add_subplot(grid[1, 1])]
    pv_plot = sns.heatmap(
        pv,
        cmap="YlOrBr",
        ax=axes[0],
        vmin=0,
        vmax=float(np.nanmax(pv.to_numpy())),
        cbar_ax=color_axes[0],
        cbar_kws={"orientation": "horizontal"},
    )
    load_plot = sns.heatmap(
        load,
        cmap="mako_r",
        ax=axes[1],
        vmin=0,
        vmax=float(np.nanmax(load.to_numpy())),
        cbar_ax=color_axes[1],
        cbar_kws={"orientation": "horizontal"},
    )
    format_heatmap_axis(axes[0], pv.index, font_size, show_y=True)
    format_heatmap_axis(axes[1], pv.index, font_size, show_y=False)
    style_colorbar(pv_plot.collections[0].colorbar, font_size, "PV power (W)", orientation="horizontal")
    style_colorbar(load_plot.collections[0].colorbar, font_size, "Load power (W)", orientation="horizontal")
    save(fig, "figure3_attempt_b_wide")


def candidate_c(pv: pd.DataFrame, load: pd.DataFrame) -> None:
    """Readability-first stacked panels with a shared two-hour x scale."""
    font_size = 10.5
    set_theme(font_size)
    fig = plt.figure(figsize=(FIGURE_WIDTH_IN, 6.4))
    grid = fig.add_gridspec(
        2,
        2,
        width_ratios=(1, 0.035),
        left=0.13,
        right=0.92,
        bottom=0.10,
        top=0.985,
        hspace=0.10,
        wspace=0.05,
    )
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[1, 0])]
    color_axes = [fig.add_subplot(grid[0, 1]), fig.add_subplot(grid[1, 1])]
    pv_plot = sns.heatmap(
        pv,
        cmap="YlOrBr",
        ax=axes[0],
        vmin=0,
        vmax=float(np.nanmax(pv.to_numpy())),
        cbar_ax=color_axes[0],
    )
    load_plot = sns.heatmap(
        load,
        cmap="mako_r",
        ax=axes[1],
        vmin=0,
        vmax=float(np.nanmax(load.to_numpy())),
        cbar_ax=color_axes[1],
    )
    format_heatmap_axis(axes[0], pv.index, font_size, show_y=True, show_x=False)
    format_heatmap_axis(axes[1], pv.index, font_size, show_y=True, show_x=True)
    style_colorbar(pv_plot.collections[0].colorbar, font_size, "PV power (W)", orientation="vertical")
    style_colorbar(load_plot.collections[0].colorbar, font_size, "Load power (W)", orientation="vertical")
    save(fig, "figure3_attempt_c_stacked")


def main() -> None:
    pv, load = load_heatmaps()
    candidate_a(pv, load)
    candidate_b(pv, load)
    candidate_c(pv, load)
    print(f"Wrote Figure 3 candidates to {OUT}")


if __name__ == "__main__":
    main()
