#!/usr/bin/env python3
"""Builds a gallery of Seaborn figures for the OpenCEM descriptor."""

from __future__ import annotations

import math
import os
import textwrap
import warnings
from datetime import date, datetime, timedelta
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import psycopg
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch, Rectangle


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "visualization_gallery" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

CONNINFO = os.environ.get(
    "OPENCEM_PG_DSN", "host=localhost port=5432 dbname=opencem user=postgres"
)
TZ = "Asia/Shanghai"
MANUSCRIPT_MULTIMODAL_DAY = date(2025, 12, 18)

COLORS = {
    "cpu_compilation_workload": "#4C78A8",
    "gpu_cnn_training_workload": "#F58518",
    "battery_charging": "#54A24B",
    "battery_discharging": "#E45756",
    "pv_generation_active": "#EECA3B",
    "grid_unavailable_or_islanded": "#B279A2",
    "high_ac_load": "#FF9DA6",
    "windows_event_log": "#72B7B2",
    "wsl_bash_history": "#9D755D",
    "manual entry": "#766A65",
    "manual_workload_entry": "#766A65",
    "derived_context_pipeline": "#59A14F",
    "workstation1_log": "#4E79A7",
    "workstation2_log": "#F28E2B",
}


def query(sql: str, params: dict | None = None) -> pd.DataFrame:
    with psycopg.connect(CONNINFO) as conn:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="pandas only supports SQLAlchemy connectable.*",
                category=UserWarning,
            )
            return pd.read_sql_query(sql, conn, params=params)


def savefig(
    fig: plt.Figure,
    stem: str,
    aliases: tuple[str, ...] = (),
    *,
    tight: bool = True,
) -> None:
    bbox = "tight" if tight else None
    for output_stem in (stem, *aliases):
        png = OUT / f"{output_stem}.png"
        pdf = OUT / f"{output_stem}.pdf"
        fig.savefig(png, dpi=220, bbox_inches=bbox, facecolor=fig.get_facecolor(), transparent=False)
        fig.savefig(pdf, bbox_inches=bbox, facecolor=fig.get_facecolor(), transparent=False)
    plt.close(fig)


def setup_theme() -> None:
    sns.set_theme(
        context="paper",
        style="whitegrid",
        font="Times New Roman",
        rc={
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "font.monospace": ["Andale Mono"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "mathtext.fontset": "custom",
            "mathtext.rm": "Times New Roman",
            "mathtext.it": "Times New Roman:italic",
            "mathtext.bf": "Times New Roman:bold",
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": "#D8DEE9",
            "axes.labelcolor": "#2E3440",
            "axes.titlecolor": "#2E3440",
            "grid.color": "#E5E9F0",
            "grid.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.facecolor": "white",
            "font.size": 9,
        },
    )


def wrap_labels(labels: list[str], width: int = 26) -> list[str]:
    return ["\n".join(textwrap.wrap(str(label).replace("_", " "), width=width)) for label in labels]


def add_header(fig: plt.Figure, ax: plt.Axes, title: str, subtitle: str) -> None:
    fig.tight_layout(rect=(0, 0, 1, 0.84))
    left = ax.get_position().x0
    fig.suptitle(title, x=left, y=0.985, ha="left", fontsize=15, weight="bold")
    fig.text(left, 0.915, subtitle, fontsize=9, color="#4C566A")


def figure_01_context_taxonomy() -> None:
    df = query(
        """
        WITH c AS (
            SELECT
                COALESCE(value::jsonb->>'source', 'unspecified') AS source,
                COALESCE(value::jsonb->>'context_type', 'unspecified') AS context_type
            FROM public.context
        )
        SELECT source, context_type, count(*)::int AS rows
        FROM c
        GROUP BY 1, 2
        ORDER BY rows DESC;
        """
    )
    top_types = df.groupby("context_type")["rows"].sum().sort_values(ascending=False).head(18).index
    plot_df = df[df["context_type"].isin(top_types)].copy()
    type_order = plot_df.groupby("context_type")["rows"].sum().sort_values().index.tolist()
    pivot = plot_df.pivot_table(index="context_type", columns="source", values="rows", aggfunc="sum", fill_value=0)
    pivot = pivot.reindex(type_order)

    fig, ax = plt.subplots(figsize=(10.5, 8.3))
    left = np.zeros(len(pivot))
    sources = pivot.sum(axis=0).sort_values(ascending=False).index.tolist()
    for source in sources:
        values = pivot[source].to_numpy()
        ax.barh(
            np.arange(len(pivot)),
            values,
            left=left,
            color=COLORS.get(source, None),
            label=source.replace("_", " "),
            edgecolor="white",
            linewidth=0.5,
        )
        left += values

    ax.set_yticks(np.arange(len(pivot)))
    ax.set_yticklabels(wrap_labels(pivot.index.tolist(), width=30))
    ax.set_xlabel("Context records")
    ax.set_ylabel("")
    ax.legend(title="Source", bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False)
    ax.xaxis.set_major_formatter(lambda x, pos: f"{int(x):,}")
    add_header(
        fig,
        ax,
        "Context Taxonomy by Source Family",
        "The workload taxonomy now separates CPU compilation and GPU CNN-training context from event-log and derived operating-regime rows.",
    )
    savefig(fig, "01_context_taxonomy_by_source")


def figure_02_monthly_context_heatmap() -> None:
    df = query(
        """
        WITH c AS (
            SELECT
                date_trunc('month', to_timestamp(start) AT TIME ZONE 'Asia/Shanghai')::date AS month_local,
                CASE
                    WHEN value::jsonb->>'context_type' IN ('cpu_compilation_workload', 'gpu_cnn_training_workload') THEN 'workload records'
                    WHEN value::jsonb->>'source' = 'windows_event_log' THEN 'Windows events'
                    WHEN value::jsonb->>'source' = 'wsl_bash_history' THEN 'WSL shell activity'
                    WHEN value::jsonb->>'source' = 'derived_context_pipeline' THEN 'derived telemetry/solar'
                    WHEN value::jsonb->>'source' IN ('manual entry', 'manual_workload_entry') THEN 'manual context'
                    ELSE 'other'
                END AS family
            FROM public.context
        )
        SELECT month_local, family, count(*)::int AS rows
        FROM c
        GROUP BY 1, 2
        ORDER BY 1, 2;
        """
    )
    df = df[df["month_local"] >= pd.to_datetime("2025-06-01").date()].copy()
    pivot = df.pivot_table(index="family", columns="month_local", values="rows", fill_value=0)
    pivot = pivot.reindex(pivot.sum(axis=1).sort_values(ascending=False).index)
    pivot = pivot.reindex(sorted(pivot.columns), axis=1)
    labels = [pd.to_datetime(c).strftime("%b\n%Y") for c in pivot.columns]

    fig, ax = plt.subplots(figsize=(12.2, 4.7))
    cmap = LinearSegmentedColormap.from_list("opencem_blues", ["#F7FBFF", "#C6DBEF", "#6BAED6", "#2171B5", "#08306B"])
    sns.heatmap(
        np.log10(pivot + 1),
        cmap=cmap,
        linewidths=0.8,
        linecolor="white",
        cbar_kws={"label": "log10(records + 1)"},
        ax=ax,
    )
    ax.set_xticklabels(labels, rotation=0)
    ax.set_yticklabels([s.replace("_", " ") for s in pivot.index], rotation=0)
    ax.set_xlabel("")
    ax.set_ylabel("")
    add_header(
        fig,
        ax,
        "Monthly Context Density by Modality",
        "A compact calendar view of when each context modality is dense, sparse, or absent.",
    )
    savefig(fig, "02_monthly_context_density_heatmap")


def figure_03_context_duration_ridges() -> None:
    df = query(
        """
        WITH c AS (
            SELECT
                COALESCE(value::jsonb->>'context_type', 'unspecified') AS context_type,
                GREATEST("end" - start, 1) / 60.0 AS duration_minutes
            FROM public.context
            WHERE value::jsonb->>'source' IS DISTINCT FROM 'manual_workload_entry'
        ),
        ranked AS (
            SELECT context_type, count(*) AS rows
            FROM c
            GROUP BY 1
            ORDER BY rows DESC
            LIMIT 14
        )
        SELECT c.context_type, c.duration_minutes
        FROM c
        JOIN ranked USING (context_type);
        """
    )
    df["duration_minutes"] = df["duration_minutes"].clip(lower=0.02, upper=24 * 60)
    df["log_duration_minutes"] = np.log10(df["duration_minutes"])
    order = df.groupby("context_type")["duration_minutes"].median().sort_values().index.tolist()

    fig, ax = plt.subplots(figsize=(10.8, 7.1))
    sns.boxenplot(
        data=df,
        y="context_type",
        x="log_duration_minutes",
        order=order,
        color="#86BBD8",
        linewidth=0.8,
        ax=ax,
    )
    ax.set_yticks(np.arange(len(order)))
    ax.set_yticklabels(wrap_labels(order, width=30))
    ticks = np.array([0.1, 1, 5, 15, 60, 240, 720, 1440])
    ax.set_xticks(np.log10(ticks))
    ax.set_xticklabels(["6s", "1m", "5m", "15m", "1h", "4h", "12h", "24h"])
    ax.set_xlabel("Duration of context interval")
    ax.set_ylabel("")
    add_header(
        fig,
        ax,
        "Context Interval Durations",
        "Short workload/log records, hour-scale operating regimes, and day-scale solar/calendar context occupy distinct duration bands.",
    )
    savefig(fig, "03_context_duration_distribution")


def figure_04_daily_richness_calendar() -> None:
    df = query(
        """
        WITH daily AS (
            SELECT
                (to_timestamp(start) AT TIME ZONE 'Asia/Shanghai')::date AS day_local,
                count(*)::int AS context_rows,
                count(DISTINCT COALESCE(value::jsonb->>'context_type', 'unspecified'))::int AS context_types,
                count(*) FILTER (WHERE value::jsonb->>'context_type' IN ('cpu_compilation_workload', 'gpu_cnn_training_workload'))::int AS workload_rows,
                count(*) FILTER (WHERE value::jsonb->>'source' = 'windows_event_log')::int AS windows_rows,
                count(*) FILTER (WHERE value::jsonb->>'source' = 'derived_context_pipeline')::int AS derived_rows
            FROM public.context
            GROUP BY 1
        )
        SELECT *
        FROM daily
        WHERE day_local BETWEEN date '2025-07-12' AND date '2026-07-13'
        ORDER BY day_local;
        """
    )
    all_days = pd.date_range("2025-07-12", "2026-07-13", freq="D")
    df["day_local"] = pd.to_datetime(df["day_local"])
    df = df.set_index("day_local").reindex(all_days, fill_value=0).rename_axis("day_local").reset_index()
    df["month"] = df["day_local"].dt.strftime("%Y-%m")
    df["day"] = df["day_local"].dt.day
    pivot = df.pivot_table(index="month", columns="day", values="context_rows", fill_value=np.nan)
    pivot = pivot.reindex(sorted(pivot.index))

    font_size = 9.5
    fig = plt.figure(figsize=(7.3, 3.7), facecolor="white")
    ax = fig.add_axes((0.145, 0.17, 0.72, 0.79))
    cbar_ax = fig.add_axes((0.895, 0.17, 0.025, 0.79))
    cmap = LinearSegmentedColormap.from_list("opencem_gold", ["#F9FBFD", "#FEE8A8", "#FDB863", "#E08214", "#7F3B08"])
    sns.heatmap(
        np.log10(pivot + 1),
        cmap=cmap,
        linewidths=0.25,
        linecolor="#FFFFFF",
        cbar_ax=cbar_ax,
        cbar_kws={"label": "log10(context rows + 1)"},
        ax=ax,
    )
    shown_days = [day for day in range(1, 32, 2) if day in pivot.columns]
    ax.set_xticks([pivot.columns.get_loc(day) + 0.5 for day in shown_days])
    ax.set_xticklabels([str(day) for day in shown_days], rotation=0)
    shown_months = list(range(0, len(pivot.index), 2))
    ax.set_yticks([index + 0.5 for index in shown_months])
    ax.set_yticklabels([pivot.index[index] for index in shown_months], rotation=0)
    ax.set_xlabel("Day of month", fontsize=font_size, labelpad=5)
    ax.set_ylabel("Year-month", fontsize=font_size, labelpad=6)
    ax.tick_params(axis="both", labelsize=font_size)
    cbar_ax.tick_params(labelsize=font_size)
    cbar_ax.set_ylabel("log10(context rows + 1)", fontsize=font_size, labelpad=7)
    savefig(fig, "04_daily_context_richness_calendar", tight=False)


def interval_coverage_by_month(df: pd.DataFrame, order: list[str]) -> pd.DataFrame:
    """Split intervals at month boundaries and merge overlaps within each group."""
    if df.empty:
        return pd.DataFrame(columns=["month_local", "context_type", "inverter", "hours"])

    df = df.copy()
    df["start_local"] = pd.to_datetime(df["start_local"])
    df["end_local"] = pd.to_datetime(df["end_local"])
    pieces: list[dict[str, object]] = []

    for row in df.itertuples(index=False):
        start_local = row.start_local.to_pydatetime().replace(tzinfo=None)
        end_local = row.end_local.to_pydatetime().replace(tzinfo=None)
        month_start = pd.Timestamp(start_local).to_period("M").to_timestamp()
        final_month = pd.Timestamp(end_local).to_period("M").to_timestamp()
        while month_start <= final_month:
            next_month = month_start + pd.DateOffset(months=1)
            seg_start = max(start_local, month_start.to_pydatetime())
            seg_end = min(end_local, next_month.to_pydatetime())
            if seg_end > seg_start:
                pieces.append(
                    {
                        "month_local": month_start.date(),
                        "context_type": row.context_type,
                        "inverter": row.inverter,
                        "start_local": seg_start,
                        "end_local": seg_end,
                    }
                )
            month_start = next_month

    if not pieces:
        return pd.DataFrame(columns=["month_local", "context_type", "inverter", "hours"])

    split = pd.DataFrame(pieces)
    rows = []
    for keys, group in split.groupby(["month_local", "context_type", "inverter"], sort=True):
        intervals = sorted(zip(group["start_local"], group["end_local"]), key=lambda item: item[0])
        merged: list[list[datetime]] = []
        for start_local, end_local in intervals:
            if not merged or start_local > merged[-1][1]:
                merged.append([start_local, end_local])
            else:
                merged[-1][1] = max(merged[-1][1], end_local)
        hours = sum((end_local - start_local).total_seconds() / 3600 for start_local, end_local in merged)
        rows.append({"month_local": keys[0], "context_type": keys[1], "inverter": keys[2], "hours": hours})

    coverage = pd.DataFrame(rows)
    months = pd.period_range(
        pd.to_datetime(coverage["month_local"]).min(),
        pd.to_datetime(coverage["month_local"]).max(),
        freq="M",
    ).to_timestamp()
    inverters = sorted(coverage["inverter"].dropna().unique().tolist())
    full_index = pd.MultiIndex.from_product(
        [months.date, order, inverters],
        names=["month_local", "context_type", "inverter"],
    )
    coverage = (
        coverage.set_index(["month_local", "context_type", "inverter"])
        .reindex(full_index, fill_value=0)
        .reset_index()
    )
    return coverage


def figure_05_operating_regime_hours() -> None:
    intervals = query(
        """
        SELECT
            to_timestamp(start) AT TIME ZONE 'Asia/Shanghai' AS start_local,
            to_timestamp("end") AT TIME ZONE 'Asia/Shanghai' AS end_local,
            value::jsonb->>'context_type' AS context_type,
            COALESCE((value::jsonb->>'inverter')::int, 0) AS inverter
        FROM public.context
        WHERE value::jsonb->>'context_type' IN (
            'battery_charging', 'battery_discharging', 'pv_generation_active',
            'grid_unavailable_or_islanded', 'high_ac_load'
        )
          AND "end" > start
        ORDER BY start;
        """
    )
    order = ["pv_generation_active", "battery_charging", "battery_discharging", "grid_unavailable_or_islanded", "high_ac_load"]
    df = interval_coverage_by_month(intervals, order)
    df["month_label"] = pd.to_datetime(df["month_local"]).dt.strftime("%b\n%Y")
    palette = [COLORS[t] for t in order]

    g = sns.FacetGrid(
        df,
        row="inverter",
        height=2.8,
        aspect=4.3,
        sharey=False,
        margin_titles=True,
    )
    g.map_dataframe(
        sns.lineplot,
        x="month_label",
        y="hours",
        hue="context_type",
        hue_order=order,
        palette=palette,
        marker="o",
        linewidth=1.8,
    )
    g.set_axis_labels("", "Active hours")
    g.set_titles(row_template="Inverter {row_name}")
    for ax in g.axes.flatten():
        ax.tick_params(axis="x", labelrotation=0)
        ax.grid(True, axis="y")
    label_map = {item: item.replace("_", " ") for item in order}
    g.add_legend(title="Regime", label_order=order)
    for text in g.legend.texts:
        text.set_text(label_map.get(text.get_text(), text.get_text()))
    g.figure.suptitle("Derived Operating Regime Hours", x=0.06, y=1.02, ha="left", fontsize=15, weight="bold")
    g.figure.text(
        0.06,
        0.955,
        "Monthly active hours for SQL-derived battery, PV, grid, and high-load regimes.",
        fontsize=9,
        color="#4C566A",
    )
    g.figure.tight_layout()
    savefig(g.figure, "05_operating_regime_hours_by_month")


def figure_06_hourly_pv_load_heatmaps() -> None:
    df = query(
        """
        WITH h AS (
            SELECT
                date_trunc('hour', read_ts AT TIME ZONE 'Asia/Shanghai') AS hour_local,
                inverter,
                avg(COALESCE(pv1power,0) + COALESCE(pv2power,0) + COALESCE(pv3power,0))::float AS pv_w,
                avg(outsumw)::float AS load_w,
                count(*)::int AS samples
            FROM measurement.analog_measurement_fixed
            WHERE read_ts >= timestamptz '2025-11-24 00:00:00+08'
              AND read_ts <  timestamptz '2026-02-01 00:00:00+08'
            GROUP BY 1, 2
        )
        SELECT *
        FROM h
        ORDER BY hour_local, inverter;
        """
    )
    df["hour_local"] = pd.to_datetime(df["hour_local"])
    df["date"] = df["hour_local"].dt.normalize()
    df["hour"] = df["hour_local"].dt.hour
    inv = 2
    sub = df[df["inverter"] == inv].copy()
    pv = sub.pivot_table(index="date", columns="hour", values="pv_w", aggfunc="mean")
    load = sub.pivot_table(index="date", columns="hour", values="load_w", aggfunc="mean")
    days = pd.date_range("2025-11-24", "2026-01-31", freq="D")
    hours = pd.Index(range(24), name="hour")
    pv = pv.reindex(index=days, columns=hours).loc[:, 6:18]
    load = load.reindex(index=days, columns=hours)

    font_size = 9.5
    fig = plt.figure(figsize=(7.3, 4.75), facecolor="white")
    pv_ax = fig.add_axes((0.11, 0.12, 0.255, 0.84))
    pv_cbar_ax = fig.add_axes((0.385, 0.12, 0.024, 0.84))
    load_ax = fig.add_axes((0.535, 0.12, 0.35, 0.84))
    load_cbar_ax = fig.add_axes((0.905, 0.12, 0.024, 0.84))

    pv_plot = sns.heatmap(
        pv,
        cmap="YlOrBr",
        ax=pv_ax,
        vmin=0,
        vmax=float(np.nanmax(pv.to_numpy())),
        cbar_ax=pv_cbar_ax,
    )
    load_plot = sns.heatmap(
        load,
        cmap="mako_r",
        ax=load_ax,
        vmin=0,
        vmax=float(np.nanmax(load.to_numpy())),
        cbar_ax=load_cbar_ax,
    )

    def format_axis(ax: plt.Axes, columns: pd.Index, show_y: bool) -> None:
        tick_hours = [hour for hour in columns if hour % 2 == 0]
        positions = [columns.get_loc(hour) + 0.5 for hour in tick_hours]
        ax.set_xticks(positions)
        ax.set_xticklabels([str(hour) for hour in tick_hours], rotation=0)
        ax.set_xlabel("Hour of day", fontsize=font_size, labelpad=5)
        ax.tick_params(axis="x", labelsize=font_size, length=3, width=0.6, pad=3)

        weekly = np.arange(0, len(days), 7)
        ax.set_yticks(weekly + 0.5)
        if show_y:
            ax.set_yticklabels([days[index].strftime("%b %d") for index in weekly], rotation=0)
            ax.set_ylabel("Date", fontsize=font_size, labelpad=7)
            ax.tick_params(axis="y", labelsize=font_size, labelleft=True, length=0, pad=4)
        else:
            ax.set_yticklabels([])
            ax.set_ylabel("")
            ax.tick_params(axis="y", labelleft=False, length=0)

        for boundary in range(1, len(days)):
            weekly_boundary = boundary % 7 == 0
            ax.axhline(
                boundary,
                color="#BFC3C7" if weekly_boundary else "#D9DDE1",
                linewidth=0.55 if weekly_boundary else 0.28,
                zorder=4,
            )
        for spine in ax.spines.values():
            spine.set_visible(False)

    format_axis(pv_ax, pv.columns, True)
    format_axis(load_ax, load.columns, False)
    for colorbar, label in (
        (pv_plot.collections[0].colorbar, "PV power (W)"),
        (load_plot.collections[0].colorbar, "Load power (W)"),
    ):
        colorbar.ax.tick_params(labelsize=font_size, width=0.5, length=2.5)
        colorbar.set_label(label, fontsize=font_size, labelpad=5)

    savefig(fig, "06_hourly_pv_load_heatmaps_inverter2")


def select_representative_days() -> list[tuple[date, str]]:
    df = query(
        """
        WITH daily AS (
            SELECT
                (to_timestamp(start) AT TIME ZONE 'Asia/Shanghai')::date AS day_local,
                count(*) FILTER (
                    WHERE value::jsonb->>'context_type' IN (
                        'gpu_cnn_training_workload', 'cpu_compilation_workload'
                    )
                )::int AS workload_rows,
                count(*) FILTER (WHERE value::jsonb->>'source' = 'windows_event_log')::int AS windows_rows,
                count(*) FILTER (WHERE value::jsonb->>'source' = 'wsl_bash_history')::int AS wsl_rows,
                count(DISTINCT COALESCE(value::jsonb->>'context_type', 'unspecified'))::int AS context_types
            FROM public.context
            GROUP BY 1
        ), measured AS (
            SELECT DISTINCT (read_ts AT TIME ZONE 'Asia/Shanghai')::date AS day_local
            FROM measurement.analog_measurement_fixed
        )
        SELECT d.*
        FROM daily d
        JOIN measured USING (day_local)
        WHERE workload_rows > 0
          AND day_local BETWEEN date '2025-07-12' AND date '2026-06-09'
        ORDER BY day_local;
        """
    )
    df["day_local"] = pd.to_datetime(df["day_local"])

    selections: list[tuple[pd.Series, str]] = []
    selections.append(
        (
            df.sort_values(["workload_rows", "day_local"], ascending=[False, True]).iloc[0],
            "peak workload context",
        )
    )

    with_wsl = df[df["wsl_rows"] > 0]
    if not with_wsl.empty:
        selections.append(
            (
                with_wsl.sort_values(
                    ["wsl_rows", "context_types", "day_local"], ascending=[False, False, True]
                ).iloc[0],
                "WSL-enriched context",
            )
        )

    selections.append(
        (
            df.sort_values(
                ["context_types", "workload_rows", "day_local"], ascending=[False, False, True]
            ).iloc[0],
            "greatest context-type diversity",
        )
    )

    december = df[df["day_local"].dt.to_period("M") == pd.Period("2025-12", freq="M")]
    if not december.empty:
        selections.append(
            (
                december.sort_values(
                    ["windows_rows", "context_types", "day_local"], ascending=[False, False, True]
                ).iloc[0],
                "Windows-event-rich December day",
            )
        )

    unique: list[tuple[date, str]] = []
    seen: set[date] = set()
    for row, reason in selections:
        selected_day = row["day_local"].date()
        if selected_day not in seen:
            unique.append((selected_day, reason))
            seen.add(selected_day)
    return unique


def render_multimodal_day(day: date, reason: str, *, canonical: bool = False) -> None:
    next_day = day + timedelta(days=1)
    data = query(
        """
        SELECT
            date_trunc('minute', read_ts AT TIME ZONE 'Asia/Shanghai') AS minute_local,
            inverter,
            avg(outsumw)::float AS load_w,
            avg(COALESCE(pv1power,0) + COALESCE(pv2power,0) + COALESCE(pv3power,0))::float AS pv_w,
            avg(battsoc)::float AS soc,
            avg(battcurr)::float AS batt_current_a
        FROM measurement.analog_measurement_fixed
        WHERE read_ts >= %(start)s::timestamptz
          AND read_ts < %(end)s::timestamptz
        GROUP BY 1, 2
        ORDER BY 1, 2;
        """,
        {"start": f"{day.isoformat()} 00:00:00+08", "end": f"{next_day.isoformat()} 00:00:00+08"},
    )
    ctx = query(
        """
        SELECT
            id,
            to_timestamp(start) AT TIME ZONE 'Asia/Shanghai' AS start_local,
            to_timestamp("end") AT TIME ZONE 'Asia/Shanghai' AS end_local,
            COALESCE(value::jsonb->>'context_type', 'unspecified') AS context_type,
            COALESCE(value::jsonb->>'source', 'unspecified') AS source
        FROM public.context
        WHERE "end" >= extract(epoch FROM %(start)s::timestamptz)::bigint
          AND start < extract(epoch FROM %(end)s::timestamptz)::bigint
          AND COALESCE(value::jsonb->>'context_type', 'unspecified') IN (
              'cpu_compilation_workload', 'gpu_cnn_training_workload',
              'battery_charging', 'battery_discharging', 'pv_generation_active',
              'grid_unavailable_or_islanded', 'high_ac_load',
              'windows_update_activity', 'windows_update_maintenance_window',
              'unexpected_shutdown', 'scheduled_reboot_or_shutdown',
              'virtualized_disk_io_summary', 'build_or_test_activity',
              'compiler_invocation_burst', 'repository_activity',
              'interactive_development_window', 'package_or_environment_setup'
          )
        ORDER BY start, context_type
        LIMIT 500;
        """,
        {"start": f"{day.isoformat()} 00:00:00+08", "end": f"{next_day.isoformat()} 00:00:00+08"},
    )
    data["minute_local"] = pd.to_datetime(data["minute_local"])
    ctx["start_local"] = pd.to_datetime(ctx["start_local"])
    ctx["end_local"] = pd.to_datetime(ctx["end_local"])

    day_start = pd.Timestamp(day)
    day_end = pd.Timestamp(next_day)
    ctx["plot_start"] = ctx["start_local"].clip(lower=day_start)
    ctx["plot_end"] = ctx["end_local"].clip(upper=day_end)
    ctx = ctx[ctx["plot_end"] > ctx["plot_start"]].copy()

    interesting = [
        "cpu_compilation_workload",
        "gpu_cnn_training_workload",
        "battery_charging",
        "battery_discharging",
        "pv_generation_active",
        "grid_unavailable_or_islanded",
        "high_ac_load",
        "virtualized_disk_io_summary",
        "windows_update_activity",
        "windows_update_maintenance_window",
        "unexpected_shutdown",
        "scheduled_reboot_or_shutdown",
        "build_or_test_activity",
        "compiler_invocation_burst",
        "repository_activity",
        "interactive_development_window",
        "package_or_environment_setup",
    ]
    observed_types = set(ctx["context_type"])
    active_types = [name for name in interesting if name in observed_types][:12]
    context_height = max(1.6, 0.36 * max(len(active_types), 1) + 0.4)
    fig, axes = plt.subplots(
        4,
        1,
        figsize=(7.3, 6.2),
        sharex=True,
        gridspec_kw={"height_ratios": [1.15, 1.0, 1.15, context_height]},
    )
    ax_pv, ax_soc, ax_load, ax_context = axes

    inverter_colors = {1: "#2878B5", 2: "#E67E22"}
    legend_handles = []
    for inv, sub in data.groupby("inverter"):
        color = inverter_colors[int(inv)]
        pv_line, = ax_pv.plot(sub["minute_local"], sub["pv_w"], color=color, linewidth=1.25)
        ax_soc.plot(sub["minute_local"], sub["soc"], color=color, linewidth=1.15)
        ax_load.plot(sub["minute_local"], sub["load_w"], color=color, linewidth=1.25)
        legend_handles.append(pv_line)
    font_size = 9.5
    ax_pv.set_ylabel("PV (W)", fontsize=font_size)
    ax_soc.set_ylabel("SOC (%)", fontsize=font_size)
    ax_load.set_ylabel("Load (W)", fontsize=font_size)
    legend_labels = [f"Inverter {int(inv)}" for inv in sorted(data["inverter"].unique())]
    for ax, headroom_ratio in ((ax_pv, 0.20), (ax_soc, 0.38), (ax_load, 0.20)):
        lower, upper = ax.get_ylim()
        headroom = max((upper - lower) * headroom_ratio, 1.0)
        ax.set_ylim(lower, upper + headroom)
        ax.legend(
            legend_handles,
            legend_labels,
            ncols=2,
            frameon=False,
            loc="upper right",
            fontsize=font_size,
            handlelength=1.7,
            columnspacing=1.0,
            borderaxespad=0.25,
        )

    lane_y = {name: i for i, name in enumerate(active_types)}
    for _, row in ctx.iterrows():
        ctype = row["context_type"]
        if ctype not in lane_y:
            continue
        start = row["plot_start"]
        end = row["plot_end"]
        ax_context.add_patch(
            Rectangle(
                (mdates.date2num(start), lane_y[ctype] - 0.35),
                max(mdates.date2num(end) - mdates.date2num(start), 1 / (24 * 60 * 5)),
                0.7,
                facecolor=COLORS.get(ctype, COLORS.get(row["source"], "#8DA0CB")),
                alpha=0.75,
                edgecolor="none",
            )
        )
    if active_types:
        context_labels = {
            "cpu_compilation_workload": "CPU compilation workload",
            "gpu_cnn_training_workload": "GPU CNN training workload",
            "battery_charging": "Battery charging",
            "battery_discharging": "Battery discharging",
            "pv_generation_active": "PV generation active",
            "grid_unavailable_or_islanded": "Grid unavailable or islanded",
            "high_ac_load": "High AC load",
            "virtualized_disk_io_summary": "Virtualized disk I/O summary",
            "windows_update_activity": "Windows Update activity",
            "windows_update_maintenance_window": "Windows Update maintenance window",
            "unexpected_shutdown": "Unexpected shutdown",
            "scheduled_reboot_or_shutdown": "Scheduled reboot or shutdown",
            "build_or_test_activity": "Build or test activity",
            "compiler_invocation_burst": "Compiler invocation burst",
            "repository_activity": "Repository activity",
            "interactive_development_window": "Interactive development window",
            "package_or_environment_setup": "Package or environment setup",
        }
        ax_context.set_yticks(range(len(active_types)))
        ax_context.set_yticklabels(
            ["\n".join(textwrap.wrap(context_labels.get(name, name.replace("_", " ").capitalize()), width=18)) for name in active_types],
            fontsize=font_size,
        )
        ax_context.set_ylim(-0.6, len(active_types) - 0.4)
    else:
        ax_context.set_yticks([])
        ax_context.set_ylim(-0.5, 0.5)
        ax_context.text(day_start + pd.Timedelta(hours=12), 0, "No selected context records", ha="center", va="center", color="#6B7280")
    ax_context.set_ylabel("")
    ax_context.xaxis_date()
    tick_hours = range(0, 24, 3)
    ax_context.set_xticks([day_start + pd.Timedelta(hours=hour) for hour in tick_hours])
    ax_context.set_xticklabels([f"{hour:02d}:00" for hour in tick_hours])
    ax_context.set_xlim(day_start, day_end)
    for ax in axes:
        ax.grid(True, axis="y", color="#E1E4E8", linewidth=0.55)
        ax.tick_params(axis="both", labelsize=font_size)
        ax.margins(x=0)
    fig.subplots_adjust(left=0.19, right=0.985, bottom=0.09, top=0.985, hspace=0.16)
    aliases = ("07_multimodal_representative_day",) if canonical else ()
    savefig(
        fig,
        f"07_multimodal_representative_day_{day.isoformat()}",
        aliases=aliases,
        tight=False,
    )


def figure_07_multimodal_days() -> list[tuple[date, str]]:
    selections = select_representative_days()
    for day, reason in selections:
        render_multimodal_day(
            day,
            reason,
            canonical=day == MANUSCRIPT_MULTIMODAL_DAY,
        )
    return selections


def figure_08_data_gaps() -> None:
    df = query(
        """
        SELECT
            (to_timestamp(start) AT TIME ZONE 'Asia/Shanghai')::date AS day_local,
            (value::jsonb->>'inverter')::int AS inverter,
            (value::jsonb->>'gap_seconds')::float / 60.0 AS gap_minutes
        FROM public.context
        WHERE value::jsonb->>'context_type' = 'data_gap'
        ORDER BY start;
        """
    )
    df["day_local"] = pd.to_datetime(df["day_local"])
    df["month"] = df["day_local"].dt.to_period("M").astype(str)
    monthly = df.groupby(["month", "inverter"], as_index=False).agg(gaps=("gap_minutes", "size"), total_gap_h=("gap_minutes", lambda s: s.sum() / 60.0))

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), gridspec_kw={"width_ratios": [1.3, 1]})
    sns.barplot(data=monthly, x="month", y="total_gap_h", hue="inverter", palette="Set2", ax=axes[0])
    axes[0].tick_params(axis="x", rotation=45)
    axes[0].set_xlabel("")
    axes[0].set_ylabel("Total data-gap hours")
    axes[0].set_title("Monthly Data-Gap Burden", loc="left", fontsize=13, weight="bold")
    sns.stripplot(data=df, x="inverter", y="gap_minutes", hue="inverter", palette="Set2", ax=axes[1], jitter=0.22, alpha=0.7, size=4, legend=False)
    axes[1].set_yscale("log")
    axes[1].set_xlabel("Inverter")
    axes[1].set_ylabel("Gap duration (minutes, log scale)")
    axes[1].set_title("Individual Gap Durations", loc="left", fontsize=13, weight="bold")
    fig.suptitle("Data Availability: Analog Measurement Gaps", x=0.05, y=1.03, ha="left", fontsize=15, weight="bold")
    fig.text(0.05, 0.985, "Derived rows mark analog-measurement gaps longer than 10 minutes.", fontsize=9, color="#4C566A")
    fig.tight_layout()
    savefig(fig, "08_data_gap_diagnostics")


def figure_09_schema_register_map() -> None:
    df = query(
        """
        SELECT
            table_name,
            count(*) FILTER (WHERE column_name NOT IN ('read_ts','inverter'))::int AS non_key_columns
        FROM information_schema.columns
        WHERE table_schema='measurement'
          AND table_name IN ('analog_measurement_fixed','status','totals','settings','specs','statistics','fault_history')
        GROUP BY table_name
        ORDER BY non_key_columns DESC;
        """
    )
    rows = query(
        """
        SELECT 'analog_measurement_fixed' AS table_name, count(*)::bigint AS rows FROM measurement.analog_measurement_fixed
        UNION ALL SELECT 'status', count(*) FROM measurement.status
        UNION ALL SELECT 'totals', count(*) FROM measurement.totals
        UNION ALL SELECT 'settings', count(*) FROM measurement.settings
        UNION ALL SELECT 'specs', count(*) FROM measurement.specs
        UNION ALL SELECT 'statistics', count(*) FROM measurement.statistics
        UNION ALL SELECT 'fault_history', count(*) FROM measurement.fault_history;
        """
    )
    df = df.merge(rows, on="table_name")
    family = {
        "analog_measurement_fixed": "instantaneous analog",
        "settings": "configuration",
        "statistics": "energy statistics",
        "totals": "system totals",
        "status": "state/status",
        "fault_history": "fault records",
        "specs": "device metadata",
    }
    df["family"] = df["table_name"].map(family)
    df = df.sort_values("non_key_columns", ascending=True)

    fig, ax1 = plt.subplots(figsize=(10.5, 5.8))
    sns.barplot(data=df, y="family", x="non_key_columns", color="#4C78A8", ax=ax1)
    ax1.set_xlabel("Non-key columns")
    ax1.set_ylabel("")
    ax1.set_title("Inverter Register Breadth by Table", loc="left", fontsize=15, weight="bold")
    ax2 = ax1.twiny()
    ax2.scatter(df["rows"] / 1_000_000, np.arange(len(df)), color="#E45756", s=58, zorder=4)
    ax2.set_xlabel("Rows (millions)")
    ax2.grid(False)
    for _, row in df.iterrows():
        y = df.index.get_loc(row.name)
        ax1.text(row["non_key_columns"] + 2, y, f"{row['non_key_columns']} cols", va="center", fontsize=8, color="#2E3440")
    fig.text(0.12, 0.92, "A compact visual argument for register depth: many columns are not simple aggregate meter readings.", fontsize=9, color="#4C566A")
    fig.tight_layout()
    savefig(fig, "09_register_breadth_and_rows")


def figure_10_context_record_examples() -> None:
    df = query(
        """
        WITH selectors(ord, source, context_type, description) AS (
            VALUES
                (1, 'workstation1_log', 'cpu_compilation_workload', NULL),
                (2, 'workstation2_log', 'gpu_cnn_training_workload', NULL),
                (3, 'windows_event_log', 'unexpected_shutdown', NULL),
                (4, 'wsl_bash_history', 'build_or_test_activity', NULL),
                (5, 'manual entry', NULL, 'Chinese New Year Holiday'),
                (6, 'derived_context_pipeline', 'data_gap', NULL)
        )
        SELECT
            s.ord,
            s.source,
            COALESCE(c.value::jsonb->>'context_type', 'manual_calendar_record') AS context_type,
            COALESCE(c.value::jsonb->>'device', 'calendar') AS device,
            to_timestamp(c.recorded) AT TIME ZONE 'Asia/Shanghai' AS recorded_local,
            to_timestamp(c.start) AT TIME ZONE 'Asia/Shanghai' AS start_local,
            to_timestamp(c."end") AT TIME ZONE 'Asia/Shanghai' AS end_local,
            c.value::jsonb->>'summary' AS summary,
            c.value::jsonb->>'textual_description' AS textual_description,
            c.value::jsonb->>'task_type' AS task_type,
            c.value::jsonb->>'library' AS library,
            c.value::jsonb->>'cpu_cores_active' AS cpu_cores_active,
            c.value::jsonb->>'task_files' AS task_files,
            c.value::jsonb->>'model' AS model,
            c.value::jsonb->>'dataset' AS dataset,
            c.value::jsonb->>'epochs' AS epochs,
            c.value::jsonb->>'batch_size' AS batch_size,
            c.value::jsonb#>>'{windows_event,event_id}' AS event_id,
            c.value::jsonb#>>'{windows_event,level}' AS event_level,
            c.value::jsonb->>'gap_seconds' AS gap_seconds,
            c.value::jsonb->>'threshold_seconds' AS threshold_seconds,
            c.value::jsonb->'command_families' AS command_families
        FROM selectors s
        CROSS JOIN LATERAL (
            SELECT recorded, start, "end", value
            FROM public.context
            WHERE value::jsonb->>'source' = s.source
              AND (s.context_type IS NULL OR value::jsonb->>'context_type' = s.context_type)
              AND (s.description IS NULL OR value::jsonb->>'textual_description' = s.description)
            ORDER BY length(value::text), start
            LIMIT 1
        ) c
        ORDER BY s.ord;
        """
    )

    source_labels = {
        "workstation1_log": "Direct workload log\n(workstation 1)",
        "workstation2_log": "Direct workload log\n(workstation 2)",
        "windows_event_log": "Windows Event Log",
        "wsl_bash_history": "Instrumented WSL\nhistory",
        "manual entry": "Calendar/manual\nentry",
        "derived_context_pipeline": "Telemetry-derived\ncontext",
    }

    context_type_labels = {
        "cpu_compilation_workload": "CPU compilation\nworkload",
        "gpu_cnn_training_workload": "GPU CNN\ntraining workload",
        "unexpected_shutdown": "Unexpected\nshutdown",
        "build_or_test_activity": "Build or test\nactivity",
        "manual_calendar_record": "Manual calendar\nrecord",
        "data_gap": "Data gap",
    }

    def timestamp(value: object) -> str:
        return pd.Timestamp(value).strftime("%Y-%m-%d %H:%M")

    def interval(row: pd.Series) -> str:
        start = pd.Timestamp(row["start_local"])
        end = pd.Timestamp(row["end_local"])
        if start.date() == end.date():
            return f"{start:%Y-%m-%d %H:%M} to {end:%H:%M}"
        return f"{start:%Y-%m-%d %H:%M} to\n{end:%Y-%m-%d %H:%M}"

    def payload(row: pd.Series) -> str:
        source = row["source"]
        if source == "workstation1_log":
            return f"task_type: {row['task_type']}\nlibrary: {row['library']}; cores: {row['cpu_cores_active']}; files: {row['task_files']}"
        if source == "workstation2_log":
            return f"task_type: {row['task_type']}\nmodel: {row['model']}; data: {row['dataset']}\nepochs: {row['epochs']}; batch: {row['batch_size']}"
        if source == "windows_event_log":
            return f"event_id: {row['event_id']}; level: {row['event_level']}\nPrevious system shutdown was unexpected."
        if source == "wsl_bash_history":
            families = row["command_families"] or {}
            family_text = ", ".join(str(key) for key in families) if isinstance(families, dict) else str(families)
            return f"Build/test activity; one shell command\ncommand family: {family_text}"
        if source == "manual entry":
            return f"textual_description: {row['textual_description']}\nEntered before applicability interval"
        gap_minutes = float(row["gap_seconds"]) / 60
        threshold_minutes = float(row["threshold_seconds"]) / 60
        return f"No analog records for more than 10 minutes\ngap: {gap_minutes:.1f} min; threshold: {threshold_minutes:.0f} min"

    def wrap_payload(value: str, width: int = 47) -> str:
        lines: list[str] = []
        for paragraph in value.splitlines():
            lines.extend(textwrap.wrap(paragraph, width=width, break_long_words=False) or [""])
        return "\n".join(lines[:3])

    fig = plt.figure(figsize=(12.0, 6.5), facecolor="white")
    ax = fig.add_axes((0, 0, 1, 1))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.add_patch(Rectangle((0, 0), 1, 1, facecolor="white", edgecolor="none", zorder=0))

    left, right = 0.025, 0.985
    col_source, col_time, col_type, col_payload = 0.045, 0.245, 0.49, 0.63
    header_y = 0.95
    for x, label in [
        (col_source, "Provenance"),
        (col_time, "Recorded / applicability interval"),
        (col_type, "Context type"),
        (col_payload, "Selected payload fields"),
    ]:
        fig.text(x, header_y, label, fontsize=10.3, weight="bold", color="#374151")
    ax.plot([left, right], [0.922, 0.922], color="#9CA3AF", linewidth=1.0)

    row_top = 0.915
    row_height = 0.145
    for index, (_, row) in enumerate(df.iterrows()):
        top = row_top - index * row_height
        bottom = top - row_height + 0.006
        mid = (top + bottom) / 2
        background = "#F7F9FC" if index % 2 == 0 else "#FFFFFF"
        ax.add_patch(Rectangle((left, bottom), right - left, top - bottom, facecolor=background, edgecolor="none"))
        source_color = COLORS.get(row["source"], "#6B7280")
        ax.add_patch(Rectangle((left, bottom), 0.009, top - bottom, facecolor=source_color, edgecolor="none"))

        fig.text(col_source, mid, source_labels[row["source"]], fontsize=12.0, weight="bold", color="#1F2937", va="center")
        timing = (
            f"recorded {timestamp(row['recorded_local'])}\n"
            f"start    {timestamp(row['start_local'])}\n"
            f"end      {timestamp(row['end_local'])}"
        )
        fig.text(col_time, mid, timing, fontsize=10.3, family="monospace", color="#374151", va="center", linespacing=1.25)
        context_type = str(row["context_type"])
        fig.text(col_type, mid, context_type_labels.get(context_type, context_type.replace("_", " ").capitalize()), fontsize=10.8, weight="bold", color=source_color, va="center")
        fig.text(col_payload, mid, wrap_payload(payload(row)), fontsize=10.3, family="monospace", color="#273142", va="center", linespacing=1.25)

        if index < len(df) - 1:
            ax.plot([left + 0.009, right], [bottom, bottom], color="#E5E7EB", linewidth=0.7)

    savefig(fig, "10_context_record_examples_wide")


def write_index(multimodal_days: list[tuple[date, str]]) -> None:
    captions = [
        ("01_context_taxonomy_by_source.png", "Context taxonomy by source family", "Stacked horizontal bars for the largest context types. Good for Data Records."),
        ("02_monthly_context_density_heatmap.png", "Monthly context density", "A compact modality-availability heatmap, useful for showing when context is dense."),
        ("03_context_duration_distribution.png", "Context interval durations", "Shows that workloads, event logs, operating regimes, and solar/calendar intervals occupy different time scales."),
        ("04_daily_context_richness_calendar.png", "Daily context richness calendar", "InstructMPC-inspired dense calendar; good candidate for a flagship context-coverage figure."),
        ("05_operating_regime_hours_by_month.png", "Derived operating-regime hours", "Monthly derived battery/PV/grid/load regime coverage by inverter."),
        ("06_hourly_pv_load_heatmaps_inverter2.png", "PV/load hourly heatmaps", "Dense diurnal structure for inverter 2 over the central dense recording period."),
        ("07_multimodal_representative_day.png", "Multimodal representative day", "Aligned line plots and context ribbons for the selected 18 December 2025 manuscript example."),
        ("08_data_gap_diagnostics.png", "Data-gap diagnostics", "Technical-validation candidate: monthly gap burden plus individual gap durations."),
        ("09_register_breadth_and_rows.png", "Register breadth and row counts", "Compact schema/richness figure for the inverter-register novelty claim."),
        ("10_context_record_examples_wide.png", "Representative context records", "Wide, source-diverse replacement for the old narrow event timeline."),
    ]
    for day, reason in multimodal_days:
        captions.append(
            (
                f"07_multimodal_representative_day_{day.isoformat()}.png",
                f"Multimodal candidate: {day.isoformat()}",
                f"Alternative representative day selected for {reason}.",
            )
        )
    md = OUT / "gallery_index.md"
    lines = [
        "# OpenCEM Visualization Gallery",
        "",
        "Candidate Seaborn/Matplotlib figures generated from PostgreSQL aggregates. Each PNG also has a matching PDF in this folder.",
        "",
    ]
    for filename, title, caption in captions:
        lines.extend([f"## {title}", "", f"![{title}]({filename})", "", caption, ""])
    md.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    setup_theme()
    figure_01_context_taxonomy()
    figure_02_monthly_context_heatmap()
    figure_03_context_duration_ridges()
    figure_04_daily_richness_calendar()
    figure_05_operating_regime_hours()
    figure_06_hourly_pv_load_heatmaps()
    multimodal_days = figure_07_multimodal_days()
    figure_08_data_gaps()
    figure_09_schema_register_map()
    figure_10_context_record_examples()
    write_index(multimodal_days)
    print(f"Wrote gallery to {OUT}")


if __name__ == "__main__":
    main()
