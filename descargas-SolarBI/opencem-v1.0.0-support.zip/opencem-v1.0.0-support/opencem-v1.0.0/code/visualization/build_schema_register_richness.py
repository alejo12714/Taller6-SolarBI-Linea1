#!/usr/bin/env python3
"""Build the schema/register-richness figure for the OpenCEM descriptor."""

from __future__ import annotations

from collections import Counter, defaultdict, OrderedDict
from pathlib import Path
import sqlite3

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


MANUSCRIPT = Path(__file__).resolve().parents[1]
ROOT = MANUSCRIPT.parent
DEFAULT_DATABASE = ROOT / "opencem_dataset_current.sqlite"
DEFAULT_OUTPUT = MANUSCRIPT / "images" / "11_schema_register_richness"
TABLES = (
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
    "context",
)
KEY_COLUMNS = {"read_ts", "inverter", "id"}

FAMILIES = OrderedDict(
    [
        ("Battery/BMS", "#357ABD"),
        ("PV/generation", "#F2B134"),
        ("AC load/output", "#5AA469"),
        ("Grid/line", "#9B5DE5"),
        ("State/thermal", "#00A6A6"),
        ("Settings/control", "#F26457"),
        ("Energy/statistics", "#7A9E7E"),
        ("Specs/identity", "#8D6E63"),
        ("Fault/alarm", "#C44536"),
        ("Context", "#4B5563"),
        ("Reserved/arrays", "#9CA3AF"),
        ("Other", "#D1D5DB"),
    ]
)


def classify_family(table: str, column: str) -> str:
    name = column.lower()
    if table == "context":
        return "Context"
    if table == "specs":
        return "Specs/identity"
    if table == "fault_history" or "fault" in name or "alarm" in name:
        return "Fault/alarm"
    if table == "settings":
        return "Settings/control"
    if table == "statistics":
        return "Energy/statistics"
    if "reserve" in name or "flag" in name or name.endswith("back"):
        return "Reserved/arrays"
    if any(token in name for token in ("batt", "bat", "bms", "soc")):
        return "Battery/BMS"
    if any(token in name for token in ("pv", "generated")):
        return "PV/generation"
    if any(token in name for token in ("load", "out", "backup", "normal")):
        return "AC load/output"
    if any(token in name for token in ("grid", "line", "ct")):
        return "Grid/line"
    if any(
        token in name
        for token in (
            "temp",
            "fan",
            "bus",
            "sir",
            "state",
            "status",
            "mode",
            "contact",
            "der",
            "eco",
            "startup",
            "chgstatus",
        )
    ):
        return "State/thermal"
    return "Other"


def classify_storage_type(table: str, column: str, sqlite_type: str) -> str:
    name = column.lower()
    if table == "context":
        return "JSON context"
    if sqlite_type.upper() in {"INTEGER", "REAL"}:
        return "Scalar numeric/state"
    if any(
        token in name
        for token in (
            "reserve",
            "flag",
            "alarm",
            "history",
            "last7day",
            "time",
            "sn",
            "name",
            "libver",
            "prd",
        )
    ):
        return "Register array/string"
    return "Text/metadata"


def fetch_schema(database: Path) -> tuple[list[dict], dict[str, int]]:
    connection = sqlite3.connect(database)
    try:
        columns: list[dict] = []
        rows_by_table: dict[str, int] = {}
        for table in TABLES:
            rows_by_table[table] = connection.execute(
                f'SELECT count(*) FROM "{table}"'
            ).fetchone()[0]
            for _, name, sqlite_type, *_ in connection.execute(
                f'PRAGMA table_info("{table}")'
            ):
                if name in KEY_COLUMNS:
                    continue
                columns.append(
                    {
                        "table": table,
                        "column": name,
                        "sqlite_type": sqlite_type or "TEXT",
                        "family": classify_family(table, name),
                        "storage_type": classify_storage_type(
                            table, name, sqlite_type or "TEXT"
                        ),
                    }
                )
        return columns, rows_by_table
    finally:
        connection.close()


def build_figure(database: Path, output_stem: Path) -> None:
    columns, rows_by_table = fetch_schema(database)
    table_family_counts: dict[str, Counter] = defaultdict(Counter)
    storage_counts: Counter = Counter()
    data_columns_by_table: Counter = Counter()
    for item in columns:
        table_family_counts[item["table"]][item["family"]] += 1
        storage_counts[item["storage_type"]] += 1
        data_columns_by_table[item["table"]] += 1

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.edgecolor": "#C9D1D9",
            "grid.color": "#E6EAF0",
        }
    )
    fig = plt.figure(figsize=(13.5, 7.6), constrained_layout=False)
    fig.subplots_adjust(
        left=0.12,
        right=0.96,
        top=0.88,
        bottom=0.22,
        wspace=0.22,
        hspace=0.42,
    )
    grid = fig.add_gridspec(2, 2, width_ratios=(1.65, 1), height_ratios=(1, 1))
    ax_matrix = fig.add_subplot(grid[:, 0])
    ax_storage = fig.add_subplot(grid[0, 1])
    ax_footprint = fig.add_subplot(grid[1, 1])

    y = np.arange(len(TABLES))
    left = np.zeros(len(TABLES))
    for family, color in FAMILIES.items():
        values = np.array([table_family_counts[table][family] for table in TABLES])
        if not values.any():
            continue
        ax_matrix.barh(y, values, left=left, color=color, label=family, height=0.72)
        left += values
    ax_matrix.set_yticks(y, [table.replace("_", "\n") for table in TABLES])
    ax_matrix.invert_yaxis()
    ax_matrix.set_xlabel("Non-key columns")
    ax_matrix.set_title("A  Register and context field families by table", loc="left", fontweight="bold")
    ax_matrix.grid(axis="x", alpha=0.7)
    handles, labels = ax_matrix.get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        ncol=6,
        frameon=False,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.045),
        fontsize=8,
        columnspacing=0.8,
        handlelength=1.6,
    )

    storage_labels = list(storage_counts)
    storage_values = np.array([storage_counts[label] for label in storage_labels])
    storage_colors = ["#2878B5", "#8E6C8A", "#4B5563", "#9CA3AF"][: len(storage_labels)]
    wedges, _ = ax_storage.pie(
        storage_values,
        colors=storage_colors,
        startangle=90,
        wedgeprops={"width": 0.36, "edgecolor": "white"},
    )
    ax_storage.set_title("B  Storage representation", loc="left", fontweight="bold")
    total = storage_values.sum()
    ax_storage.legend(
        wedges,
        [f"{label}: {value} ({value / total:.0%})" for label, value in zip(storage_labels, storage_values)],
        loc="center left",
        bbox_to_anchor=(0.92, 0.5),
        frameon=False,
        fontsize=8,
    )

    x = np.array([rows_by_table[table] for table in TABLES], dtype=float)
    c = np.array([data_columns_by_table[table] for table in TABLES], dtype=float)
    size = 35 + c * 2.6
    ax_footprint.scatter(x, c, s=size, color="#2878B5", alpha=0.75, edgecolor="white")
    label_offsets = {
        "analog_measurements": (5, 6),
        "status": (5, -7),
        "totals": (5, -15),
        "settings": (-48, 5),
        "specs": (5, -2),
        "statistics": (5, 15),
        "fault_history": (5, 25),
        "context": (5, 4),
    }
    for table, rows, cols in zip(TABLES, x, c):
        ax_footprint.annotate(
            table.replace("_", " "),
            (rows, cols),
            textcoords="offset points",
            xytext=label_offsets.get(table, (5, 4)),
            fontsize=7,
        )
    ax_footprint.set_xscale("log")
    ax_footprint.set_xlabel("Rows per table (log scale)")
    ax_footprint.set_ylabel("Non-key columns")
    ax_footprint.set_title("C  Table footprint", loc="left", fontweight="bold")
    ax_footprint.grid(True, alpha=0.75)
    ax_footprint.margins(x=0.18, y=0.22)

    fig.suptitle(
        "OpenCEM schema and register richness",
        x=0.01,
        ha="left",
        fontsize=15,
        fontweight="bold",
    )
    output_stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(output_stem.with_suffix(".png"), dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    build_figure(DEFAULT_DATABASE, DEFAULT_OUTPUT)
    print(f"Wrote {DEFAULT_OUTPUT.with_suffix('.pdf')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
