#!/usr/bin/env python3
"""Extract privacy-conscious context candidates from WSL bash histories."""

from __future__ import annotations

import argparse
import csv
import json
import re
import shlex
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES: dict[str, Path] = {}
OUT_CSV = ROOT / "bash_history_context_candidates.csv"
OUT_MD = ROOT / "bash_history_context_candidates_review.md"
SENSITIVE_TERMS: tuple[str, ...] = ()
TZ = timezone(timedelta(hours=8))

TRAILER_RE = re.compile(r"^(?P<cmd>.*?)\s+###\s+(?P<date>\d{8})\s+(?P<time>\d{2}:\d{2})\s+(?P<pwd>.+?)\s*$")


@dataclass
class CommandRecord:
    device: str
    source_file: str
    recorded: datetime
    command: str
    cwd: str | None
    line_no: int


@dataclass
class CandidateEvent:
    device: str
    source_file: str
    category: str
    recorded: datetime
    start: datetime
    end: datetime
    summary: str
    project: str | None
    command_family: str
    details: dict


@dataclass
class Window:
    device: str
    source_file: str
    category: str
    project: str | None
    start: datetime
    last: datetime
    recorded: datetime
    command_families: Counter = field(default_factory=Counter)
    summaries: Counter = field(default_factory=Counter)
    examples: list[str] = field(default_factory=list)
    details: dict = field(default_factory=dict)


def epoch(dt: datetime) -> int:
    return int(dt.timestamp())


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def clean_space(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())


def split_command_and_cwd(raw: str) -> tuple[str, str | None]:
    match = TRAILER_RE.match(raw)
    if not match:
        return raw.strip(), None
    return match.group("cmd").strip(), match.group("pwd").strip()


def sanitize_path(path: str | None) -> str | None:
    if not path:
        return None
    path = path.strip()
    path = re.sub(r"/home/[^/\s]+", "/home/<user>", path)
    path = re.sub(r"/mnt/c/Users/[^/\s]+", "/mnt/c/Users/<user>", path, flags=re.I)
    path = re.sub(r"/mnt/[a-z]/Users/[^/\s]+", "/mnt/<drive>/Users/<user>", path, flags=re.I)
    for term in SENSITIVE_TERMS:
        path = re.sub(re.escape(term), "<redacted>", path, flags=re.I)
    return path


def project_from_cwd(cwd: str | None) -> str | None:
    if not cwd:
        return None
    lower = cwd.lower()
    rules = [
        ("opencem", "OpenCEM dataset/code work"),
        ("/boost/", "C++ library build or test"),
        ("benchmark", "benchmark or profiling workload"),
        ("gpu", "GPU workload"),
        ("dataset", "dataset processing"),
        ("build", "software build"),
    ]
    for token, label in rules:
        if token in lower:
            return label
    if "/dev/" in lower:
        return "development workspace"
    return None


def command_words(command: str) -> list[str]:
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()


def base_command(command: str) -> str:
    words = command_words(command)
    if not words:
        return ""
    if words[0] in {"time", "sudo", "command"} and len(words) > 1:
        base = words[1]
    elif words[0] in {"(", "while", "for"}:
        return words[0]
    else:
        base = words[0]
    lower_base = base.lower()
    if "random_bitset_grids" in lower_base:
        return "random_bitset_grids"
    if re.search(r"(^|/)(a\.out|[^/\s]*\.out)$", lower_base):
        return "benchmark_executable"
    return base


def sanitize_command(command: str) -> str:
    command = clean_space(command)
    words = command_words(command)
    if words and words[0] == "git":
        action = words[1] if len(words) > 1 else ""
        if action == "clone":
            return "git clone <repository>"
        if action in {"fetch", "pull", "push"}:
            return f"git {action} <remote>"
        if action == "checkout":
            return "git checkout <branch>"
        if action == "remote":
            subcommand = words[2] if len(words) > 2 else "<subcommand>"
            return f"git remote {subcommand} <redacted>"
        if action in {"commit", "reset", "rebase"}:
            return f"git {action} <redacted>"
    command = re.sub(r"git@github\.com:[^\s]+", "<github_repo>", command)
    command = re.sub(r"https://github\.com/[^\s]+", "<github_url>", command)
    command = re.sub(r"[\w.+-]+@[\w.-]+", "<email>", command)
    command = re.sub(r"https?://[^\s]+", "<url>", command)
    command = re.sub(r"/home/[^/\s]+", "/home/<user>", command)
    command = re.sub(r"/mnt/c/Users/[^/\s]+", "/mnt/c/Users/<user>", command, flags=re.I)
    command = re.sub(r"--author=(?:\"[^\"]+\"|'[^']+'|[^\s]+)", "--author=<redacted>", command)
    command = re.sub(r"user\.email\s+(?:\"[^\"]+\"|'[^']+'|[^\s]+)", "user.email <redacted>", command)
    command = re.sub(r"user\.name\s+(?:\"[^\"]+\"|'[^']+'|[^\s]+)", "user.name <redacted>", command)
    for term in SENSITIVE_TERMS:
        command = re.sub(re.escape(term), "<redacted>", command, flags=re.I)
    return command[:360]


def parse_records() -> list[CommandRecord]:
    records: list[CommandRecord] = []
    for device, path in FILES.items():
        pending_ts: int | None = None
        for line_no, raw in enumerate(path.read_text(errors="replace").splitlines(), start=1):
            if raw.startswith("#") and raw[1:].isdigit():
                pending_ts = int(raw[1:])
                continue
            if pending_ts is None:
                continue
            command, cwd = split_command_and_cwd(raw)
            timestamp = pending_ts
            pending_ts = None
            if not command:
                continue
            records.append(
                CommandRecord(
                    device=device,
                    source_file=path.name,
                    recorded=datetime.fromtimestamp(timestamp, TZ),
                    command=clean_space(command),
                    cwd=sanitize_path(cwd),
                    line_no=line_no,
                )
            )
    records.sort(key=lambda r: (r.recorded, r.device, r.line_no))
    return dedupe_records(records)


def dedupe_records(records: list[CommandRecord]) -> list[CommandRecord]:
    deduped: list[CommandRecord] = []
    for rec in records:
        if deduped:
            prev = deduped[-1]
            same = prev.device == rec.device and prev.command == rec.command
            close = abs((rec.recorded - prev.recorded).total_seconds()) <= 120
            if same and close:
                if rec.cwd and not prev.cwd:
                    deduped[-1] = rec
                continue
        deduped.append(rec)
    return deduped


NOISE_BASES = {
    "cd", "ls", "ll", "dir", "pwd", "exit", "history", "clear", "cat", "less",
    "head", "tail", "grep", "awk", "wc", "cp", "mv", "rm", "mkdir", "chmod",
    "nvim", "vim", "nano", "lvim", "echo", "source", "bash", "sh", "dmesg",
    "df", "find",
}


def package_names(words: list[str], command: str) -> list[str]:
    packages: list[str] = []
    skip_next = False
    for word in words[1:]:
        if skip_next:
            skip_next = False
            continue
        if word in {"-i", "--index-url", "--extra-index-url", "-t", "-r"}:
            skip_next = True
            continue
        if word.startswith("-") or "://" in word:
            continue
        if word in {"install", "apt", "pip", "python", "python3"}:
            continue
        packages.append(word)
    if "torch" in command and "torch" not in packages:
        packages.append("torch")
    return packages[:12]


def classify_record(rec: CommandRecord) -> CandidateEvent | None:
    cmd = rec.command
    words = command_words(cmd)
    base = base_command(cmd)
    lower = cmd.lower()
    cwd_project = project_from_cwd(rec.cwd)
    sanitized = sanitize_command(cmd)

    if not words:
        return None
    if lower.startswith("git config") or " user.email " in lower or " user.name " in lower:
        return None

    details_base = {
        "source": "wsl_bash_history",
        "device": rec.device,
        "source_file": rec.source_file,
        "line_no": rec.line_no,
        "cwd_redacted": rec.cwd,
        "sanitized_command": sanitized,
    }

    def event(
        category: str,
        summary: str,
        minutes: int,
        family: str | None = None,
        project: str | None = cwd_project,
        sanitized_override: str | None = None,
        **details,
    ) -> CandidateEvent:
        local_details = dict(details_base)
        if sanitized_override is not None:
            local_details["sanitized_command"] = sanitized_override
        return CandidateEvent(
            rec.device,
            rec.source_file,
            category,
            rec.recorded,
            rec.recorded,
            rec.recorded + timedelta(minutes=minutes),
            summary,
            project,
            family or base,
            {**local_details, **details},
        )

    compiler_analysis_like = (
        base in {"objdump", "nm", "gdb", "readelf", "addr2line"}
        or (re.search(r"\.(?:s|asm)\b", lower) and re.search(r"\b(grep|awk|sed|wc|sort|uniq)\b", lower))
        or re.search(r"\b(vf?madd|vf?msub|vfnmadd|vfnmsub|fmadd|fmsub|fnmadd|fnmsub)\b", lower)
    )
    if compiler_analysis_like:
        return event(
            "compiler_analysis_activity",
            "Compiler-output, binary, or assembly-analysis command executed.",
            20,
            family=base,
            sanitized_override=f"{base} <redacted-analysis-command>",
            analysis_tool=base,
        )

    manual_termination_like = (
        base in {"pkill", "kill", "killall"}
        or re.search(r"\bscreen\s+-X\s+(?:quit|kill)\b", lower)
        or re.search(r"\btmux\s+kill", lower)
        or re.search(r"\bdocker\s+(?:stop|kill|compose\s+down)\b", lower)
    )
    if manual_termination_like:
        return event(
            "manual_workload_termination",
            "Manual termination or shutdown command for a process/session/container.",
            5,
            family=base,
            sanitized_override=f"{base} <redacted-target>",
        )

    database_activity_like = (
        base in {"psql", "pg_dump", "pg_restore", "sqlite3"}
        or re.search(r"\b(to_db|export\.py|import_.*\.py|dump|restore|sqlite|postgres|pgsql|psql)\b", lower)
        or (
            base in {"python", "python3"}
            and re.search(r"opencem|dataset|export|to_db|sqlite|postgres|pgsql", lower + " " + (rec.cwd or "").lower())
        )
    )
    if database_activity_like:
        return event(
            "database_export_or_conversion_activity",
            "Database export, conversion, import, or dataset-packaging command executed.",
            60,
            family=base,
            sanitized_override=sanitize_command(cmd),
            script_hint=re.sub(r".*/", "", words[1]) if len(words) > 1 and words[1].endswith(".py") else None,
        )

    transfer_or_archive_like = (
        base in {"scp", "rsync", "tar", "zip", "7z", "unzip", "gzip", "gunzip", "xz", "unxz", "wget", "curl"}
        or re.search(r"\b(?:tar|zip|7z|unzip|gzip|gunzip|rsync|scp)\b", lower)
    )
    if transfer_or_archive_like:
        return event(
            "data_transfer_or_archive_activity",
            "Data transfer, download, archive, or extraction command executed.",
            45,
            family=base,
            sanitized_override=f"{base} <redacted-transfer-or-archive-command>",
        )

    remote_shell_like = base in {"ssh", "ssh-keygen"} or re.search(r"\bssh\s+", lower)
    if remote_shell_like:
        return event(
            "remote_shell_or_key_setup_activity",
            "Remote shell access or SSH key setup command executed.",
            15,
            family=base,
            sanitized_override=f"{base} <redacted-remote-command>",
        )

    system_control_like = base in {"wsl", "systemctl", "service", "mount", "umount", "shutdown", "reboot"}
    if system_control_like:
        return event(
            "system_control_activity",
            "System, WSL, service, mount, or reboot control command executed.",
            15,
            family=base,
            sanitized_override=f"{base} <redacted-system-command>",
        )

    interactive_dev_like = base in {"nvim", "vim", "nano", "lvim", "vimdiff"} or (
        base == "git" and len(words) > 1 and words[1] in {"add", "status", "diff", "log", "show", "branch", "restore", "rm"}
    )
    if interactive_dev_like:
        family = f"git {words[1]}" if base == "git" and len(words) > 1 else base
        return event(
            "interactive_development_window",
            "Interactive editing, inspection, or local repository staging command executed.",
            30,
            family=family,
            sanitized_override=f"{family} <redacted-local-context>",
        )

    if base in NOISE_BASES:
        return None

    if re.search(r"\b(b2|cmake|make|ninja|ctest|pytest)\b", lower) or base in {"b2", "cmake", "make", "ninja", "ctest", "pytest", "./b2_runner.sh"}:
        return event(
            "build_or_test_activity",
            "Build or test command executed in WSL.",
            45,
            family=base,
            build_tool=base,
        )

    benchmark_like = (
        base in {"perf", "gprof", "gprofng", "valgrind", "vtune", "ClangBuildAnalyzer", "random_bitset_grids", "benchmark_executable"}
        or "random_bitset_grids" in lower
        or re.match(r"^(\./|~/).*(a\.out|gcc\.out|random_bitset|counting|benchmark)", lower)
    )
    if benchmark_like:
        return event(
            "benchmark_or_profiling_activity",
            "Benchmark, profiling, or robustness-test command executed.",
            60,
            family=base,
            benchmark_tool=base,
        )

    compiler_like = (
        base in {"g++", "gcc", "clang++", "clang", "g++-12", "g++-15", "clang++-15"}
        or re.search(r"(^|[;&|]\s*)(g\+\+|gcc|clang\+\+|clang)(?:-\d+)?\b", lower)
    )
    if compiler_like:
        flags = sorted(set(re.findall(r"-(?:O[0-3sz]|march=[^\s]+|mtune=[^\s]+|ffp-contract=[^\s]+|fno-[^\s]+|std=[^\s]+)", cmd)))
        return event(
            "compiler_invocation_burst",
            "C/C++ compiler invocation, likely CPU-intensive when repeated.",
            30,
            family=base,
            compiler=base,
            notable_flags=flags[:12],
        )

    if base in {"python", "python3"} or re.search(r"\b(\.venv|venv)\b", lower):
        category = "dataset_processing_or_python_activity" if re.search(r"opencem|dataset|export\.py|sqlite", lower + " " + (rec.cwd or "").lower()) else "python_environment_or_script_activity"
        return event(
            category,
            "Python, SQLite, or environment command executed.",
            30,
            family=base,
            script_hint=re.sub(r".*/", "", words[1]) if len(words) > 1 and words[1].endswith(".py") else None,
        )

    if base in {"pip", "conda"} or re.search(r"\bapt(?:-get)?\s+install\b", lower) or re.search(r"\bpip\s+install\b", lower):
        return event(
            "package_or_environment_setup",
            "Package installation or environment setup command executed.",
            30,
            family=base,
            packages=package_names(words, cmd),
        )

    if base == "git":
        action = words[1] if len(words) > 1 else ""
        if action in {"clone", "pull", "fetch", "checkout", "commit", "push", "rebase", "reset", "remote"}:
            return event(
                "repository_activity",
                f"Git repository activity: {action}.",
                10,
                family=f"git {action}".strip(),
                git_action=action,
            )
        return None

    if base in {"screen", "nohup", "timeout"} or "screen -r" in lower or "screen -s" in lower:
        return event(
            "background_or_long_running_session",
            "Background, screen, or timeout-controlled shell activity.",
            240 if "screen" in lower else 60,
            family=base,
        )

    if base in {"top", "free", "ps", "nvidia-smi", "lscpu"}:
        return event(
            "system_monitoring_activity",
            "System monitoring command executed.",
            5,
            family=base,
        )

    return None


MERGE_GAP = {
    "compiler_invocation_burst": timedelta(minutes=20),
    "benchmark_or_profiling_activity": timedelta(minutes=25),
    "build_or_test_activity": timedelta(minutes=20),
    "dataset_processing_or_python_activity": timedelta(minutes=20),
    "python_environment_or_script_activity": timedelta(minutes=15),
    "package_or_environment_setup": timedelta(minutes=20),
    "repository_activity": timedelta(minutes=15),
    "background_or_long_running_session": timedelta(minutes=20),
    "system_monitoring_activity": timedelta(minutes=10),
    "download_activity": timedelta(minutes=15),
    "data_transfer_or_archive_activity": timedelta(minutes=20),
    "database_export_or_conversion_activity": timedelta(minutes=30),
    "manual_workload_termination": timedelta(minutes=10),
    "compiler_analysis_activity": timedelta(minutes=15),
    "remote_shell_or_key_setup_activity": timedelta(minutes=10),
    "system_control_activity": timedelta(minutes=10),
    "interactive_development_window": timedelta(minutes=20),
}


def merge_events(events: list[CandidateEvent]) -> list[Window]:
    events.sort(key=lambda e: (e.device, e.category, e.project or "", e.start))
    windows: list[Window] = []
    for ev in events:
        gap = MERGE_GAP.get(ev.category, timedelta(minutes=15))
        if windows:
            cur = windows[-1]
            if cur.device == ev.device and cur.category == ev.category and cur.project == ev.project and ev.start <= cur.last + gap:
                cur.last = max(cur.last, ev.start)
                cur.command_families[ev.command_family] += 1
                cur.summaries[ev.summary] += 1
                if len(cur.examples) < 5:
                    cur.examples.append(ev.details.get("sanitized_command", ""))
                cur.details["event_count"] = cur.details.get("event_count", 1) + 1
                for key in ("notable_flags", "packages"):
                    if key in ev.details:
                        cur.details.setdefault(key, [])
                        for value in ev.details[key] or []:
                            if value and value not in cur.details[key] and len(cur.details[key]) < 20:
                                cur.details[key].append(value)
                continue
        windows.append(
            Window(
                device=ev.device,
                source_file=ev.source_file,
                category=ev.category,
                project=ev.project,
                start=ev.start,
                last=ev.start,
                recorded=ev.recorded,
                command_families=Counter({ev.command_family: 1}),
                summaries=Counter({ev.summary: 1}),
                examples=[ev.details.get("sanitized_command", "")],
                details={
                    "event_count": 1,
                    "cwd_redacted": ev.details.get("cwd_redacted"),
                    "source_file": ev.source_file,
                    "line_no_first": ev.details.get("line_no"),
                    **({"notable_flags": ev.details.get("notable_flags", [])} if "notable_flags" in ev.details else {}),
                    **({"packages": ev.details.get("packages", [])} if "packages" in ev.details else {}),
                },
            )
        )
    for win in windows:
        base_minutes = {
            "compiler_invocation_burst": 30,
            "benchmark_or_profiling_activity": 60,
            "build_or_test_activity": 45,
            "background_or_long_running_session": 240,
            "system_monitoring_activity": 5,
            "data_transfer_or_archive_activity": 45,
            "database_export_or_conversion_activity": 60,
            "manual_workload_termination": 5,
            "compiler_analysis_activity": 20,
            "remote_shell_or_key_setup_activity": 15,
            "system_control_activity": 15,
            "interactive_development_window": 30,
        }.get(win.category, 20)
        win.details["end"] = win.last + timedelta(minutes=base_minutes)
    windows.sort(key=lambda w: (w.start, w.device, w.category))
    return windows


def window_summary(win: Window) -> str:
    project = f" for {win.project}" if win.project else ""
    count = win.details.get("event_count", 1)
    category_label = win.category.replace("_", " ")
    return f"{category_label.capitalize()}{project}; {count} shell command(s) in this window."


def main() -> None:
    global FILES, OUT_CSV, OUT_MD, SENSITIVE_TERMS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workstation1", type=Path, required=True)
    parser.add_argument("--workstation2", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, default=OUT_CSV)
    parser.add_argument("--review-output", type=Path, default=OUT_MD)
    parser.add_argument(
        "--sensitive-terms-file",
        type=Path,
        help="Private newline-delimited terms to redact; terms are not copied to output.",
    )
    args = parser.parse_args()
    FILES = {"workstation1": args.workstation1, "workstation2": args.workstation2}
    OUT_CSV, OUT_MD = args.output_csv, args.review_output
    if args.sensitive_terms_file:
        SENSITIVE_TERMS = tuple(
            line.strip()
            for line in args.sensitive_terms_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    records = parse_records()
    events = [ev for rec in records if (ev := classify_record(rec))]
    windows = merge_events(events)
    coarse_privacy_categories = {
        "interactive_development_window",
        "remote_shell_or_key_setup_activity",
        "manual_workload_termination",
        "system_control_activity",
    }

    with OUT_CSV.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "device",
            "category",
            "recorded_unix",
            "start_unix",
            "end_unix",
            "recorded_local",
            "start_local",
            "end_local",
            "project",
            "summary",
            "value",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for win in windows:
            end = win.details["end"]
            value = {
                "source": "wsl_bash_history",
                "device": win.device,
                "inverter": 1,
                "context_type": win.category,
                "summary": window_summary(win),
                "project": win.project,
                "command_families": dict(win.command_families.most_common()),
                "example_commands_redacted": []
                if win.category in coarse_privacy_categories
                else [ex for ex in win.examples if ex],
                "metadata": {
                    k: v for k, v in win.details.items()
                    if k not in {"end"} and v not in (None, [], "")
                },
            }
            if win.category in coarse_privacy_categories:
                value["privacy_note"] = "Command examples omitted for this coarse context category."
            writer.writerow(
                {
                    "device": win.device,
                    "category": win.category,
                    "recorded_unix": epoch(win.recorded),
                    "start_unix": epoch(win.start),
                    "end_unix": epoch(end),
                    "recorded_local": iso(win.recorded),
                    "start_local": iso(win.start),
                    "end_local": iso(end),
                    "project": win.project or "",
                    "summary": window_summary(win),
                    "value": json.dumps(value, ensure_ascii=False, separators=(",", ":")),
                }
            )

    counts = Counter((w.device, w.category) for w in windows)
    with OUT_MD.open("w", encoding="utf-8") as f:
        f.write("# WSL Bash History Context Candidates\n\n")
        f.write("Generated from the two supplied workstation Bash-history files.\n\n")
        f.write("Commands before the first bash-history Unix timestamp marker were ignored. ")
        f.write("Later records may include `### YYYYMMDD HH:MM <pwd>` trailers; these are retained only as redacted working-directory metadata. ")
        f.write("Raw commands are reduced to activity windows and redacted examples; account names, emails, URLs, GitHub remotes, and user paths are removed.\n\n")
        f.write("## Timestamp Coverage\n\n")
        f.write("| Device | Source file | First timestamped command | Last timestamped command |\n|---|---|---:|---:|\n")
        for device, path in FILES.items():
            dev_records = [r for r in records if r.device == device]
            f.write(f"| {device} | `{path.name}` | {iso(dev_records[0].recorded)} | {iso(dev_records[-1].recorded)} |\n")
        f.write("\n## Category Counts\n\n")
        f.write("| Device | Category | Count |\n|---|---:|---:|\n")
        for (device, category), count in sorted(counts.items()):
            f.write(f"| {device} | {category} | {count} |\n")
        f.write("\n## Candidate Windows By Time\n\n")
        f.write("| Device | Category | Start local | End local | Project | Summary |\n|---|---|---:|---:|---|---|\n")
        for win in windows:
            f.write(f"| {win.device} | {win.category} | {iso(win.start)} | {iso(win.details['end'])} | {win.project or ''} | {window_summary(win)} |\n")
        f.write("\nFull review CSV: `bash_history_context_candidates.csv`.\n")

    print(f"timestamped records: {len(records)}")
    print(f"candidate command events before merging: {len(events)}")
    print(f"candidate windows: {len(windows)}")
    print(f"wrote {OUT_CSV}")
    print(f"wrote {OUT_MD}")


if __name__ == "__main__":
    main()
