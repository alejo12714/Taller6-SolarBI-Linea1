\set ON_ERROR_STOP on

CREATE TEMP TABLE tmp_derived_context (
    recorded bigint,
    start_ts bigint,
    end_ts bigint,
    value text
);

CREATE TEMP TABLE tmp_table_coverage AS
SELECT table_name, inverter, row_count, first_read_ts, last_read_ts
FROM (
    SELECT 'measurement.analog_measurement_fixed'::text AS table_name, inverter, count(*)::bigint AS row_count, min(read_ts) AS first_read_ts, max(read_ts) AS last_read_ts FROM measurement.analog_measurement_fixed GROUP BY inverter
    UNION ALL
    SELECT 'measurement.status', inverter, count(*)::bigint, min(read_ts), max(read_ts) FROM measurement.status GROUP BY inverter
    UNION ALL
    SELECT 'measurement.totals', inverter, count(*)::bigint, min(read_ts), max(read_ts) FROM measurement.totals GROUP BY inverter
    UNION ALL
    SELECT 'measurement.statistics', inverter, count(*)::bigint, min(read_ts), max(read_ts) FROM measurement.statistics GROUP BY inverter
    UNION ALL
    SELECT 'measurement.settings', inverter, count(*)::bigint, min(read_ts), max(read_ts) FROM measurement.settings GROUP BY inverter
    UNION ALL
    SELECT 'measurement.specs', inverter, count(*)::bigint, min(read_ts), max(read_ts) FROM measurement.specs GROUP BY inverter
) AS coverage;

INSERT INTO tmp_derived_context (recorded, start_ts, end_ts, value)
SELECT
    extract(epoch FROM first_read_ts)::bigint AS recorded,
    extract(epoch FROM first_read_ts)::bigint AS start_ts,
    extract(epoch FROM last_read_ts)::bigint AS end_ts,
    jsonb_build_object(
        'source', 'derived_context_pipeline',
        'source_version', '2026-06-19-v1',
        'context_type', 'data_coverage_summary',
        'table_name', table_name,
        'device', 'inverter',
        'inverter', inverter,
        'summary', 'Measurement table coverage summary for this inverter.',
        'row_count', row_count,
        'first_read_local', to_char(first_read_ts AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD"T"HH24:MI:SS'),
        'last_read_local', to_char(last_read_ts AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD"T"HH24:MI:SS')
    )::text
FROM tmp_table_coverage
WHERE first_read_ts IS NOT NULL
  AND last_read_ts IS NOT NULL;

WITH ordered AS (
    SELECT
        inverter,
        read_ts,
        lag(read_ts) OVER (PARTITION BY inverter ORDER BY read_ts) AS prev_read_ts
    FROM measurement.analog_measurement_fixed
),
gaps AS (
    SELECT
        inverter,
        prev_read_ts,
        read_ts,
        extract(epoch FROM read_ts - prev_read_ts)::numeric AS gap_seconds
    FROM ordered
    WHERE prev_read_ts IS NOT NULL
      AND read_ts - prev_read_ts > interval '10 minutes'
)
INSERT INTO tmp_derived_context (recorded, start_ts, end_ts, value)
SELECT
    extract(epoch FROM read_ts)::bigint AS recorded,
    extract(epoch FROM prev_read_ts)::bigint AS start_ts,
    extract(epoch FROM read_ts)::bigint AS end_ts,
    jsonb_build_object(
        'source', 'derived_context_pipeline',
        'source_version', '2026-06-19-v1',
        'context_type', 'data_gap',
        'source_table', 'measurement.analog_measurement_fixed',
        'device', 'inverter',
        'inverter', inverter,
        'summary', 'No analog measurement records were available for more than 10 minutes.',
        'threshold_seconds', 600,
        'gap_seconds', round(gap_seconds, 3),
        'previous_sample_local', to_char(prev_read_ts AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD"T"HH24:MI:SS'),
        'next_sample_local', to_char(read_ts AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD"T"HH24:MI:SS')
    )::text
FROM gaps;

WITH temp_quality AS (
    SELECT
        inverter,
        count(*)::bigint AS row_count,
        count(*) FILTER (WHERE GREATEST(temper1, temper2, temper3, temper4) = 120)::bigint AS sentinel_like_count,
        min(read_ts) AS first_read_ts,
        max(read_ts) AS last_read_ts
    FROM measurement.analog_measurement_fixed
    GROUP BY inverter
)
INSERT INTO tmp_derived_context (recorded, start_ts, end_ts, value)
SELECT
    extract(epoch FROM first_read_ts)::bigint AS recorded,
    extract(epoch FROM first_read_ts)::bigint AS start_ts,
    extract(epoch FROM last_read_ts)::bigint AS end_ts,
    jsonb_build_object(
        'source', 'derived_context_pipeline',
        'source_version', '2026-06-19-v1',
        'context_type', 'telemetry_quality_note',
        'source_table', 'measurement.analog_measurement_fixed',
        'device', 'inverter',
        'inverter', inverter,
        'summary', 'Temperature channels are dominated by a 120 °C sentinel-like reading and should be treated cautiously for thermal analysis.',
        'field_group', 'temperature_channels',
        'sentinel_value', 120,
        'sentinel_like_count', sentinel_like_count,
        'row_count', row_count,
        'sentinel_like_fraction', round((sentinel_like_count::numeric / NULLIF(row_count, 0)), 4)
    )::text
FROM temp_quality
WHERE sentinel_like_count::numeric / NULLIF(row_count, 0) > 0.5;

CREATE TEMP TABLE tmp_minute_features AS
SELECT
    inverter,
    to_timestamp(floor(extract(epoch FROM read_ts) / 60) * 60) AS minute_ts,
    count(*)::integer AS sample_count,
    avg(COALESCE(pv1power, 0) + COALESCE(pv2power, 0) + COALESCE(pv3power, 0))::numeric AS pv_power_w_mean,
    max(COALESCE(pv1power, 0) + COALESCE(pv2power, 0) + COALESCE(pv3power, 0))::numeric AS pv_power_w_max,
    avg(outsumw)::numeric AS ac_load_w_mean,
    max(outsumw)::numeric AS ac_load_w_max,
    avg(battcurr)::numeric AS battery_current_a_mean,
    min(battcurr)::numeric AS battery_current_a_min,
    max(battcurr)::numeric AS battery_current_a_max,
    avg(battchgpower)::numeric AS battery_charge_power_w_mean,
    max(GREATEST(temper1, temper2, temper3, temper4))::numeric AS temperature_c_max,
    avg(CASE WHEN COALESCE(linevolta, 0) < 100 AND COALESCE(linevoltb, 0) < 100 AND COALESCE(linevoltc, 0) < 100 THEN 1.0 ELSE 0.0 END)::numeric AS grid_low_ratio
FROM measurement.analog_measurement_fixed
GROUP BY inverter, to_timestamp(floor(extract(epoch FROM read_ts) / 60) * 60);

CREATE INDEX tmp_minute_features_idx ON tmp_minute_features (inverter, minute_ts);

WITH active_points AS (
    SELECT
        mf.*,
        labels.context_type,
        labels.summary,
        labels.threshold_description
    FROM tmp_minute_features AS mf
    CROSS JOIN LATERAL (
        VALUES
            ('grid_unavailable_or_islanded', 'Grid input voltage was absent or below threshold for most samples in the minute.', 'all line voltages below 100 V for at least 80% of samples', mf.grid_low_ratio >= 0.8),
            ('battery_discharging', 'Battery current indicates discharge over the minute.', 'mean battery current <= -5 A', mf.battery_current_a_mean <= -5),
            ('battery_charging', 'Battery current or charge power indicates charging over the minute.', 'mean battery current >= 5 A or mean charge power >= 500 W', mf.battery_current_a_mean >= 5 OR mf.battery_charge_power_w_mean >= 500),
            ('pv_generation_active', 'PV input power exceeded the active-generation threshold.', 'mean PV power >= 500 W', mf.pv_power_w_mean >= 500),
            ('high_ac_load', 'AC output load was in a high-load regime for this installation.', 'mean AC load >= 900 W for inverter 1 or >= 1800 W for inverter 2', mf.ac_load_w_mean >= CASE WHEN mf.inverter = 1 THEN 900 ELSE 1800 END)
    ) AS labels(context_type, summary, threshold_description, is_active)
    WHERE labels.is_active
),
marked AS (
    SELECT
        *,
        CASE
            WHEN lag(minute_ts) OVER (PARTITION BY inverter, context_type ORDER BY minute_ts) >= minute_ts - interval '30 minutes'
            THEN 0
            ELSE 1
        END AS new_group
    FROM active_points
),
islands AS (
    SELECT
        *,
        sum(new_group) OVER (PARTITION BY inverter, context_type ORDER BY minute_ts) AS island_id
    FROM marked
),
merged AS (
    SELECT
        inverter,
        context_type,
        min(summary) AS summary,
        min(threshold_description) AS threshold_description,
        min(minute_ts) AS start_minute,
        max(minute_ts) + interval '1 minute' AS end_minute,
        count(*)::integer AS active_minutes,
        sum(sample_count)::integer AS sample_count,
        avg(pv_power_w_mean)::numeric AS pv_power_w_mean,
        max(pv_power_w_max)::numeric AS pv_power_w_max,
        avg(ac_load_w_mean)::numeric AS ac_load_w_mean,
        max(ac_load_w_max)::numeric AS ac_load_w_max,
        avg(battery_current_a_mean)::numeric AS battery_current_a_mean,
        min(battery_current_a_min)::numeric AS battery_current_a_min,
        max(battery_current_a_max)::numeric AS battery_current_a_max,
        avg(battery_charge_power_w_mean)::numeric AS battery_charge_power_w_mean,
        max(temperature_c_max)::numeric AS temperature_c_max,
        avg(grid_low_ratio)::numeric AS grid_low_ratio_mean
    FROM islands
    GROUP BY inverter, context_type, island_id
)
INSERT INTO tmp_derived_context (recorded, start_ts, end_ts, value)
SELECT
    extract(epoch FROM start_minute)::bigint AS recorded,
    extract(epoch FROM start_minute)::bigint AS start_ts,
    extract(epoch FROM end_minute)::bigint AS end_ts,
    jsonb_strip_nulls(jsonb_build_object(
        'source', 'derived_context_pipeline',
        'source_version', '2026-06-19-v1',
        'context_type', context_type,
        'source_table', 'measurement.analog_measurement_fixed',
        'device', 'inverter',
        'inverter', inverter,
        'summary', summary,
        'threshold_description', threshold_description,
        'active_minutes', active_minutes,
        'sample_count', sample_count,
        'metrics', jsonb_build_object(
            'pv_power_w_mean', round(pv_power_w_mean, 2),
            'pv_power_w_max', round(pv_power_w_max, 2),
            'ac_load_w_mean', round(ac_load_w_mean, 2),
            'ac_load_w_max', round(ac_load_w_max, 2),
            'battery_current_a_mean', round(battery_current_a_mean, 2),
            'battery_current_a_min', round(battery_current_a_min, 2),
            'battery_current_a_max', round(battery_current_a_max, 2),
            'battery_charge_power_w_mean', round(battery_charge_power_w_mean, 2),
            'temperature_c_max', round(temperature_c_max, 2),
            'grid_low_ratio_mean', round(grid_low_ratio_mean, 3)
        )
    ))::text
FROM merged
WHERE active_minutes >= CASE
    WHEN context_type = 'high_ac_load' THEN 3
    WHEN context_type = 'grid_unavailable_or_islanded' THEN 2
    WHEN context_type IN ('pv_generation_active', 'battery_charging', 'battery_discharging') THEN 15
    ELSE 3
END;

WITH inserted AS (
    INSERT INTO public.context (recorded, start, "end", value)
    SELECT recorded, start_ts, end_ts, value::jsonb
    FROM tmp_derived_context AS src
    WHERE NOT EXISTS (
        SELECT 1
        FROM public.context AS existing
        WHERE existing.recorded = src.recorded
          AND existing.start = src.start_ts
          AND existing."end" = src.end_ts
          AND existing.value = src.value::jsonb
    )
    ORDER BY start_ts, value
    RETURNING 1
)
SELECT count(*) AS inserted_derived_telemetry_context_rows
FROM inserted;

SELECT
    value::jsonb->>'context_type' AS context_type,
    count(*) AS staged_rows
FROM tmp_derived_context
GROUP BY 1
ORDER BY 1;
