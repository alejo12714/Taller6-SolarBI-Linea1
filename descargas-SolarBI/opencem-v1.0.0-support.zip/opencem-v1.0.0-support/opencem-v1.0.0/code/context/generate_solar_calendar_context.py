#!/usr/bin/env python3
"""Generate deterministic solar and calendar context rows for OpenCEM."""

from __future__ import annotations

import argparse
import csv
import json
import math
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
OUT_CSV = ROOT / "solar_calendar_context.csv"

LATITUDE = 22.693001
LONGITUDE = 114.211386
LOCAL_TZ = ZoneInfo("Asia/Shanghai")
SOURCE_VERSION = "2026-06-19-v1"


def normalize_degrees(value: float) -> float:
    return value % 360.0


def day_of_year(day: date) -> int:
    return day.timetuple().tm_yday


def local_day_bounds(day: date) -> tuple[datetime, datetime]:
    start = datetime.combine(day, time.min, LOCAL_TZ)
    return start, start + timedelta(days=1)


def epoch(dt: datetime) -> int:
    return int(dt.timestamp())


def clip_interval(start: datetime, end: datetime, coverage_start: datetime, coverage_end: datetime) -> tuple[datetime, datetime] | None:
    clipped_start = max(start, coverage_start)
    clipped_end = min(end, coverage_end)
    if clipped_end <= clipped_start:
        return None
    return clipped_start, clipped_end


def solar_event(day: date, *, sunrise: bool, zenith: float) -> datetime:
    """Return a local sunrise/sunset-like event using the NOAA approximation."""

    n = day_of_year(day)
    lng_hour = LONGITUDE / 15.0
    t = n + (((6 if sunrise else 18) - lng_hour) / 24.0)

    mean_anomaly = (0.9856 * t) - 3.289
    true_longitude = normalize_degrees(
        mean_anomaly
        + (1.916 * math.sin(math.radians(mean_anomaly)))
        + (0.020 * math.sin(math.radians(2 * mean_anomaly)))
        + 282.634
    )

    right_ascension = math.degrees(math.atan(0.91764 * math.tan(math.radians(true_longitude))))
    right_ascension = normalize_degrees(right_ascension)

    longitude_quadrant = math.floor(true_longitude / 90.0) * 90.0
    ascension_quadrant = math.floor(right_ascension / 90.0) * 90.0
    right_ascension = (right_ascension + longitude_quadrant - ascension_quadrant) / 15.0

    sin_dec = 0.39782 * math.sin(math.radians(true_longitude))
    cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (
        math.cos(math.radians(zenith))
        - (sin_dec * math.sin(math.radians(LATITUDE)))
    ) / (cos_dec * math.cos(math.radians(LATITUDE)))

    if cos_h > 1:
        event_utc_hour = 0.0
    elif cos_h < -1:
        event_utc_hour = 12.0
    else:
        hour_angle = 360.0 - math.degrees(math.acos(cos_h)) if sunrise else math.degrees(math.acos(cos_h))
        hour_angle /= 15.0
        local_mean_time = hour_angle + right_ascension - (0.06571 * t) - 6.622
        event_utc_hour = (local_mean_time - lng_hour) % 24.0

    hour = int(event_utc_hour)
    minute_float = (event_utc_hour - hour) * 60.0
    minute = int(minute_float)
    second = int(round((minute_float - minute) * 60.0))
    if second == 60:
        second = 0
        minute += 1
    if minute == 60:
        minute = 0
        hour += 1
    event_utc = datetime.combine(day, time.min, timezone.utc) + timedelta(hours=hour, minutes=minute, seconds=second)
    event_local = event_utc.astimezone(LOCAL_TZ)
    while event_local.date() > day:
        event_local -= timedelta(days=1)
    while event_local.date() < day:
        event_local += timedelta(days=1)
    return event_local


def add_row(rows: list[dict[str, str | int]], start: datetime, end: datetime, payload: dict, coverage_start: datetime, coverage_end: datetime) -> None:
    clipped = clip_interval(start, end, coverage_start, coverage_end)
    if not clipped:
        return
    clipped_start, clipped_end = clipped
    payload = {
        "source": "derived_context_pipeline",
        "source_version": SOURCE_VERSION,
        "device": "installation",
        "inverter": 1,
        **payload,
    }
    rows.append(
        {
            "recorded": epoch(clipped_start),
            "start": epoch(clipped_start),
            "end": epoch(clipped_end),
            "value": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        }
    )


def generate(coverage_start: datetime, coverage_end: datetime) -> list[dict[str, str | int]]:
    rows: list[dict[str, str | int]] = []

    add_row(
        rows,
        coverage_start,
        coverage_end,
        {
            "context_type": "installation_location",
            "summary": "Geographic coordinates used for deterministic solar-position and calendar context.",
            "latitude": LATITUDE,
            "longitude": LONGITUDE,
            "coordinate_source": "Apple Maps coordinates supplied by the dataset authors",
            "timezone": "Asia/Shanghai",
        },
        coverage_start,
        coverage_end,
    )

    current = coverage_start.date()
    while current <= coverage_end.date():
        day_start, day_end = local_day_bounds(current)
        weekday = current.weekday()
        day_type = "weekend" if weekday >= 5 else "weekday"
        add_row(
            rows,
            day_start,
            day_end,
            {
                "context_type": "calendar_day",
                "summary": f"Local calendar day classified as {day_type}.",
                "local_date": current.isoformat(),
                "weekday": weekday,
                "weekday_name": current.strftime("%A"),
                "day_type": day_type,
                "timezone": "Asia/Shanghai",
            },
            coverage_start,
            coverage_end,
        )

        sunrise = solar_event(current, sunrise=True, zenith=90.833)
        sunset = solar_event(current, sunrise=False, zenith=90.833)
        civil_dawn = solar_event(current, sunrise=True, zenith=96.0)
        civil_dusk = solar_event(current, sunrise=False, zenith=96.0)

        add_row(
            rows,
            sunrise,
            sunset,
            {
                "context_type": "solar_daylight",
                "summary": "Sun above the apparent horizon at the installation coordinates.",
                "latitude": LATITUDE,
                "longitude": LONGITUDE,
                "local_date": current.isoformat(),
                "sunrise_local": sunrise.isoformat(timespec="seconds"),
                "sunset_local": sunset.isoformat(timespec="seconds"),
                "method": "NOAA sunrise/sunset approximation",
                "zenith_degrees": 90.833,
            },
            coverage_start,
            coverage_end,
        )
        add_row(
            rows,
            civil_dawn,
            sunrise,
            {
                "context_type": "solar_civil_twilight_morning",
                "summary": "Morning civil twilight at the installation coordinates.",
                "latitude": LATITUDE,
                "longitude": LONGITUDE,
                "local_date": current.isoformat(),
                "civil_dawn_local": civil_dawn.isoformat(timespec="seconds"),
                "sunrise_local": sunrise.isoformat(timespec="seconds"),
                "method": "NOAA sunrise/sunset approximation",
                "zenith_degrees": 96.0,
            },
            coverage_start,
            coverage_end,
        )
        add_row(
            rows,
            sunset,
            civil_dusk,
            {
                "context_type": "solar_civil_twilight_evening",
                "summary": "Evening civil twilight at the installation coordinates.",
                "latitude": LATITUDE,
                "longitude": LONGITUDE,
                "local_date": current.isoformat(),
                "sunset_local": sunset.isoformat(timespec="seconds"),
                "civil_dusk_local": civil_dusk.isoformat(timespec="seconds"),
                "method": "NOAA sunrise/sunset approximation",
                "zenith_degrees": 96.0,
            },
            coverage_start,
            coverage_end,
        )

        current += timedelta(days=1)

    rows.sort(key=lambda row: (int(row["start"]), str(row["value"])))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--coverage-start", default="2025-07-12T21:31:35+08:00")
    parser.add_argument("--coverage-end", default="2026-06-09T14:18:16+08:00")
    parser.add_argument("--output", type=Path, default=OUT_CSV)
    args = parser.parse_args()

    coverage_start = datetime.fromisoformat(args.coverage_start).astimezone(LOCAL_TZ)
    coverage_end = datetime.fromisoformat(args.coverage_end).astimezone(LOCAL_TZ)
    rows = generate(coverage_start, coverage_end)

    with args.output.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["recorded", "start", "end", "value"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"wrote {args.output}")
    print(f"rows {len(rows)}")


if __name__ == "__main__":
    main()
