#!/usr/bin/env python3
"""Extract reviewable context candidates from Windows Event Log CSV exports."""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import Counter, OrderedDict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

csv.field_size_limit(sys.maxsize)

ROOT = Path(__file__).resolve().parent
FILES: dict[str, Path] = {}
OUT_CSV = ROOT / "windows_event_context_candidates.csv"
OUT_MD = ROOT / "windows_event_context_candidates_review.md"
SENSITIVE_TERMS: tuple[str, ...] = ()
TZ = timezone(timedelta(hours=8))


@dataclass
class Candidate:
    device: str
    category: str
    recorded: datetime
    start: datetime
    end: datetime
    provider: str
    event_id: str
    log_name: str
    level: str
    confidence: str
    summary: str
    details: dict
    record_id: str = ""


def parse_time(value: str) -> datetime | None:
    value = (value or "").strip().replace("\u200e", "")
    for fmt in ("%Y/%m/%d %H:%M:%S", "%m/%d/%Y %I:%M:%S %p"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=TZ)
        except ValueError:
            pass
    return None


def parse_previous_shutdown_time(message: str, recorded: datetime) -> datetime | None:
    clean = (message or "").replace("\u200e", "")
    match = re.search(r"at\s+(\d{1,2}:\d{2}:\d{2})\s+on\s+([0-9/]+)", clean)
    if not match:
        return None
    clock, date = match.groups()
    for fmt in ("%Y/%m/%d %H:%M:%S", "%d/%m/%Y %H:%M:%S", "%m/%d/%Y %H:%M:%S"):
        try:
            parsed = datetime.strptime(f"{date} {clock}", fmt).replace(tzinfo=TZ)
            # Prefer a parsed time that is not after the event reporting it.
            if parsed <= recorded + timedelta(minutes=5):
                return parsed
        except ValueError:
            pass
    return None


def epoch(dt: datetime) -> int:
    return int(dt.timestamp())


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def sanitize(text: str, limit: int = 600) -> str:
    text = (text or "").replace("\r", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"S-1-\d+(?:-\d+)+", "<sid>", text)
    text = re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "<ip>", text)
    text = re.sub(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b", "<guid>", text)
    text = re.sub(r"([A-Za-z]:\\Users\\)[^\\\s]+", r"\1<user>", text)
    text = re.sub(r"(User:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(Account Name:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(Account Domain:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(Network Account Name:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(Network Account Domain:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(Source Network Address:\s*)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"(on behalf of user\s+)[^\s]+", r"\1<redacted>", text)
    text = re.sub(r"\b(?:SERVER|DESKTOP-[A-Za-z0-9-]+)\\[A-Za-z0-9._-]+\b", r"<redacted_user>", text)
    text = re.sub(r"\b(?:SERVER|DESKTOP-[A-Za-z0-9-]+)\b", "<device>", text)
    for term in SENSITIVE_TERMS:
        text = re.sub(re.escape(term), "<redacted>", text, flags=re.I)
    return text[:limit]


def extract_logon_type(message: str) -> str | None:
    match = re.search(r"Logon Type:\s*(\d+)", message or "")
    return match.group(1) if match else None


LOGON_TYPE_LABELS = {
    "2": "local interactive logon",
    "8": "network cleartext logon, commonly used by services such as SSH/basic authentication",
    "10": "remote interactive logon",
    "11": "cached interactive logon",
}


def source_network_kind(message: str) -> str:
    match = re.search(r"Source Network Address:\s*([^\s]+)", message or "")
    if not match:
        return "unspecified"
    raw = match.group(1)
    if raw in {"-", "本地", "localhost", "::1", "127.0.0.1"}:
        return "local"
    return "remote"


def update_is_relevant(message: str) -> bool:
    msg = message or ""
    if re.search(r"Microsoft Defender|Defender Antivirus|KB2267602|KB4052623|安全智能更新|反恶意软件平台|防病毒", msg, re.I):
        return False
    if re.search(r"\bMicrosoft\.(WindowsStore|WindowsNotepad|DesktopAppInstaller|Xbox|CrossDevice)\b", msg):
        return False
    if re.search(r"\b[A-Z0-9]{8,}-Microsoft", msg):
        return False
    return bool(re.search(r"Cumulative Update|Servicing Stack|Feature Update|Security Update|Update for Windows|Windows 11|Windows 10|KB\d{6,}", msg, re.I))


def wer_event_name(message: str) -> str | None:
    match = re.search(r"Event Name:\s*([^\s]+)", message or "")
    return match.group(1) if match else None


def extract_storage_vsp_details(message: str) -> dict:
    details: dict[str, object] = {}
    patterns = {
        "io_type": r"IO type:\s*([A-Za-z]+)",
        "interval_duration_s": r"Interval duration:\s*(\d+)\s*s",
        "high_latency_ios": r"High Latency IOs:\s*(\d+)",
        "io_count": r"IO count:\s*(\d+)",
        "avg_iops": r"Avg IOPS:\s*(\d+)",
        "avg_bps": r"Avg Bps:\s*(\d+)",
        "avg_latency_ms": r"Avg latency:\s*(\d+)\s*ms",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, message or "")
        if not match:
            continue
        value = match.group(1)
        details[key] = int(value) if value.isdigit() else value
    dev = re.search(r"Device:\s*(.*?)\s+IO type:", message or "")
    if dev:
        details["device_path_redacted"] = sanitize(dev.group(1), limit=220)
    return details


def extract_latency_ms(message: str) -> int | None:
    match = re.search(r"took\s+(\d+)\s+milliseconds", message or "", flags=re.I)
    return int(match.group(1)) if match else None


def extract_time_delta_ms(message: str) -> int | None:
    match = re.search(r"Time Delta:\s*(-?\d+)\s*ms", message or "", flags=re.I)
    return int(match.group(1)) if match else None


def extract_service_name(message: str) -> str | None:
    msg = message or ""
    patterns = [
        r"The\s+(.+?)\s+service terminated unexpectedly",
        r"The\s+(.+?)\s+service entered the\s+(.+?)\s+state",
        r"The start type of the\s+(.+?)\s+service was changed",
        r"服务\s+(.+?)\s+",
    ]
    for pattern in patterns:
        match = re.search(pattern, msg, flags=re.I)
        if match:
            return sanitize(match.group(1), limit=120)
    return None


def service_is_contextual(service: str | None, message: str) -> bool:
    text = f"{service or ''} {message or ''}"
    if re.search(r"Autodesk|Bonjour|Xbox|Store|AppX|Windows Search|Software Protection", text, re.I):
        return False
    return bool(
        re.search(
            r"OpenSSH|sshd|LxssManager|Hyper-V|vmcompute|vmms|Host Network Service|Docker|"
            r"NVIDIA|Display|PostgreSQL|postgres|Windows Update|Background Intelligent Transfer Service|BITS",
            text,
            re.I,
        )
    )


def device_change_kind(message: str) -> str | None:
    msg = message or ""
    rules = [
        (r"\bDISPLAY\\|monitor", "display"),
        (r"\bUSBSTOR\\|\bSCSI\\|\bDisk&|\bSTORAGE\\", "storage_device"),
        (r"camera|image|imaging|video capture", "camera_or_imaging_device"),
        (r"NVIDIA|nvlddmkm|\bPCI\\VEN", "gpu_or_pci_device"),
        (r"Ethernet|Wi-?Fi|Network|NetAdapter", "network_device"),
    ]
    for pattern, label in rules:
        if re.search(pattern, msg, re.I):
            return label
    return None


SUPPLEMENTAL_MIN_EVENTS = {
    "wsl_virtualization_network_activity": 20,
    "virtual_disk_io_latency_window": 1,
    "windows_update_maintenance_window": 3,
    "service_failure_or_restart_window": 1,
    "remote_access_or_ssh_activity": 1,
    "system_time_adjustment": 1,
    "storage_capacity_pressure": 1,
    "device_connectivity_change_window": 5,
}


SUPPLEMENTAL_END_PADDING_MINUTES = {
    "wsl_virtualization_network_activity": 10,
    "virtual_disk_io_latency_window": 10,
    "windows_update_maintenance_window": 30,
    "service_failure_or_restart_window": 10,
    "remote_access_or_ssh_activity": 10,
    "system_time_adjustment": 5,
    "storage_capacity_pressure": 20,
    "device_connectivity_change_window": 10,
}


SUPPLEMENTAL_SUMMARIES = {
    "wsl_virtualization_network_activity": "Aggregated WSL/Hyper-V virtual-network activity or warning window.",
    "virtual_disk_io_latency_window": "Hyper-V/WSL virtual disk I/O latency warning window.",
    "windows_update_maintenance_window": "Aggregated Windows Update or scheduled maintenance activity window.",
    "service_failure_or_restart_window": "Contextual Windows service failure, restart, or state-change window.",
    "remote_access_or_ssh_activity": "OpenSSH or remote-access related Windows event window.",
    "system_time_adjustment": "Windows time-service or system-clock adjustment event window.",
    "storage_capacity_pressure": "Windows storage-capacity or state-repository pressure window.",
    "device_connectivity_change_window": "Repeated relevant device connectivity change window.",
}


def supplemental_event(device: str, row: dict) -> dict | None:
    recorded = parse_time(row.get("TimeCreated", ""))
    if recorded is None:
        return None
    provider = row.get("ProviderName", "")
    event_id = row.get("Id", "")
    log_name = row.get("LogName", "")
    level = row.get("LevelDisplayName", "")
    message = row.get("Message", "") or ""
    base = {
        "source": "windows_event_log_aggregated",
        "device": device,
        "provider": provider,
        "event_id": event_id,
        "log_name": log_name,
        "level": level,
    }

    category: str | None = None
    details: dict[str, object] = {}

    if provider == "Microsoft-Windows-Hyper-V-VmSwitch" and event_id in {"148", "285"}:
        category = "wsl_virtualization_network_activity"
        details = {"event_focus": "hyper_v_virtual_switch_warning"}
    elif provider == "Microsoft-Windows-SMBClient" and event_id in {"30810", "30812", "30813"} and re.search(
        r"WSL|Hyper-V|vEthernet|NetBT|Tcpip", message, re.I
    ):
        category = "wsl_virtualization_network_activity"
        details = {"event_focus": "wsl_or_virtual_network_transport_binding"}
    elif provider == "Microsoft-Windows-Hyper-V-StorageVSP" and event_id == "9":
        latency = extract_latency_ms(message)
        category = "virtual_disk_io_latency_window"
        details = {
            "latency_ms": latency,
            "device_path_redacted": sanitize(re.search(r"device '([^']+)'", message or "").group(1), 220)
            if re.search(r"device '([^']+)'", message or "")
            else None,
        }
    elif provider == "Microsoft-Windows-WindowsUpdateClient" and event_id in {"19", "20", "26", "41", "43", "44"}:
        if event_id in {"19", "20", "43"} and not update_is_relevant(message):
            return None
        category = "windows_update_maintenance_window"
        details = {"event_focus": "windows_update_client"}
    elif provider == "Microsoft-Windows-TaskScheduler" and log_name == "Microsoft-Windows-TaskScheduler/Maintenance" and event_id == "800":
        category = "windows_update_maintenance_window"
        details = {"event_focus": "scheduled_maintenance_state"}
    elif provider == "Service Control Manager" and event_id in {"7031", "7034", "7036", "7040"}:
        service = extract_service_name(message)
        if not service_is_contextual(service, message):
            return None
        category = (
            "windows_update_maintenance_window"
            if re.search(r"Background Intelligent Transfer Service|BITS|Windows Update", service or message, re.I)
            else "service_failure_or_restart_window"
        )
        details = {"service_name_redacted": service, "event_focus": "contextual_service_event"}
    elif provider == "OpenSSH" or log_name.startswith("OpenSSH") or re.search(r"\bsshd\b|OpenSSH", message, re.I):
        category = "remote_access_or_ssh_activity"
        details = {"event_focus": "openssh_event"}
    elif provider == "Microsoft-Windows-Kernel-General" and event_id == "1":
        delta_ms = extract_time_delta_ms(message)
        if delta_ms is not None and abs(delta_ms) >= 5000:
            category = "system_time_adjustment"
            details = {"event_focus": "system_clock_change", "time_delta_ms": delta_ms}
    elif provider == "Microsoft-Windows-Time-Service" and level in {"Warning", "Error", "Critical"}:
        if re.search(r"time|clock|synchroni|NTP", message, re.I):
            category = "system_time_adjustment"
            details = {"event_focus": "time_service_warning_or_error"}
    elif provider == "Microsoft-Windows-StateRepository" and level in {"Warning", "Error", "Critical"} and re.search(
        r"disk|space|112|StateRepository", message, re.I
    ):
        category = "storage_capacity_pressure"
        details = {"event_focus": "state_repository_or_disk_space_error"}
    elif provider == "Microsoft-Windows-Kernel-PnP" and event_id == "1010":
        kind = device_change_kind(message)
        if not kind:
            return None
        category = "device_connectivity_change_window"
        details = {"device_kind": kind}

    if not category:
        return None
    details = {k: v for k, v in details.items() if v not in (None, "", [])}
    return {
        "device": device,
        "category": category,
        "recorded": recorded,
        "provider": provider,
        "event_id": event_id,
        "log_name": log_name,
        "level": level,
        "record_id": row.get("RecordId", ""),
        "message": message,
        "details": {**base, **details},
    }


def add_supplemental_bucket(store: OrderedDict, info: dict) -> None:
    recorded = info["recorded"]
    hour = recorded.replace(minute=0, second=0, microsecond=0)
    key = (info["device"], info["category"], hour)
    entry = store.setdefault(
        key,
        {
            "count": 0,
            "first": recorded,
            "last": recorded,
            "providers": Counter(),
            "event_ids": Counter(),
            "levels": Counter(),
            "record_ids": [],
            "sample": sanitize(info.get("message", "")),
            "focus": Counter(),
            "service_names": Counter(),
            "device_kinds": Counter(),
            "max_latency_ms": None,
        },
    )
    entry["count"] += 1
    entry["first"] = min(entry["first"], recorded)
    entry["last"] = max(entry["last"], recorded)
    entry["providers"][info.get("provider", "")] += 1
    entry["event_ids"][info.get("event_id", "")] += 1
    entry["levels"][info.get("level", "")] += 1
    if len(entry["record_ids"]) < 8:
        entry["record_ids"].append(info.get("record_id", ""))
    details = info.get("details", {})
    if details.get("event_focus"):
        entry["focus"][details["event_focus"]] += 1
    if details.get("service_name_redacted"):
        entry["service_names"][details["service_name_redacted"]] += 1
    if details.get("device_kind"):
        entry["device_kinds"][details["device_kind"]] += 1
    if details.get("latency_ms") is not None:
        entry["max_latency_ms"] = max(entry["max_latency_ms"] or 0, int(details["latency_ms"]))
    if details.get("time_delta_ms") is not None:
        entry["max_abs_time_delta_ms"] = max(entry.get("max_abs_time_delta_ms") or 0, abs(int(details["time_delta_ms"])))
    if details.get("device_path_redacted") and "device_path_redacted" not in entry:
        entry["device_path_redacted"] = details["device_path_redacted"]


def make_candidate(
    device: str,
    category: str,
    recorded: datetime,
    provider: str,
    event_id: str,
    log_name: str,
    level: str,
    summary: str,
    details: dict,
    record_id: str = "",
    start: datetime | None = None,
    end: datetime | None = None,
    confidence: str = "medium",
) -> Candidate:
    start = start or recorded
    end = end or (start + timedelta(minutes=10))
    return Candidate(device, category, recorded, start, end, provider, event_id, log_name, level, confidence, summary, details, record_id)


def row_candidate(device: str, row: dict) -> Candidate | None:
    recorded = parse_time(row.get("TimeCreated", ""))
    if recorded is None:
        return None
    provider = row.get("ProviderName", "")
    event_id = row.get("Id", "")
    log_name = row.get("LogName", "")
    level = row.get("LevelDisplayName", "")
    message = row.get("Message", "") or ""
    record_id = row.get("RecordId", "")
    base = {
        "source": "windows_event_log",
        "device": device,
        "provider": provider,
        "event_id": event_id,
        "log_name": log_name,
        "level": level,
        "record_id": record_id,
    }

    if provider == "EventLog" and event_id == "6008":
        start = parse_previous_shutdown_time(message, recorded) or recorded
        return make_candidate(
            device, "unexpected_shutdown", recorded, provider, event_id, log_name, level,
            "Windows reported that the previous system shutdown was unexpected.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, start=start, end=start + timedelta(minutes=5), confidence="high",
        )

    if provider == "User32" and event_id == "1074":
        return make_candidate(
            device, "scheduled_reboot_or_shutdown", recorded, provider, event_id, log_name, level,
            "Windows reported an initiated reboot/shutdown, often due to planned OS servicing.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=5), confidence="high",
        )

    if provider == "EventLog" and event_id in {"6005", "6006"}:
        category = "system_boot_eventlog_started" if event_id == "6005" else "system_shutdown_eventlog_stopped"
        return make_candidate(
            device, category, recorded, provider, event_id, log_name, level,
            "Windows Event Log service start/stop, used as a boot or shutdown marker.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=5), confidence="medium",
        )

    if provider == "Microsoft-Windows-Kernel-Power" and event_id in {"41", "109", "577", "578"}:
        summary = {
            "41": "Kernel-Power reported a reboot without clean shutdown.",
            "109": "Kernel power manager initiated a shutdown transition.",
            "577": "System prepared for a system-initiated reboot.",
            "578": "System detected a system-initiated reboot.",
        }[event_id]
        return make_candidate(
            device, "power_transition", recorded, provider, event_id, log_name, level,
            summary,
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=5), confidence="medium",
        )

    if provider == "Microsoft-Windows-TerminalServices-LocalSessionManager" and event_id in {"21", "23", "24", "25"}:
        category = {
            "21": "remote_desktop_logon",
            "23": "remote_desktop_logoff",
            "24": "remote_desktop_disconnect",
            "25": "remote_desktop_reconnect",
        }[event_id]
        duration = 10 if event_id in {"21", "25"} else 5
        return make_candidate(
            device, category, recorded, provider, event_id, log_name, level,
            "Remote Desktop session activity; user and source address redacted.",
            {**base, "source_network_kind": source_network_kind(message), "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=duration), confidence="high",
        )

    if provider == "Microsoft-Windows-Security-Auditing" and event_id == "4624":
        logon_type = extract_logon_type(message)
        if logon_type in LOGON_TYPE_LABELS:
            return make_candidate(
                device, "interactive_or_remote_logon", recorded, provider, event_id, log_name, level,
                f"Successful {LOGON_TYPE_LABELS[logon_type]}; account details redacted.",
                {**base, "logon_type": logon_type, "logon_type_label": LOGON_TYPE_LABELS[logon_type], "source_network_kind": source_network_kind(message)},
                record_id, end=recorded + timedelta(minutes=10), confidence="medium",
            )
        return None

    if provider == "Microsoft-Windows-WindowsUpdateClient" and event_id in {"19", "20", "43"} and update_is_relevant(message):
        status = {"19": "successful", "20": "failed", "43": "started"}[event_id]
        return make_candidate(
            device, "windows_update_activity", recorded, provider, event_id, log_name, level,
            f"Windows Update installation {status}; likely OS-level update rather than routine Defender signatures.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=30), confidence="medium",
        )

    if provider == "Windows Error Reporting" and event_id == "1001":
        name = wer_event_name(message)
        if name in {"BlueScreen", "LiveKernelEvent"}:
            # WER often re-emits the same report many times. These rows are
            # aggregated after scanning, so skip the per-row candidate here.
            return None
        return None

    if (provider == "Microsoft-Windows-WHEA-Logger" and event_id == "3") or (
        provider == "Microsoft-Windows-Kernel-WHEA" and event_id == "20"
    ):
        return make_candidate(
            device, "hardware_error_report", recorded, provider, event_id, log_name, level,
            "Windows Hardware Error Architecture reported a hardware event.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=10), confidence="medium",
        )

    if provider == "Microsoft-Windows-Winlogon" and event_id in {"1002", "6004", "6005", "6006"}:
        return make_candidate(
            device, "winlogon_issue", recorded, provider, event_id, log_name, level,
            "Winlogon reported a shell/session notification issue that may reflect disruption around user activity or shutdown.",
            {**base, "sanitized_message": sanitize(message)},
            record_id, end=recorded + timedelta(minutes=10), confidence="medium",
        )

    if provider == "Microsoft-Windows-Hyper-V-StorageVSP" and event_id == "301":
        details = extract_storage_vsp_details(message)
        duration = int(details.get("interval_duration_s", 3600))
        start = recorded - timedelta(seconds=duration)
        return make_candidate(
            device, "virtualized_disk_io_summary", recorded, provider, event_id, log_name, level,
            "Hyper-V/WSL virtual disk I/O summary; path redacted.",
            {**base, **details},
            record_id, start=start, end=recorded, confidence="medium",
        )

    return None


def storage_bucket(device: str, row: dict) -> tuple | None:
    recorded = parse_time(row.get("TimeCreated", ""))
    if recorded is None:
        return None
    provider = row.get("ProviderName", "")
    event_id = row.get("Id", "")
    if provider == "Microsoft-Windows-StorPort" and event_id in {"524", "548"}:
        pass
    elif provider == "Microsoft-Windows-StorDiag" and event_id in {"507", "523"}:
        pass
    else:
        return None
    hour = recorded.replace(minute=0, second=0, microsecond=0)
    return device, provider, event_id, row.get("LogName", ""), row.get("LevelDisplayName", ""), hour


def main() -> None:
    global FILES, OUT_CSV, OUT_MD, SENSITIVE_TERMS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workstation1", type=Path, required=True)
    parser.add_argument("--workstation2", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, default=OUT_CSV)
    parser.add_argument("--review-output", type=Path, default=OUT_MD)
    parser.add_argument(
        "--sensitive-terms-file",
        type=Path,
        help="Private newline-delimited terms to redact; terms are not copied to output.",
    )
    args = parser.parse_args()
    FILES = {"workstation1": args.workstation1, "workstation2": args.workstation2}
    OUT_CSV, OUT_MD = args.output_csv, args.review_output
    if args.sensitive_terms_file:
        SENSITIVE_TERMS = tuple(
            line.strip()
            for line in args.sensitive_terms_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    candidates: list[Candidate] = []
    storage = OrderedDict()
    wer_reports = OrderedDict()
    supplemental = OrderedDict()

    for device, path in FILES.items():
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                cand = row_candidate(device, row)
                if cand:
                    candidates.append(cand)
                bucket = storage_bucket(device, row)
                if bucket:
                    recorded = parse_time(row.get("TimeCreated", ""))
                    entry = storage.setdefault(
                        bucket,
                        {
                            "count": 0,
                            "first": recorded,
                            "last": recorded,
                            "sample": sanitize(row.get("Message", "")),
                            "record_ids": [],
                        },
                    )
                    entry["count"] += 1
                    entry["first"] = min(entry["first"], recorded)
                    entry["last"] = max(entry["last"], recorded)
                    if len(entry["record_ids"]) < 8:
                        entry["record_ids"].append(row.get("RecordId", ""))
                provider = row.get("ProviderName", "")
                event_id = row.get("Id", "")
                message = row.get("Message", "") or ""
                recorded = parse_time(row.get("TimeCreated", ""))
                event_name = wer_event_name(message)
                if provider == "Windows Error Reporting" and event_id == "1001" and recorded and event_name in {"BlueScreen", "LiveKernelEvent"}:
                    report = re.search(r"Report Id:\s*([^\s]+)", message)
                    p1 = re.search(r"P1:\s*([^\s]+)", message)
                    key = (device, event_name, report.group(1) if report else p1.group(1) if p1 else row.get("RecordId", ""))
                    entry = wer_reports.setdefault(
                        key,
                        {
                            "provider": provider,
                            "event_id": event_id,
                            "log_name": row.get("LogName", ""),
                            "level": row.get("LevelDisplayName", ""),
                            "first": recorded,
                            "last": recorded,
                            "count": 0,
                            "record_ids": [],
                            "sample": sanitize(message),
                            "event_name": event_name,
                            "problem_signature_p1": p1.group(1) if p1 else None,
                            "report_id_redacted": "<report_id>",
                        },
                    )
                    entry["count"] += 1
                    entry["first"] = min(entry["first"], recorded)
                    entry["last"] = max(entry["last"], recorded)
                    if len(entry["record_ids"]) < 8:
                        entry["record_ids"].append(row.get("RecordId", ""))
                supp = supplemental_event(device, row)
                if supp:
                    add_supplemental_bucket(supplemental, supp)

    for (device, provider, event_id, log_name, level, hour), entry in storage.items():
        if entry["count"] < 10:
            continue
        start = entry["first"]
        end = entry["last"] + timedelta(minutes=5)
        candidates.append(
            make_candidate(
                device, "storage_health_or_error_window", entry["last"], provider, event_id, log_name, level,
                f"Storage subsystem logged {entry['count']} health/error event(s) in this time window.",
                {
                    "source": "windows_event_log_aggregated",
                    "device": device,
                    "provider": provider,
                    "event_id": event_id,
                    "log_name": log_name,
                    "level": level,
                    "event_count": entry["count"],
                    "sample_record_ids": entry["record_ids"],
                    "sample_sanitized_message": entry["sample"],
                },
                record_id=";".join(entry["record_ids"]),
                start=start,
                end=end,
                confidence="medium",
            )
        )

    for (device, event_name, _report_key), entry in wer_reports.items():
        candidates.append(
            make_candidate(
                device,
                "system_stability_report",
                entry["last"],
                entry["provider"],
                entry["event_id"],
                entry["log_name"],
                entry["level"],
                f"Windows Error Reporting recorded {event_name}; {entry['count']} repeated report row(s) collapsed.",
                {
                    "source": "windows_event_log_aggregated",
                    "device": device,
                    "provider": entry["provider"],
                    "event_id": entry["event_id"],
                    "log_name": entry["log_name"],
                    "level": entry["level"],
                    "event_name": entry["event_name"],
                    "problem_signature_p1": entry["problem_signature_p1"],
                    "event_count": entry["count"],
                    "sample_record_ids": entry["record_ids"],
                    "sample_sanitized_message": entry["sample"],
                },
                record_id=";".join(entry["record_ids"]),
                start=entry["first"],
                end=entry["last"] + timedelta(minutes=10),
                confidence="high",
            )
        )

    for (device, category, _hour), entry in supplemental.items():
        minimum = SUPPLEMENTAL_MIN_EVENTS.get(category, 1)
        if entry["count"] < minimum:
            continue
        top_provider = entry["providers"].most_common(1)[0][0] if entry["providers"] else "multiple"
        top_event_id = entry["event_ids"].most_common(1)[0][0] if entry["event_ids"] else "multiple"
        top_level = entry["levels"].most_common(1)[0][0] if entry["levels"] else ""
        padding = SUPPLEMENTAL_END_PADDING_MINUTES.get(category, 10)
        details = {
            "source": "windows_event_log_aggregated",
            "device": device,
            "category": category,
            "event_count": entry["count"],
            "providers": dict(entry["providers"].most_common()),
            "event_ids": dict(entry["event_ids"].most_common()),
            "levels": dict(entry["levels"].most_common()),
            "event_focus": dict(entry["focus"].most_common()),
            "service_names_redacted": [name for name, _ in entry["service_names"].most_common(8)],
            "device_kinds": dict(entry["device_kinds"].most_common()),
            "max_latency_ms": entry["max_latency_ms"],
            "max_abs_time_delta_ms": entry.get("max_abs_time_delta_ms"),
            "device_path_redacted": entry.get("device_path_redacted"),
            "sample_record_ids": entry["record_ids"],
            "sample_sanitized_message": entry["sample"],
        }
        details = {k: v for k, v in details.items() if v not in (None, [], {}, "")}
        candidates.append(
            make_candidate(
                device,
                category,
                entry["last"],
                top_provider,
                top_event_id,
                "aggregated",
                top_level,
                SUPPLEMENTAL_SUMMARIES.get(category, category.replace("_", " ")),
                details,
                record_id=";".join(entry["record_ids"]),
                start=entry["first"],
                end=entry["last"] + timedelta(minutes=padding),
                confidence="medium",
            )
        )

    candidates.sort(key=lambda c: (c.start, c.device, c.category, c.event_id))

    with OUT_CSV.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "device",
            "category",
            "recorded_unix",
            "start_unix",
            "end_unix",
            "recorded_local",
            "start_local",
            "end_local",
            "provider",
            "event_id",
            "log_name",
            "level",
            "summary",
            "value",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for c in candidates:
            value = {
                "source": "windows_event_log",
                "device": c.device,
                "inverter": 1,
                "context_type": c.category,
                "summary": c.summary,
                "windows_event": c.details,
            }
            writer.writerow(
                {
                    "device": c.device,
                    "category": c.category,
                    "recorded_unix": epoch(c.recorded),
                    "start_unix": epoch(c.start),
                    "end_unix": epoch(c.end),
                    "recorded_local": iso(c.recorded),
                    "start_local": iso(c.start),
                    "end_local": iso(c.end),
                    "provider": c.provider,
                    "event_id": c.event_id,
                    "log_name": c.log_name,
                    "level": c.level,
                    "summary": c.summary,
                    "value": json.dumps(value, ensure_ascii=False, separators=(",", ":")),
                }
            )

    from collections import Counter

    counts = Counter((c.device, c.category) for c in candidates)
    with OUT_MD.open("w", encoding="utf-8") as f:
        f.write("# Windows Event Log Context Candidates\n\n")
        f.write("Generated from the two supplied workstation Event Log CSV exports.\n\n")
        f.write("The extraction intentionally redacts obvious account names, SIDs, IP addresses, GUIDs, and user-profile paths. ")
        f.write("Timestamps are interpreted as Asia/Shanghai local time and exported as Unix seconds for potential insertion into the context table.\n\n")
        f.write("## Category Counts\n\n")
        f.write("| Device | Category | Count |\n|---|---:|---:|\n")
        for (device, category), count in sorted(counts.items()):
            f.write(f"| {device} | {category} | {count} |\n")
        f.write("\n## First 120 Candidates By Time\n\n")
        f.write("| Device | Category | Start local | End local | Provider | Id | Summary |\n|---|---|---:|---:|---|---:|---|\n")
        for c in candidates[:120]:
            f.write(
                f"| {c.device} | {c.category} | {iso(c.start)} | {iso(c.end)} | "
                f"{c.provider} | {c.event_id} | {c.summary} |\n"
            )
        f.write("\nFull review CSV: `windows_event_context_candidates.csv`.\n")

    print(f"wrote {len(candidates)} candidates to {OUT_CSV}")
    print(f"wrote review summary to {OUT_MD}")


if __name__ == "__main__":
    main()
