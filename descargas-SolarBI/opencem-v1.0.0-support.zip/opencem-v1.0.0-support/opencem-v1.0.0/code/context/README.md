# Context construction

The context utilities reduce raw workstation and system logs to structured,
privacy-reviewed intervals. Raw Event Log exports, Bash histories, candidate
review files, account identifiers, credentials, and private repository names are
not distributed.

The released scripts implement the reusable transformations:

- timestamped Bash-history activity windows, with optional working-directory
  trailers and rule-based redaction;
- selected Windows Event categories and interval heuristics;
- deterministic telemetry, solar, and ordinary calendar annotations;
- public university-calendar interval conversion; and
- the manual web-form field contract used for contributed context.

Run the utilities on copies of source logs and inspect their generated candidate
files before database insertion.

