\set ON_ERROR_STOP on

WITH updated AS (
    UPDATE public.context
    SET value = jsonb_set(
        value::jsonb,
        '{context_type}',
        to_jsonb(CASE value::jsonb->>'task_type'
            WHEN 'compilation, CPU load' THEN 'cpu_compilation_workload'
            WHEN 'CNN fitting, GPU load' THEN 'gpu_cnn_training_workload'
        END),
        true
    )::text
    WHERE value::jsonb ? 'task_type'
      AND NOT value::jsonb ? 'context_type'
      AND value::jsonb->>'task_type' IN ('compilation, CPU load', 'CNN fitting, GPU load')
    RETURNING value::jsonb->>'context_type' AS context_type
)
SELECT context_type, count(*) AS updated_rows
FROM updated
GROUP BY 1
ORDER BY 1;

SELECT
    value::jsonb->>'task_type' AS task_type,
    value::jsonb->>'context_type' AS context_type,
    count(*) AS rows
FROM public.context
WHERE value::jsonb ? 'task_type'
GROUP BY 1, 2
ORDER BY 1, 2;
