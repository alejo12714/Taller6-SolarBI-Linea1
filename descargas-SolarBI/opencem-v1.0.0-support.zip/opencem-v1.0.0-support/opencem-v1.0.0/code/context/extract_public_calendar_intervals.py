#!/usr/bin/env python3
"""Convert a reviewed public university-calendar CSV to context-table rows."""

from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo


LOCAL_TZ = ZoneInfo("Asia/Shanghai")


def local_datetime(value: str, *, end: bool = False) -> datetime:
    value = value.strip()
    if len(value) == 10:
        base = datetime.combine(datetime.fromisoformat(value).date(), time.min, LOCAL_TZ)
        return base + timedelta(days=1) if end else base
    parsed = datetime.fromisoformat(value)
    return parsed.replace(tzinfo=LOCAL_TZ) if parsed.tzinfo is None else parsed.astimezone(LOCAL_TZ)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Reviewed CSV with start,end,title,type columns")
    parser.add_argument("output", type=Path)
    parser.add_argument("--recorded", required=True, help="Publication or retrieval timestamp")
    args = parser.parse_args()
    recorded = int(local_datetime(args.recorded).timestamp())
    rows = []
    with args.source.open(encoding="utf-8-sig", newline="") as handle:
        for line, row in enumerate(csv.DictReader(handle), start=2):
            missing = {field for field in ("start", "end", "title", "type") if not row.get(field)}
            if missing:
                raise ValueError(f"line {line}: missing {sorted(missing)}")
            start = local_datetime(row["start"])
            end = local_datetime(row["end"], end=True)
            if end <= start:
                raise ValueError(f"line {line}: end must be after start")
            payload = {
                "source": "manual entry",
                "device": "installation",
                "inverter": 1,
                "context_type": row["type"].strip(),
                "summary": row["title"].strip(),
                "source_kind": "public_university_calendar",
                "timezone": "Asia/Shanghai",
            }
            rows.append(
                {
                    "recorded": recorded,
                    "start": int(start.timestamp()),
                    "end": int(end.timestamp()),
                    "value": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                }
            )
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["recorded", "start", "end", "value"])
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda item: (item["start"], item["end"])))
    print(f"Wrote {len(rows)} reviewed calendar intervals to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

