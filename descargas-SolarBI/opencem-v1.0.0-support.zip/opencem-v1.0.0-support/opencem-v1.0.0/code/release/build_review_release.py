#!/usr/bin/env python3
"""Assemble an unpacked, sanitized OpenCEM release directory."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATASET_TITLE = "OpenCEM: Multimodal photovoltaic and battery microgrid dataset with context records and sky imagery"
DATASET_DOI = "10.5281/zenodo.21436223"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--staging", type=Path, required=True)
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--version", default="1.0.0")
    return parser.parse_args()


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def hardlink_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if os.path.samefile(source, destination):
            return
        destination.unlink()
    os.link(source, destination)


def copy_tree(source: Path, destination: Path, *, ignore=None) -> None:
    shutil.copytree(source, destination, dirs_exist_ok=True, ignore=ignore, copy_function=shutil.copy2)


def code_ignore(_directory: str, names: list[str]) -> set[str]:
    ignored = {
        ".git",
        ".DS_Store",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".venv",
        "__pycache__",
        "build",
        "dist",
        "*.egg-info",
    }
    result = {
        name
        for name in names
        if name in ignored
        or name.endswith((".pyc", ".sqlite", ".sqlite3", ".7z", ".egg-info"))
    }
    result.update(name for name in names if name.startswith("test_") and name.endswith("_report.json"))
    return result


def copy_release_code(staging: Path) -> None:
    code = staging / "code"
    if code.exists():
        shutil.rmtree(code)
    code.mkdir(parents=True)
    copy_tree(ROOT / "repos/opencem_simulator", code / "opencem_simulator", ignore=code_ignore)

    database = code / "database"
    copy_file(ROOT / "database_ingest/export_postgres_to_sqlite.py", database / "export_postgres_to_sqlite.py")
    copy_file(ROOT / "database_ingest/prune_structural_null_columns.py", database / "prune_structural_null_columns.py")
    copy_file(ROOT / "release_tools/public_code/database/README.md", database / "README.md")

    context = code / "context"
    for name in (
        "extract_bash_history_context_candidates.py",
        "extract_windows_event_context_candidates.py",
        "generate_solar_calendar_context.py",
        "import_derived_telemetry_context.sql",
        "add_workload_context_types.sql",
    ):
        copy_file(ROOT / "context_candidates" / name, context / name)
    copy_tree(ROOT / "release_tools/public_code/context", context)

    image = code / "image"
    if image.exists():
        shutil.rmtree(image)
    copy_tree(ROOT / "video_pipeline_package", image, ignore=code_ignore)
    copy_file(ROOT / "release_tools/public_code/image/README.md", image / "README.md")

    copy_tree(ROOT / "release_tools/public_code/acquisition", code / "acquisition")
    for name in (
        "README.md",
        "build_release_candidate.py",
        "build_review_release.py",
        "generate_release_metadata.py",
    ):
        copy_file(ROOT / "release_tools" / name, code / "release" / name)

    visualization = code / "visualization"
    copy_file(ROOT / "visualization_gallery/build_context_gallery.py", visualization / "build_context_gallery.py")
    copy_file(ROOT / "visualization_gallery/build_figure3_candidates.py", visualization / "build_figure3_candidates.py")
    for name in ("build_dataset_atlas.py", "build_schema_register_richness.py"):
        copy_file(
            ROOT / "OpenCEM_Scientific_Data_Dataset_Descriptor/technical_validation" / name,
            visualization / name,
        )
    copy_file(ROOT / "repos/opencem_simulator/LICENSE", code / "LICENSE")


def copy_validation(staging: Path) -> None:
    source = ROOT / "OpenCEM_Scientific_Data_Dataset_Descriptor/technical_validation"
    destination = staging / "validation"
    for name in ("README.md", "requirements.txt", "validate_release.py"):
        copy_file(source / name, destination / name)
    copy_tree(source / "outputs", destination / "outputs", ignore=code_ignore)
    figures = destination / "figures"
    image_source = ROOT / "OpenCEM_Scientific_Data_Dataset_Descriptor/images"
    for path in sorted(image_source.glob("technical_validation_dashboard*")):
        if path.suffix.lower() in {".pdf", ".png"}:
            copy_file(path, figures / path.name)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(8 * 1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def write_release_manifest(staging: Path, version: str) -> None:
    entries = []
    excluded_prefixes = ("sky_images/frames/", ".git/")
    for path in sorted(item for item in staging.rglob("*") if item.is_file()):
        relative = path.relative_to(staging).as_posix()
        if (
            "__pycache__" in path.parts
            or path.suffix == ".pyc"
            or path.name == ".DS_Store"
        ):
            continue
        if relative.startswith(excluded_prefixes) or relative in {
            "manifests/release_manifest.json",
            "manifests/SHA256SUMS.txt",
        }:
            continue
        entries.append(
            {
                "path": relative,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "status": "included",
            }
        )

    image_metadata = json.loads((staging / "documentation/metadata_build_summary.json").read_text())
    entries.append(
        {
            "path": "sky_images/frames/",
            "files": image_metadata["image_count"],
            "size_bytes": image_metadata["image_bytes"],
            "integrity_contract": "documentation/image_manifest.csv",
            "status": "included",
        }
    )
    for month in ("2026-03", "2026-04", "2026-05", "2026-06", "2026-07"):
        entries.append(
            {
                "path": f"opencem-v{version}-sky-{month}.tar.zst",
                "status": "deterministic packaging target",
            }
        )
    entries.append(
        {
            "path": f"opencem-v{version}.sqlite.zst",
            "status": "deterministic packaging target",
        }
    )
    entries.append(
        {
            "path": f"opencem-v{version}-support.zip",
            "status": "deterministic packaging target",
        }
    )
    entries.append(
        {
            "path": f"opencem-v{version}-SHA256SUMS.txt",
            "status": "post-packaging upload checksum target",
        }
    )
    payload = {
        "dataset": "OpenCEM",
        "title": DATASET_TITLE,
        "doi": DATASET_DOI,
        "version": version,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "unpacked release tree and deterministic compressed-archive targets",
        "entries": entries,
    }
    manifests = staging / "manifests"
    manifests.mkdir(parents=True, exist_ok=True)
    (manifests / "release_manifest.json").write_text(json.dumps(payload, indent=2) + "\n")
    manifest_sha = sha256_file(manifests / "release_manifest.json")
    with (manifests / "SHA256SUMS.txt").open("w", encoding="utf-8") as handle:
        for entry in entries:
            if entry.get("sha256"):
                handle.write(f"{entry['sha256']}  {entry['path']}\n")
        handle.write(f"{manifest_sha}  manifests/release_manifest.json\n")


def main() -> int:
    args = parse_args()
    staging = args.staging.resolve()
    staging.mkdir(parents=True, exist_ok=True)
    for residue in staging.rglob(".DS_Store"):
        residue.unlink()

    static = ROOT / "release_tools/release_content"
    (staging / "TODO_MISSING.md").unlink(missing_ok=True)
    for name in ("README.md", "LICENSE-DATA.txt", ".zenodo.json", "CHANGELOG.md"):
        copy_file(static / name, staging / name)

    hardlink_file(args.database.resolve(), staging / "data" / f"opencem-v{args.version}.sqlite")
    for source in sorted(args.image_root.resolve().rglob("*.jpg")):
        hardlink_file(source, staging / "sky_images/frames" / source.relative_to(args.image_root.resolve()))
    shutil.rmtree(staging / "documentation/manuscript", ignore_errors=True)
    copy_tree(args.metadata.resolve(), staging / "documentation", ignore=code_ignore)
    copy_release_code(staging)
    copy_validation(staging)
    write_release_manifest(staging, args.version)

    (staging / ".gitignore").write_text(
        "data/*.sqlite\nsky_images/frames/\n.git/\n.DS_Store\n__pycache__/\n*.pyc\n",
        encoding="utf-8",
    )
    print(f"Assembled unpacked release directory: {staging}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
