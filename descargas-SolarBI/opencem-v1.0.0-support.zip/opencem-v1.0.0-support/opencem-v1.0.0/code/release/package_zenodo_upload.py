#!/usr/bin/env python3
"""Build and verify the deterministic OpenCEM Zenodo upload files."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tarfile
import zipfile


MONTHS = ("2026-03", "2026-04", "2026-05", "2026-06", "2026-07")
DEFAULT_SOURCE_DATE_EPOCH = 315532800  # 1980-01-01T00:00:00Z
COPY_BLOCK_SIZE = 8 * 1024 * 1024


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path, default=Path.cwd())
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--version", default="1.0.0")
    parser.add_argument("--zstd", default="zstd")
    parser.add_argument("--database-level", type=int, default=10)
    parser.add_argument("--image-level", type=int, default=3)
    parser.add_argument(
        "--source-date-epoch",
        type=int,
        default=int(os.environ.get("SOURCE_DATE_EPOCH", DEFAULT_SOURCE_DATE_EPOCH)),
    )
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(COPY_BLOCK_SIZE):
            digest.update(block)
    return digest.hexdigest()


def ensure_safe_member_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts:
        raise RuntimeError(f"Unsafe archive member path: {name}")


def normalized_mode(path: Path) -> int:
    if path.is_dir():
        return 0o755
    return 0o755 if path.stat().st_mode & 0o111 else 0o644


def normalize_tar_info(info: tarfile.TarInfo, source: Path, epoch: int) -> tarfile.TarInfo:
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = epoch
    info.mode = normalized_mode(source)
    info.pax_headers = {}
    return info


def support_files(release_root: Path) -> list[Path]:
    selected = []
    for path in release_root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(release_root)
        if (
            ".git" in relative.parts
            or "__pycache__" in relative.parts
            or relative.parts[0] == "data"
            or relative.parts[:2] == ("sky_images", "frames")
            or path.name == ".DS_Store"
            or path.suffix == ".pyc"
        ):
            continue
        if path.is_symlink():
            raise RuntimeError(f"Symlinks are not permitted in the release: {relative}")
        selected.append(path)
    return sorted(selected, key=lambda item: item.relative_to(release_root).as_posix())


def write_zip_directory(
    archive: zipfile.ZipFile, name: str, date_time: tuple[int, int, int, int, int, int]
) -> None:
    if not name.endswith("/"):
        name += "/"
    info = zipfile.ZipInfo(name, date_time)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_STORED
    info.external_attr = (stat.S_IFDIR | 0o755) << 16 | 0x10
    archive.writestr(info, b"")


def build_support_zip(
    release_root: Path, target: Path, version: str, epoch: int
) -> list[str]:
    files = support_files(release_root)
    prefix = f"opencem-v{version}"
    date_time = datetime.fromtimestamp(epoch, tz=timezone.utc).timetuple()[:6]
    directory_names = {prefix}
    for path in files:
        relative = path.relative_to(release_root)
        parent = PurePosixPath(prefix, relative.as_posix()).parent
        while str(parent) not in (".", ""):
            directory_names.add(parent.as_posix())
            parent = parent.parent

    temporary = target.with_name(target.name + ".part")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        allowZip64=True,
    ) as archive:
        for directory in sorted(
            directory_names, key=lambda item: (item.count("/"), item)
        ):
            write_zip_directory(archive, directory, date_time)
        for path in files:
            relative = path.relative_to(release_root).as_posix()
            member_name = f"{prefix}/{relative}"
            info = zipfile.ZipInfo(member_name, date_time)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | normalized_mode(path)) << 16
            with path.open("rb") as source, archive.open(
                info, mode="w", force_zip64=True
            ) as destination:
                shutil.copyfileobj(source, destination, COPY_BLOCK_SIZE)
    temporary.replace(target)
    return [f"{prefix}/{path.relative_to(release_root).as_posix()}" for path in files]


def compress_database(
    source: Path, target: Path, zstd: str, level: int
) -> None:
    temporary = target.with_name(target.name + ".part")
    temporary.unlink(missing_ok=True)
    subprocess.run(
        [
            zstd,
            "-q",
            f"-{level}",
            "-T1",
            "-f",
            str(source),
            "-o",
            str(temporary),
        ],
        check=True,
    )
    temporary.replace(target)


def iter_month_entries(month_root: Path) -> list[Path]:
    entries = [month_root]
    entries.extend(month_root.rglob("*"))
    return sorted(
        entries,
        key=lambda item: (
            item.relative_to(month_root.parent).as_posix().count("/"),
            item.relative_to(month_root.parent).as_posix(),
        ),
    )


def build_month_archive(
    release_root: Path,
    month: str,
    target: Path,
    zstd: str,
    level: int,
    epoch: int,
) -> dict[str, int]:
    year, month_number = month.split("-")
    month_root = release_root / "sky_images" / "frames" / year / month_number
    if not month_root.is_dir():
        raise FileNotFoundError(month_root)

    temporary = target.with_name(target.name + ".part")
    temporary.unlink(missing_ok=True)
    file_sizes: dict[str, int] = {}
    with temporary.open("wb") as compressed_output:
        process = subprocess.Popen(
            [zstd, "-q", f"-{level}", "-T1", "-c"],
            stdin=subprocess.PIPE,
            stdout=compressed_output,
        )
        if process.stdin is None:
            raise RuntimeError("Unable to open the Zstandard input stream")
        try:
            with tarfile.open(
                fileobj=process.stdin,
                mode="w|",
                format=tarfile.PAX_FORMAT,
                dereference=True,
            ) as archive:
                for path in iter_month_entries(month_root):
                    if path.is_symlink():
                        raise RuntimeError(
                            f"Symlinks are not permitted in the image archive: {path}"
                        )
                    member_name = path.relative_to(release_root).as_posix()
                    ensure_safe_member_name(member_name)
                    info = archive.gettarinfo(str(path), arcname=member_name)
                    normalize_tar_info(info, path, epoch)
                    if path.is_file():
                        file_sizes[member_name] = path.stat().st_size
                        with path.open("rb") as source:
                            archive.addfile(info, source)
                    elif path.is_dir():
                        archive.addfile(info)
                    else:
                        raise RuntimeError(f"Unsupported image-tree entry: {path}")
            process.stdin.close()
            return_code = process.wait()
        except BaseException:
            process.stdin.close()
            process.terminate()
            process.wait()
            temporary.unlink(missing_ok=True)
            raise
    if return_code:
        temporary.unlink(missing_ok=True)
        raise subprocess.CalledProcessError(return_code, process.args)
    temporary.replace(target)
    return file_sizes


def verify_zstd(path: Path, zstd: str) -> None:
    subprocess.run([zstd, "-q", "-t", str(path)], check=True)


def decompressed_sha256(path: Path, zstd: str) -> str:
    process = subprocess.Popen(
        [zstd, "-q", "-d", "-c", str(path)],
        stdout=subprocess.PIPE,
    )
    if process.stdout is None:
        raise RuntimeError("Unable to open the Zstandard output stream")
    digest = hashlib.sha256()
    while block := process.stdout.read(COPY_BLOCK_SIZE):
        digest.update(block)
    process.stdout.close()
    return_code = process.wait()
    if return_code:
        raise subprocess.CalledProcessError(return_code, process.args)
    return digest.hexdigest()


def verify_support_zip(path: Path, expected_files: list[str]) -> None:
    with zipfile.ZipFile(path) as archive:
        failed = archive.testzip()
        if failed:
            raise RuntimeError(f"ZIP CRC verification failed for {failed}")
        actual_files = sorted(
            info.filename for info in archive.infolist() if not info.is_dir()
        )
    if actual_files != sorted(expected_files):
        raise RuntimeError("Support ZIP member set does not match the release tree")


def verify_month_archive(
    archive_path: Path,
    expected_files: dict[str, int],
    zstd: str,
) -> None:
    remaining = dict(expected_files)
    process = subprocess.Popen(
        [zstd, "-q", "-d", "-c", str(archive_path)],
        stdout=subprocess.PIPE,
    )
    if process.stdout is None:
        raise RuntimeError("Unable to open the Zstandard output stream")
    try:
        with tarfile.open(fileobj=process.stdout, mode="r|") as archive:
            for member in archive:
                ensure_safe_member_name(member.name)
                if member.issym() or member.islnk():
                    raise RuntimeError(
                        f"Links are not permitted in image archives: {member.name}"
                    )
                if member.isfile():
                    expected_size = remaining.pop(member.name, None)
                    if expected_size is None:
                        raise RuntimeError(
                            f"Unexpected image archive member: {member.name}"
                        )
                    if member.size != expected_size:
                        raise RuntimeError(
                            f"Size mismatch for image archive member: {member.name}"
                        )
        process.stdout.close()
        return_code = process.wait()
    except BaseException:
        process.stdout.close()
        process.terminate()
        process.wait()
        raise
    if return_code:
        raise subprocess.CalledProcessError(return_code, process.args)
    if remaining:
        raise RuntimeError(
            f"{len(remaining)} expected files are missing from {archive_path.name}"
        )


def write_upload_checksums(output_dir: Path, target: Path) -> list[Path]:
    files = sorted(
        path
        for path in output_dir.iterdir()
        if path.is_file() and path != target and not path.name.endswith(".part")
    )
    with target.open("w", encoding="ascii", newline="\n") as handle:
        for path in files:
            handle.write(f"{sha256_file(path)}  {path.name}\n")
    return files


def verify_upload_checksums(checksum_path: Path) -> None:
    for line in checksum_path.read_text(encoding="ascii").splitlines():
        digest, name = line.split("  ", 1)
        path = checksum_path.parent / name
        if not path.is_file() or sha256_file(path) != digest:
            raise RuntimeError(f"Upload checksum verification failed: {name}")


def format_size(size: int) -> str:
    return f"{size / (1024 ** 3):.2f} GiB" if size >= 1024 ** 3 else f"{size / (1024 ** 2):.2f} MiB"


def main() -> int:
    args = parse_args()
    release_root = args.release_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not shutil.which(args.zstd):
        raise RuntimeError(f"Zstandard executable not found: {args.zstd}")

    version = args.version
    database_source = release_root / "data" / f"opencem-v{version}.sqlite"
    if not database_source.is_file():
        raise FileNotFoundError(database_source)

    expected_names = {
        "README.md",
        "LICENSE-DATA.txt",
        f"opencem-v{version}-support.zip",
        f"opencem-v{version}.sqlite.zst",
        f"opencem-v{version}-SHA256SUMS.txt",
        *(f"opencem-v{version}-sky-{month}.tar.zst" for month in MONTHS),
    }
    existing = sorted(name for name in expected_names if (output_dir / name).exists())
    if existing and not args.force:
        raise RuntimeError(
            "Refusing to overwrite existing upload files: " + ", ".join(existing)
        )

    print("Copying standalone release files...", flush=True)
    shutil.copyfile(release_root / "README.md", output_dir / "README.md")
    shutil.copyfile(
        release_root / "LICENSE-DATA.txt", output_dir / "LICENSE-DATA.txt"
    )

    support_target = output_dir / f"opencem-v{version}-support.zip"
    print(f"Building {support_target.name}...", flush=True)
    support_members = build_support_zip(
        release_root, support_target, version, args.source_date_epoch
    )

    database_target = output_dir / f"opencem-v{version}.sqlite.zst"
    print(f"Building {database_target.name}...", flush=True)
    compress_database(
        database_source, database_target, args.zstd, args.database_level
    )

    month_members: dict[str, dict[str, int]] = {}
    for month in MONTHS:
        target = output_dir / f"opencem-v{version}-sky-{month}.tar.zst"
        print(f"Building {target.name}...", flush=True)
        month_members[month] = build_month_archive(
            release_root,
            month,
            target,
            args.zstd,
            args.image_level,
            args.source_date_epoch,
        )

    checksum_target = output_dir / f"opencem-v{version}-SHA256SUMS.txt"
    print("Writing upload checksums...", flush=True)
    upload_files = write_upload_checksums(output_dir, checksum_target)

    print("Verifying support ZIP...", flush=True)
    verify_support_zip(support_target, support_members)
    print("Verifying compressed database...", flush=True)
    verify_zstd(database_target, args.zstd)
    if decompressed_sha256(database_target, args.zstd) != sha256_file(database_source):
        raise RuntimeError("Compressed database does not reproduce the SQLite source")

    for month in MONTHS:
        target = output_dir / f"opencem-v{version}-sky-{month}.tar.zst"
        print(f"Verifying {target.name}...", flush=True)
        verify_zstd(target, args.zstd)
        verify_month_archive(target, month_members[month], args.zstd)

    verify_upload_checksums(checksum_target)
    print("Verified upload files:", flush=True)
    for path in [*upload_files, checksum_target]:
        print(f"  {path.name}: {format_size(path.stat().st_size)}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
