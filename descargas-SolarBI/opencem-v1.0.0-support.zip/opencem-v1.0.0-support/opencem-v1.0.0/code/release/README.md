# OpenCEM release tooling

These scripts record the fixed assembly order used to produce the OpenCEM
deposit. `build_release_candidate.py` validates a frozen database and image
tree, regenerates metadata, assembles an unpacked release tree, and verifies its
checksums. End-to-end execution requires the source-project layout and the
corresponding source artifacts; the scripts are not required for ordinary use
of the released dataset.

An assembly run from the source-project root has the following form:

```bash
python release_tools/build_release_candidate.py \
  --database /path/to/frozen-opencem.sqlite \
  --image-root /path/to/retained-frames \
  --image-index /path/to/frame-processing-state.sqlite3 \
  --staging /path/to/unpacked-release
```

The private sensitive-string list may additionally be supplied with
`--sensitive-strings-file`; the strings themselves are never written to release
outputs. Deterministic archive compression is performed separately after
validation of the unpacked tree. The final upload files can be built and
verified without intermediate uncompressed tar files:

```bash
python code/release/package_zenodo_upload.py \
  --release-root . \
  --output-dir ../zenodo_upload_v1.0.0
```

The packer normalizes archive timestamps, ownership and permissions; creates
the database, support and monthly image archives; writes upload checksums; and
verifies the database digest, Zstandard streams, ZIP CRCs and archive member
sets.
