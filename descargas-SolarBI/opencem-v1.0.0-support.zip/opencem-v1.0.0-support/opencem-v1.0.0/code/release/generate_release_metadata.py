#!/usr/bin/env python3
"""Generates deterministic metadata for an unpacked OpenCEM release tree."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import mimetypes
import platform
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
DATASET_TITLE = "OpenCEM: Multimodal photovoltaic and battery microgrid dataset with context records and sky imagery"
DATASET_DOI = "10.5281/zenodo.21436223"


TABLE_DESCRIPTIONS = {
    "analog_measurements": "Instantaneous battery, photovoltaic, AC, grid, and inverter measurements.",
    "status": "Operating, charging, alarm, control, and communication states.",
    "totals": "Aggregate power, energy, battery-management, and alarm values.",
    "settings": "Recorded inverter configuration, limits, schedules, and protection settings.",
    "specs": "Repeated device identity, hardware, firmware, protocol, and build metadata.",
    "statistics": "Daily, recent-history, cumulative-energy, and operating-time statistics.",
    "fault_history": "Original fault-history register arrays and calibrated event-time companions.",
    "context": "Privacy-reviewed interval context with separate availability and applicability times.",
}

EXACT_DESCRIPTIONS = {
    "read_ts": "UTC time at which the raw JSON state snapshot was written.",
    "inverter": "Logical inverter identifier (1 or 2) used throughout the release.",
    "id": "Surrogate primary key for the context record.",
    "recorded": "UTC time at which the context item entered the record or was derived.",
    "start": "UTC start of the interval to which the context item applies.",
    "end": "UTC end of the interval to which the context item applies.",
    "value": "Privacy-reviewed JSON object containing context provenance, type, and payload.",
    "presenttime": "Calibrated inverter clock at the acquisition time.",
    "powerontime": "Calibrated device-clock value reported for the power-on event.",
    "stactimeback": "Calibrated device-clock value reported by the statistics clock field.",
    "battvolt": "Battery terminal voltage.",
    "battcurr": "Signed battery current; positive denotes discharge and negative denotes charge.",
    "batsoc": "Battery state of charge reported by the inverter.",
    "pv1volt": "PV input-channel 1 voltage.",
    "pv1curr": "PV input-channel 1 current.",
    "pv1power": "PV input-channel 1 active power.",
}

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--version", default="1.0.0")
    parser.add_argument("--image-cutoff-local")
    parser.add_argument("--electrical-cutoff-utc")
    parser.add_argument("--validation-results", type=Path)
    parser.add_argument("--pruning-report", type=Path)
    parser.add_argument("--export-report", type=Path)
    parser.add_argument("--calibration-report", type=Path)
    return parser.parse_args()


def iso_utc(epoch: float | int | None) -> str | None:
    if epoch is None:
        return None
    return datetime.fromtimestamp(float(epoch), timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def command_version(command: list[str]) -> str | None:
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        return (result.stdout or result.stderr).strip().splitlines()[0]
    except (FileNotFoundError, subprocess.CalledProcessError, IndexError):
        return None


def repository_state(path: Path) -> dict[str, Any] | None:
    try:
        commit = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        status = subprocess.run(
            ["git", "-C", str(path), "status", "--porcelain"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    except (FileNotFoundError, subprocess.CalledProcessError):
        return None
    return {"commit": commit, "dirty_at_metadata_build": bool(status)}


def table_columns(connection: sqlite3.Connection, table: str) -> list[dict[str, Any]]:
    return [
        {
            "position": row[0],
            "name": row[1],
            "type": row[2] or "",
            "not_null": bool(row[3]),
            "default": row[4],
            "primary_key": bool(row[5]),
        }
        for row in connection.execute(f'PRAGMA table_info("{table}")')
    ]


def array_columns(connection: sqlite3.Connection, table: str) -> set[str]:
    arrays: set[str] = set()
    for column in table_columns(connection, table):
        if column["type"].upper() != "TEXT" or table == "context":
            continue
        name = column["name"].replace('"', '""')
        row = connection.execute(
            f'SELECT json_type("{name}") FROM "{table}" '
            f'WHERE "{name}" IS NOT NULL AND json_valid("{name}") LIMIT 1'
        ).fetchone()
        if row and row[0] == "array":
            arrays.add(column["name"])
    return arrays


def unit_for(name: str, is_timestamp: bool, is_array: bool) -> str:
    if is_array:
        return "component-defined"
    if is_timestamp:
        return "s since 1970-01-01 UTC"
    lowered = name.lower()
    if "soc" in lowered or "percent" in lowered:
        return "%"
    if "energy" in lowered or "kwh" in lowered:
        return "kWh"
    if "freq" in lowered:
        return "Hz"
    if "temper" in lowered or "temp" in lowered:
        return "degrees C"
    if "volt" in lowered:
        return "V"
    if "curr" in lowered:
        return "A"
    if "powerva" in lowered or "sumva" in lowered or lowered.endswith(("va", "va_a")):
        return "VA"
    if "power" in lowered or "outw" in lowered or "loadw" in lowered:
        return "W"
    return "unitless or component-defined"


def description_for(table: str, name: str, is_timestamp: bool, is_array: bool) -> str:
    if name in EXACT_DESCRIPTIONS:
        return EXACT_DESCRIPTIONS[name]
    if is_timestamp and name.endswith("_time"):
        base = name.removesuffix("_time")
        return f"Calibrated event time decoded from the historical `{base}` fault payload."
    if is_array:
        return (
            f"JSON array retaining the original multi-register `{name}` payload; "
            "element semantics are component-specific."
        )
    family = TABLE_DESCRIPTIONS[table].split(".", 1)[0].lower()
    readable = name.replace("_", " ")
    return (
        f"Processed `{readable}` field in the {family}; the stable release name is retained "
        "for machine use and component-specific details follow the inverter documentation."
    )


def write_schema(connection: sqlite3.Connection, output: Path) -> None:
    rows = connection.execute(
        "SELECT type, name, sql FROM sqlite_master "
        "WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' "
        "ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 ELSE 2 END, name"
    ).fetchall()
    lines = ["-- OpenCEM SQLite schema, generated from the frozen release database.", "PRAGMA foreign_keys=ON;", ""]
    for _kind, _name, sql in rows:
        lines.extend((sql.rstrip(";") + ";", ""))
    output.write_text("\n".join(lines), encoding="utf-8")


def write_dictionary(connection: sqlite3.Connection, output_dir: Path) -> dict[str, int]:
    records: list[dict[str, Any]] = []
    tables = [
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    for table in tables:
        arrays = array_columns(connection, table)
        for column in table_columns(connection, table):
            name = column["name"]
            is_timestamp = name in {"read_ts", "recorded", "start", "end", "presenttime", "powerontime", "stactimeback"} or name.endswith("_time")
            is_array = name in arrays
            if table == "context" and name == "value":
                encoding = "JSON object encoded as UTF-8 text"
            elif is_array:
                encoding = "JSON array encoded as UTF-8 text"
            elif is_timestamp:
                encoding = "fractional Unix timestamp in UTC"
            else:
                encoding = column["type"].upper() or "SQLite dynamic type"
            records.append(
                {
                    "table": table,
                    "column": name,
                    "position": column["position"],
                    "sqlite_type": column["type"].upper(),
                    "unit": unit_for(name, is_timestamp, is_array),
                    "scale_and_sign": "already converted; no additional register scaling" if table != "context" else "not applicable",
                    "encoding": encoding,
                    "description": description_for(table, name, is_timestamp, is_array),
                    "missing_or_sentinel": "SQL NULL denotes missing/unavailable; no imputation" if name not in {"id", "inverter"} else "not expected to be NULL",
                    "applicability": "both inverters unless values are absent; inactive structural channels were pruned" if table != "context" else "source-specific; inspect the JSON payload",
                }
            )
    fields = list(records[0])
    with (output_dir / "column_dictionary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (output_dir / "column_dictionary.json").write_text(
        json.dumps(
            {
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "timestamp_encoding": "fractional Unix seconds in UTC",
                "array_encoding": "JSON text",
                "tables": TABLE_DESCRIPTIONS,
                "columns": records,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return {table: sum(record["table"] == table for record in records) for table in tables}


def parse_image_timestamp(path: Path) -> datetime:
    # The trailing Z is part of the recorder's historical naming convention;
    # the digits reproduce the visible camera-local Asia/Shanghai clock.
    return datetime.strptime(path.stem, "%Y%m%dT%H%M%SZ").replace(tzinfo=ZoneInfo("Asia/Shanghai"))


def write_image_manifest(image_root: Path, output: Path, version: str) -> dict[str, Any]:
    paths = sorted(image_root.rglob("*.jpg"))
    total_bytes = 0
    first_local: datetime | None = None
    last_local: datetime | None = None
    dimensions: dict[str, int] = {}
    with output.open("w", encoding="utf-8", newline="") as handle:
        fields = [
            "relative_path",
            "camera_local_time",
            "utc_time",
            "timezone",
            "width_px",
            "height_px",
            "size_bytes",
            "sha256",
            "planned_monthly_archive",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for path in paths:
            local = parse_image_timestamp(path)
            first_local = local if first_local is None else min(first_local, local)
            last_local = local if last_local is None else max(last_local, local)
            size = path.stat().st_size
            total_bytes += size
            with Image.open(path) as image:
                width, height = image.size
            dimensions[f"{width}x{height}"] = dimensions.get(f"{width}x{height}", 0) + 1
            writer.writerow(
                {
                    "relative_path": path.relative_to(image_root).as_posix(),
                    "camera_local_time": local.isoformat(),
                    "utc_time": local.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
                    "timezone": "Asia/Shanghai",
                    "width_px": width,
                    "height_px": height,
                    "size_bytes": size,
                    "sha256": sha256_file(path, 1024 * 1024),
                    "planned_monthly_archive": f"opencem-v{version}-sky-{local:%Y-%m}.tar.zst",
                }
            )
    return {
        "count": len(paths),
        "size_bytes": total_bytes,
        "first_camera_local": first_local.isoformat() if first_local else None,
        "last_camera_local": last_local.isoformat() if last_local else None,
        "dimensions": dimensions,
        "sha256_manifest": sha256_file(output),
    }


def database_summary(connection: sqlite3.Connection) -> dict[str, Any]:
    result: dict[str, Any] = {}
    tables = [
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    for table in tables:
        columns = table_columns(connection, table)
        if table == "context":
            start, end = connection.execute("SELECT MIN(start), MAX(end) FROM context").fetchone()
        else:
            start, end = connection.execute(f'SELECT MIN(read_ts), MAX(read_ts) FROM "{table}"').fetchone()
        result[table] = {
            "rows": connection.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0],
            "columns": len(columns),
            "start_utc": iso_utc(start),
            "end_utc": iso_utc(end),
        }
    return result


def sanitize_paths(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: sanitize_paths(item) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize_paths(item) for item in value]
    if isinstance(value, str) and value.startswith(("/Users/", "/private/", "/home/")):
        return Path(value).name
    return value


def sanitized_json_copy(source: Path | None, output: Path) -> None:
    if source is None or not source.exists():
        return
    payload = sanitize_paths(json.loads(source.read_text(encoding="utf-8")))
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    database = args.database.resolve()
    image_root = args.image_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(f"file:{database}?mode=ro", uri=True) as connection:
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {integrity}")
        write_schema(connection, output_dir / "schema.sql")
        dictionary_counts = write_dictionary(connection, output_dir)
        tables = database_summary(connection)

    image_summary = write_image_manifest(
        image_root, output_dir / "image_manifest.csv", args.version
    )
    electrical_cutoff_utc = args.electrical_cutoff_utc or max(
        details["end_utc"]
        for table, details in tables.items()
        if table != "context" and details["end_utc"]
    )
    image_cutoff_local = args.image_cutoff_local or image_summary["last_camera_local"]
    database_hash = sha256_file(database)

    provenance = {
        "dataset": "OpenCEM",
        "title": DATASET_TITLE,
        "doi": DATASET_DOI,
        "doi_url": f"https://doi.org/{DATASET_DOI}",
        "version": args.version,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "release_state": "public Zenodo release",
        "cutoff_policy": {
            "electrical_cutoff_utc": electrical_cutoff_utc,
            "image_cutoff_camera_local": image_cutoff_local,
            "image_timezone": "Asia/Shanghai",
            "cross_modal_endpoint_policy": "The image archive intentionally extends beyond the electrical endpoint; consumers must use the modality-specific ranges recorded in the manifests.",
        },
        "database": {
            "filename": f"opencem-v{args.version}.sqlite",
            "size_bytes": database.stat().st_size,
            "sha256": database_hash,
            "integrity_check": "ok",
            "timestamp_encoding": "fractional Unix seconds in UTC",
            "array_encoding": "JSON text",
            "tables": tables,
            "dictionary_column_counts": dictionary_counts,
        },
        "images": image_summary,
        "historical_fault_timestamps": {
            "policy": "Each distinct fault payload is anchored to the clock regime at its first observed appearance; later device-clock changes do not alter earlier event times.",
            "original_arrays_retained": True,
            "calibrated_companion_columns": 32,
        },
        "privacy": {
            "context": "rule-based redaction plus private sensitive-string full-text review",
            "images": "automated candidate ranking followed by manual review and deletion before manifest construction",
            "removed_image_count_disclosure": "aggregate only",
        },
        "code_repositories": {
            "simulator": repository_state(ROOT / "repos/opencem_simulator"),
        },
        "tools": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "sqlite_runtime": sqlite3.sqlite_version,
            "psql": command_version(["psql", "--version"]),
            "pg_dump": command_version(["pg_dump", "--version"]),
            "zstd": command_version(["zstd", "--version"]),
            "ffmpeg": command_version(["ffmpeg", "-version"]),
            "tesseract": command_version(["tesseract", "--version"]),
        },
    }
    (output_dir / "provenance.json").write_text(
        json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    sanitized_json_copy(args.export_report, output_dir / "database_export_report.json")
    sanitized_json_copy(args.pruning_report, output_dir / "release_pruning.json")
    sanitized_json_copy(args.calibration_report, output_dir / "timestamp_calibration_report.json")
    sanitized_json_copy(args.validation_results, output_dir / "validation_results.json")

    summary = {
        "title": DATASET_TITLE,
        "doi": DATASET_DOI,
        "database_sha256": database_hash,
        "database_size_bytes": database.stat().st_size,
        "dictionary_columns": sum(dictionary_counts.values()),
        "image_count": image_summary["count"],
        "image_bytes": image_summary["size_bytes"],
        "image_manifest_sha256": image_summary["sha256_manifest"],
    }
    (output_dir / "metadata_build_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
