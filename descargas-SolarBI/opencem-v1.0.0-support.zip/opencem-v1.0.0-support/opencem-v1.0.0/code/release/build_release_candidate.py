#!/usr/bin/env python3
"""Validate source artifacts and assemble an unpacked OpenCEM release tree."""

from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANUSCRIPT = ROOT / "OpenCEM_Scientific_Data_Dataset_Descriptor"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--staging", type=Path, required=True)
    parser.add_argument("--version", default="1.0.0")
    parser.add_argument("--image-index", type=Path)
    parser.add_argument("--sensitive-strings-file", type=Path)
    return parser.parse_args()


def run(command: list[str], *, cwd: Path = ROOT) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def verify_checksums(staging: Path) -> None:
    checksums = staging / "manifests/SHA256SUMS.txt"
    for line in checksums.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        digest = hashlib.sha256()
        with (staging / relative).open("rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != expected:
            raise RuntimeError(f"Checksum mismatch: {relative}")


def main() -> int:
    args = parse_args()
    database = args.database.resolve()
    image_root = args.image_root.resolve()
    staging = args.staging.resolve()
    generated = ROOT / "release_build/generated"

    validation = [
        sys.executable,
        str(MANUSCRIPT / "technical_validation/validate_release.py"),
        "--database",
        str(database),
        "--image-root",
        str(image_root),
        "--results-dir",
        str(MANUSCRIPT / "technical_validation/outputs"),
        "--manuscript-dir",
        str(MANUSCRIPT),
    ]
    if args.image_index:
        validation.extend(("--image-index", str(args.image_index.resolve())))
    if args.sensitive_strings_file:
        validation.extend(("--sensitive-strings-file", str(args.sensitive_strings_file.resolve())))
    run(validation)

    metadata = [
        sys.executable,
        str(ROOT / "release_tools/generate_release_metadata.py"),
        "--database",
        str(database),
        "--image-root",
        str(image_root),
        "--output-dir",
        str(generated),
        "--version",
        args.version,
        "--validation-results",
        str(MANUSCRIPT / "technical_validation/outputs/validation_results.json"),
        "--pruning-report",
        str(ROOT / "opencem_dataset_current.sqlite.prune.json"),
        "--export-report",
        str(ROOT / "opencem_dataset_current.sqlite.export.json"),
        "--calibration-report",
        str(ROOT / "database_ingest/inverter_timestamp_calibration_report.json"),
    ]
    run(metadata)
    run(
        [
            sys.executable,
            str(ROOT / "release_tools/build_review_release.py"),
            "--database",
            str(database),
            "--image-root",
            str(image_root),
            "--metadata",
            str(generated),
            "--staging",
            str(staging),
            "--version",
            args.version,
        ]
    )
    verify_checksums(staging)
    print(f"Verified unpacked release tree: {staging}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
