import json
import math
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import numpy as np
from typing import Any, Dict, List, Optional, Tuple, Type, Union

from opencem.clock import Clock
from opencem.interfaces import (
    Battery,
    BatteryStepInput,
    BatteryStepMode,
    BatteryStepResult,
    Context,
    ContextRecord,
    Grid,
    GridStepInput,
    GridStepResult,
    Inverter,
    InverterStepInput,
    InverterStepResult,
    Load,
    LoadStepResult,
    PowerSource,
    PowerSourceStepResult,
)

INVERTER_READING_TABLES = (
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
)
OPEN_METEO_VARIABLES = (
    "temperature_2m",
    "relative_humidity_2m",
    "precipitation",
    "cloud_cover",
    "wind_speed_10m",
    "shortwave_radiation",
    "direct_radiation",
    "diffuse_radiation",
)
INSTALLATION_LATITUDE = 22.693001
INSTALLATION_LONGITUDE = 114.211386
LOCAL_TZ = timezone(timedelta(hours=8), "Asia/Shanghai")


def load_context(con: sqlite3.Connection, now: Clock) -> List[ContextRecord]:
    cur = con.cursor()
    query = """
        SELECT recorded, start, end, value 
        FROM context
        WHERE end >= ?
    """
    cur.execute(query, (now.to_seconds(),))
    rows = cur.fetchall()
    return [
        ContextRecord(
            Clock.from_seconds(row[0]),
            Clock.from_seconds(row[1]),
            Clock.from_seconds(row[2]),
            json.loads(row[3]),
        )
        for row in rows
    ]


def table_exists(con: sqlite3.Connection, table_name: str) -> bool:
    cur = con.cursor()
    cur.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (table_name,))
    return cur.fetchone() is not None


def decode_sqlite_value(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    stripped = value.strip()
    if not stripped or stripped[0] not in "[{":
        return value
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        return value


def load_inverter_row(con: sqlite3.Connection, table_name: str, inv: int, ts: float) -> Optional[Dict[str, Any]]:
    if table_name not in INVERTER_READING_TABLES or not table_exists(con, table_name):
        return None
    cur = con.cursor()
    cur.execute(
        f"""
        SELECT *
        FROM {table_name}
        WHERE inverter = :inv
          AND read_ts <= :ts
        ORDER BY read_ts DESC
        LIMIT 1
        """,
        {"inv": inv, "ts": ts},
    )
    row = cur.fetchone()
    if row is None:
        cur.execute(
            f"""
            SELECT *
            FROM {table_name}
            WHERE inverter = :inv
            ORDER BY read_ts ASC
            LIMIT 1
            """,
            {"inv": inv},
        )
        row = cur.fetchone()
    if row is None:
        return None
    columns = [description[0] for description in cur.description]
    return {column: decode_sqlite_value(value) for column, value in zip(columns, row)}


def load_inverter_readings(
    con: sqlite3.Connection,
    inv: int,
    ts: float,
    tables: Tuple[str, ...] = INVERTER_READING_TABLES,
) -> Dict[str, Dict[str, Any]]:
    readings = {}
    for table_name in tables:
        row = load_inverter_row(con, table_name, inv, ts)
        if row is not None:
            readings[table_name] = row
    return readings


def fetch_open_meteo_weather_context(
    start: Clock,
    end: Clock,
    *,
    latitude: float = INSTALLATION_LATITUDE,
    longitude: float = INSTALLATION_LONGITUDE,
    variables: Tuple[str, ...] = OPEN_METEO_VARIABLES,
    timeout_seconds: float = 20.0,
) -> List[ContextRecord]:
    start_dt = datetime.fromtimestamp(start.to_seconds(), tz=timezone.utc)
    end_dt = datetime.fromtimestamp(end.to_seconds(), tz=timezone.utc)
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "start_date": start_dt.date().isoformat(),
        "end_date": end_dt.date().isoformat(),
        "hourly": ",".join(variables),
        "timezone": "UTC",
    }
    url = "https://archive-api.open-meteo.com/v1/archive?" + urlencode(params)
    request = Request(url, headers={"User-Agent": "opencem-simulator/1.0"})
    with urlopen(request, timeout=timeout_seconds) as response:
        payload = json.loads(response.read().decode("utf-8"))
    hourly = payload.get("hourly", {})
    times = hourly.get("time", [])
    records = []
    for index, time_text in enumerate(times):
        ts = datetime.fromisoformat(time_text).replace(tzinfo=timezone.utc).timestamp()
        if ts < start.to_seconds() or ts > end.to_seconds():
            continue
        values = {}
        for variable in variables:
            series = hourly.get(variable)
            if series is not None and index < len(series):
                values[variable] = series[index]
        value = {
            "source": "open_meteo",
            "context_type": "weather_hourly",
            "device": "installation",
            "latitude": latitude,
            "longitude": longitude,
            "timezone": "UTC",
            "variables": values,
        }
        records.append(
            ContextRecord(
                recorded_at=Clock.from_seconds(ts),
                start=Clock.from_seconds(ts),
                end=Clock.from_seconds(ts + 3600),
                payload=value,
            )
        )
    return records


def inverter_column_exists(con: sqlite3.Connection, column: str) -> bool:
    return any(
        row[1] == column
        for row in con.execute("PRAGMA table_info(analog_measurements)")
    )


def load_inverter_array(
    con: sqlite3.Connection, col: str, inv: int, ts: float
) -> np.ndarray:
    if not inverter_column_exists(con, col):
        raise ValueError(f"Unknown analog_measurements column: {col}")
    cur = con.cursor()
    query = f"""
        SELECT read_ts, {col}
        FROM analog_measurements
        WHERE inverter = :inv
          AND {col} IS NOT NULL
          AND read_ts >= COALESCE((
              SELECT MAX(read_ts)
              FROM analog_measurements
              WHERE inverter = :inv
                AND {col} IS NOT NULL
                AND read_ts <= :ts
          ), (
              SELECT MIN(read_ts)
              FROM analog_measurements
              WHERE inverter = :inv
                AND {col} IS NOT NULL
          ))
        ORDER BY read_ts
    """
    cur.execute(query, {"inv": inv, "ts": ts})
    rows = cur.fetchall()
    return np.array(rows, dtype=float)

def interpolate_value(arr: np.ndarray, ts: float) -> float:
    """Linearly interpolate ``[timestamp, value]`` rows at ``ts``."""
    if arr.ndim != 2 or arr.shape[0] == 0 or arr.shape[1] != 2:
        raise ValueError("Cannot interpolate an empty or malformed reading array")
    times = arr[:, 0]
    values = arr[:, 1]
    if ts < times[0] or ts > times[-1]:
        raise ValueError(
            f"Timestamp {ts} is outside available range {times[0]}..{times[-1]}"
        )
    idx = int(np.searchsorted(times, ts, side="left"))
    if idx < len(times) and times[idx] == ts:
        return float(values[idx])
    if idx == 0 or idx == len(times):
        raise ValueError(f"Timestamp {ts} cannot be bracketed for interpolation")
    t0, t1 = times[idx - 1], times[idx]
    v0, v1 = values[idx - 1], values[idx]
    frac = (ts - t0) / (t1 - t0)
    return float(v0 + frac * (v1 - v0))


class BatteryDataset(Battery):
    def __init__(self, clock: Clock, inverter_id: int, database: sqlite3.Connection):
        self.clock = clock
        self.battvolt = load_inverter_array(con = database, col = "battvolt", inv = inverter_id, ts = clock.to_seconds())
        self.battcurr = load_inverter_array(con = database, col = "battcurr", inv = inverter_id, ts = clock.to_seconds())
        self.battsoc  = load_inverter_array(con = database, col = "battsoc", inv = inverter_id, ts = clock.to_seconds())
        self.nominal_voltage = 55

    def step(self, step_ticks: int, battery_input : Optional[BatteryStepInput], *args, **kwargs) -> BatteryStepResult:
        next_clock = self.clock.advance(step_ticks)
        hours_passed = Clock.difference_hours(self.clock, next_clock)
        battvolt = interpolate_value(arr = self.battvolt, ts = self.clock.to_seconds())
        battcurr = interpolate_value(arr = self.battcurr, ts = self.clock.to_seconds())
        battsoc = interpolate_value(arr = self.battsoc, ts = self.clock.to_seconds())
        discharge_energy_j = battvolt * battcurr * hours_passed * 3600
        discharge_capacity_c = discharge_energy_j / self.nominal_voltage
        self.clock = next_clock
        return BatteryStepResult(voltage_v = battvolt or self.nominal_voltage,
                                 current_a = battcurr or 0,
                                 soc = battsoc / 100 or 0,
                                 discharge_capacity_c = discharge_capacity_c or 0,
                                 discharge_energy_j = discharge_energy_j or 0)

class LoadDataset(Load):
    def __init__(self, clock: Clock, inverter_id: int, database: sqlite3.Connection):
        self.clock = clock
        self.outcurra = load_inverter_array(con = database, col = "outcurra", inv = inverter_id, ts = clock.to_seconds())
        self.outvolta = load_inverter_array(con = database, col = "outvolta", inv = inverter_id, ts = clock.to_seconds())
        self.outva_a  = load_inverter_array(con = database, col = "outva_a", inv = inverter_id, ts = clock.to_seconds())
        self.outw_a   = load_inverter_array(con = database, col = "outw_a", inv = inverter_id, ts = clock.to_seconds())

    def step(self, step_ticks: int, *args, **kwargs) -> LoadStepResult:
        next_clock = self.clock.advance(step_ticks)
        outcurra = interpolate_value(arr = self.outcurra, ts = self.clock.to_seconds())
        outvolta = interpolate_value(arr = self.outvolta, ts = self.clock.to_seconds())
        outva_a = interpolate_value(arr = self.outva_a, ts = self.clock.to_seconds())
        outw_a = interpolate_value(arr = self.outw_a, ts = self.clock.to_seconds())
        self.clock = next_clock
        return LoadStepResult(current_a = outcurra,
                              voltage_v = outvolta,
                              power_apparent_va = outva_a,
                              power_active_w = outw_a)

class BlockSampledDataset():
    def sample_new_block(self):
        block = self.rng.integers(0, self.blocks)
        self.clock = self.start_clock.advance_seconds(60 * 60 * self.block_hours * block)
        self.end = self.clock.advance_seconds(60*60*self.block_hours)
        self.ds = self.cls(self.clock, self.inverter_id, self.database)

    def __init__(self, cls: Type, start_clock: Clock, end_clock: Clock, inverter_id: int, database: sqlite3.Connection, block_hours : float = 6.0, seed: int = 0):
        self.database = database
        self.start_clock = start_clock
        self.inverter_id = inverter_id
        self.blocks = math.floor(Clock.difference_hours(start_clock, end_clock)/8)
        self.block_hours = block_hours
        self.rng = np.random.default_rng(seed)
        self.cls = cls
        self.sample_new_block()

    def step(self, step_ticks: int, *args, **kwargs):
        if self.clock > self.end:
            self.sample_new_block()
        self.clock = self.clock.advance(step_ticks)
        return self.ds.step(step_ticks, *args, **kwargs)

class GridDataset(Grid):
    def __init__(self, clock: Clock, inverter_id: int, database: sqlite3.Connection):
        self.clock = clock
        self.linepowerva_a = load_inverter_array(con = database, col = "linepowerva_a", inv = inverter_id, ts = clock.to_seconds())
        self.linepowerw_a = load_inverter_array(con = database, col = "linepowerw_a", inv = inverter_id, ts = clock.to_seconds())

    def step(self, step_ticks: int, grid_input: Optional[GridStepInput], *args, **kwargs) -> GridStepResult:
        next_clock = self.clock.advance(step_ticks)
        linepowerva_a = interpolate_value(arr = self.linepowerva_a, ts = self.clock.to_seconds())
        linepowerw_a = interpolate_value(arr = self.linepowerw_a, ts = self.clock.to_seconds())
        self.clock = next_clock
        return GridStepResult(power_delivered_apparent_va = linepowerva_a,
                              power_delivered_active_w = linepowerw_a)

class PowerSourceDataset(PowerSource):
    def __init__(self, clock: Clock, inverter_id: int, database: sqlite3.Connection):
        self.pv1volt = load_inverter_array(con = database, col = "pv1volt", inv = inverter_id, ts = clock.to_seconds())
        self.pv1curr = load_inverter_array(con = database, col = "pv1curr", inv = inverter_id, ts = clock.to_seconds())
        self.pv1power = load_inverter_array(con = database, col = "pv1power", inv = inverter_id, ts = clock.to_seconds())
        self.clock = clock

    def step(self, step_ticks: int, *args, **kwargs) -> PowerSourceStepResult:
        next_clock = self.clock.advance(step_ticks)
        pv1volt = interpolate_value(arr = self.pv1volt, ts = self.clock.to_seconds())
        pv1curr = interpolate_value(arr = self.pv1curr, ts = self.clock.to_seconds())
        pv1power = interpolate_value(arr = self.pv1power, ts = self.clock.to_seconds())
        self.clock = next_clock
        return PowerSourceStepResult(voltage_v = pv1volt,
                                     current_a = pv1curr,
                                     power_w = pv1power)

class InverterDataset(Inverter):
    def __init__(
        self,
        clock: Clock,
        inverter_id: int,
        database: sqlite3.Connection,
        include_readings: bool = True,
    ):
        self.clock = clock
        self.inverter_id = inverter_id
        self.database = database
        self.include_readings = include_readings
        self.battcurr = load_inverter_array(con = database, col = "battcurr", inv = inverter_id, ts = clock.to_seconds())
        self.linepowerw_a = load_inverter_array(con = database, col = "linepowerw_a", inv = inverter_id, ts = clock.to_seconds())
        self.linepowerva_a = load_inverter_array(con = database, col = "linepowerva_a", inv = inverter_id, ts = clock.to_seconds())
        self.pv1power = load_inverter_array(con = database, col = "pv1power", inv = inverter_id, ts = clock.to_seconds())

    def step(self, step_ticks: int, inverter_input: InverterStepInput, *args, **kwargs) -> InverterStepResult:
        next_clock = self.clock.advance(step_ticks)
        battcurr = interpolate_value(arr = self.battcurr, ts = self.clock.to_seconds())
        pv1power = interpolate_value(arr = self.pv1power, ts = self.clock.to_seconds())
        linepowerva_a = interpolate_value(arr = self.linepowerva_a, ts = self.clock.to_seconds())
        linepowerw_a = interpolate_value(arr = self.linepowerw_a, ts = self.clock.to_seconds())
        readings = load_inverter_readings(self.database, self.inverter_id, self.clock.to_seconds()) if self.include_readings else {}
        self.clock = next_clock
        return InverterStepResult(next_battery_input = BatteryStepInput(mode = BatteryStepMode.CHARGE if battcurr < 0 else BatteryStepMode.DISCHARGE if battcurr > 0 else BatteryStepMode.IDLE,
                                                                        current_a = abs(battcurr)),
                                  next_grid_input = GridStepInput(power_demand_apparent_va = linepowerva_a,
                                                                  power_demand_active_w = linepowerw_a),
                                  generator_power_drawn_w = pv1power,
                                  readings = readings)

class ContextDataset(Context):
    def __init__(
        self,
        clock: Clock,
        horizon_ticks: int,
        database: sqlite3.Connection,
        *,
        include_weather: bool = False,
        weather_latitude: float = INSTALLATION_LATITUDE,
        weather_longitude: float = INSTALLATION_LONGITUDE,
        weather_variables: Tuple[str, ...] = OPEN_METEO_VARIABLES,
        weather_timeout_seconds: float = 20.0,
        image_root: Optional[Union[str, Path]] = None,
    ):
        self.clock = clock
        self.database = database
        self.all_context = load_context(database, clock)
        self.horizon = horizon_ticks
        self.include_weather = include_weather
        self.weather_latitude = weather_latitude
        self.weather_longitude = weather_longitude
        self.weather_variables = weather_variables
        self.weather_timeout_seconds = weather_timeout_seconds
        self.weather_loaded_until: Optional[Clock] = None
        self.image_root = None if image_root is None else Path(image_root)
        if include_weather:
            self._ensure_weather_loaded(self.clock.advance(self.horizon))

    def _ensure_weather_loaded(self, until: Clock) -> None:
        if self.weather_loaded_until is not None and self.weather_loaded_until.ticks >= until.ticks:
            return
        start = (
            self.clock
            if self.weather_loaded_until is None
            else self.weather_loaded_until.advance_seconds(1)
        )
        weather_records = fetch_open_meteo_weather_context(
            start,
            until,
            latitude=self.weather_latitude,
            longitude=self.weather_longitude,
            variables=self.weather_variables,
            timeout_seconds=self.weather_timeout_seconds,
        )
        existing = {
            (record.start.ticks, record.payload.get("source"))
            for record in self.all_context
            if isinstance(record.payload, dict)
        }
        self.all_context.extend(
            record
            for record in weather_records
            if (record.start.ticks, record.payload.get("source")) not in existing
        )
        self.weather_loaded_until = until

    def closest_image(self, clock: Optional[Clock] = None, max_delta_seconds: int = 90) -> Optional[Path]:
        if self.image_root is None:
            return None
        target_clock = clock or self.clock
        target_utc = datetime.fromtimestamp(target_clock.to_seconds(), tz=timezone.utc)
        target_local = target_utc.astimezone(LOCAL_TZ).replace(second=0, microsecond=0)
        max_minutes = max(0, math.ceil(max_delta_seconds / 60))
        best_path = None
        best_delta = None
        for minute_delta in range(-max_minutes, max_minutes + 1):
            candidate_local = target_local + timedelta(minutes=minute_delta)
            candidate_utc = candidate_local.astimezone(timezone.utc)
            # Released filenames preserve the camera-local overlay digits.
            candidate_paths = (
                self.image_root
                / candidate_local.strftime("%Y/%m/%d")
                / candidate_local.strftime("%Y%m%dT%H%M00Z.jpg"),
                self.image_root
                / candidate_local.strftime("%Y-%m-%d")
                / candidate_local.strftime("%Y-%m-%d-%H-%M.jpg"),
            )
            candidate_path = next(
                (path for path in candidate_paths if path.exists()), None
            )
            if candidate_path is None:
                continue
            delta_seconds = abs((candidate_utc - target_utc).total_seconds())
            if best_delta is None or delta_seconds < best_delta:
                best_path = candidate_path
                best_delta = delta_seconds
        return best_path

    def closest_image_record(self, clock: Optional[Clock] = None, max_delta_seconds: int = 90) -> Optional[ContextRecord]:
        image_path = self.closest_image(clock, max_delta_seconds)
        if image_path is None:
            return None
        target_clock = clock or self.clock
        payload = {
            "source": "sky_image_archive",
            "context_type": "sky_image",
            "device": "installation",
            "path": str(image_path),
        }
        return ContextRecord(target_clock, target_clock, target_clock, payload)

    def step(self, step_ticks: int) -> List[ContextRecord]:
        now = self.clock
        if self.include_weather:
            self._ensure_weather_loaded(now.advance(self.horizon))
        self.clock = self.clock.advance(step_ticks)
        out = [c for c in self.all_context if c.end > now and now > c.recorded_at and now.advance(self.horizon) > c.start]
        return out

class BlockSampledContext():
    def sample_new_block(self):
        block = self.rng.integers(0, self.blocks)
        self.clock = self.start_clock.advance_seconds(60 * 60 * self.block_hours * block)
        self.end = self.clock.advance_seconds(60*60*self.block_hours)
        self.ds = ContextDataset(self.clock, self.horizon_ticks, self.database, **self.context_kwargs)

    def __init__(self, start_clock: Clock, end_clock: Clock, horizon_ticks: int, database: sqlite3.Connection, block_hours : float = 6.0, seed: int = 0, **context_kwargs):
        self.database = database
        self.start_clock = start_clock
        self.horizon_ticks = horizon_ticks
        self.context_kwargs = context_kwargs
        self.blocks = math.floor(Clock.difference_hours(start_clock, end_clock)/8)
        self.block_hours = block_hours
        self.rng = np.random.default_rng(seed)
        self.sample_new_block()

    def step(self, step_ticks: int):
        if self.clock > self.end:
            self.sample_new_block()
        self.clock = self.clock.advance(step_ticks)
        return self.ds.step(step_ticks)
