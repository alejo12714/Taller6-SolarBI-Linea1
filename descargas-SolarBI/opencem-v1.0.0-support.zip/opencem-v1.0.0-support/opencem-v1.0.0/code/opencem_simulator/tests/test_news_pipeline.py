from __future__ import annotations

from io import BytesIO
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

from warcio.statusandheaders import StatusAndHeaders
from warcio.warcwriter import WARCWriter


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPOSITORY_ROOT / "scripts" / "pull_shenzhen_news_context.py"


class NewsPipelineTest(unittest.TestCase):
    def build_warc(self, path: Path) -> None:
        article = """<!doctype html><html><head><title>Longgang energy update</title></head>
        <body><article><h1>Longgang energy update</h1>
        <p>Researchers in Longgang District, Shenzhen reported a new energy
        systems project near the university campus. The project brings together
        engineers, students, and local infrastructure specialists to study how
        distributed resources respond to changing urban demand.</p>
        <p>The team collected operational observations throughout the day and
        reviewed the measurements before publication. Their work connects local
        conditions with renewable generation, battery operation, and electricity
        use across a working installation.</p>
        <p>Additional records describe weather, maintenance, and computing
        activity. These records provide enough context for later researchers to
        compare physical measurements with events in the surrounding city.</p>
        </article></body></html>""".encode("utf-8")
        headers = StatusAndHeaders(
            "200 OK", [("Content-Type", "text/html; charset=utf-8")], "HTTP/1.0"
        )
        with path.open("wb") as output:
            writer = WARCWriter(output, gzip=True)
            record = writer.create_warc_record(
                "https://example.org/longgang-energy",
                "response",
                payload=BytesIO(article),
                http_headers=headers,
            )
            try:
                writer.write_record(record)
            finally:
                record.raw_stream.close()

    def run_pipeline(self, warc: Path, database: Path, report: Path) -> None:
        subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "--warc",
                str(warc),
                "--database",
                str(database),
                "--report",
                str(report),
            ],
            check=True,
            cwd=REPOSITORY_ROOT,
        )

    def test_warc_to_deduplicated_context(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            warc = root / "sample.warc.gz"
            database = root / "sample.sqlite"
            report = root / "report.json"
            self.build_warc(warc)

            self.run_pipeline(warc, database, report)
            self.run_pipeline(warc, database, report)

            with sqlite3.connect(database) as connection:
                rows = connection.execute("SELECT value FROM context").fetchall()
            self.assertEqual(len(rows), 1)
            payload = json.loads(rows[0][0])
            self.assertEqual(payload["context_type"], "local_news_article")
            self.assertEqual(payload["source"], "common_crawl_news")
            self.assertEqual(
                {entity["name"] for entity in payload["geocoded_entities"]},
                {"Longgang District", "Shenzhen"},
            )
            self.assertEqual(payload["target_coordinates"]["latitude"], 22.693001)
            self.assertEqual(json.loads(report.read_text())["counters"]["duplicates"], 1)


if __name__ == "__main__":
    unittest.main()
