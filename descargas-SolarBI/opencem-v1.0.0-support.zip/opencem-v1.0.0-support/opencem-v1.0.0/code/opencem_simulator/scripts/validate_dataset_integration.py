#!/usr/bin/env python3
"""Runs release integration checks against an extracted OpenCEM SQLite file."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from opencem.clock import Clock
from opencem.dataset import (
    BatteryDataset,
    ContextDataset,
    GridDataset,
    InverterDataset,
    LoadDataset,
    PowerSourceDataset,
    fetch_open_meteo_weather_context,
)
from opencem.simulator import Simulator


REQUIRED_ANALOG_COLUMNS = (
    "battvolt",
    "battcurr",
    "battsoc",
    "outcurra",
    "outvolta",
    "outva_a",
    "outw_a",
    "linepowerva_a",
    "linepowerw_a",
    "pv1volt",
    "pv1curr",
    "pv1power",
)
EXPECTED_READING_TABLES = {
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", required=True, type=Path)
    parser.add_argument("--inverter", type=int, default=1)
    parser.add_argument("--image-root", type=Path)
    parser.add_argument(
        "--image-time",
        help="UTC ISO timestamp for a known image, for example 2026-03-29T11:13:00Z.",
    )
    parser.add_argument("--weather", action="store_true")
    parser.add_argument("--news-database", type=Path)
    parser.add_argument("--report", type=Path)
    return parser.parse_args()


def integration_timestamp(connection: sqlite3.Connection, inverter: int) -> float:
    predicates = " AND ".join(f"{column} IS NOT NULL" for column in REQUIRED_ANALOG_COLUMNS)
    row = connection.execute(
        f"""
        WITH boundary AS (
            SELECT max(read_ts) - 3600 AS cutoff
            FROM analog_measurements
            WHERE inverter = ?
        )
        SELECT read_ts
        FROM analog_measurements, boundary
        WHERE inverter = ?
          AND read_ts <= boundary.cutoff
          AND {predicates}
        ORDER BY read_ts DESC
        LIMIT 1
        """,
        (inverter, inverter),
    ).fetchone()
    if row is None:
        raise RuntimeError("No fully populated integration interval was found")
    return float(row[0])


def sqlite_type(connection: sqlite3.Connection, table: str, column: str) -> str:
    for row in connection.execute(f"PRAGMA table_info({table})"):
        if row[1] == column:
            return str(row[2]).upper()
    raise RuntimeError(f"Missing {table}.{column}")


def test_simulator(database: Path, inverter: int) -> dict[str, object]:
    with sqlite3.connect(database) as connection:
        timestamp = integration_timestamp(connection, inverter)
        clock = Clock.from_seconds(timestamp)
        horizon = 60 * clock.RES
        battery = BatteryDataset(clock, inverter, connection)
        load = LoadDataset(clock, inverter, connection)
        grid = GridDataset(clock, inverter, connection)
        source = PowerSourceDataset(clock, inverter, connection)
        inverter_model = InverterDataset(clock, inverter, connection)
        context = ContextDataset(clock, horizon, connection)
        result = Simulator(
            source, battery, load, grid, inverter_model, clock, context
        ).step(horizon)
        missing = EXPECTED_READING_TABLES - set(result.inverter.readings)
        if missing:
            raise RuntimeError(f"Missing inverter reading tables: {sorted(missing)}")
        if sqlite_type(connection, "settings", "presenttime") != "REAL":
            raise RuntimeError("settings.presenttime is not a SQLite REAL timestamp")
        if sqlite_type(connection, "statistics", "powerontime") != "REAL":
            raise RuntimeError("statistics.powerontime is not a SQLite REAL timestamp")
        fault_time_columns = [
            row[1]
            for row in connection.execute("PRAGMA table_info(fault_history)")
            if row[1].startswith("faulthistoryrecord") and row[1].endswith("_time")
        ]
        if len(fault_time_columns) != 32:
            raise RuntimeError(f"Expected 32 fault timestamps, found {len(fault_time_columns)}")
        return {
            "timestamp": timestamp,
            "timestamp_utc": datetime.fromtimestamp(
                timestamp, tz=timezone.utc
            ).isoformat(),
            "reading_tables": sorted(result.inverter.readings),
            "fault_timestamp_columns": len(fault_time_columns),
            "context_records": len(result.context),
            "battery_soc": result.battery.soc,
            "pv_power_w": result.power_source.power_w,
            "load_power_w": result.load.power_active_w,
        }


def test_image(image_root: Path, image_time: str, database: Path) -> str:
    timestamp = datetime.fromisoformat(image_time.replace("Z", "+00:00")).timestamp()
    clock = Clock.from_seconds(timestamp)
    with sqlite3.connect(database) as connection:
        context = ContextDataset(
            clock, clock.RES, connection, image_root=image_root
        )
        path = context.closest_image(max_delta_seconds=90)
    if path is None:
        raise RuntimeError(f"No image found near {image_time}")
    try:
        return path.resolve().relative_to(image_root.resolve()).as_posix()
    except ValueError:
        return path.name


def test_weather(database: Path) -> dict[str, object]:
    start = Clock.from_string("2025-12-18T00:00:00Z")
    end = Clock.from_string("2025-12-18T06:00:00Z")
    records = fetch_open_meteo_weather_context(start, end)
    if not records or not records[0].payload.get("variables"):
        raise RuntimeError("Open-Meteo returned no usable hourly records")
    with sqlite3.connect(database) as connection:
        context = ContextDataset(
            start,
            end.ticks - start.ticks,
            connection,
            include_weather=True,
        )
        integrated_records = [
            record
            for record in context.all_context
            if record.payload.get("source") == "open_meteo"
        ]
    if not integrated_records:
        raise RuntimeError("ContextDataset did not include Open-Meteo records")
    return {
        "records": len(records),
        "integrated_records": len(integrated_records),
        "variables": sorted(records[0].payload["variables"]),
    }


def test_news(database: Path) -> dict[str, object]:
    with sqlite3.connect(database) as connection:
        row = connection.execute(
            """
            SELECT value
            FROM context
            WHERE json_extract(value, '$.source') = 'common_crawl_news'
            LIMIT 1
            """
        ).fetchone()
    if row is None:
        raise RuntimeError("No Common Crawl News context record was found")
    payload = json.loads(row[0])
    if not payload.get("geocoded_entities"):
        raise RuntimeError("News context record has no geocoded entities")
    return {
        "url": payload.get("url"),
        "entities": payload["geocoded_entities"],
    }


def main() -> int:
    args = parse_args()
    report: dict[str, object] = {
        "database": args.database.name,
        "simulator": test_simulator(args.database, args.inverter),
    }
    if args.image_root or args.image_time:
        if not args.image_root or not args.image_time:
            raise ValueError("--image-root and --image-time must be provided together")
        report["image"] = test_image(
            args.image_root, args.image_time, args.database
        )
    if args.weather:
        report["weather"] = test_weather(args.database)
    if args.news_database:
        report["news"] = test_news(args.news_database)
    output = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
    print(output, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
