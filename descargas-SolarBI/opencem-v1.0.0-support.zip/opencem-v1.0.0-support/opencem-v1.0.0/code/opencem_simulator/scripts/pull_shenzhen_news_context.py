#!/usr/bin/env python3
"""Add geographically relevant CC-NEWS articles to an OpenCEM SQLite file.

The pipeline follows the staged extraction, quality filtering, location-entity
recognition, and geocoding method described by Kriesch and Losacker, "A
geolocated dataset of German news articles", Scientific Data 12, 1128 (2025),
https://doi.org/10.1038/s41597-025-05422-w. Because this helper targets one
known installation locality, its named-entity recognizer and gazetteer are
small, explicit, and multilingual rather than country-wide statistical models.

The script can scan the WARC shards listed for a CC-NEWS month or one or more
local/remote ``.warc.gz`` files. It streams each WARC, extracts article text,
applies reproducible quality rules, resolves Shenzhen-area place entities, and
writes deduplicated JSON records to the released ``context`` table.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
import gzip
import hashlib
import html
import io
import json
import logging
from pathlib import Path
import re
import sqlite3
from typing import Any, BinaryIO, Iterator, Sequence
from urllib.parse import urlparse, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from langdetect import DetectorFactory, LangDetectException, detect
import trafilatura
from warcio.archiveiterator import ArchiveIterator


COMMON_CRAWL_NEWS_ROOT = "https://data.commoncrawl.org/crawl-data/CC-NEWS"
COMMON_CRAWL_OBJECT_ROOT = "https://data.commoncrawl.org"
INSTALLATION_COORDINATES = (22.693001, 114.211386)
DetectorFactory.seed = 0


@dataclass(frozen=True)
class Place:
    canonical_name: str
    level: str
    aliases: tuple[str, ...]


PLACES = (
    Place(
        "CUHK-Shenzhen",
        "campus",
        (
            "CUHK-Shenzhen",
            "CUHK Shenzhen",
            "Chinese University of Hong Kong, Shenzhen",
            "Chinese University of Hong Kong (Shenzhen)",
            "香港中文大学（深圳）",
            "香港中文大学(深圳)",
            "香港中文大學（深圳）",
            "港中深",
        ),
    ),
    Place(
        "Longcheng Subdistrict",
        "subdistrict",
        ("Longcheng", "Longcheng Subdistrict", "龙城", "龍城"),
    ),
    Place(
        "Longgang District",
        "district",
        ("Longgang", "Longgang District", "龙岗", "龍崗"),
    ),
    Place(
        "Shenzhen",
        "city",
        ("Shenzhen", "Shen Zhen", "深圳"),
    ),
)


@dataclass
class Counters:
    warc_files: int = 0
    response_records: int = 0
    html_records: int = 0
    extracted_articles: int = 0
    quality_passed: int = 0
    locality_matched: int = 0
    inserted: int = 0
    duplicates: int = 0
    extraction_errors: int = 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "year_month",
        nargs="?",
        help="CC-NEWS month as YYYY/MM; omit when every input uses --warc.",
    )
    parser.add_argument(
        "--warc",
        action="append",
        default=[],
        help="Local path or URL of a .warc.gz file. May be repeated.",
    )
    parser.add_argument(
        "--database", required=True, type=Path, help="OpenCEM SQLite file to update."
    )
    parser.add_argument(
        "--limit-files", type=int, help="Cap month-derived WARC shards."
    )
    parser.add_argument(
        "--max-records",
        type=int,
        help="Stop after this many inserted matches; intended only for smoke tests.",
    )
    parser.add_argument(
        "--timeout", type=float, default=120.0, help="HTTP timeout in seconds."
    )
    parser.add_argument(
        "--text-limit",
        type=int,
        default=5000,
        help="Maximum extracted article characters stored in each JSON value.",
    )
    parser.add_argument(
        "--commit-every", type=int, default=250, help="Inserted rows per transaction."
    )
    parser.add_argument(
        "--report",
        type=Path,
        help="Optional JSON run report; defaults next to the database.",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Scan and report without modifying SQLite."
    )
    return parser.parse_args()


def request(url: str, timeout: float):
    return urlopen(
        Request(url, headers={"User-Agent": "opencem-news-context/1.0"}),
        timeout=timeout,
    )


def download_bytes(url: str, timeout: float) -> bytes:
    with request(url, timeout) as response:
        return response.read()


def warc_paths_for_month(year_month: str, timeout: float) -> list[str]:
    if not re.fullmatch(r"\d{4}/\d{2}", year_month):
        raise ValueError("year_month must use YYYY/MM format")
    compressed = download_bytes(
        f"{COMMON_CRAWL_NEWS_ROOT}/{year_month}/warc.paths.gz", timeout
    )
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        return [line.decode("utf-8").strip() for line in stream if line.strip()]


def resolve_warc_sources(args: argparse.Namespace) -> list[str]:
    sources = list(args.warc)
    if args.year_month:
        month_paths = warc_paths_for_month(args.year_month, args.timeout)
        if args.limit_files is not None:
            month_paths = month_paths[: args.limit_files]
        sources.extend(f"{COMMON_CRAWL_OBJECT_ROOT}/{path}" for path in month_paths)
    if not sources:
        raise ValueError("provide year_month, --warc, or both")
    return sources


@contextmanager
def open_warc(source: str, timeout: float) -> Iterator[BinaryIO]:
    if source.startswith(("http://", "https://")):
        response = request(source, timeout)
        try:
            with gzip.GzipFile(fileobj=response) as stream:
                yield stream
        finally:
            response.close()
    else:
        with gzip.open(Path(source).expanduser(), "rb") as stream:
            yield stream


def is_html_response(record) -> bool:
    if record.rec_type != "response":
        return False
    if record.http_headers:
        status = record.http_headers.get_statuscode()
        if status and not str(status).startswith("2"):
            return False
        mime = (record.http_headers.get_header("Content-Type") or "").lower()
        if mime and "html" not in mime and "xhtml" not in mime:
            return False
    return True


def iter_warc_articles(source: str, timeout: float, counters: Counters):
    with open_warc(source, timeout) as stream:
        for record in ArchiveIterator(stream):
            if record.rec_type == "response":
                counters.response_records += 1
            if not is_html_response(record):
                continue
            counters.html_records += 1
            url = record.rec_headers.get_header("WARC-Target-URI")
            if not url:
                continue
            yield {
                "url": url,
                "warc_record_id": record.rec_headers.get_header("WARC-Record-ID"),
                "warc_date": record.rec_headers.get_header("WARC-Date"),
                "content": record.content_stream().read(),
            }


def strip_html(value: str) -> str:
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", value)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def normalized_language(value: str | None) -> str | None:
    if not value:
        return None
    language = value.strip().lower().replace("_", "-").split("-")[0]
    return {"zh-cn": "zh", "zh-tw": "zh"}.get(language, language)


def detect_language(text: str) -> str | None:
    if len(text.strip()) < 40:
        return None
    han_characters = len(re.findall(r"[\u3400-\u9fff]", text))
    kana_or_hangul = len(
        re.findall(r"[\u3040-\u30ff\uac00-\ud7af]", text)
    )
    if han_characters >= 40 and kana_or_hangul == 0:
        return "zh"
    try:
        return normalized_language(detect(text[:10000]))
    except LangDetectException:
        return None


def extract_article(content: bytes, url: str, warc_date: str | None) -> dict[str, Any] | None:
    decoded = content.decode("utf-8", errors="replace")
    extracted = trafilatura.extract(
        decoded,
        include_comments=False,
        deduplicate=True,
        output_format="json",
        with_metadata=True,
        url=url,
    )
    if extracted:
        root = json.loads(extracted)
        text = root.get("raw_text") or root.get("text") or ""
        language = normalized_language(root.get("language") or root.get("lang"))
        detected = detect_language(text)
        if detected == "zh":
            language = detected
        return {
            "title": root.get("title"),
            "text": text,
            "excerpt": root.get("excerpt"),
            "date": root.get("date"),
            "language": language or detected,
            "hostname": root.get("hostname") or urlparse(url).hostname,
            "date_crawled": root.get("filedate") or warc_date,
        }
    fallback = strip_html(decoded)
    if not fallback:
        return None
    return {
        "title": None,
        "text": fallback,
        "excerpt": None,
        "date": None,
        "language": detect_language(fallback),
        "hostname": urlparse(url).hostname,
        "date_crawled": warc_date,
    }


SENTENCE_PATTERN = re.compile(r"[^.!?。！？]+[.!?。！？]?")
CJK_PATTERN = re.compile(r"[\u3400-\u9fff]")


def quality_metrics(text: str) -> dict[str, float | int]:
    lines = text.splitlines() or [text]
    words = text.split()
    non_alpha = sum(not any(character.isalpha() for character in word) for word in words)
    return {
        "fraction_non_alpha_words": non_alpha / len(words) if words else 0.0,
        "mean_word_length": (
            sum(len(word) for word in words) / len(words) if words else 0.0
        ),
        "javascript_count": text.lower().count("javascript"),
        "words_per_line": len(words) / len(lines) if lines else 0.0,
        "sentences_count": len(
            [part for part in SENTENCE_PATTERN.findall(text) if part.strip()]
        ),
        "word_count": len(words),
        "cjk_character_count": len(CJK_PATTERN.findall(text)),
    }


def passes_quality(metrics: dict[str, float | int]) -> bool:
    if metrics["javascript_count"] != 0 or metrics["sentences_count"] < 3:
        return False
    if metrics["cjk_character_count"] >= 80:
        return True
    return bool(
        metrics["fraction_non_alpha_words"] < 0.1
        and metrics["words_per_line"] > 5
        and 3 <= metrics["mean_word_length"] <= 12
        and 50 <= metrics["word_count"] <= 10000
    )


def alias_pattern(alias: str) -> re.Pattern[str]:
    escaped = re.escape(alias)
    if re.search(r"[A-Za-z]", alias):
        return re.compile(rf"(?i)(?<![A-Za-z]){escaped}(?![A-Za-z])")
    return re.compile(escaped)


PLACE_PATTERNS = tuple(
    (place, alias, alias_pattern(alias))
    for place in PLACES
    for alias in sorted(place.aliases, key=len, reverse=True)
)


def recognize_and_geocode_places(article: dict[str, Any]) -> list[dict[str, Any]]:
    text = "\n".join(
        str(article.get(field) or "") for field in ("title", "excerpt", "text")
    )
    matches: dict[str, dict[str, Any]] = {}
    for place, alias, pattern in PLACE_PATTERNS:
        count = len(pattern.findall(text))
        if not count:
            continue
        current = matches.setdefault(
            place.canonical_name,
            {
                "name": place.canonical_name,
                "level": place.level,
                "matched_aliases": [],
                "mention_count": 0,
            },
        )
        current["matched_aliases"].append(alias)
        current["mention_count"] += count
    if "Longcheng Subdistrict" in matches and not (
        {"Longgang District", "Shenzhen", "CUHK-Shenzhen"} & matches.keys()
    ):
        del matches["Longcheng Subdistrict"]
    if set(matches) == {"Shenzhen"}:
        title = str(article.get("title") or "")
        title_mentions = sum(
            len(pattern.findall(title))
            for place, _alias, pattern in PLACE_PATTERNS
            if place.canonical_name == "Shenzhen"
        )
        if title_mentions == 0 and matches["Shenzhen"]["mention_count"] < 3:
            del matches["Shenzhen"]
    return list(matches.values())


def location_scope(places: list[dict[str, Any]]) -> str:
    names = {place["name"] for place in places}
    if "CUHK-Shenzhen" in names:
        return "CUHK-Shenzhen, Longgang District, Shenzhen"
    if "Longcheng Subdistrict" in names:
        return "Longcheng Subdistrict, Longgang District, Shenzhen"
    if "Longgang District" in names:
        return "Longgang District, Shenzhen"
    return "Shenzhen"


def parse_timestamp(value: str | None, fallback: str | None = None) -> int:
    for candidate in (value, fallback):
        if not candidate:
            continue
        text = str(candidate).strip()
        try:
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
                dt = datetime.fromisoformat(text).replace(tzinfo=timezone.utc)
            else:
                dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp())
        except ValueError:
            try:
                dt = parsedate_to_datetime(text)
                return int(dt.timestamp())
            except (TypeError, ValueError):
                continue
    return int(datetime.now(tz=timezone.utc).timestamp())


def canonical_url(url: str) -> str:
    parts = urlsplit(url)
    query = "&".join(
        item
        for item in parts.query.split("&")
        if item and not item.lower().startswith(("utm_", "fbclid=", "gclid="))
    )
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path, query, ""))


def ensure_context_table(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS context (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recorded INTEGER,
            start INTEGER,
            end INTEGER,
            value TEXT
        )
        """
    )
    connection.execute("CREATE INDEX IF NOT EXISTS idx_context_start ON context(start)")
    connection.commit()


def context_row_exists(connection: sqlite3.Connection, url: str, content_hash: str) -> bool:
    try:
        return (
            connection.execute(
                """
                SELECT 1
                FROM context
                WHERE json_extract(value, '$.source') = 'common_crawl_news'
                  AND (
                      json_extract(value, '$.url') = ?
                      OR json_extract(value, '$.content_sha256') = ?
                  )
                LIMIT 1
                """,
                (url, content_hash),
            ).fetchone()
            is not None
        )
    except sqlite3.OperationalError:
        return False


def insert_article(
    connection: sqlite3.Connection,
    article: dict[str, Any],
    raw: dict[str, Any],
    places: list[dict[str, Any]],
    metrics: dict[str, float | int],
    source_warc: str,
    text_limit: int,
) -> bool:
    text = article.get("text") or ""
    url = canonical_url(raw["url"])
    content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    if context_row_exists(connection, url, content_hash):
        return False
    start = parse_timestamp(article.get("date"), raw.get("warc_date"))
    recorded = parse_timestamp(raw.get("warc_date"), article.get("date"))
    value = {
        "source": "common_crawl_news",
        "context_type": "local_news_article",
        "location_scope": location_scope(places),
        "target_coordinates": {
            "latitude": INSTALLATION_COORDINATES[0],
            "longitude": INSTALLATION_COORDINATES[1],
        },
        "geocoded_entities": places,
        "url": url,
        "title": article.get("title"),
        "excerpt": article.get("excerpt"),
        "text": text[:text_limit],
        "text_truncated": len(text) > text_limit,
        "content_sha256": content_hash,
        "hostname": article.get("hostname"),
        "language": article.get("language"),
        "article_date": article.get("date"),
        "date_crawled": article.get("date_crawled") or raw.get("warc_date"),
        "quality_metrics": metrics,
        "warc_record_id": raw.get("warc_record_id"),
        "warc_source": source_warc.rsplit("/", 1)[-1],
        "method_reference": "https://doi.org/10.1038/s41597-025-05422-w",
    }
    connection.execute(
        "INSERT INTO context(recorded, start, end, value) VALUES (?, ?, ?, ?)",
        (
            recorded,
            start,
            start + int(timedelta(days=1).total_seconds()),
            json.dumps(value, ensure_ascii=False, sort_keys=True),
        ),
    )
    return True


def process_warc(
    connection: sqlite3.Connection,
    source: str,
    args: argparse.Namespace,
    counters: Counters,
) -> bool:
    counters.warc_files += 1
    logging.info("Scanning WARC %d: %s", counters.warc_files, source)
    for raw in iter_warc_articles(source, args.timeout, counters):
        try:
            article = extract_article(raw["content"], raw["url"], raw["warc_date"])
        except (json.JSONDecodeError, UnicodeError, ValueError) as error:
            counters.extraction_errors += 1
            logging.debug("Article extraction failed for %s: %s", raw["url"], error)
            continue
        if not article:
            continue
        counters.extracted_articles += 1
        metrics = quality_metrics(article.get("text") or "")
        if not passes_quality(metrics):
            continue
        counters.quality_passed += 1
        places = recognize_and_geocode_places(article)
        if not places:
            continue
        counters.locality_matched += 1
        if args.dry_run:
            print(
                json.dumps(
                    {
                        "url": raw["url"],
                        "title": article.get("title"),
                        "places": places,
                    },
                    ensure_ascii=False,
                )
            )
        elif insert_article(
            connection,
            article,
            raw,
            places,
            metrics,
            source,
            args.text_limit,
        ):
            counters.inserted += 1
            if counters.inserted % args.commit_every == 0:
                connection.commit()
        else:
            counters.duplicates += 1
        if args.max_records is not None and counters.inserted >= args.max_records:
            return True
    return False


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("trafilatura").setLevel(logging.CRITICAL)
    logging.getLogger("htmldate").setLevel(logging.CRITICAL)
    if args.commit_every < 1 or args.text_limit < 1:
        raise ValueError("--commit-every and --text-limit must be positive")
    sources = resolve_warc_sources(args)
    counters = Counters()
    args.database = args.database.expanduser().resolve()
    report_path = args.report or args.database.with_suffix(".news-import.json")
    with sqlite3.connect(args.database) as connection:
        ensure_context_table(connection)
        for source in sources:
            if process_warc(connection, source, args, counters):
                break
        if args.dry_run:
            connection.rollback()
        else:
            connection.commit()
    report = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "database": str(args.database),
        "dry_run": args.dry_run,
        "method_reference": "https://doi.org/10.1038/s41597-025-05422-w",
        "sources": sources,
        "counters": asdict(counters),
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    logging.info("Finished: %s", json.dumps(asdict(counters), sort_keys=True))
    logging.info("Report: %s", report_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
