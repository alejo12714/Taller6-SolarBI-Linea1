# OpenCEM Simulator

OpenCEM provides simulation components and Python helpers for the accompanying
*OpenCEM: Multimodal photovoltaic and battery microgrid dataset with context
records and sky imagery*.

## Installation

Python 3.10 or newer is required.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

Install the optional Common Crawl News dependencies with:

```bash
pip install -e '.[news]'
```

## Dataset Access

Download the compressed SQLite artifact and sky-image archives from the
[Zenodo dataset](https://doi.org/10.5281/zenodo.21436223), then extract them
locally.
The database contains these public tables:

```text
analog_measurements  context       fault_history  settings
specs                statistics    status         totals
```

The four context interval columns are Unix seconds. Measurement tables use
`read_ts` in Unix seconds. Calibrated inverter clock fields are also Unix
timestamps in SQLite; JSON arrays and objects are decoded by the Python helper.

## Recorded Readings

`InverterDataset.step()` preserves the control-oriented result fields and adds
`result.readings`, keyed by measurement table. Each entry is the nearest row at
or before the current timestamp and contains every released column.

```python
import sqlite3

from opencem.clock import Clock
from opencem.dataset import load_inverter_readings

clock = Clock.from_string("2025-12-18 12:00:00+08:00")
with sqlite3.connect("data/opencem-v1.0.0.sqlite") as database:
    readings = load_inverter_readings(database, inv=1, ts=clock.to_seconds())
    print(readings["analog_measurements"]["pv1power"])
    print(readings["fault_history"]["faulthistoryrecord00_time"])
```

The dataset-backed `BatteryDataset`, `LoadDataset`, `GridDataset`,
`PowerSourceDataset`, and `InverterDataset` classes can be composed with
`opencem.simulator.Simulator`. The notebook in `notebooks/` gives a complete
example after its `dataset_db` path is set to the downloaded SQLite file.

## Context Helpers

Context records already deposited in SQLite are available through
`ContextDataset`. Open-Meteo archive data can be included at runtime; network
enrichment is disabled by default.

```python
from opencem.dataset import ContextDataset

context = ContextDataset(
    clock,
    horizon_ticks=24 * 60 * 60 * clock.RES,
    database=database,
    include_weather=True,
)
```

When the extracted sky-image root is supplied, the same class resolves the
nearest available minute image without scanning the archive:

```python
context = ContextDataset(
    clock,
    horizon_ticks=clock.RES,
    database=database,
    image_root="sky_images/frames",
)
nearest = context.closest_image(max_delta_seconds=90)
```

## Shenzhen News

`scripts/pull_shenzhen_news_context.py` streams Common Crawl News WARC files,
extracts article text, applies quality rules, recognizes and geocodes local
place entities, and inserts deduplicated records into a working copy of the
SQLite `context` table.

```bash
python scripts/pull_shenzhen_news_context.py 2026/03 \
  --database data/opencem-v1.0.0.sqlite \
  --limit-files 2
```

The implementation adapts the extraction, named-entity recognition, and
geocoding method of Kriesch and Losacker, *A geolocated dataset of German news
articles*, Scientific Data 12, 1128 (2025),
[doi:10.1038/s41597-025-05422-w](https://doi.org/10.1038/s41597-025-05422-w).
Its gazetteer is limited to Shenzhen, Longgang, Longcheng, and the
CUHK-Shenzhen campus hierarchy for this dataset.

## Tests

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Citation

Please cite the dataset as DOI
[10.5281/zenodo.21436223](https://doi.org/10.5281/zenodo.21436223). The
simulator code is licensed under the MIT License; dataset licensing is stated
separately in the Zenodo record.
