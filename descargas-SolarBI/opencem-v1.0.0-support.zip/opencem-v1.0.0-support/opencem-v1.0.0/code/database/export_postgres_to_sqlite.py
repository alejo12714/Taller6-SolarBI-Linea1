#!/usr/bin/env python3
"""Stream the OpenCEM release tables from PostgreSQL into SQLite.

The exporter uses PostgreSQL COPY for extraction and batched SQLite inserts for
loading.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time


RELEASE_TABLES = (
    ("measurement", "analog_measurements"),
    ("measurement", "status"),
    ("measurement", "totals"),
    ("measurement", "settings"),
    ("measurement", "specs"),
    ("measurement", "statistics"),
    ("measurement", "fault_history"),
    ("public", "context"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=5432)
    parser.add_argument("--user", default="postgres")
    parser.add_argument("--database", default="opencem")
    parser.add_argument("--batch-size", type=int, default=5_000)
    parser.add_argument(
        "--limit-per-table",
        type=int,
        help="Export at most this many rows per table (smoke tests only).",
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def pg_quote(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def sqlite_quote(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


class Postgres:
    def __init__(self, args: argparse.Namespace) -> None:
        self.base_command = [
            "psql",
            "-h",
            args.host,
            "-p",
            str(args.port),
            "-U",
            args.user,
            "-d",
            args.database,
            "-X",
            "-v",
            "ON_ERROR_STOP=1",
        ]
        self.env = os.environ.copy()

    def query_rows(self, sql: str) -> list[list[str]]:
        result = subprocess.run(
            self.base_command + ["-A", "-t", "-F", "\t", "-c", sql],
            env=self.env,
            check=True,
            capture_output=True,
            text=True,
        )
        return [line.split("\t") for line in result.stdout.splitlines() if line]

    def copy_process(self, sql: str) -> subprocess.Popen[bytes]:
        return subprocess.Popen(
            self.base_command + ["-q", "-c", sql],
            env=self.env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )


def get_columns(pg: Postgres, schema: str, table: str) -> list[dict[str, str]]:
    sql = f"""
        SELECT column_name, data_type, udt_name, is_nullable
        FROM information_schema.columns
        WHERE table_schema = {sql_literal(schema)}
          AND table_name = {sql_literal(table)}
        ORDER BY ordinal_position
    """
    rows = pg.query_rows(sql)
    if not rows:
        raise RuntimeError(f"No columns found for {schema}.{table}")
    return [
        {
            "name": name,
            "data_type": data_type,
            "udt_name": udt_name,
            "nullable": nullable,
        }
        for name, data_type, udt_name, nullable in rows
    ]


def sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def sqlite_type(column: dict[str, str]) -> str:
    data_type = column["data_type"]
    if data_type in {"smallint", "integer", "bigint", "boolean"}:
        return "INTEGER"
    if data_type in {
        "numeric",
        "real",
        "double precision",
        "timestamp with time zone",
        "timestamp without time zone",
    }:
        return "REAL"
    return "TEXT"


def create_table(
    connection: sqlite3.Connection,
    table: str,
    columns: list[dict[str, str]],
) -> None:
    definitions = []
    for column in columns:
        name = column["name"]
        definition = f"{sqlite_quote(name)} {sqlite_type(column)}"
        if table == "context" and name == "id":
            definition += " PRIMARY KEY"
        elif column["nullable"] == "NO":
            definition += " NOT NULL"
        definitions.append(definition)
    connection.execute(
        f"CREATE TABLE {sqlite_quote(table)} ({', '.join(definitions)})"
    )


def select_expression(column: dict[str, str]) -> str:
    name = pg_quote(column["name"])
    data_type = column["data_type"]
    if data_type == "timestamp with time zone":
        return f"extract(epoch FROM {name})::double precision AS {name}"
    if data_type == "timestamp without time zone":
        return f"extract(epoch FROM {name} AT TIME ZONE 'UTC')::double precision AS {name}"
    if data_type == "ARRAY":
        return f"to_json({name})::text AS {name}"
    if data_type in {"json", "jsonb"}:
        return f"{name}::text AS {name}"
    if data_type == "boolean":
        return f"CASE WHEN {name} THEN 1 WHEN NOT {name} THEN 0 END AS {name}"
    return name


def source_count(
    pg: Postgres,
    schema: str,
    table: str,
    limit: int | None,
) -> int:
    if limit is not None:
        return min(
            int(
                pg.query_rows(
                    f"SELECT count(*) FROM {pg_quote(schema)}.{pg_quote(table)}"
                )[0][0]
            ),
            limit,
        )
    return int(
        pg.query_rows(
            f"SELECT count(*) FROM {pg_quote(schema)}.{pg_quote(table)}"
        )[0][0]
    )


def copy_sql(
    schema: str,
    table: str,
    columns: list[dict[str, str]],
    limit: int | None,
) -> str:
    expressions = ", ".join(select_expression(column) for column in columns)
    limit_sql = f" LIMIT {limit}" if limit is not None else ""
    return (
        "COPY (SELECT "
        + expressions
        + f" FROM {pg_quote(schema)}.{pg_quote(table)}{limit_sql}) "
        + "TO STDOUT WITH (FORMAT CSV, NULL '\\N', ENCODING 'UTF8')"
    )


def import_table(
    connection: sqlite3.Connection,
    pg: Postgres,
    schema: str,
    table: str,
    columns: list[dict[str, str]],
    expected_rows: int,
    batch_size: int,
    limit: int | None,
) -> int:
    placeholders = ",".join("?" for _ in columns)
    insert_sql = f"INSERT INTO {sqlite_quote(table)} VALUES ({placeholders})"
    process = pg.copy_process(copy_sql(schema, table, columns, limit))
    assert process.stdout is not None
    stream = io.TextIOWrapper(process.stdout, encoding="utf-8", newline="")
    reader = csv.reader(stream)
    imported = 0
    batch: list[tuple[str | None, ...]] = []
    started = time.monotonic()

    connection.execute("BEGIN IMMEDIATE")
    try:
        for row in reader:
            if len(row) != len(columns):
                raise RuntimeError(
                    f"{schema}.{table}: expected {len(columns)} fields, got {len(row)}"
                )
            batch.append(tuple(None if value == r"\N" else value for value in row))
            if len(batch) >= batch_size:
                connection.executemany(insert_sql, batch)
                imported += len(batch)
                batch.clear()
                if imported % 100_000 < batch_size:
                    elapsed = max(time.monotonic() - started, 0.001)
                    print(
                        f"  {table}: {imported:,}/{expected_rows:,} rows "
                        f"({imported / elapsed:,.0f} rows/s)",
                        flush=True,
                    )
        if batch:
            connection.executemany(insert_sql, batch)
            imported += len(batch)
        connection.commit()
    except Exception:
        connection.rollback()
        process.kill()
        process.wait()
        raise
    finally:
        stream.close()

    stderr = process.stderr.read().decode("utf-8", errors="replace") if process.stderr else ""
    return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(
            f"PostgreSQL COPY failed for {schema}.{table}: {stderr.strip()}"
        )
    if imported != expected_rows:
        raise RuntimeError(
            f"Row-count mismatch for {schema}.{table}: "
            f"expected {expected_rows:,}, imported {imported:,}"
        )
    print(f"  {table}: complete ({imported:,} rows)", flush=True)
    return imported


def create_indexes(connection: sqlite3.Connection) -> None:
    print("Creating indexes...", flush=True)
    for _, table in RELEASE_TABLES:
        if table == "context":
            for column in ("recorded", "start", "end"):
                connection.execute(
                    f"CREATE INDEX {sqlite_quote(f'context_{column}_idx')} "
                    f"ON {sqlite_quote(table)} ({sqlite_quote(column)})"
                )
        else:
            connection.execute(
                f"CREATE UNIQUE INDEX "
                f"{sqlite_quote(f'{table}_read_ts_inverter_uidx')} "
                f"ON {sqlite_quote(table)} "
                f"({sqlite_quote('read_ts')}, {sqlite_quote('inverter')})"
            )
    connection.commit()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    args = parse_args()
    if not os.environ.get("PGPASSWORD"):
        print("PGPASSWORD must be set in the environment", file=sys.stderr)
        return 2
    if args.output.exists():
        if not args.overwrite:
            print(f"Refusing to overwrite existing file: {args.output}", file=sys.stderr)
            return 2
        args.output.unlink()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    pg = Postgres(args)
    metadata: dict[str, object] = {
        "source": {
            "host": args.host,
            "port": args.port,
            "database": args.database,
        },
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "timestamp_encoding": "fractional Unix seconds in UTC",
        "array_encoding": "JSON text",
        "tables": {},
    }

    connection = sqlite3.connect(args.output)
    try:
        connection.execute("PRAGMA page_size=65536")
        connection.execute("PRAGMA journal_mode=OFF")
        connection.execute("PRAGMA synchronous=OFF")
        connection.execute("PRAGMA locking_mode=EXCLUSIVE")
        connection.execute("PRAGMA temp_store=MEMORY")
        connection.execute("PRAGMA cache_size=-1048576")
        connection.execute("PRAGMA foreign_keys=OFF")

        for schema, table in RELEASE_TABLES:
            columns = get_columns(pg, schema, table)
            expected = source_count(pg, schema, table, args.limit_per_table)
            print(
                f"Exporting {schema}.{table}: {expected:,} rows, "
                f"{len(columns)} columns",
                flush=True,
            )
            create_table(connection, table, columns)
            imported = import_table(
                connection,
                pg,
                schema,
                table,
                columns,
                expected,
                args.batch_size,
                args.limit_per_table,
            )
            metadata["tables"][table] = {
                "source_schema": schema,
                "rows": imported,
                "columns": len(columns),
            }

        create_indexes(connection)
        print("Analyzing database...", flush=True)
        connection.execute("ANALYZE")
        connection.commit()
        print("Running SQLite integrity check...", flush=True)
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {integrity}")
        metadata["sqlite_integrity_check"] = integrity
    finally:
        connection.close()

    metadata["size_bytes"] = args.output.stat().st_size
    print("Computing SHA-256...", flush=True)
    metadata["sha256"] = sha256_file(args.output)
    report_path = args.output.with_suffix(args.output.suffix + ".export.json")
    report_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(f"Export complete: {args.output}", flush=True)
    print(f"Report: {report_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
