# Database construction

The public database utilities stream normalized records into SQLite and remove
columns that are structurally empty or correspond to inactive channels in this
installation. The PostgreSQL source schemas use the same public table and column
names as the released SQLite file.

The component-specific Modbus register dictionary and packed-register decoder
are not redistributed because they derive from a private technical manual. The
released schema, data dictionary, timestamp-calibration report, and original
fault arrays provide the public release information.

