#!/usr/bin/env python3
"""Create a pruned OpenCEM SQLite release artifact.

The PostgreSQL ingestion schema retains all transferred inverter fields, including
channels that are structural placeholders for this physical installation (e.g. due to
our inverter not supporting all features for which modbus registers are documented).
The public SQLite artifact omits columns that are either fully NULL or known
inactive channels so downstream users and validation plots do not have to work
around uninformative near-empty fields.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time


TABLES = (
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
    "context",
)
KEY_COLUMNS = {"read_ts", "inverter", "id"}

CURATED_STRUCTURAL_COLUMNS = {
    "analog_measurements": {
        "pv2volt",
        "pv2curr",
        "pv2power",
        "pv3volt",
        "pv3curr",
        "pv3power",
        "outvoltb",
        "outcurrb",
        "invcurrb",
        "outw_b",
        "outva_b",
        "loadpercentb",
        "normalloadw_b",
        "outvoltc",
        "outcurrc",
        "invcurrc",
        "outw_c",
        "outva_c",
        "loadpercentc",
        "normalloadw_c",
        "generatedpowerp_b",
        "generatedpowerp_c",
        "generatedpowers_b",
        "generatedpowers_c",
        "generatedpowerq_b",
        "generatedpowerq_c",
        "linevoltb",
        "linecurrb",
        "linevoltc",
        "linecurrc",
        "linepowerva_b",
        "linepowerva_c",
        "linepowerw_b",
        "linepowerw_c",
        "gridpowerw_b",
        "gridpowerw_c",
        "gridcurr_b",
        "gridcurr_c",
    },
    "totals": {
        "extpvsumoutw_b",
        "extpvsumoutw_c",
        "backupsumoutw_b",
        "backupsumoutw_c",
        "backupsumoutva_b",
        "backupsumoutva_c",
        "normalsumloadw_b",
        "normalsumloadw_c",
        "normalsumloadva_b",
        "normalsumloadva_c",
        "generatedsumpowerp_b",
        "generatedsumpowerp_c",
        "generatedsumpowers_b",
        "generatedsumpowers_c",
        "linesumpowerw_b",
        "linesumpowerw_c",
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--report",
        type=Path,
        help="JSON report path; defaults to OUTPUT.prune.json.",
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def quote_identifier(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def table_columns(connection: sqlite3.Connection, table: str) -> list[sqlite3.Row]:
    return list(connection.execute(f"PRAGMA table_info({quote_identifier(table)})"))


def non_null_counts(
    connection: sqlite3.Connection, table: str, columns: list[sqlite3.Row]
) -> dict[str, int]:
    names = [column["name"] for column in columns if column["name"] not in KEY_COLUMNS]
    if not names:
        return {}
    expressions = [
        f"COUNT({quote_identifier(name)}) AS {quote_identifier(name)}" for name in names
    ]
    row = connection.execute(
        f"SELECT {', '.join(expressions)} FROM {quote_identifier(table)}"
    ).fetchone()
    return {name: int(row[name]) for name in names}


def create_table(
    output: sqlite3.Connection,
    table: str,
    columns: list[sqlite3.Row],
) -> None:
    primary_key_columns = [column for column in columns if column["pk"]]
    definitions: list[str] = []
    for column in columns:
        name = column["name"]
        definition = quote_identifier(name)
        if column["type"]:
            definition += f" {column['type']}"
        if column["notnull"]:
            definition += " NOT NULL"
        if column["dflt_value"] is not None:
            definition += f" DEFAULT {column['dflt_value']}"
        if column["pk"] and len(primary_key_columns) == 1:
            definition += " PRIMARY KEY"
        definitions.append(definition)
    if len(primary_key_columns) > 1:
        ordered = sorted(primary_key_columns, key=lambda column: column["pk"])
        definitions.append(
            "PRIMARY KEY ("
            + ", ".join(quote_identifier(column["name"]) for column in ordered)
            + ")"
        )
    output.execute(
        f"CREATE TABLE {quote_identifier(table)} ({', '.join(definitions)})"
    )


def copy_table(
    output: sqlite3.Connection,
    table: str,
    columns: list[sqlite3.Row],
) -> None:
    quoted_columns = ", ".join(quote_identifier(column["name"]) for column in columns)
    output.execute(
        f"INSERT INTO {quote_identifier(table)} ({quoted_columns}) "
        f"SELECT {quoted_columns} FROM source.{quote_identifier(table)}"
    )


def create_indexes(output: sqlite3.Connection) -> None:
    for table in TABLES:
        if table == "context":
            for column in ("recorded", "start", "end"):
                output.execute(
                    f"CREATE INDEX {quote_identifier(f'context_{column}_idx')} "
                    f"ON {quote_identifier(table)} ({quote_identifier(column)})"
                )
        else:
            output.execute(
                f"CREATE UNIQUE INDEX "
                f"{quote_identifier(f'{table}_read_ts_inverter_uidx')} "
                f"ON {quote_identifier(table)} "
                f"({quote_identifier('read_ts')}, {quote_identifier('inverter')})"
            )


def main() -> int:
    args = parse_args()
    source_path = args.input.resolve()
    output_path = args.output.resolve()
    report_path = args.report or output_path.with_suffix(output_path.suffix + ".prune.json")

    if not source_path.exists():
        print(f"Input database not found: {source_path}", file=sys.stderr)
        return 2
    if output_path.exists():
        if not args.overwrite:
            print(f"Refusing to overwrite existing output: {output_path}", file=sys.stderr)
            return 2
        output_path.unlink()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    source = sqlite3.connect(f"file:{source_path}?mode=ro", uri=True)
    source.row_factory = sqlite3.Row
    source.execute("PRAGMA query_only=ON")
    available = {
        row[0]
        for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    missing = [table for table in TABLES if table not in available]
    if missing:
        print(f"Missing tables in input: {', '.join(missing)}", file=sys.stderr)
        return 2

    report: dict[str, object] = {
        "source": str(source_path),
        "output": str(output_path),
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "policy": {
            "all_null": "Drop non-key columns with zero non-null values.",
            "curated_structural": (
                "Drop known inactive PV2/PV3 and phase-B/C channel placeholders "
                "for the single-phase OpenCEM installation."
            ),
        },
        "tables": {},
    }

    table_plan: dict[str, dict[str, object]] = {}
    for table in TABLES:
        columns = table_columns(source, table)
        counts = non_null_counts(source, table, columns)
        curated = CURATED_STRUCTURAL_COLUMNS.get(table, set())
        drop: dict[str, list[str]] = {}
        for name, count in counts.items():
            reasons: list[str] = []
            if count == 0:
                reasons.append("all_null")
            if name in curated:
                reasons.append("curated_structural")
            if reasons:
                drop[name] = reasons
        missing_curated = sorted(curated - {column["name"] for column in columns})
        kept = [column for column in columns if column["name"] not in drop]
        table_plan[table] = {"columns": columns, "kept": kept, "drop": drop}
        report["tables"][table] = {
            "columns_before": len(columns),
            "columns_after": len(kept),
            "dropped_columns": drop,
            "missing_curated_columns": missing_curated,
        }

    output = sqlite3.connect(output_path)
    try:
        output.execute("PRAGMA page_size=65536")
        output.execute("PRAGMA journal_mode=OFF")
        output.execute("PRAGMA synchronous=OFF")
        output.execute("PRAGMA locking_mode=EXCLUSIVE")
        output.execute("PRAGMA temp_store=FILE")
        output.execute("PRAGMA cache_size=-1048576")
        output.execute("PRAGMA foreign_keys=OFF")
        output.execute("ATTACH DATABASE ? AS source", (str(source_path),))
        for table in TABLES:
            plan = table_plan[table]
            kept = plan["kept"]
            dropped = plan["drop"]
            print(
                f"Copying {table}: {len(kept)} kept, {len(dropped)} dropped",
                flush=True,
            )
            create_table(output, table, kept)
            output.execute("BEGIN IMMEDIATE")
            try:
                copy_table(output, table, kept)
                output.commit()
            except Exception:
                output.rollback()
                raise
        print("Creating indexes...", flush=True)
        create_indexes(output)
        output.commit()
        print("Analyzing database...", flush=True)
        output.execute("ANALYZE")
        output.commit()
        integrity = output.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {integrity}")
        report["sqlite_integrity_check"] = integrity
    finally:
        output.close()
        source.close()

    report["size_bytes"] = output_path.stat().st_size
    print("Computing SHA-256...", flush=True)
    report["sha256"] = file_sha256(output_path)
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Pruned artifact: {output_path}", flush=True)
    print(f"Report: {report_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
