# Technical validation

The deposited validation can be repeated from the root of an extracted release
after installing the listed Python dependencies:

```bash
python -m pip install -r validation/requirements.txt
MPLCONFIGDIR=/tmp/opencem-matplotlib python validation/validate_release.py \
  --database data/opencem-v1.0.0.sqlite \
  --image-root sky_images/frames \
  --results-dir validation/recomputed/outputs \
  --manuscript-dir validation/recomputed
```

The command writes an independent set of regenerated outputs under
`validation/recomputed/`:

- `outputs/validation_results.json`
- the supporting CSV reports under `outputs/`
- `generated/validation_macros.tex`
- `generated/validation_table.tex`
- `images/technical_validation_dashboard*.{pdf,png}`

The optional `--sensitive-strings-file PATH` argument accepts an external,
newline-delimited audit list. Supplied strings are never copied into generated
outputs.
