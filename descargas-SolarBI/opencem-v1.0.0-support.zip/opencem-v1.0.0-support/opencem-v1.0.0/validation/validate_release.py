#!/usr/bin/env python3
"""Validate an OpenCEM SQLite release and its sky-image archive.

The script writes a machine-readable report, manuscript-ready LaTeX macros and
table, and a dense validation dashboard for user-supplied release artifacts.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sqlite3
import sys
from zoneinfo import ZoneInfo

import matplotlib

matplotlib.use("Agg")

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from matplotlib.colors import PowerNorm
import numpy as np
import pandas as pd
from PIL import Image
import seaborn as sns


MANUSCRIPT = Path(__file__).resolve().parents[1]
ROOT = MANUSCRIPT.parent
TABLES = (
    "analog_measurements",
    "status",
    "totals",
    "settings",
    "specs",
    "statistics",
    "fault_history",
    "context",
)
MEASUREMENT_TABLES = TABLES[:-1]
LOCAL_TZ = ZoneInfo("Asia/Shanghai")
LEGACY_IMAGE_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2})-(\d{2})-(\d{2})\.jpg$", re.I
)
ARCHIVE_IMAGE_RE = re.compile(
    r"^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z\.jpg$", re.I
)
IMAGE_DIMENSIONS = (1920, 1920)
LATITUDE = 22.693001
LONGITUDE = 114.211386


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--database", type=Path, default=ROOT / "opencem_dataset_current.sqlite"
    )
    parser.add_argument("--image-root", type=Path, default=ROOT / "output_images")
    parser.add_argument(
        "--image-index",
        type=Path,
        help="Optional frame-processing SQLite index used to report privacy removals.",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=MANUSCRIPT / "technical_validation" / "outputs",
    )
    parser.add_argument(
        "--manuscript-dir", type=Path, default=MANUSCRIPT
    )
    parser.add_argument("--brightness-sample", type=int, default=800)
    parser.add_argument(
        "--skip-image-content-check",
        action="store_true",
        help="Parse image timestamps but skip decoding and content hashing.",
    )
    parser.add_argument(
        "--sensitive-strings-file",
        type=Path,
        help="Optional newline-delimited private audit list; strings are never written to outputs.",
    )
    return parser.parse_args()


def sqlite_connect(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    connection.execute("PRAGMA temp_store=FILE")
    connection.execute("PRAGMA cache_size=-524288")
    return connection


def scalar(connection: sqlite3.Connection, sql: str, parameters: tuple = ()):
    return connection.execute(sql, parameters).fetchone()[0]


def unix_to_local(value: float | int | None, include_time: bool = True) -> str:
    if value is None:
        return "--"
    converted = datetime.fromtimestamp(float(value), tz=timezone.utc).astimezone(LOCAL_TZ)
    return converted.strftime("%d %B %Y, %H:%M:%S" if include_time else "%d %B %Y")


def unix_to_iso(value: float | int | None) -> str | None:
    if value is None:
        return None
    return datetime.fromtimestamp(float(value), tz=timezone.utc).isoformat()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def table_columns(connection: sqlite3.Connection, table: str) -> list[dict]:
    return [dict(row) for row in connection.execute(f'PRAGMA table_info("{table}")')]


def validate_tables(connection: sqlite3.Connection) -> tuple[dict, list[dict]]:
    results: dict[str, dict] = {}
    null_records: list[dict] = []
    available = {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    missing = [table for table in TABLES if table not in available]
    if missing:
        raise RuntimeError(f"Missing release tables: {', '.join(missing)}")

    for table in TABLES:
        print(f"Validating table structure: {table}", flush=True)
        columns = table_columns(connection, table)
        names = [column["name"] for column in columns]
        row_count = scalar(connection, f'SELECT count(*) FROM "{table}"')
        if table == "context":
            start_value, end_value = connection.execute(
                'SELECT min("start"), max("end") FROM context'
            ).fetchone()
            duplicate_keys = scalar(
                connection,
                "SELECT count(*) - count(DISTINCT id) FROM context",
            )
        else:
            start_value, end_value = connection.execute(
                f'SELECT min(read_ts), max(read_ts) FROM "{table}"'
            ).fetchone()
            duplicate_keys = scalar(
                connection,
                f"SELECT count(*) FROM ("
                f'SELECT 1 FROM "{table}" GROUP BY read_ts,inverter '
                f"HAVING count(*)>1)",
            )

        aggregate_expressions = [
            f'SUM(CASE WHEN "{name}" IS NULL THEN 1 ELSE 0 END) AS "{name}"'
            for name in names
        ]
        null_row = connection.execute(
            f'SELECT {", ".join(aggregate_expressions)} FROM "{table}"'
        ).fetchone()
        null_counts = {name: int(null_row[name] or 0) for name in names}
        for name in names:
            if name not in {"read_ts", "inverter", "id"}:
                null_records.append(
                    {
                        "table": table,
                        "column": name,
                        "null_count": null_counts[name],
                        "null_rate": null_counts[name] / row_count if row_count else 0.0,
                    }
                )

        text_columns = [
            column["name"] for column in columns if column["type"].upper() == "TEXT"
        ]
        invalid_json = 0
        if text_columns:
            expressions = [
                f'SUM(CASE WHEN "{name}" IS NOT NULL '
                f'AND NOT json_valid("{name}") THEN 1 ELSE 0 END)'
                for name in text_columns
            ]
            invalid_json = int(
                sum(
                    value or 0
                    for value in connection.execute(
                        f'SELECT {", ".join(expressions)} FROM "{table}"'
                    ).fetchone()
                )
            )

        results[table] = {
            "rows": int(row_count),
            "columns": len(columns),
            "data_columns": len(columns) - (1 if table == "context" else 2),
            "start_unix": start_value,
            "end_unix": end_value,
            "start_utc": unix_to_iso(start_value),
            "end_utc": unix_to_iso(end_value),
            "start_local": unix_to_local(start_value),
            "end_local": unix_to_local(end_value),
            "duplicate_keys": int(duplicate_keys),
            "invalid_json_text_values": invalid_json,
            "null_counts": null_counts,
        }
    return results, null_records


def validate_calibrated_timestamps(connection: sqlite3.Connection) -> dict:
    direct_columns = {
        "settings.presenttime": "settings",
        "statistics.powerontime": "statistics",
        "statistics.stactimeback": "statistics",
    }
    direct_types = {}
    for qualified, table in direct_columns.items():
        column = qualified.split(".", 1)[1]
        column_type = next(
            item["type"].upper()
            for item in table_columns(connection, table)
            if item["name"] == column
        )
        direct_types[qualified] = column_type
        if column_type != "REAL":
            raise RuntimeError(f"Calibrated timestamp is not SQLite REAL: {qualified}")

    fault_columns = [
        item["name"]
        for item in table_columns(connection, "fault_history")
        if item["name"].startswith("faulthistoryrecord")
        and item["name"].endswith("_time")
    ]
    if len(fault_columns) != 32:
        raise RuntimeError(
            f"Expected 32 calibrated fault timestamp columns, found {len(fault_columns)}"
        )

    parts = []
    future_expressions = []
    for index in range(32):
        payload = f"faulthistoryrecord{index:02d}"
        event_time = f"{payload}_time"
        parts.append(
            f"SELECT DISTINCT inverter, {payload} AS payload, "
            f"{event_time} AS event_time FROM fault_history "
            f"WHERE {payload} IS NOT NULL "
            f"AND json_extract({payload}, '$[0]') <> 0"
        )
        future_expressions.append(
            f"CASE WHEN {event_time} > read_ts + 300 THEN 1 ELSE 0 END"
        )
    all_events = " UNION ALL ".join(parts)
    total_payloads, calibrated_payloads, conflicting_payloads = connection.execute(
        f"""
        WITH all_events AS ({all_events}), grouped AS (
            SELECT inverter, payload,
                   count(DISTINCT event_time) AS calibrated_times,
                   max(event_time IS NOT NULL) AS has_calibrated_time
            FROM all_events
            GROUP BY inverter, payload
        )
        SELECT count(*),
               sum(has_calibrated_time),
               sum(calibrated_times > 1)
        FROM grouped
        """
    ).fetchone()
    events_after_observation = int(
        connection.execute(
            f"SELECT sum({' + '.join(future_expressions)}) FROM fault_history"
        ).fetchone()[0]
        or 0
    )
    if conflicting_payloads:
        raise RuntimeError(
            f"{conflicting_payloads} historical fault payloads have multiple calibrated times"
        )
    if events_after_observation:
        raise RuntimeError(
            f"{events_after_observation} fault timestamps occur after their observation row"
        )
    return {
        "direct_timestamp_types": direct_types,
        "fault_timestamp_columns": len(fault_columns),
        "distinct_fault_payloads": int(total_payloads or 0),
        "calibrated_fault_payloads": int(calibrated_payloads or 0),
        "fault_payloads_with_conflicting_times": int(conflicting_payloads or 0),
        "fault_events_more_than_5_minutes_after_observation": events_after_observation,
    }


def cadence_metrics(connection: sqlite3.Connection) -> tuple[dict, pd.DataFrame]:
    metrics: dict[str, dict] = {}
    daily_frames = []
    for inverter in (1, 2):
        timestamps = np.fromiter(
            (
                row[0]
                for row in connection.execute(
                    "SELECT read_ts FROM analog_measurements "
                    "WHERE inverter=? ORDER BY read_ts",
                    (inverter,),
                )
            ),
            dtype=np.float64,
        )
        differences = np.diff(timestamps)
        positive = differences[differences > 0]
        metrics[str(inverter)] = {
            "rows": int(timestamps.size),
            "median_seconds": float(np.median(positive)),
            "p95_seconds": float(np.percentile(positive, 95)),
            "p99_seconds": float(np.percentile(positive, 99)),
            "maximum_seconds": float(np.max(positive)),
            "gaps_over_10_minutes": int(np.sum(positive > 600)),
            "gaps_over_1_hour": int(np.sum(positive > 3600)),
            "gaps_over_1_day": int(np.sum(positive > 86400)),
            "gap_bins": {
                "0--30 s": int(np.sum(positive <= 30)),
                "30--60 s": int(np.sum((positive > 30) & (positive <= 60))),
                "1--10 min": int(np.sum((positive > 60) & (positive <= 600))),
                "10--60 min": int(np.sum((positive > 600) & (positive <= 3600))),
                ">1 h": int(np.sum(positive > 3600)),
            },
        }
        daily = pd.read_sql_query(
            """
            SELECT date(read_ts + 28800, 'unixepoch') AS day,
                   count(DISTINCT CAST(read_ts / 60 AS INTEGER)) AS occupied_minutes
            FROM analog_measurements
            WHERE inverter = ?
              AND battvolt IS NOT NULL
              AND battsoc IS NOT NULL
            GROUP BY day ORDER BY day
            """,
            connection,
            params=(inverter,),
        )
        daily["stream"] = f"Battery V + SOC inv. {inverter}"
        daily["coverage"] = daily["occupied_minutes"] / 1440.0
        daily_frames.append(daily)
    return metrics, pd.concat(daily_frames, ignore_index=True)


def electrical_checks(connection: sqlite3.Connection) -> tuple[dict, pd.DataFrame]:
    checks: dict[str, dict] = {}
    for inverter in (1, 2):
        row = connection.execute(
            """
            SELECT
              count(*) AS rows,
              SUM(CASE WHEN battsoc IS NOT NULL AND (battsoc < 0 OR battsoc > 100)
                       THEN 1 ELSE 0 END) AS soc_outside,
              SUM(CASE WHEN outfreq IS NOT NULL AND outfreq != 0
                            AND (outfreq < 45 OR outfreq > 55)
                       THEN 1 ELSE 0 END) AS output_frequency_outside,
              SUM(CASE WHEN linefreq IS NOT NULL AND linefreq != 0
                            AND (linefreq < 45 OR linefreq > 55)
                       THEN 1 ELSE 0 END) AS grid_frequency_outside,
              SUM(CASE WHEN pv1power < 0 THEN 1 ELSE 0 END) AS negative_pv_power,
              MIN(CASE WHEN battvolt > 0 THEN battvolt END) AS minimum_nonzero_battery_voltage,
              MAX(battvolt) AS maximum_battery_voltage,
              SUM(CASE WHEN temper1 = 120 OR temper2 = 120 OR temper3 = 120 OR temper4 = 120
                       THEN 1 ELSE 0 END) AS rows_with_temperature_120,
              SUM(CASE WHEN pv1power >= 100 AND pv1volt IS NOT NULL AND pv1curr IS NOT NULL
                       THEN 1 ELSE 0 END) AS pv_evaluated,
              AVG(CASE WHEN pv1power >= 100 AND pv1volt IS NOT NULL AND pv1curr IS NOT NULL
                       THEN abs(pv1power - pv1volt * pv1curr) END) AS pv_mae_w,
              AVG(CASE WHEN pv1power >= 100 AND pv1volt IS NOT NULL AND pv1curr IS NOT NULL
                       THEN abs(pv1power - pv1volt * pv1curr) / pv1power END) * 100 AS pv_mape_percent,
              AVG(CASE WHEN pv1power >= 100 AND pv1volt IS NOT NULL AND pv1curr IS NOT NULL
                       THEN abs(pv1power - pv1volt * pv1curr) <= 0.1 * pv1power END) * 100
                       AS pv_within_10_percent,
              SUM(CASE WHEN outva_a >= 100 AND outvolta IS NOT NULL AND outcurra IS NOT NULL
                       THEN 1 ELSE 0 END) AS output_va_evaluated,
              AVG(CASE WHEN outva_a >= 100 AND outvolta IS NOT NULL AND outcurra IS NOT NULL
                       THEN abs(outva_a - outvolta * outcurra) END) AS output_va_mae,
              AVG(CASE WHEN outva_a >= 100 AND outvolta IS NOT NULL AND outcurra IS NOT NULL
                       THEN abs(outva_a - outvolta * outcurra) / outva_a END) * 100
                       AS output_va_mape_percent,
              SUM(CASE WHEN outva_a IS NOT NULL AND outw_a IS NOT NULL
                            AND abs(outw_a) > outva_a + 50 THEN 1 ELSE 0 END)
                       AS active_exceeds_apparent_50va
            FROM analog_measurements WHERE inverter = ?
            """,
            (inverter,),
        ).fetchone()
        checks[str(inverter)] = {
            key: (int(value) if key in {
                "rows", "soc_outside", "output_frequency_outside",
                "grid_frequency_outside", "negative_pv_power",
                "rows_with_temperature_120", "pv_evaluated",
                "output_va_evaluated", "active_exceeds_apparent_50va"
            } and value is not None else float(value) if value is not None else None)
            for key, value in dict(row).items()
        }

    total_rows = scalar(connection, "SELECT count(*) FROM analog_measurements")
    stride = max(int(total_rows // 180_000), 1)
    sample = pd.read_sql_query(
        f"""
        SELECT inverter,pv1volt,pv1curr,pv1power,
               outvolta,outcurra,outva_a,outw_a
        FROM analog_measurements
        WHERE rowid % {stride} = 0
          AND pv1volt IS NOT NULL AND pv1curr IS NOT NULL AND pv1power >= 100
          AND outvolta IS NOT NULL AND outcurra IS NOT NULL AND outva_a >= 100
        LIMIT 180000
        """,
        connection,
    )
    sample["pv_calculated"] = sample["pv1volt"] * sample["pv1curr"]
    sample["output_va_calculated"] = sample["outvolta"] * sample["outcurra"]
    return checks, sample


def daily_energy_check(connection: sqlite3.Connection) -> dict:
    rows = connection.execute(
        """
        WITH ordered AS (
          SELECT inverter,date(read_ts + 28800,'unixepoch') AS day,
                 read_ts,pv1power,
                 lag(read_ts) OVER (PARTITION BY inverter ORDER BY read_ts) AS prev_ts,
                 lag(pv1power) OVER (PARTITION BY inverter ORDER BY read_ts) AS prev_power
          FROM analog_measurements WHERE pv1power IS NOT NULL
        ), integrated AS (
          SELECT inverter,day,
                 sum(CASE WHEN read_ts-prev_ts BETWEEN 0 AND 120
                          THEN (pv1power+prev_power)*0.5*(read_ts-prev_ts)/3600000.0
                          ELSE 0 END) AS integrated_kwh,
                 sum(CASE WHEN read_ts-prev_ts BETWEEN 0 AND 120
                          THEN read_ts-prev_ts ELSE 0 END)/3600.0 AS covered_hours
          FROM ordered GROUP BY inverter,day
        ), reported AS (
          SELECT inverter,date(read_ts + 28800,'unixepoch') AS day,
                 max(pvgeneratenergytoday) AS reported_kwh
          FROM statistics WHERE pvgeneratenergytoday IS NOT NULL
          GROUP BY inverter,day
        )
        SELECT i.inverter,count(*) AS days,
               avg(abs(i.integrated_kwh-r.reported_kwh)) AS mae_kwh,
               avg(CASE WHEN r.reported_kwh>=1
                        THEN abs(i.integrated_kwh-r.reported_kwh)/r.reported_kwh END)*100
                        AS mape_percent
        FROM integrated i JOIN reported r USING(inverter,day)
        WHERE i.covered_hours>=20
        GROUP BY i.inverter ORDER BY i.inverter
        """
    ).fetchall()
    return {
        str(row["inverter"]): {
            "days": int(row["days"]),
            "mae_kwh": float(row["mae_kwh"]),
            "mape_percent": float(row["mape_percent"]),
        }
        for row in rows
    }


def solar_elevation(local_datetime: datetime) -> float:
    day = local_datetime.timetuple().tm_yday
    hour = (
        local_datetime.hour
        + local_datetime.minute / 60
        + local_datetime.second / 3600
    )
    gamma = 2 * math.pi / 365 * (day - 1 + (hour - 12) / 24)
    equation_of_time = 229.18 * (
        0.000075
        + 0.001868 * math.cos(gamma)
        - 0.032077 * math.sin(gamma)
        - 0.014615 * math.cos(2 * gamma)
        - 0.040849 * math.sin(2 * gamma)
    )
    declination = (
        0.006918
        - 0.399912 * math.cos(gamma)
        + 0.070257 * math.sin(gamma)
        - 0.006758 * math.cos(2 * gamma)
        + 0.000907 * math.sin(2 * gamma)
        - 0.002697 * math.cos(3 * gamma)
        + 0.00148 * math.sin(3 * gamma)
    )
    offset = equation_of_time + 4 * LONGITUDE - 60 * 8
    true_solar_minutes = hour * 60 + offset
    hour_angle = math.radians(true_solar_minutes / 4 - 180)
    latitude = math.radians(LATITUDE)
    return math.degrees(
        math.asin(
            math.sin(latitude) * math.sin(declination)
            + math.cos(latitude) * math.cos(declination) * math.cos(hour_angle)
        )
    )


def parse_image_timestamp(path: Path) -> datetime | None:
    archive_match = ARCHIVE_IMAGE_RE.fullmatch(path.name)
    if archive_match:
        year, month, day, hour, minute, second = map(
            int, archive_match.groups()
        )
        # The camera overlay and archive key use Shenzhen wall-clock time.
        return datetime(
            year, month, day, hour, minute, second, tzinfo=LOCAL_TZ
        )
    legacy_match = LEGACY_IMAGE_RE.fullmatch(path.name)
    if legacy_match:
        date_text, hour, minute = legacy_match.groups()
        return datetime.strptime(
            f"{date_text} {hour}:{minute}", "%Y-%m-%d %H:%M"
        ).replace(tzinfo=LOCAL_TZ)
    return None


def image_directory_matches(
    image_root: Path, path: Path, timestamp: datetime
) -> bool:
    relative = path.relative_to(image_root)
    if ARCHIVE_IMAGE_RE.fullmatch(path.name):
        return relative.parts[-4:-1] == (
            timestamp.strftime("%Y"),
            timestamp.strftime("%m"),
            timestamp.strftime("%d"),
        )
    return path.parent.name == timestamp.strftime("%Y-%m-%d")


def validate_image_index(
    image_index: Path | None,
    image_root: Path,
    physical_paths: list[Path],
) -> dict:
    if image_index is None:
        return {
            "index_path": None,
            "indexed_frames": None,
            "indexed_but_missing_privacy_removed": None,
            "excluded_frame_tombstones": None,
            "privacy_removed_total": None,
            "unindexed_physical_files": None,
        }

    connection = sqlite3.connect(
        f"file:{image_index.resolve()}?mode=ro", uri=True
    )
    try:
        indexed_rows = connection.execute(
            "SELECT timestamp_utc,path FROM frames ORDER BY timestamp_utc"
        ).fetchall()
        excluded_count = int(
            connection.execute("SELECT count(*) FROM excluded_frames").fetchone()[0]
        )
    finally:
        connection.close()

    def resolve_stored_path(stored: str) -> Path:
        normalized = stored.replace("\\", "/")
        if "/frames/" in normalized:
            return image_root / normalized.split("/frames/", 1)[1]
        stored_path = Path(stored)
        if not stored_path.is_absolute():
            if stored_path.parts and stored_path.parts[0] == "frames":
                return image_root.parent / stored_path
            return image_root / stored_path
        return stored_path

    indexed_paths = {
        resolve_stored_path(str(stored)).resolve()
        for _, stored in indexed_rows
    }
    physical_resolved = {path.resolve() for path in physical_paths}
    indexed_missing = len(indexed_paths - physical_resolved)
    return {
        "index_path": image_index.name,
        "indexed_frames": len(indexed_rows),
        "indexed_but_missing_privacy_removed": indexed_missing,
        "excluded_frame_tombstones": excluded_count,
        "privacy_removed_total": indexed_missing + excluded_count,
        "unindexed_physical_files": len(physical_resolved - indexed_paths),
    }


def validate_images(
    image_root: Path,
    image_index: Path | None,
    connection: sqlite3.Connection,
    brightness_sample: int,
    skip_content: bool,
) -> tuple[dict, pd.DataFrame, pd.DataFrame]:
    paths = sorted(image_root.rglob("*.jpg")) if image_root.exists() else []
    parsed: list[tuple[Path, datetime]] = []
    unparseable = 0
    directory_mismatches = 0
    for path in paths:
        timestamp = parse_image_timestamp(path)
        if timestamp is None:
            unparseable += 1
            continue
        if not image_directory_matches(image_root, path, timestamp):
            directory_mismatches += 1
        parsed.append((path, timestamp))

    timestamp_counts = Counter(timestamp for _, timestamp in parsed)
    duplicate_timestamps = sum(count - 1 for count in timestamp_counts.values())
    decode_failures = 0
    dimension_mismatches = 0
    format_mismatches = 0
    digest_counts: Counter[str] = Counter()
    bytes_total = 0
    if not skip_content:
        for index, (path, _) in enumerate(parsed, start=1):
            try:
                data = path.read_bytes()
                bytes_total += len(data)
                digest_counts[hashlib.sha256(data).hexdigest()] += 1
                with Image.open(io.BytesIO(data)) as image:
                    if image.size != IMAGE_DIMENSIONS:
                        dimension_mismatches += 1
                    if image.format != "JPEG":
                        format_mismatches += 1
                    image.verify()
            except Exception:
                decode_failures += 1
            if index % 5_000 == 0:
                print(f"  checked {index:,}/{len(parsed):,} images", flush=True)
    else:
        bytes_total = sum(path.stat().st_size for path, _ in parsed)
    duplicate_contents = sum(count - 1 for count in digest_counts.values())

    daily_counter = Counter(timestamp.date().isoformat() for _, timestamp in parsed)
    if parsed:
        first = min(timestamp for _, timestamp in parsed)
        last = max(timestamp for _, timestamp in parsed)
        full_days = pd.date_range(first.date(), last.date(), freq="D")
    else:
        first = last = None
        full_days = pd.DatetimeIndex([])
    daily = pd.DataFrame(
        {
            "day": full_days.strftime("%Y-%m-%d"),
            "occupied_minutes": [daily_counter.get(day.strftime("%Y-%m-%d"), 0) for day in full_days],
        }
    )
    if not daily.empty:
        daily["stream"] = "Sky images"
        daily["coverage"] = daily["occupied_minutes"] / 901.0

    ordered_times = sorted(timestamp for _, timestamp in parsed)
    deltas = np.array(
        [
            (right - left).total_seconds()
            for left, right in zip(ordered_times, ordered_times[1:])
            if left.date() == right.date()
        ],
        dtype=float,
    )
    outside_window = sum(
        not (6 <= timestamp.hour <= 21) for _, timestamp in parsed
    )

    brightness_rows = []
    if parsed and brightness_sample > 0 and not skip_content:
        sample_indices = np.unique(
            np.linspace(0, len(parsed) - 1, min(brightness_sample, len(parsed)), dtype=int)
        )
        for index in sample_indices:
            path, timestamp = parsed[int(index)]
            try:
                with Image.open(path) as image:
                    gray = image.convert("L")
                    gray.thumbnail((96, 96))
                    brightness = float(np.asarray(gray, dtype=float).mean())
            except Exception:
                continue
            epoch = timestamp.astimezone(timezone.utc).timestamp()
            pv_total = 0.0
            nearest_delta = math.inf
            matched = False
            for inverter in (1, 2):
                row = connection.execute(
                    """
                    SELECT read_ts,pv1power FROM analog_measurements
                    WHERE inverter=? AND read_ts BETWEEN ? AND ?
                    ORDER BY abs(read_ts-?) LIMIT 1
                    """,
                    (inverter, epoch - 90, epoch + 90, epoch),
                ).fetchone()
                if row is not None:
                    delta = abs(float(row["read_ts"]) - epoch)
                    nearest_delta = min(nearest_delta, delta)
                    if delta <= 60:
                        matched = True
                    if row["pv1power"] is not None:
                        pv_total += float(row["pv1power"])
            brightness_rows.append(
                {
                    "timestamp": timestamp.isoformat(),
                    "brightness": brightness,
                    "solar_elevation": solar_elevation(timestamp),
                    "pv_power_w": pv_total,
                    "matched_within_60s": matched,
                    "nearest_measurement_seconds": nearest_delta,
                }
            )
    brightness_df = pd.DataFrame(brightness_rows)
    if not brightness_df.empty:
        daylight = brightness_df[brightness_df["solar_elevation"] > 0]
        brightness_solar_correlation = (
            float(daylight["brightness"].corr(daylight["solar_elevation"]))
            if len(daylight) > 1 else None
        )
        brightness_pv_correlation = (
            float(daylight["brightness"].corr(daylight["pv_power_w"]))
            if len(daylight) > 1 else None
        )
        match_rate = float(brightness_df["matched_within_60s"].mean() * 100)
    else:
        brightness_solar_correlation = None
        brightness_pv_correlation = None
        match_rate = None

    results = {
        "root": image_root.name,
        "files": len(paths),
        "parsed_timestamps": len(parsed),
        "unparseable_filenames": unparseable,
        "directory_date_mismatches": directory_mismatches,
        "start_local": first.isoformat() if first else None,
        "end_local": last.isoformat() if last else None,
        "start_display": first.strftime("%d %B %Y, %H:%M") if first else "--",
        "end_display": last.strftime("%d %B %Y, %H:%M") if last else "--",
        "duplicate_timestamps": duplicate_timestamps,
        "decode_failures": decode_failures,
        "dimension_mismatches": dimension_mismatches,
        "format_mismatches": format_mismatches,
        "duplicate_contents": duplicate_contents,
        "bytes": bytes_total,
        "outside_06_21_window": outside_window,
        "within_day_exact_60_second_fraction": (
            float(np.mean(deltas == 60)) if deltas.size else None
        ),
        "within_day_gaps_over_60_seconds": int(np.sum(deltas > 60)) if deltas.size else 0,
        "brightness_sample_size": len(brightness_df),
        "brightness_solar_elevation_correlation": brightness_solar_correlation,
        "brightness_pv_power_correlation": brightness_pv_correlation,
        "measurement_match_within_60_seconds_percent": match_rate,
        "daily_counts": dict(sorted(daily_counter.items())),
        "documented_dimensions": list(IMAGE_DIMENSIONS),
    }
    results.update(validate_image_index(image_index, image_root, paths))
    return results, daily, brightness_df


def validate_context(
    connection: sqlite3.Connection, sensitive_strings_file: Path | None
) -> dict:
    row = connection.execute(
        """
        SELECT count(*) AS rows,
               count(*)-count(DISTINCT id) AS duplicate_ids,
               SUM(recorded IS NULL OR start IS NULL OR "end" IS NULL) AS missing_times,
               SUM(start > "end") AS reversed_intervals,
               SUM(NOT json_valid(value)) AS invalid_json,
               SUM(json_type(value) != 'object') AS non_object_json,
               SUM(json_extract(value,'$.context_type') IS NULL) AS missing_context_type,
               count(DISTINCT json_extract(value,'$.context_type')) AS context_types,
               count(DISTINCT json_extract(value,'$.source')) AS source_families
        FROM context
        """
    ).fetchone()
    results = {key: int(value or 0) for key, value in dict(row).items()}
    source_rows = connection.execute(
        """
        SELECT coalesce(json_extract(value,'$.source'),'missing') AS source,count(*) AS rows
        FROM context GROUP BY source ORDER BY rows DESC
        """
    ).fetchall()
    results["rows_by_source"] = {row["source"]: int(row["rows"]) for row in source_rows}
    sensitive_matches = None
    sensitive_terms = 0
    if sensitive_strings_file:
        terms = [
            line.strip()
            for line in sensitive_strings_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
        sensitive_terms = len(terms)
        sensitive_matches = sum(
            scalar(
                connection,
                "SELECT count(*) FROM context WHERE instr(lower(value),lower(?))>0",
                (term,),
            )
            for term in terms
        )
    results["sensitive_string_terms_checked"] = sensitive_terms
    results["sensitive_string_matches"] = sensitive_matches
    return results


def build_dashboard(
    output_stem: Path,
    cadence: dict,
    electrical_daily: pd.DataFrame,
    image_daily: pd.DataFrame,
    electrical_sample: pd.DataFrame,
    null_records: list[dict],
    brightness: pd.DataFrame,
) -> None:
    def save_figure(fig: plt.Figure, stem: Path) -> None:
        stem.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
        fig.savefig(stem.with_suffix(".png"), dpi=220, bbox_inches="tight")
        plt.close(fig)

    sns.set_theme(
        context="paper",
        style="whitegrid",
        font="Times New Roman",
        rc={
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "mathtext.fontset": "custom",
            "mathtext.rm": "Times New Roman",
            "mathtext.it": "Times New Roman:italic",
            "mathtext.bf": "Times New Roman:bold",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.edgecolor": "#C9D1D9",
            "grid.color": "#E6EAF0",
            "axes.titleweight": "bold",
            "font.size": 10,
            "axes.labelsize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "legend.fontsize": 9,
        },
    )
    coverage = electrical_daily.copy()
    if not image_daily.empty:
        coverage = pd.concat([coverage, image_daily], ignore_index=True)
    coverage["day"] = pd.to_datetime(coverage["day"])
    start, end = coverage["day"].min(), coverage["day"].max()
    all_days = pd.date_range(start, end, freq="D")
    matrix = coverage.pivot(index="stream", columns="day", values="coverage").reindex(columns=all_days)
    ticks = np.linspace(0, len(all_days) - 1, min(5, len(all_days)), dtype=int)

    labels = list(cadence["1"]["gap_bins"])
    x = np.arange(len(labels))
    width = 0.36

    null_df = pd.DataFrame(null_records)
    null_df = null_df[null_df["null_rate"] < 1.0].copy()
    null_plot_df = null_df[null_df["null_rate"] <= 0.9].copy()
    null_plot_df["table"] = null_plot_df["table"].str.replace("_", " ")
    table_order = [
        table.replace("_", " ")
        for table in TABLES
        if table.replace("_", " ") in set(null_plot_df["table"])
    ]
    medians = null_plot_df.groupby("table", observed=True)["null_rate"].median()

    def plot_coverage(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        sns.heatmap(
            matrix,
            ax=ax,
            cmap=sns.color_palette("mako", as_cmap=True),
            vmin=0,
            vmax=1,
            cbar_kws={"label": "Available-minute fraction", "shrink": 0.75},
            mask=matrix.isna(),
        )
        ax.set_xticks(ticks + 0.5)
        ax.set_xticklabels(
            [all_days[i].strftime("%b %Y") for i in ticks],
            rotation=30,
            ha="right",
        )
        ax.set_xlabel("")
        ax.set_ylabel("")
        if title:
            ax.set_title(title)

    def plot_intervals(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        for offset, inverter, color in (
            (-width / 2, "1", "#2878B5"),
            (width / 2, "2", "#E67E22"),
        ):
            values = np.array(list(cadence[inverter]["gap_bins"].values()), dtype=float)
            values = values / values.sum() * 100
            ax.bar(
                x + offset,
                values,
                width,
                label=f"Inverter {inverter}",
                color=color,
            )
        ax.set_yscale("log")
        ax.set_xticks(x, labels, rotation=25, ha="right")
        ax.set_ylabel("Intervals (%)")
        ax.legend(frameon=False)
        if title:
            ax.set_title(title)

    def plot_pv_identity(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        hb = ax.hexbin(
            electrical_sample["pv_calculated"],
            electrical_sample["pv1power"],
            gridsize=65,
            bins="log",
            mincnt=1,
            cmap="viridis",
        )
        maximum = float(
            max(
                electrical_sample["pv_calculated"].max(),
                electrical_sample["pv1power"].max(),
            )
        )
        ax.plot([0, maximum], [0, maximum], color="#D62728", lw=1.2, ls="--")
        ax.set(
            xlabel=r"Calculated $V_{PV}I_{PV}$ (W)",
            ylabel="Reported PV power (W)",
        )
        fig.colorbar(hb, ax=ax, label="log count", shrink=0.75)
        if title:
            ax.set_title(title)

    def plot_ac_identity(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        hb = ax.hexbin(
            electrical_sample["output_va_calculated"],
            electrical_sample["outva_a"],
            gridsize=65,
            bins="log",
            mincnt=1,
            cmap="cividis",
        )
        maximum = float(
            max(
                electrical_sample["output_va_calculated"].max(),
                electrical_sample["outva_a"].max(),
            )
        )
        ax.plot([0, maximum], [0, maximum], color="#D62728", lw=1.2, ls="--")
        ax.set(
            xlabel=r"Calculated $V_{AC}I_{AC}$ (VA)",
            ylabel="Reported apparent power (VA)",
        )
        fig.colorbar(hb, ax=ax, label="log count", shrink=0.75)
        if title:
            ax.set_title(title)

    def plot_missingness(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        sns.stripplot(
            data=null_plot_df,
            x="null_rate",
            y="table",
            order=table_order,
            hue="table",
            palette="colorblind",
            jitter=0.24,
            size=3.1,
            alpha=0.68,
            linewidth=0,
            legend=False,
            ax=ax,
        )
        for y, table in enumerate(table_order):
            ax.scatter(
                medians[table],
                y,
                marker="|",
                s=110,
                linewidth=1.5,
                color="#111827",
                zorder=4,
            )
        ax.set_xscale("symlog", base=10, linthresh=1e-4, linscale=0.5)
        ax.set_xlim(-1e-5, 1.05)
        ax.set_xticks([0, 1e-4, 1e-3, 1e-2, 1e-1, 1])
        ax.set_xticklabels(["0", "0.01%", "0.1%", "1%", "10%", "100%"])
        ax.set_ylabel("")
        ax.set_xlabel("Per-column NULL fraction")
        if title:
            ax.set_title(title)

    def plot_image_alignment(fig: plt.Figure, ax: plt.Axes, title: str | None = None) -> None:
        if not brightness.empty:
            pv_colour = brightness["pv_power_w"].clip(lower=0, upper=1000)
            scatter = ax.scatter(
                brightness["solar_elevation"],
                brightness["brightness"],
                c=pv_colour,
                cmap="plasma",
                norm=PowerNorm(gamma=0.55, vmin=0, vmax=1000),
                s=13,
                alpha=0.75,
                linewidths=0,
            )
            ax.axvline(0, color="#6B7280", ls="--", lw=1)
            ax.set(
                xlabel="Calculated solar elevation (degrees)",
                ylabel="Mean image brightness",
            )
            cbar = fig.colorbar(
                scatter,
                ax=ax,
                label="PV power (W; max 1 kW)",
                shrink=0.75,
            )
            cbar.set_ticks([0, 250, 500, 750, 1000])
        else:
            ax.text(0.5, 0.5, "Image brightness check not run", ha="center", va="center")
            ax.set_axis_off()
        if title:
            ax.set_title(title)

    panels = [
        ("a_coverage", "Daily usable coverage", plot_coverage),
        ("b_intervals", "Inter-reading intervals", plot_intervals),
        ("c_pv_identity", "PV electrical identity", plot_pv_identity),
        ("d_ac_identity", "AC apparent-power identity", plot_ac_identity),
        ("e_missingness", "Missingness after release pruning", plot_missingness),
        ("f_image_alignment", "Image and electrical alignment", plot_image_alignment),
    ]

    for suffix, _, drawer in panels:
        fig, ax = plt.subplots(figsize=(3.25, 2.25), constrained_layout=True)
        drawer(fig, ax, None)
        save_figure(fig, output_stem.with_name(f"{output_stem.name}_{suffix}"))

    fig, axes = plt.subplots(2, 3, figsize=(14.2, 8.2), constrained_layout=True)
    for ax, (_, title, drawer), letter in zip(
        axes.ravel(), panels, ("A", "B", "C", "D", "E", "F")
    ):
        drawer(fig, ax, f"{letter}  {title}")
    fig.suptitle(
        "OpenCEM release validation",
        x=0.01, ha="left", fontsize=16, fontweight="bold"
    )
    save_figure(fig, output_stem)


def tex_escape(value: str) -> str:
    return value.replace("_", r"\_")


def write_latex_outputs(results: dict, manuscript_dir: Path) -> None:
    generated = manuscript_dir / "generated"
    generated.mkdir(parents=True, exist_ok=True)
    tables = results["database"]["tables"]
    cadence = results["temporal"]["analog_cadence"]
    electrical = results["electrical"]["internal_checks"]
    images = results["images"]
    context = results["context"]
    calibrated = results["calibrated_timestamps"]
    daily_energy = results["electrical"]["daily_pv_energy_comparison"]
    measurement_rows = sum(tables[table]["rows"] for table in MEASUREMENT_TABLES)
    measurement_columns = sum(
        tables[table]["data_columns"] for table in MEASUREMENT_TABLES
    )
    total_rows = measurement_rows + tables["context"]["rows"]
    duplicate_keys = sum(tables[table]["duplicate_keys"] for table in MEASUREMENT_TABLES)
    invalid_json = sum(tables[table]["invalid_json_text_values"] for table in TABLES)
    soc_outside = sum(electrical[str(i)]["soc_outside"] for i in (1, 2))
    frequency_outside = sum(
        electrical[str(i)]["output_frequency_outside"]
        + electrical[str(i)]["grid_frequency_outside"]
        for i in (1, 2)
    )
    negative_pv = sum(electrical[str(i)]["negative_pv_power"] for i in (1, 2))
    macros = {
        "ValidationMeasurementRows": f"{measurement_rows:,}",
        "ValidationMeasurementColumns": f"{measurement_columns:,}",
        "ValidationTotalRows": f"{total_rows:,}",
        "ValidationContextRows": f"{tables['context']['rows']:,}",
        "ValidationArtifactSizeGiB": f"{results['database']['size_bytes'] / 2**30:.2f}",
        "ValidationElectricalStart": tables["analog_measurements"]["start_local"],
        "ValidationElectricalEnd": tables["analog_measurements"]["end_local"],
        "ValidationImageStart": images["start_display"],
        "ValidationImageEnd": images["end_display"],
        "ValidationImageFrames": f"{images['files']:,}",
        "ValidationImageWidth": f"{images['documented_dimensions'][0]:,}",
        "ValidationImageHeight": f"{images['documented_dimensions'][1]:,}",
        "ValidationImagePrivacyRemoved": (
            f"{images['privacy_removed_total']:,}"
            if images["privacy_removed_total"] is not None else "--"
        ),
        "ValidationImageDecodeFailures": f"{images['decode_failures']:,}",
        "ValidationImageDimensionMismatches": f"{images['dimension_mismatches']:,}",
        "ValidationImageTimestampDuplicates": f"{images['duplicate_timestamps']:,}",
        "ValidationImageContentDuplicates": f"{images['duplicate_contents']:,}",
        "ValidationContextTypes": f"{context['context_types']:,}",
        "ValidationDuplicateMeasurementKeys": f"{duplicate_keys:,}",
        "ValidationInvalidJsonValues": f"{invalid_json:,}",
        "ValidationAnalogOneMedian": f"{cadence['1']['median_seconds']:.1f}",
        "ValidationAnalogTwoMedian": f"{cadence['2']['median_seconds']:.1f}",
        "ValidationAnalogOnePninetyfive": f"{cadence['1']['p95_seconds']:.1f}",
        "ValidationAnalogTwoPninetyfive": f"{cadence['2']['p95_seconds']:.1f}",
        "ValidationPVOneMAPE": f"{electrical['1']['pv_mape_percent']:.2f}",
        "ValidationPVTwoMAPE": f"{electrical['2']['pv_mape_percent']:.2f}",
        "ValidationPVOneWithinTen": f"{electrical['1']['pv_within_10_percent']:.2f}",
        "ValidationPVTwoWithinTen": f"{electrical['2']['pv_within_10_percent']:.2f}",
        "ValidationVAOneMAPE": f"{electrical['1']['output_va_mape_percent']:.2f}",
        "ValidationVATwoMAPE": f"{electrical['2']['output_va_mape_percent']:.2f}",
        "ValidationEnergyOneMAPE": f"{daily_energy['1']['mape_percent']:.2f}",
        "ValidationEnergyTwoMAPE": f"{daily_energy['2']['mape_percent']:.2f}",
        "ValidationTemperatureOneSentinelPercent": (
            f"{electrical['1']['rows_with_temperature_120'] / electrical['1']['rows'] * 100:.2f}"
        ),
        "ValidationTemperatureTwoSentinelPercent": (
            f"{electrical['2']['rows_with_temperature_120'] / electrical['2']['rows'] * 100:.2f}"
        ),
        "ValidationSocOutOfRange": f"{soc_outside:,}",
        "ValidationFrequencyOutOfRange": f"{frequency_outside:,}",
        "ValidationNegativePVPower": f"{negative_pv:,}",
        "ValidationContextMissingType": f"{context['missing_context_type']:,}",
        "ValidationFaultTimestampColumns": f"{calibrated['fault_timestamp_columns']:,}",
        "ValidationFaultDistinctPayloads": f"{calibrated['distinct_fault_payloads']:,}",
        "ValidationFaultConflictingPayloads": (
            f"{calibrated['fault_payloads_with_conflicting_times']:,}"
        ),
        "ValidationFaultEventsAfterObservation": (
            f"{calibrated['fault_events_more_than_5_minutes_after_observation']:,}"
        ),
        "ValidationImageExactMinutePercent": (
            f"{images['within_day_exact_60_second_fraction'] * 100:.2f}"
            if images["within_day_exact_60_second_fraction"] is not None else "--"
        ),
        "ValidationImageGapsOverMinute": f"{images['within_day_gaps_over_60_seconds']:,}",
        "ValidationImageMatchPercent": (
            f"{images['measurement_match_within_60_seconds_percent']:.1f}"
            if images["measurement_match_within_60_seconds_percent"] is not None else "--"
        ),
    }
    table_macro_prefixes = {
        "analog_measurements": "Analog",
        "status": "Status",
        "totals": "Totals",
        "settings": "Settings",
        "specs": "Specs",
        "statistics": "Statistics",
        "fault_history": "FaultHistory",
    }
    for table, prefix in table_macro_prefixes.items():
        item = tables[table]
        macros[f"Validation{prefix}Rows"] = f"{item['rows']:,}"
        macros[f"Validation{prefix}Columns"] = f"{item['data_columns']:,}"
        macros[f"Validation{prefix}StartDate"] = item["start_local"].split(",")[0]
        macros[f"Validation{prefix}EndDate"] = item["end_local"].split(",")[0]
    context_source_macros = {
        "workstation2_log": "ValidationContextWorkstationTwoRows",
        "workstation1_log": "ValidationContextWorkstationOneRows",
        "windows_event_log": "ValidationContextWindowsRows",
        "derived_context_pipeline": "ValidationContextDerivedRows",
        "wsl_bash_history": "ValidationContextWslRows",
        "manual entry": "ValidationContextManualRows",
        "manual_workload_entry": "ValidationContextManualWorkloadRows",
    }
    for source, macro in context_source_macros.items():
        macros[macro] = f"{context['rows_by_source'].get(source, 0):,}"
    macro_text = ["% Generated by technical_validation/validate_release.py"]
    for name, value in macros.items():
        macro_text.append(rf"\providecommand{{\{name}}}{{{value}}}")
    (generated / "validation_macros.tex").write_text(
        "\n".join(macro_text) + "\n", encoding="utf-8"
    )

    rows = []
    for table in TABLES:
        item = tables[table]
        rows.append(
            rf"\texttt{{{tex_escape(table)}}} & {item['rows']:,} & "
            rf"{item['data_columns']} & {item['start_local'].split(',')[0]} & "
            rf"{item['end_local'].split(',')[0]} & {item['duplicate_keys']:,} \\"
        )
    table_text = r"""% Generated by technical_validation/validate_release.py
\begin{table*}[htbp]
\centering
\scriptsize
\caption{\textbf{Integrity and temporal coverage of the SQLite validation snapshot.} Data-column counts exclude \texttt{read\_ts} and \texttt{inverter}; for \texttt{context}, they exclude only \texttt{id}. Dates use \texttt{Asia/Shanghai}.}
\label{tab:validation-integrity}
\begin{tabular}{lrrrrr}
\toprule
\textbf{Table} & \textbf{Rows} & \textbf{Data columns} & \textbf{Start} & \textbf{End} & \textbf{Duplicate keys} \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table*}
"""
    (generated / "validation_table.tex").write_text(table_text, encoding="utf-8")


def json_default(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot serialize {type(value)}")


def main() -> int:
    args = parse_args()
    if not args.database.exists():
        print(f"Database not found: {args.database}", file=sys.stderr)
        return 2
    args.results_dir.mkdir(parents=True, exist_ok=True)
    (args.manuscript_dir / "images").mkdir(parents=True, exist_ok=True)
    print("Opening SQLite release...", flush=True)
    connection = sqlite_connect(args.database)
    try:
        integrity = scalar(connection, "PRAGMA integrity_check")
        if integrity != "ok":
            raise RuntimeError(f"SQLite integrity check failed: {integrity}")
        tables, null_records = validate_tables(connection)
        print("Validating calibrated device and fault timestamps...", flush=True)
        calibrated_timestamps = validate_calibrated_timestamps(connection)
        print("Calculating cadence and gap statistics...", flush=True)
        cadence, electrical_daily = cadence_metrics(connection)
        print("Running electrical consistency checks...", flush=True)
        electrical, electrical_sample = electrical_checks(connection)
        energy = daily_energy_check(connection)
        print("Validating context records...", flush=True)
        context = validate_context(connection, args.sensitive_strings_file)
        print(f"Validating sky images under {args.image_root}...", flush=True)
        images, image_daily, brightness = validate_images(
            args.image_root,
            args.image_index,
            connection,
            args.brightness_sample,
            args.skip_image_content_check,
        )
        results = {
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "database": {
                "path": args.database.name,
                "size_bytes": args.database.stat().st_size,
                "sha256": file_sha256(args.database),
                "sqlite_version": sqlite3.sqlite_version,
                "integrity_check": integrity,
                "tables": tables,
            },
            "temporal": {"analog_cadence": cadence},
            "calibrated_timestamps": calibrated_timestamps,
            "electrical": {
                "internal_checks": electrical,
                "daily_pv_energy_comparison": energy,
            },
            "context": context,
            "images": images,
        }
        output_json = args.results_dir / "validation_results.json"
        output_json.write_text(
            json.dumps(results, indent=2, default=json_default) + "\n",
            encoding="utf-8",
        )
        pd.DataFrame(null_records).to_csv(
            args.results_dir / "column_null_rates.csv", index=False
        )
        electrical_daily.to_csv(
            args.results_dir / "electrical_daily_coverage.csv", index=False
        )
        image_daily.to_csv(args.results_dir / "image_daily_coverage.csv", index=False)
        brightness.to_csv(args.results_dir / "image_alignment_sample.csv", index=False)
        print("Rendering validation dashboard...", flush=True)
        dashboard_stem = args.manuscript_dir / "images" / "technical_validation_dashboard"
        build_dashboard(
            dashboard_stem,
            cadence,
            electrical_daily,
            image_daily,
            electrical_sample,
            null_records,
            brightness,
        )
        write_latex_outputs(results, args.manuscript_dir)
        print(f"Validation report: {output_json}", flush=True)
        print(f"Dashboard: {dashboard_stem.with_suffix('.pdf')}", flush=True)
    finally:
        connection.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
