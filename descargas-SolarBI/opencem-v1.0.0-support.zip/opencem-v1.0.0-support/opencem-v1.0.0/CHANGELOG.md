# Changelog

## 1.0.0

- Published as *OpenCEM: Multimodal photovoltaic and battery microgrid dataset
  with context records and sky imagery* under DOI
  `10.5281/zenodo.21436223`.
- Initial frozen one-year electrical release for two PV-battery inverter systems.
- Seven inverter tables with processed physical values, device state, settings,
  specifications, statistics, and original fault arrays.
- Calibrated device-clock and historical fault-event timestamps; distinct fault
  payloads retain their event time across later inverter clock changes.
- Privacy-reviewed interval context with availability timestamps.
- Retained one-minute 1920 by 1920 upward-facing sky images.
- Modality-specific endpoints retain the complete reviewed image archive even
  though it extends beyond the electrical endpoint.
- Included the installable local-video processing package used for overlay
  timestamp indexing, one-pass full-minute extraction, and privacy review.
- Schema, complete column dictionary, validation results, manifests,
  reproducibility utilities, and dataset-backed simulator.
- Sanitized acquisition script retaining the recorder's actual polling,
  timeout, delay, carry-forward, and snapshot-writing behavior.
